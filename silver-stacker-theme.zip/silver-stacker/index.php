<?php
/**
 * Fallback template. Normal WordPress pages are never shown publicly: the portal plugin redirects
 * every request to /login or /portal. This file only renders if the plugin is inactive.
 */
defined( 'ABSPATH' ) || exit;
status_header( 503 );
?><!doctype html><html><head><meta charset="utf-8"><meta name="robots" content="noindex"><title>Silver Stacker</title></head>
<body style="font-family:Roboto,Arial,sans-serif;text-align:center;padding:60px">
<h1>Silver Stacker Pre-Sale Portal</h1><p>The portal is temporarily unavailable.</p></body></html>
