<?php
/**
 * Silver Stacker theme. Intentionally minimal: the plugin owns routing, access control and templates.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
} );
