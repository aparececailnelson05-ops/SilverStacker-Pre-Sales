# Testing

Three automated suites cover the Version 1 acceptance criteria (REV2 §17 and Master Prompt §26). The last run was on WordPress 6.9.9, PHP 8.4 and MariaDB 10.11, with 12,000 archived products seeded.

| Suite | How to run | Result |
|---|---|---|
| Functional acceptance (domain and database, simulated QuickBooks and Google APIs, 8 parallel processes for the concurrency test) | `wp eval-file wp-content/plugins/silver-stacker-portal/tests/acceptance.php` | **94 passed, 0 failed** |
| Browser E2E: visitor privacy, registration wizard, approval, terms gate, ordering, isolation, Ship My Box, mobile | `tests/e2e`: `node e2e.js` | **35 passed, 0 failed** |
| Browser E2E: staff console (approval, product creation with image, tracker availability, invoice, box shipping, CSV export) | `tests/e2e`: `node staff.js` | **9 passed, 0 failed** |
| Smoke: every staff screen renders without PHP errors | `tests/e2e`: `node admin.js` | **26/26 screens OK** |

Run all of these on **staging only**. They create customers, products and orders.

## Archive search performance (12,000 archived records)

| Query | Matches | Server time |
|---|---|---|
| `kangaroo` (Archive tab) | 800 | 48 ms |
| `ARC-009912` (SKU) | 1 | 44 ms |
| `700000005123` (barcode) | 1 | 42 ms |
| `silver coin` + Silver filter | 3,001 | 65 ms |
| `perth`, page 40 | 1,201 | 39 ms |

Each request also computes the result counts for both tabs (Active Items and The Archive).

## External services

Real QuickBooks, Google and SMTP accounts were not available while this was built. In the tests:

- QuickBooks and Google Sheets are simulated at the HTTP layer, so the real request and response handling code runs.
- Email jobs fail without SMTP, and they show as retryable in Integrations.

Before go-live, run the QuickBooks sandbox steps in DEPLOYMENT.md §7.

## Latest results

### Functional acceptance
```
    AT-01..04 Registration, approval, terms gate
      PASS Two individual accounts register (same company name allowed)
      PASS New account is Pending approval
      PASS Pending customer cannot view catalog
      PASS Duplicate email rejected
      PASS Invalid transition pending -> suspended blocked
      PASS Rejection requires a reason
      PASS Staff approves customers
      PASS Approval email queued
      PASS Approved but terms not accepted: still no catalog
      PASS After accepting terms: catalog visible
      PASS Acceptance recorded with customer, version, timestamp
    AT-05..07 Catalog, search, ETA, countdown
      PASS Search by name finds product in Active Items
      PASS Search by SKU
      PASS Search by barcode
      PASS Archive tab count returned alongside
      PASS ETA label shown
      PASS Presale with future closing is orderable
    AT-08..10 Pre-order, allocation, history
      PASS Below minimum quantity is blocked
      PASS Above per-customer allocation is blocked with clear message
      PASS Valid pre-order submitted without payment
      PASS Double-submit with same key returns same order (idempotent)
      PASS Allocation decreased correctly (4 reserved, 6 remaining)
      PASS Order number assigned
      PASS Order history searchable by item name
      PASS Customer B cannot load customer A's order (same company name)
      PASS Customer B cannot load A's order line by ID
      PASS Customer B cannot change A's line
      PASS Line chosen "Add to My Box" is in A's open box
      PASS Concurrent orders never oversell (reserved 6 of 6, 2 winners)
      PASS Reserved counter matches order lines after race
    AT-51 Waitlist and override
      PASS Fully allocated item offers waitlist entry
      PASS Winner decreases before close (allocation released)
      PASS Released allocation held for the waitlisted customer (hold mode)
      PASS Held quantity counted against allocation
      PASS Others cannot take held allocation
      PASS Waitlist offer accepted and converted to a pre-order
      PASS Hold consumed; reserved back to full allocation (6)
      PASS Staff override recorded
      PASS Override logged with staff, time, quantity, reason
      PASS Override without reason refused
    AT-52 Amend before close, lock after close
      PASS Increase within limits accepted
      PASS Increase over per-customer limit refused
      PASS Decrease accepted
      PASS Allocation recalculated (5 reserved)
      PASS ETA update reflects everywhere; original order snapshot unchanged
      PASS Countdown at zero: presale ended immediately (server clock)
      PASS New orders blocked after closing
      PASS Customer cannot edit after closing (line locked)
      PASS Line status Locked
      PASS Staff correction after close allowed with reason
      PASS Staff correction without reason refused
    AT-11/12/53 Line availability (partial)
      PASS Staff marks part of a line available
      PASS Customer sees Partially available
      PASS Availability above ordered refused
    AT-13..17/55/56 Box: multiple orders, shipment request, shipping
      PASS Eligible item from a second order added to My Box
      PASS Box holds lines from 2 different orders with original order references
      PASS Default shipping address assigned to box
      PASS Customer requests box shipment
      PASS Items ordered after a shipment request go to a new open box (one open box at a time)
      PASS Requested box keeps its contents; only one box is open
      PASS Staff records tier, carrier and tracking; box shipped
      PASS Shipment preserves which lines were included (2 lines)
      PASS Partially shipped line carried into the open box for the remainder
      PASS Box status Shipped with rate tier recorded
    AT-18/54 QuickBooks invoice (simulated QBO), idempotent retry
      PASS Staff selects available, uninvoiced lines (2)
      PASS QBO failure: invoice in Error state with actionable message (QuickBooks error: Service unavailable:  (code 503))
      PASS Failed QBO action did NOT mark lines invoiced
      PASS Lines held as pending so they cannot be double-selected
      PASS Repeating the same staff action returns the same invoice (no duplicate)
      PASS Retry succeeded: QBO invoice number/ID stored
      PASS Both attempts used the same QBO requestid (idempotent at QuickBooks)
      PASS Pay link, due date and amount due retrieved
      PASS Invoice linked to the correct lines at line level
      PASS Not shown as paid until QBO confirms
      PASS Signed QBO webhook accepted
      PASS Forged webhook signature rejected
      PASS Payment status synchronized back automatically (Paid)
      PASS Duplicate webhook delivery ignored
    AT-19/57 Google Sheets one-way copy (simulated API)
      PASS Sheet holds exactly one row per stable line ID after repeated events
      PASS Second event updated the row in place (PUT), not appended
      PASS Row reflects latest quantity
    AT-20/58 Warehouse event idempotency
      PASS Warehouse availability event updates the correct line
      PASS Repeated warehouse event ignored (no double counting)
    AT-22 Archive
      PASS Closed product moved to The Archive tab, out of Active
      PASS Archived listing not orderable
      PASS Product with history cannot be deleted
      PASS Permanent link (product UID) still resolves
    Audit trail
      PASS Audit log contains allocation.override
      PASS Audit log contains line.availability_changed
      PASS Audit log contains line.qty_changed
      PASS Audit log contains box.shipped
      PASS Audit log contains invoice.synced
      PASS Audit log contains customer.status_changed
      PASS Audit log contains product.eta_changed
    Result: 94 passed, 0 failed
```

### Browser E2E (customer)
```
      PASS visitor /portal/shop/ -> login
      PASS no product names or prices on /portal/shop/
      PASS visitor /portal/search/?q=silver -> login
      PASS no product names or prices on /portal/search/?q=silver
      PASS visitor /portal/archive/ -> login
      PASS no product names or prices on /portal/archive/
      PASS visitor /?s=silver -> login
      PASS no product names or prices on /?s=silver
      PASS visitor /?post_type=attachment -> login
      PASS no product names or prices on /?post_type=attachment
      PASS visitor cannot fetch product image via portal media URL
      PASS private upload folder blocked (403)
      PASS catalog REST requires login
      PASS users REST blocked
      PASS registration submitted
      PASS pending customer sees account status only
      PASS pending customer blocked from shop
      PASS approved customer forced to Terms first
      PASS cannot continue without ticking agreement
      PASS after accepting terms: dashboard
      PASS search tabs shown
      PASS live countdown on search results: 3 Days 10:59:28
      PASS product shows ETA
      PASS cart count updated
      PASS review page
      PASS confirmation page after Submit Pre-Order
      PASS order in history, searchable by item
      PASS item in My Box with original order number
      PASS cannot open another customer's order (same company name)
      PASS confirmation required before shipment request
      PASS shipment requested
      PASS mobile /portal/ has no horizontal scroll (390px)
      PASS mobile /portal/shop/ has no horizontal scroll (390px)
      PASS mobile /portal/orders/15009/ has no horizontal scroll (390px)
      PASS mobile /portal/box/ has no horizontal scroll (390px)
```

### Browser E2E (staff)
```
      PASS Staff approves pending registration in UI
      PASS Product created
      PASS Image uploaded privately
      PASS Published as presale
      PASS ETA month shown
      PASS Tracker bulk availability saved: 9 line(s) updated.Dismiss this notice.
      PASS Invoice recorded and linked: Invoice M-97204 created and linked to the selected lines.Dismiss this notice.
      PASS Box shipping: Box shipped and tracking recorded. The customer has been notified.Dismiss this notice.
      PASS Report CSV export
```
