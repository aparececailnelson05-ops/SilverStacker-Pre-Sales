# Silver Stacker LLC Private Pre-Sale Portal
## Phase 0 Analysis: Requirements, Architecture, Data Model, Page Map, Roles, Phases, Open Decisions

**Prepared:** October 1, 2026
**Inputs analyzed:**
- **[REV2]** Functional Specification, WordPress Pre-Sales Portal, Version 1 Revision 2 (Aug 13, 2026). Primary source of truth.
- **[ORIG]** Silver Stacker LLC Pre-Sale Portal/Website Site Structure Spec. Used for branding, layout, sign-up questions, T&C text, admin screen references, Pre-Sale Tracker, and reports.
- **[MP]** Master Website Development Prompt (sections 1 to 26 + Final Instruction).

**Conflict rule applied:** REV2 wins on function. ORIG is kept for visual design and any detail REV2 does not address. Every conflict is listed in Section 3 with the resolution used.

**Status:** Analysis only. No code has been written. Coding starts at Phase 1 after this document is reviewed.

---

## Table of contents

1. Requirements checklist (traceability matrix)
2. Key interpretations
3. Conflicts between the documents
4. Proposed WordPress architecture
5. WordPress / WooCommerce vs custom development
6. Roles and capabilities matrix
7. Data model
8. Product / order / allocation / box / invoice / shipment relationships
9. Status models and transitions
10. Page map (customer portal)
11. Staff / admin screens
12. API and integration architecture
13. Security and privacy design
14. Unresolved business decisions
15. Implementation phases and sequence
16. Acceptance test plan
17. Assets and access needed from Silver Stacker

---

## 1. Requirements checklist (traceability matrix)

Legend for **Layer**: P = customer page, S = staff screen, B = backend service, M = data model, I = integration, R = role/permission.
Phase numbers refer to Section 15.

### 1.1 Scope and boundaries

| ID | Requirement | Source | Layer | Where it lives | Phase |
|---|---|---|---|---|---|
| SC-01 | Brand-new portal, no OrderSpace account/order migration | REV2 §2.1, §18.60 | B | No migration tooling built | 1 |
| SC-02 | Registration, staff approval and login required before any catalog content | REV2 §2.2, MP §2 | R, B | Access Gate (13.1) | 1 |
| SC-03 | Every customer has an individual account, never shared | REV2 §2.3, §4.1.11, §18.63 | M, R | `wp_users` + `ss_customer_profiles` (1 user = 1 customer) | 1 |
| SC-04 | Orders, invoices, addresses, waitlists, box private to the account | REV2 §2.4, §16.40 | B, R | Ownership Guard on every query | 1 |
| SC-05 | All orders must be submitted through the website | REV2 §2.5, §12.34 | B | No staff "create order on behalf" in V1 (see D-18) | 3 |
| SC-06 | All sales reps see every customer and pre-order | REV2 §2.6, §3, §18.67 | R | `ss_sales_rep` caps are global | 1 |
| SC-07 | No payment collected in WordPress | REV2 §2.7, §18.62, MP §10 | B | "Submit Pre-Order" has no payment step | 3 |
| SC-08 | USD only; QuickBooks calculates tax | REV2 §2.8 | M, I | DECIMAL(12,2) USD fields; tax only in QBO | 2, 6 |
| SC-09 | Downloads/sales materials staff-only | REV2 §2.9, §5.1.26, §18.66 | S, R | Staff Resources (protected files) | 9 |

### 1.2 Accounts, registration, terms

| ID | Requirement | Source | Layer | Where it lives | Phase |
|---|---|---|---|---|---|
| AC-01 | Fields: contact name, email, phone, company/store, billing address, shipping address, password | REV2 §4.1.10, MP §3 | P, M | `/register` steps 1 and 2; `ss_customer_profiles`, `ss_addresses` | 1 |
| AC-02 | Company name is profile info only, no shared login | REV2 §4.1.11 | M | Plain text column, no company entity | 1 |
| AC-03 | 8 qualification/trust questions stored for staff review | ORIG p.2-3, MP §3 | P, M, S | `/register` step 3; `ss_signup_questions`, `ss_signup_answers`; Customer detail | 1 |
| AC-04 | Account states Pending → Approved → Rejected/Suspended | REV2 §15, MP §2 | M, B | `ss_customer_profiles.status` + state machine (9.1) | 1 |
| AC-05 | Approval/rejection email (approval includes secure login link + next steps) | REV2 §4.1.13, §13 | B | Notification service, templates | 1 |
| AC-06 | No catalog or price data before approval | REV2 §4.1.14, §17.44 | R | Access Gate + private media | 1 |
| AC-07 | T&C shown on first approved access, checkbox required, block until accepted | ORIG p.2, MP §4 | P, B | `/portal/terms` gate middleware | 1 |
| AC-08 | Record acceptance with customer ID, timestamp, terms version | MP §4 | M | `ss_terms_versions`, `ss_terms_acceptances` | 1 |
| AC-09 | Multiple saved shipping addresses, one default | REV2 §4.2.17 | P, M | `/portal/addresses`; `ss_addresses.is_default` | 1 |
| AC-10 | Default shipping address auto-assigned to box | REV2 §4.2.18, §8.2.19 | B | Box service snapshot on create/request | 5 |
| AC-11 | Staff: review registrations, approve/reject, view contact/company/addresses, maintain status | REV2 §9 | S | Staff › Customers | 1 |
| AC-12 | Staff can deactivate a customer account | ORIG p.4 | S, B | "Suspend" action, kills active sessions | 1 |
| AC-13 | Customer detail shows contact, created, last login, phone, payment terms, shipping/billing, sign-up answers | ORIG p.4 | S | Customer detail page | 1 |
| AC-14 | Customer list: name/company, primary contact, created, last order date, status, search, export | ORIG p.3-4 | S | Customers list | 1 |
| AC-15 | Password recovery for visitors | REV2 §3 | P | WP core reset flow, branded | 1 |

### 1.3 Catalog, ETA, countdown, search, archive

| ID | Requirement | Source | Layer | Where it lives | Phase |
|---|---|---|---|---|---|
| CA-01 | Catalog only for logged-in approved customers and staff | REV2 §5.1.21 | R | Access Gate | 2 |
| CA-02 | Listing shows Presale vs In Stock and whether orderable now | REV2 §5.1.22 | P | Product card badge + order control state | 2 |
| CA-03 | Search/filter by name, SKU, barcode, brand, category, lifecycle, variations | REV2 §5.1.23, MP §9 | P, B, M | `ss_product_search` index | 2 |
| CA-04 | Multiple images and variations (size/color) | REV2 §5.1.24 | P, M | `ss_product_images`, `ss_product_variants` | 2 |
| CA-05 | Swipeable image gallery on product detail | ORIG p.2 | P | Touch gallery component | 2 |
| CA-06 | Same staff-controlled USD price for all approved customers | REV2 §5.1.25, §18.64 | M | `ss_product_variants.price_usd` (no price lists) | 2 |
| CA-07 | Product fields: name, SKU, barcode, brand, category, description/specs, primary + gallery images, variations, mintage, USD price, lifecycle, presale/in-stock, closing date, ETA, min qty, total allocation, per-customer allocation, supplier, availability | REV2 §5.5, MP §6 | M, S | Product editor tabs | 2 |
| CA-08 | Metal categories Silver, Gold, Copper, Platinum (staff-editable) | ORIG p.4-5, MP §6 | M | `ss_metal` taxonomy, seeded | 2 |
| CA-09 | ETA admin-editable; date, date range, month, or free text; "estimate, not guarantee" | MP §7, REV2 §5.5 | M, S | ETA fields on product (variant override optional) | 2 |
| CA-10 | ETA shown on cards, product page, order details, order history, My Box, staff order screens, tracker | MP §7 | P, S | Shared `EtaFormatter` + template partial | 2-5 |
| CA-11 | ETA change does not modify the original order; all views show current ETA | MP §7 | B, M | ETA read live from product; `eta_at_order` snapshot kept for history only | 2 |
| CA-12 | Live countdown on cards, search results, product page | REV2 §5.4, MP §8 | P | Countdown component driven by server UTC timestamp | 2 |
| CA-13 | At zero: block new orders and qty increases, show "Pre-Sale Ended", keep data | REV2 §5.4, MP §8 | B | Server-side validation uses server clock, not JS | 2, 3 |
| CA-14 | Search results in two tabs: Active Items, The Archive | REV2 §5.2.27 | P | `/portal/search?tab=` | 2 |
| CA-15 | Query preserved between tabs, count per tab | REV2 §5.2.30 | P, B | Both counts computed in one request | 2 |
| CA-16 | Indexed search + pagination, responsive with 10,000+ archive records | REV2 §5.2.31, §17.47 | B, M | FULLTEXT + B-tree indexes, keyset pagination, perf test with 12k seed | 2 |
| CA-17 | Archive = every item previously offered; name, mintage, photos | REV2 §5.3.32-33 | M, P | Lifecycle `archived` + archive page template | 2 |
| CA-18 | Archive listings expandable later without changing permanent links | REV2 §5.3.34 | M | Permanent URL `/portal/p/{product_uid}/{slug}` | 2 |
| CA-19 | Items leaving active sale keep their listing, never deleted | REV2 §5.3.35, MP §9 | B | Soft lifecycle change; hard delete disabled for products with history | 2 |
| CA-20 | Archived items visible, not orderable unless staff reactivates | REV2 §5.3.36 | B | Lifecycle transition rules | 2 |
| CA-21 | Archive bulk import (source TBD) | REV2 §19 | S, B | CSV importer (Phase 2), mapping finalized when source known | 2 |
| CA-22 | Pre-sale announcement banner text below header | ORIG p.2 | P, S | Setting: editable announcement | 2 |
| CA-23 | Staff product list: name, SKU, category, price, status, search, status/category filters, export, new product | ORIG p.4 | S | Staff › Products | 2 |
| CA-24 | Product editor tabs Details, Variants, Pricing, Inventory, Images (rich-text description, image upload/reorder/delete) | ORIG p.4-5 | S | Product editor | 2 |

### 1.4 Ordering, allocation, waitlist, amendments

| ID | Requirement | Source | Layer | Where it lives | Phase |
|---|---|---|---|---|---|
| OR-01 | Flow: product → qty → fulfillment choice → submit | REV2 §6.1, MP §10 | P | Cart → Review → Submit | 3 |
| OR-02 | Validate closing date, min qty, total allocation, per-customer allocation, product status | REV2 §6.1.2, MP §10 | B | `AllocationService::reserve()` inside DB transaction | 3 |
| OR-03 | Fulfillment choice per item: add to open box, ship separately, decide later | REV2 §6.1.3, §8.2.17 | P, M | `ss_order_lines.fulfillment_choice` | 3 |
| OR-04 | Submit without payment; order number assigned; allocation reserved | REV2 §6.1.4 | B | `OrderService::submit()` | 3 |
| OR-05 | Order and lines appear in customer history, staff dashboard, Google Sheets | REV2 §6.1.5 | P, S, I | Event `order.submitted` | 3, 7 |
| OR-06 | On-screen confirmation | MP §10 | P | `/portal/orders/{no}/confirmation` | 3 |
| OR-07 | Enforce total + per-customer allocation; block when full | REV2 §6.2.6-7 | B | Row-locked allocation check | 3 |
| OR-08 | Offer waitlist when allocation unavailable | REV2 §6.2.8, MP §15 | P, M | `ss_waitlist` | 3 |
| OR-09 | Staff override of allocation limits, logged with staff, time, qty, reason | REV2 §6.2.9, MP §15 | S, M | `ss_allocation_overrides` + audit | 3 |
| OR-10 | Email waitlisted customers when allocation becomes available | REV2 §6.2.10, §13 | B | Waitlist promotion job | 3 |
| OR-11 | Customers edit qty until closing date; decrease releases; increase re-validated | REV2 §6.3, §17.52 | P, B | Order detail inline edit | 3 |
| OR-12 | After closing, line locked; staff corrections with audit record | REV2 §6.3 | S, B | Staff line correction with reason | 3 |
| OR-13 | Cart is not the box | MP §13 | M | Separate `ss_cart_items` and `ss_box_items` | 3 |
| OR-14 | Customer note on order | ORIG p.7 (tracker column) | P, M | `ss_orders.customer_note` | 3 |
| OR-15 | Invalid quantities/closed products blocked with clear messages | REV2 §17.49 | P, B | Validation error codes → friendly messages | 3 |
| OR-16 | Never trust browser-supplied IDs | MP §22 | B | Ownership Guard | 1+ |

### 1.5 Availability, invoicing, order history

| ID | Requirement | Source | Layer | Where it lives | Phase |
|---|---|---|---|---|---|
| AV-01 | Availability at order-line level, partial availability supported | REV2 §7.1, §17.53 | M, S | `ss_order_lines.qty_available` | 4 |
| AV-02 | Availability changes update portal + Sheets | REV2 §7.1 | B, I | Event `line.availability_changed` | 4, 7 |
| AV-03 | Item can be invoiced before rest of order and before box ships | REV2 §7.1, §8.1 | B | Invoice eligibility independent of box | 6 |
| IN-01 | Staff selects available uninvoiced lines for one customer | REV2 §7.2.1, §17.53 | S | Staff › Invoices › New | 6 |
| IN-02 | Confirmation screen showing qty, price, order/box info | REV2 §7.2.2 | S | Invoice preview | 6 |
| IN-03 | Staff creates invoice in QBO; never automatic on a timer | REV2 §7.2.3 | I | `QboInvoiceJob` triggered by staff action only | 6 |
| IN-04 | QBO calculates tax, emails invoice, payment method, financial record | REV2 §7.2.4, §10 | I | QBO settings (AST, online payments) | 6 |
| IN-05 | Store QBO customer + invoice IDs; retrieve number, date, total, due, due date, payment status, pay link, PDF | REV2 §7.2.5 | M, I | `ss_invoices`, `ss_integration_map` | 6 |
| IN-06 | Item arrived/invoiced notification; line-level invoice relationship | REV2 §7.2.6, §13 | B, M | `ss_invoice_lines` + notification | 6 |
| IN-07 | Failed QBO action never marks lines invoiced | REV2 §10.21 | B | Two-phase commit pattern (12.2) | 6 |
| IN-08 | Idempotent retries, no duplicate invoices | REV2 §10.22 | B, I | Idempotency key + QBO `requestid` | 6 |
| IN-09 | Actionable integration errors + safe retry | REV2 §10.23 | S | Integrations › Job queue | 6 |
| IN-10 | Payment status syncs back automatically | REV2 §10.24 | I | QBO webhooks + scheduled CDC poll | 6 |
| OH-01 | Order history newest first, search by item name, basic filters | REV2 §7.3.7-8 | P | `/portal/orders` | 3 |
| OH-02 | Item name/image links to active listing or permanent archive listing | REV2 §7.3.9-10, §17.50 | P | Permanent product URL resolves by lifecycle | 3 |
| OH-03 | Show order no, date, fulfillment choice, lines, ordered/available/invoiced qty, line status, ETA, totals | REV2 §7.3.11, MP §14 | P | Order detail | 3-6 |
| OH-04 | Show linked QBO invoice details incl. view/pay link and PDF | REV2 §7.3.12 | P | Order detail + `/portal/invoices` | 6 |
| OH-05 | Show whether each line is in box, separate shipment, or awaiting decision | REV2 §7.3.14 | P | Fulfillment column | 5 |

### 1.6 Box and shipping

| ID | Requirement | Source | Layer | Where it lives | Phase |
|---|---|---|---|---|---|
| BX-01 | Add to Box is a fulfillment option, not a cart action | REV2 §8.1, MP §11, §13 | M | `ss_boxes`, `ss_box_items` | 5 |
| BX-02 | Items from multiple orders in one open box, keeping source order + invoice refs | REV2 §8.2.16, §17.55 | M | `ss_box_items.order_line_id` | 5 |
| BX-03 | My Box page: image, name, SKU, order no, order date, qty, availability, ETA, invoice ref, payment status, fulfillment status, total items, address, box status, rate tier | REV2 §8.2.15, MP §12 | P | `/portal/box` | 5 |
| BX-04 | Customer and staff can trigger shipment request, with confirmation | REV2 §8.2.18, MP §12 | P, S | "Ship My Box" with confirm dialog | 5 |
| BX-05 | Box content change → customer email + Sheets update | REV2 §8.2.20, §13 | B, I | Debounced box digest email | 5, 7 |
| BX-06 | Staff records rate tier, charge, carrier, tracking, ship date, delivery state | REV2 §8.3, MP §12 | S, M | `ss_shipments` | 5 |
| BX-07 | Preserve which lines were in each shipment | REV2 §8.3 | M | `ss_shipment_lines` | 5 |
| BX-08 | Box lifecycle Open → Shipment Requested → Preparing → Shipped → Delivered → Closed; closed boxes kept | REV2 §15, MP §12 | M, B | State machine (9.6) | 5 |
| BX-09 | One active open box per customer, configurable | REV2 §19, MP §12 | B | Setting `max_open_boxes` (default 1) | 5 |
| BX-10 | Staff: view open boxes, move eligible lines, process requests, set tier, tracking | REV2 §9 | S | Staff › Boxes & Shipments | 5 |
| BX-11 | Fixed-rate shipping tiers by box size or weight (values TBD) | REV2 §8.3 | M, S | `ss_rate_tiers` (configurable) | 5 |

### 1.7 Staff operations, tracker, reports

| ID | Requirement | Source | Layer | Where it lives | Phase |
|---|---|---|---|---|---|
| ST-01 | Workspaces: Accounts, Catalog & Archive, Pre-orders, Allocation & Waitlist, Boxes & Shipments, Invoices, Staff Resources, Reports | REV2 §9 | S | Staff console | 1-9 |
| ST-02 | Plus: Dashboard, Pre-Sale Tracker, Integrations, Settings, Audit Log | MP §16 | S | Staff console | 1-9 |
| ST-03 | Admin header menu: Orders, Customers, Reports, Settings, Log Out (staff only); Cart (customer only); Search (both) | ORIG p.1 | P | Header partial | 1 |
| ST-04 | Orders list: order no, customer, date, total, status, search | ORIG p.3 | S | Staff › Orders | 3 |
| TR-01 | Active Product Master List: product, ETA, price, date posted, qty ordered from supplier, available qty, order-by date, status, supplier (editable) | ORIG p.7, MP §17 | S, M | Tracker tab 1 | 4 |
| TR-02 | Active Orders: per product, buyers with order date, order no, name, qty, unit price, total, qty available, close date, customer note, ETA | ORIG p.7 | S | Tracker tab 2 | 4 |
| TR-03 | Updating supplier qty / availability reflects in Active Orders "Qty Available" | ORIG p.7 | B | Live query, no copied data | 4 |
| TR-04 | Closed Orders: same data, products past close date awaiting arrival | ORIG p.7-8 | S | Tracker tab 3 (auto by closing date) | 4 |
| TR-05 | Ready to Invoice: received items, status dropdown (Invoiced, Cancelled, Invoice Updated) | ORIG p.8 | S | Tracker tab 4, linked to invoice flow | 4, 6 |
| RP-01 | Sales Summary by month: no. orders, total USD, date range, print, export | ORIG p.6 | S | Reports | 8 |
| RP-02 | Sales by Product: date range, category, sort (name, code, qty, A-Z, Z-A, date posted) | ORIG p.6 | S | Reports | 8 |
| RP-03 | Sales by Category with weekly/monthly/annual graph | ORIG p.6 | S | Reports | 8 |
| RP-04 | Sales by Customer with ranking per day/month/year by qty and by value | ORIG p.6 | S | Reports | 8 |
| RP-05 | Pre-orders by customer and by product incl. allocation, availability, invoice state | REV2 §14.35 | S | Reports | 8 |
| RP-06 | Open boxes and shipments incl. held items, address, request, tier, tracking, box age | REV2 §14.36 | S | Reports | 8 |
| RP-07 | Sales totals and product performance distinguishing Ordered / Invoiced / Paid | REV2 §14.37, MP §20 | S | Reports | 8 |
| RP-08 | Date, customer, product, category filters; sorting; on-screen totals; CSV export | REV2 §14, MP §20 | S | Shared report framework | 8 |
| RP-09 | Never show paid unless QBO confirms | REV2 §14, MP §20 | B | Paid measure only from QBO payment status | 8 |
| RP-10 | Data Export: Orders, Invoices, Customers, Products | ORIG p.7 | S | Reports › Data Export | 8 |

### 1.8 Integrations, notifications, audit, non-functional

| ID | Requirement | Source | Layer | Where it lives | Phase |
|---|---|---|---|---|---|
| QB-01 | Intuit OAuth 2.0, stable mappings customer/product/line ↔ QBO | REV2 §10 | I, M | `QboClient`, `ss_integration_map` | 6 |
| GS-01 | One-way export to one master Google Sheet; Sheet never updates portal | REV2 §11, MP §19 | I | `SheetsExporter` (write-only) | 7 |
| GS-02 | Tabs: Customers, Pre-order Lines, Allocations & Waitlists, Open Boxes (+ Shipments per MP) | REV2 §11.1, MP §19 | I | Tab schemas (12.3) | 7 |
| GS-03 | Sync on: order submit, qty/box change, status changes, availability/invoicing | REV2 §11.2 | B | Domain events → queue | 7 |
| GS-04 | Stable IDs, upsert in place, failed exports queued and visible, never block customer | REV2 §11.2 | I | Row map + retry queue | 7 |
| WH-01 | Send order lines, qty, customer refs, fulfillment choice, stable IDs to warehouse | REV2 §12.29 | I | `WarehouseAdapter` interface | 7 |
| WH-02 | Keep reserved/available/held/separate/shipped/cancelled qty in sync without double counting | REV2 §12.30 | B | Quantity buckets on line (7.4) | 7 |
| WH-03 | Return availability/fulfillment changes to WP | REV2 §12.31 | I | Inbound webhook endpoint | 7 |
| WH-04 | Idempotent events, retry queue, integration status view | REV2 §12.32-33 | I, S | Shared job queue | 7 |
| NT-01 | Emails: approved/rejected, waitlist available, item arrived & invoiced, box contents change | REV2 §13 | B | Notification service | 1, 3, 5, 6 |
| AU-01 | Log staff changes to prices, allocations, overrides, availability, quantities, fulfillment choices, boxes, shipments, invoice links | REV2 §16.38 | M | `ss_audit_log` (append-only) | 1+ |
| AU-02 | Role-based checks on every private page and operation | REV2 §16.39, MP §2, §22 | R | Capability checks + Access Gate | 1+ |
| AU-03 | Secure credential storage, HTTPS, least privilege, backups | REV2 §16.41, MP §22 | B | Encrypted options, host config | 0, 6 |
| AU-04 | Retryable, observable jobs, no duplicates | REV2 §16.42 | B | Job queue with idempotency keys | 0 |
| AU-05 | Consistent timezone, stable IDs | REV2 §16.43 | M | UTC storage, ULIDs | 0 |
| UX-01 | Branding: Blue #07067b, Red #b90c1c, Black #120f10, Roboto / Roboto Bold, logo, banner, body 11pt | ORIG p.1, MP §21 | P | Theme design tokens | 1, 9 |
| UX-02 | Modern, premium, responsive (desktop/tablet/mobile), fast, accessible (WCAG 2.2 AA target) | MP §21 | P | Theme + components | 1-9 |

---

## 2. Key interpretations

These are readings of the specs that shape the build. They are not new business rules.

1. **One sellable unit = one variant.** Every product has at least one variant. A product without size/color has one default variant. SKU, barcode, price, minimum, and allocations live on the variant, because REV2 says "for a product or variation" throughout.
2. **ETA and closing date live on the product,** with an optional per-variant override, because the ORIG tracker treats them per item.
3. **Order line status is several facts, not one.** REV2 lists line statuses (Reserved, Waitlisted, Locked, Available, Partially invoiced, Invoiced, Assigned to box, Separate shipment, Fulfilled, Cancelled) that mix four separate dimensions: allocation, availability, invoicing, and fulfillment. A line can be "Invoiced" and "Assigned to box" at the same time. The portal stores each dimension as quantities and flags, then derives the REV2 display label by a fixed precedence (Section 9.4). The REV2 labels stay exactly as written.
4. **Pre-order (order) status is derived from its lines,** never typed in by staff, so it cannot drift from reality.
5. **Cart = order draft.** The ORIG "Cart/Basket" with a checkout button becomes the customer's order draft. "Checkout" submits a pre-order with no payment.
6. **Spot-based offers** ($0.01 display price in ORIG Q7; "Spot + $34" in the tracker) need a price type. This is flagged as decision D-12 because invoicing them requires a final price rule.

---

## 3. Conflicts between the documents

| # | Topic | ORIG says | REV2 / MP says | Resolution used |
|---|---|---|---|---|
| C-1 | Customer groups and price lists | "Groups (Retail and Wholesale)", "Wholesale Price List", "Add Volume Discount", MSRP | One price for all approved customers; customer/group pricing excluded (§18.64) | **REV2.** No groups, no price lists, no volume discounts in V1. MSRP field optional, display-only, staff-only by default. See D-17. |
| C-2 | Checkout | Cart with "Checkout" button; Q8: "click the green checkout button… you will receive a confirmation" | No payment in WP | **REV2.** Button reads "Submit Pre-Order". Sign-up Q8 wording needs a small edit (D-15). |
| C-3 | Order confirmation email | Q8 promises "a confirmation" | Routine order submission not confirmed as an email trigger (§13) | On-screen confirmation always. Confirmation email built but **off by default**, toggle in Settings (D-15). |
| C-4 | Shipping charges | T&C: $6 Ground / $9 Priority billed with invoice; Build A Box flat $9 one-time paid with first item | Fixed rate by box-size or weight tier, values TBD; shipping invoice timing TBD | **REV2 model** (configurable tiers). ORIG amounts pre-loaded as **unconfirmed draft tiers** for review only (D-4, D-5). |
| C-5 | Product status | Active / Inactive, "Low Stock", "Out of Stock" | Presale, In Stock, Presale ended, Archived | **REV2 lifecycle.** "Low/Out of stock" shown as allocation indicators, not lifecycle. |
| C-6 | Closing date in title | "(08/03)" date written into product name | Dedicated pre-order closing date + countdown | **REV2 field.** Optional setting appends "(MM/DD)" to the displayed name automatically so customers keep the familiar format. |
| C-7 | Ready to Invoice status dropdown | Invoiced, Cancelled, Invoice Updated | Invoice sync statuses come from QBO | Tracker shows QBO-driven invoice status. "Cancelled" = cancel line (staff, with reason). "Invoice Updated" meaning needs confirmation (D-24). |
| C-8 | Add New Customer button | Staff can add customers | Each person registers separately | Staff "Invite Customer" creates a pending invite; the person completes their own registration, password and questions. Still individual (D-18). |
| C-9 | Text messages | Q4: invoice via email **and a text** | Notifications are email only | Store SMS consent answer. No SMS sending in V1 (D-16). |
| C-10 | Supplier qty vs allocation | "Quantity Ordered (to the supplier. Thus, this is the inventory available)" | Total allocation + warehouse authority TBD | Separate fields: `supplier_qty_ordered` (tracker) and `total_allocation` (ordering cap). Staff can link them with a "copy to allocation" action, never automatic (D-25). |
| C-11 | Reports filters | "Customer Group", "Preorder Window" filters | No groups | Customer Group filter dropped. "Preorder Window" mapped to lifecycle/closing-date filter. |
| C-12 | T&C timing | Show "first once they open the website" | Show on first approved access | Shown after login for approved customers; re-shown whenever a new terms version is published (D-21). |
| C-13 | Sign-up questions timing | "Shown right after they enter credentials" | Collected at registration | Registration step 3, right after account credentials (steps 1-2). Satisfies both. |

---

## 4. Proposed WordPress architecture

### 4.1 Overview

```
                       ┌───────────────────────────────────────────┐
  Browser (customer)   │  WordPress 6.x  (PHP 8.2+, MySQL 8 / MariaDB 10.6+) │
  Browser (staff)  ──► │                                           │
                       │  Theme: silver-stacker (presentation only)│
                       │  Plugin: silver-stacker-portal (all logic)│
                       │   ├─ Access Gate & Ownership Guard        │
                       │   ├─ Domain services (Accounts, Catalog,  │
                       │   │   Orders, Allocation, Waitlist, Box,  │
                       │   │   Shipments, Invoices, Reports)       │
                       │   ├─ REST API  /wp-json/ss/v1/*           │
                       │   ├─ Customer portal routes  /portal/*    │
                       │   ├─ Staff console (wp-admin, React)      │
                       │   ├─ Event bus → Job queue (Action Sched.)│
                       │   └─ Adapters: QBO, Google Sheets,        │
                       │       Warehouse, Email                    │
                       └──────┬───────────┬──────────┬─────────────┘
                              │           │          │
                     QuickBooks Online  Google    Warehouse system
                     (OAuth 2.0, webhooks) Sheets API  (TBD; adapter)
```

### 4.2 Components

| Component | Responsibility |
|---|---|
| **silver-stacker-portal** plugin | All business logic, DB tables (versioned migrations), roles/caps, REST API, portal routing and templates, staff console, integrations, WP-CLI commands. Theme-independent so a theme change can never break operations. |
| **silver-stacker** theme | Branding, layout, typography, design tokens, header/footer. Can override plugin templates. |
| **Customer portal** | Server-rendered PHP templates (fast, accessible, works without heavy JS). Small vanilla-JS modules for countdowns, gallery swipe, cart qty steppers, and inline edits calling the REST API. |
| **Staff console** | React app (built with `@wordpress/scripts`) mounted inside wp-admin. Data tables with server-side search/filter/pagination for large datasets. Talks only to `/ss/v1/staff/*` REST routes. |
| **Domain services** | PHP classes per area. Every write goes through a service (never directly from a template), which enforces validation, permissions, transactions, audit logging, and emits domain events. |
| **Event bus + Job queue** | Services emit events (`order.submitted`, `line.availability_changed`, `box.items_changed`…). Listeners enqueue jobs in Action Scheduler with idempotency keys. A real server cron runs the queue every minute. |
| **Adapters** | `QboClient`, `SheetsExporter`, `WarehouseAdapter` (interface; `ManualWarehouseAdapter` default until the platform is chosen), `Mailer`. |

### 4.3 Hosting requirements

- PHP 8.2+, MySQL 8.0+ or MariaDB 10.6+ (InnoDB, FULLTEXT, JSON).
- HTTPS everywhere, HSTS.
- Ability to block direct web access to a private uploads folder (nginx/Apache rule) or store it outside the web root.
- Real system cron (WP-Cron disabled).
- Persistent object cache (Redis) recommended.
- Transactional email provider (Postmark, Amazon SES, or SendGrid) via SMTP plugin.
- Daily backups with point-in-time restore; staging site for QBO sandbox testing.

---

## 5. WordPress / WooCommerce vs custom development

### 5.1 Recommendation: WordPress core + custom plugin, **without WooCommerce**

| Concern | WooCommerce | Custom plugin |
|---|---|---|
| Privacy | Ships public Store API (`/wp-json/wc/store/products`), product feeds, sitemaps, shortcodes, blocks that expose products and prices. Each must be found and closed, and updates can re-open them. | Nothing public exists unless we build it. |
| Payments | Checkout is payment-centric; "no payment" needs workarounds. | Pre-order submission is native. |
| Line-level states | Woo order items have no availability, partial invoicing, box, or allocation concepts; would be bolted on in meta. | First-class columns with indexes. |
| Allocations / waitlists | Stock is a single number per product; no per-customer caps or reservation ledger. | Purpose-built with row locks. |
| Product admin | Good UI for variations and galleries. | We build a focused editor (spec'd in ORIG screenshots). |
| 10k+ archive | Woo product lookups are heavy at scale. | Dedicated search table. |

**Verdict:** WooCommerce would save time only on the product editor while adding privacy risk and fighting the order model. Custom is safer and cleaner for this spec. (If Silver Stacker strongly prefers WooCommerce for future public retail, that is a different project; see D-32.)

### 5.2 What uses WordPress core

| WordPress feature | Used for |
|---|---|
| Users, auth, sessions, password reset | Customer and staff login (branded templates) |
| Roles and capabilities | `ss_customer`, `ss_sales_rep`, `administrator` + custom caps |
| Custom post type `ss_product` (private) | Product title, rich description/specifications, revisions, permalink slug |
| Taxonomies (private) | Metal category, sub-category, brand |
| Media library (restricted to staff) | Upload pipeline and image sizes; files stored in protected folder |
| Options API | Settings (credentials encrypted) |
| REST API infrastructure | `/ss/v1/*` routes with nonce + capability checks |
| `wp_mail` | Email delivery via SMTP provider |
| WP-CLI | Seeding, imports, queue control, maintenance |

### 5.3 Third-party components (vetted, minimal)

| Component | Purpose |
|---|---|
| Action Scheduler (standalone library) | Durable background job queue with retries and admin visibility |
| WP Mail SMTP (or host equivalent) | Reliable transactional email |
| Two Factor (WordPress.org plugin) | 2FA for staff and admins |
| Redis Object Cache | Performance |
| Composer libs (namespaced with Strauss): `firebase/php-jwt` (Google service-account auth), `symfony/uid` (ULIDs) | Integrations and stable IDs |

QBO and Google Sheets calls use direct REST over `wp_remote_request` rather than full SDKs, for control over retries, idempotency, and error reporting.

### 5.4 Custom development

Everything transactional and operational: registration wizard, approval workflow, T&C versioning, catalog presentation, search index, countdowns, cart, ordering, allocation, waitlist, overrides, availability, pre-sale tracker, box, shipments, invoicing, reports, integrations, audit log, staff console, notifications.

---

## 6. Roles and capabilities matrix

### 6.1 Roles

| Role | WP role slug | Notes |
|---|---|---|
| Visitor | (none) | Not logged in |
| Customer | `ss_customer` | Access further limited by `account_status` and T&C acceptance |
| Sales representative | `ss_sales_rep` | Global operational visibility, no platform configuration |
| WordPress administrator | `administrator` | Everything |

A customer's effective access = role caps **AND** `account_status = approved` **AND** current terms accepted. A pending/rejected/suspended customer has the `ss_customer` role but the Access Gate allows only account-status, profile-basic and logout routes.

### 6.2 Capability matrix

| Capability | Visitor | Customer: Pending / Rejected / Suspended | Customer: Approved | Sales rep | Admin |
|---|---|---|---|---|---|
| Register, log in, reset password | ✔ | ✔ | ✔ | ✔ | ✔ |
| View own account status page | | ✔ | ✔ | | |
| `ss_view_catalog` (catalog, prices, images, archive, search) | | | ✔ | ✔ | ✔ |
| `ss_place_orders` (cart, submit, amend own lines before close) | | | ✔ | | |
| Own orders, invoices, addresses, waitlist, box | | | ✔ (own only) | | |
| `ss_join_waitlist` | | | ✔ | | |
| `ss_request_box_shipment` (own box) | | | ✔ | ✔ (any) | ✔ |
| `ss_view_all_customers`, `ss_view_all_orders` | | | | ✔ | ✔ |
| `ss_approve_customers` (approve/reject/suspend/reactivate) | | | | ✔ | ✔ |
| `ss_invite_customers` | | | | ✔ | ✔ |
| `ss_manage_products` (create/edit, images, lifecycle, ETA, archive) | | | | ✔ | ✔ |
| `ss_manage_prices` | | | | ✔ | ✔ |
| `ss_manage_allocations` | | | | ✔ | ✔ |
| `ss_override_allocation` (with mandatory reason) | | | | ✔ | ✔ |
| `ss_manage_waitlists` | | | | ✔ | ✔ |
| `ss_manage_availability` | | | | ✔ | ✔ |
| `ss_correct_order_lines` (post-close corrections, cancellations, with reason) | | | | ✔ | ✔ |
| `ss_manage_boxes`, `ss_manage_shipments` | | | | ✔ | ✔ |
| `ss_create_invoices` | | | | ✔ | ✔ |
| `ss_retry_integration_jobs` | | | | ✔ | ✔ |
| `ss_view_reports`, `ss_export_data` | | | | ✔ | ✔ |
| `ss_view_staff_resources` | | | | ✔ | ✔ |
| `ss_manage_staff_resources` | | | | ✔ | ✔ |
| `ss_view_record_history` (audit trail on a record) | | | | ✔ | ✔ |
| `ss_view_audit_log` (full log) | | | | Configurable (D-23) | ✔ |
| `ss_manage_integrations` (QBO connect, Sheets, warehouse credentials) | | | | | ✔ |
| `ss_manage_settings` (terms versions, questions, tiers, rules, email templates) | | | | | ✔ |
| `ss_manage_staff_users` | | | | | ✔ |

---

## 7. Data model

All tables use prefix `{wp_prefix}ss_`. InnoDB, utf8mb4. Every table has `created_at` / `updated_at` in **UTC** (`DATETIME(6)`). Every externally visible record has a stable **ULID** (`*_uid`, CHAR(26), unique) used in integrations and URLs. Money: `DECIMAL(12,2)` USD. Quantities: `INT UNSIGNED`.

### 7.1 Customers

**`ss_customer_profiles`** (1:1 with `wp_users`)
| Column | Notes |
|---|---|
| user_id PK | FK wp_users.ID |
| customer_uid | ULID, stable across integrations |
| contact_name, company_name, phone, email_snapshot | |
| status | `pending`, `approved`, `rejected`, `suspended` |
| status_reason | Required for reject/suspend |
| approved_by, approved_at, rejected_at, suspended_at | |
| sms_consent, email_consent | From Q4 |
| last_login_at, last_order_at | Denormalized for lists |
| qbo_customer_id | Also in integration map |
| invited_by, invite_token_hash, invite_expires_at | For staff invites (D-18) |

**`ss_addresses`**: id, address_uid, user_id (indexed), type (`billing`/`shipping`), name, company, line1, line2, city, state, postal_code, country, phone, is_default, archived_at. Addresses used on boxes/shipments are **snapshotted** so later edits never rewrite history.

**`ss_signup_questions`**: id, question_key, version, text, sort, active. Seeded with the 8 ORIG questions; FB link is a setting.
**`ss_signup_answers`**: id, user_id, question_id, question_text_snapshot, answer_text, created_at, edited_by (staff edits audited).

**`ss_terms_versions`**: id, version_label, content (HTML), published_at, published_by, is_current.
**`ss_terms_acceptances`**: id, user_id, terms_version_id, accepted_at, ip, user_agent. Unique (user_id, terms_version_id). Append-only.

### 7.2 Catalog

**CPT `ss_product`** (not public, not queryable, no REST, excluded from search/sitemaps): post_title, post_content (description/specifications), post_name (slug), revisions.

**`ss_products`** (1:1 with CPT, structured + indexed)
| Column | Notes |
|---|---|
| id PK, post_id UNIQUE, product_uid | |
| name (denormalized) | |
| brand_term_id, metal_term_id, category_term_id | |
| lifecycle | `draft`, `presale`, `presale_ended`, `in_stock`, `archived` |
| closing_at | UTC; nullable for in-stock |
| eta_type | `none`, `date`, `range`, `month`, `text` |
| eta_start, eta_end (DATE), eta_text | "Nov. 15-30, 2026", "Late October" |
| mintage | Nullable text/int (some are "Unlimited") |
| supplier_id | FK ss_suppliers |
| date_posted | Tracker "Date posted" |
| price_type | `fixed`, `spot_based` (D-12) |
| spot_premium_usd, spot_metal_oz | For "Spot + $X" display |
| archived_at, reactivated_at | |

**`ss_product_variants`**
| Column | Notes |
|---|---|
| id PK, product_id, variant_uid | |
| label, attributes (JSON: size, color…) | |
| sku UNIQUE, barcode (indexed) | |
| price_usd | Same for every approved customer |
| msrp_usd | Optional, staff-only display |
| min_order_qty | Default 1 |
| total_allocation | NULL = unlimited |
| per_customer_allocation | NULL = unlimited |
| supplier_qty_ordered | Tracker column (C-10) |
| reserved_qty | Cached sum, maintained transactionally |
| eta_* override, closing_at override | Nullable |
| is_default, sort, active | |
| qbo_item_id | |

**`ss_product_images`**: id, product_id, variant_id (nullable), attachment_id, sort, is_primary. Files in protected storage (13.3).

**`ss_suppliers`**: id, name, contact, notes, active.

**`ss_product_search`** (denormalized index, one row per variant)
- product_id, variant_id, tab (`active`/`archive`), lifecycle, metal_term_id, brand_name, category_name, name, sku, barcode, variant_text, mintage, closing_at, sort_key.
- Indexes: FULLTEXT(name, brand_name, category_name, variant_text); B-tree on sku, barcode, (tab, lifecycle, metal_term_id), (tab, sort_key).
- Rebuilt on product save; full reindex via WP-CLI.

**`ss_eta_history`**: product_id, variant_id, old_value, new_value, changed_by, changed_at, note. (Also in audit log.)

### 7.3 Cart and orders

**`ss_cart_items`**: id, user_id, variant_id, qty, fulfillment_choice, added_at. Unique (user_id, variant_id). Never reserves allocation. Revalidated at submit.

**`ss_orders`**
| Column | Notes |
|---|---|
| id PK, order_uid, order_number UNIQUE | Human sequence, start value configurable (D-14) |
| user_id (indexed) | Owner |
| submitted_at | |
| customer_note | |
| terms_version_id | Terms in force at submission |
| status | Derived (9.3), cached for filtering |
| subtotal_ordered_usd | Cached |
| submit_idempotency_key UNIQUE | Prevents double-submit on double-click/retry |
| source | Always `portal` |

**`ss_order_lines`**
| Column | Notes |
|---|---|
| id PK, line_uid | |
| order_id, user_id (denormalized for scoping), product_id, variant_id | Indexed |
| name_snapshot, sku_snapshot, unit_price_snapshot, price_type_snapshot | Price at time of order |
| qty_ordered | Current customer-requested quantity (after amendments) |
| qty_cancelled | |
| qty_available | Set by staff / warehouse; ≤ net |
| qty_invoiced | Only after QBO success |
| qty_pending_invoice | Locked while an invoice job is in flight |
| qty_shipped | |
| fulfillment_choice | `box`, `separate`, `decide_later` |
| locked_at | Set when closing passes |
| eta_at_order | Snapshot for history; live ETA always read from product |
| display_status | Derived (9.4), cached |
| row_version | Optimistic concurrency for staff edits |

`net_qty = qty_ordered - qty_cancelled`.

**`ss_line_amendments`**: line_id, old_qty, new_qty, actor (customer/staff), reason, at.

### 7.4 Allocation and waitlist

**`ss_allocation_ledger`** (append-only): id, variant_id, user_id, order_line_id, type (`reserve`, `release`, `staff_adjust`), qty_delta (+/-), actor_id, reason, created_at. `ss_product_variants.reserved_qty` is the cached sum, updated in the same transaction and reconcilable by WP-CLI.

**`ss_allocation_overrides`**: id, variant_id, user_id (nullable for total-level), order_line_id, override_type (`total`, `per_customer`, `minimum`, `closing`), qty, reason (required), staff_id, created_at.

**`ss_waitlist`**: id, waitlist_uid, variant_id, user_id, qty_requested, position, status (`waiting`, `offered`, `accepted`, `expired`, `cancelled`, `converted`), offered_qty, offered_at, offer_expires_at, converted_order_line_id, created_at. Unique active entry per (variant_id, user_id).

### 7.5 Box and shipments

**`ss_boxes`**: id, box_uid, box_number, user_id, status, address_id, address_snapshot (JSON), rate_tier_id, shipping_charge_usd, shipment_requested_at, shipment_requested_by, preparing_at, closed_at, shipment_id.

**`ss_box_items`**: id, box_id, order_line_id, qty, added_at, added_by, removed_at, removed_by. (A line belongs to at most one non-closed box.)

**`ss_shipments`**: id, shipment_uid, user_id, box_id (nullable; null = separate shipment), status, address_snapshot, rate_tier_id, shipping_charge_usd, carrier, tracking_number, shipped_at, delivered_at, shipping_invoice_id (nullable), notes.

**`ss_shipment_lines`**: shipment_id, order_line_id, qty. Permanent record of exactly what shipped.

**`ss_rate_tiers`**: id, name, basis (`size`/`weight`), min_value, max_value, unit, charge_usd, priority, active, confirmed (bool; unconfirmed tiers show a warning in staff UI).

### 7.6 Invoices

**`ss_invoices`**: id, invoice_uid, user_id, qbo_invoice_id, qbo_doc_number, txn_date, due_date, total_usd, balance_usd, sync_status (9.7), payment_status, pay_link, last_synced_at, idempotency_key UNIQUE, qbo_request_id, created_by, error_code, error_message.

**`ss_invoice_lines`**: invoice_id, order_line_id (nullable for shipping line), type (`product`/`shipping`), qty, unit_price_usd, amount_usd, qbo_line_id.

Invoice PDFs are fetched from QBO on demand and streamed through an ownership-checked endpoint (optionally cached in private storage).

### 7.7 Integrations, audit, notifications

**`ss_integration_jobs`**: id, integration (`qbo`, `sheets`, `warehouse`, `email`), action, object_type, object_id, idempotency_key UNIQUE, payload (JSON), status (`queued`, `running`, `succeeded`, `failed`, `dead`), attempts, next_attempt_at, last_error, created_at, updated_at.
**`ss_integration_map`**: integration, object_type, portal_uid, external_id, external_version; unique (integration, object_type, portal_uid).
**`ss_inbound_events`**: source, external_event_id UNIQUE, payload, received_at, processed_at, result. (Webhook de-duplication.)
**`ss_sheet_row_map`**: tab, portal_uid, row_index, last_hash.
**`ss_audit_log`** (append-only, no update/delete code path): id, actor_user_id, actor_role, action, object_type, object_id, before (JSON), after (JSON), reason, ip, user_agent, created_at. Indexed on (object_type, object_id), (actor_user_id), (created_at).
**`ss_notifications`**: id, user_id, template, object_type, object_id, status, sent_at, error, dedupe_key.
**CPT `ss_resource`**: staff-only resources with private file attachments.

---

## 8. Relationships

### 8.1 Entity relationships

```
Customer (wp_user + ss_customer_profiles)
 ├── 1:N  ss_addresses
 ├── 1:N  ss_signup_answers
 ├── 1:N  ss_terms_acceptances ──► ss_terms_versions
 ├── 1:N  ss_cart_items ──► ss_product_variants        (draft, no reservation)
 ├── 1:N  ss_orders
 │         └── 1:N ss_order_lines ──► ss_product_variants ──► ss_products
 │                    ├── 1:N ss_allocation_ledger            (reservation history)
 │                    ├── 0:N ss_invoice_lines ──► ss_invoices  (partial invoicing ok)
 │                    ├── 0:1 active ss_box_items ──► ss_boxes (box can hold lines from many orders)
 │                    └── 0:N ss_shipment_lines ──► ss_shipments
 ├── 1:N  ss_waitlist ──► ss_product_variants
 ├── 0..1 open ss_boxes (configurable max), N closed boxes
 └── 1:N  ss_invoices, ss_shipments
```

### 8.2 The chain from MP §25

**Customer → Orders → Order Lines → Products → Allocation → Availability → Invoice → Box → Shipment**

| Rule from MP §25 / REV2 | How the model guarantees it |
|---|---|
| An order can contain multiple products | `ss_order_lines.order_id` (1:N) |
| Products in one order become available at different times | `qty_available` is per line |
| Products from different orders in one customer's box | `ss_box_items` references lines, not orders; constraint: line.user_id = box.user_id |
| An invoice applies to selected available lines | `ss_invoice_lines` (N:M with qty), eligibility `qty_available - qty_invoiced - qty_pending_invoice > 0` |
| A shipment contains lines from multiple orders | `ss_shipment_lines` |
| Relationships preserved permanently | No hard deletes on lines/boxes/shipments/invoices; snapshots for names, prices, addresses |

### 8.3 Quantity buckets per line (prevents double counting, REV2 §12.30)

For each line, at all times:
```
net        = qty_ordered - qty_cancelled          (reserved against allocation)
available  ≤ net
invoiced + pending_invoice ≤ available
shipped    ≤ available
held_in_box  = qty in active ss_box_items (≤ net - shipped)
```
Variant level: `reserved_qty = Σ net over non-cancelled lines` must never exceed `total_allocation + Σ total overrides`.

### 8.4 Allocation algorithm (concurrency-safe)

1. Begin transaction.
2. `SELECT … FROM ss_product_variants WHERE id IN (…) ORDER BY id FOR UPDATE` (row locks in a fixed order to avoid deadlocks).
3. Re-check lifecycle orderable, server time `< closing_at` (with overrides), `qty ≥ min`, `qty ≤ total remaining`, `customer_reserved + qty ≤ per_customer (+ overrides)`.
4. Insert order/lines, ledger rows; update `reserved_qty`.
5. Commit; then emit events (Sheets, warehouse) after commit.

If any line fails, nothing is reserved and the customer sees which line failed and why, with options: reduce qty, remove, or join waitlist for the shortfall.

---

## 9. Status models and transitions

### 9.1 Customer

| From | To | Who | Side effects |
|---|---|---|---|
| (register) | pending | Visitor | Staff dashboard counter, optional staff alert email |
| pending | approved | Staff | Approval email with login link; QBO customer created lazily at first invoice |
| pending | rejected | Staff (reason) | Rejection email |
| approved | suspended | Staff (reason) | All sessions destroyed; catalog blocked; open orders kept for staff |
| suspended | approved | Staff | Optional email |
| rejected | approved | Staff (reason) | Approval email (re-review) |

### 9.2 Product lifecycle

| From | To | Trigger |
|---|---|---|
| draft | presale / in_stock | Staff publishes (requires price, SKU, primary image; presale requires closing_at) |
| presale | presale_ended | **Automatic** at closing_at (also evaluated live on every request, so cron delay can never allow a late order) |
| presale_ended | presale | Staff extends closing date (audited) |
| presale_ended | in_stock | Staff offers remaining stock as In Stock |
| presale / presale_ended / in_stock | archived | Staff |
| archived | presale / in_stock | Staff reactivates (audited) |

Lines of a product are locked when it leaves `presale` for `presale_ended`.

### 9.3 Pre-order (derived from lines)

Evaluated in order; first match wins:
1. **Cancelled**: all lines cancelled.
2. **Completed**: every non-cancelled line fully shipped.
3. **Fully invoiced**: every non-cancelled line invoiced = net.
4. **Partially invoiced**: any line has invoiced qty.
5. **Fully available**: every non-cancelled line available = net.
6. **Partially available**: any line has available qty.
7. **Open**: any line locked (closing passed), nothing available.
8. **Submitted**: otherwise (still amendable).

### 9.4 Order line display status (REV2 labels)

Primary status, first match wins: **Cancelled** → **Fulfilled** (shipped = net) → **Invoiced** (invoiced = net) → **Partially invoiced** → **Available** (available ≥ 1; shows "x of y available") → **Locked** (closing passed) → **Reserved** → **Waitlisted** (line linked to an active waitlist entry with reserved 0).
Fulfillment badge shown alongside: **Assigned to box** / **Separate shipment** / **Awaiting decision**.

### 9.5 Waitlist

`waiting` → `offered` (allocation freed; offer held for configurable window, default 48h, FIFO by position) → `accepted` → `converted` (line created/increased through the normal allocation check). `offered` → `expired` (window passes; next in line offered). Any → `cancelled` (customer or staff). Defaults pending D-1.

### 9.6 Box

| From | To | Who | Rules |
|---|---|---|---|
| (auto) | open | System | Created when the customer first assigns a line to box; default address snapshot |
| open | shipment_requested | Customer (confirm dialog) or staff | Box must have ≥ 1 item; behavior with unavailable items per D-19 |
| shipment_requested | open | Customer or staff | Cancel request before preparing |
| shipment_requested | preparing | Staff | Address and contents frozen (D-3) |
| preparing | shipped | Staff | Requires carrier, tracking, ship date, rate tier/charge; creates `ss_shipments` + lines |
| shipped | delivered | Staff or carrier update | |
| delivered | closed | Staff or auto after N days (configurable) | Kept in history |

When a box leaves `open`, a new open box is created on the next "add to box" (respecting `max_open_boxes`).

### 9.7 Invoice sync

`not_invoiced` (line state) → `queued` → `creating` → `synced` → `partially_paid` / `paid` / `overdue` (from QBO). `creating` → `error` (lines released back to invoiceable, error shown, safe retry). `synced` → `voided` (voided in QBO; lines become invoiceable again, audited).

### 9.8 Shipment (separate or box)

`pending` → `preparing` → `shipped` → `delivered`; `cancelled` before shipped.

---

## 10. Page map (customer portal)

Every route below except the Public group requires: logged in **and** approved **and** current terms accepted. Unauthorized requests get a redirect to `/login` (no content, no product names in titles, `noindex`).

### 10.1 Public (no catalog data)

| Route | Page |
|---|---|
| `/` | Redirects to `/login` or `/portal` |
| `/login` | Branded login (banner + logo) |
| `/register` | 3-step wizard: (1) account: contact name, email, phone, password; (2) business: company/store, billing address, shipping address; (3) qualification questions (8) + consents |
| `/register/submitted` | "Your account is pending approval" |
| `/account-status` | Pending / rejected / suspended message for logged-in non-approved users |
| `/forgot-password`, `/reset-password` | Core flow, branded, no account enumeration |
| `/invite/{token}` | Complete an invited registration (D-18) |

### 10.2 Approved customer

| Route | Page | Key content |
|---|---|---|
| `/portal/terms` | Terms gate | Current terms, required checkbox, Accept |
| `/portal` | Dashboard | Announcement, closing-soon presales with countdowns, my open box summary, recent orders, invoices due, waitlist offers |
| `/portal/shop` | Shop / Pre-Sales | Presale grid: image, name, price, ETA, countdown, allocation indicator, qty + Add to Order |
| `/portal/in-stock` | In-Stock Products | Same grid for In Stock |
| `/portal/search?q=&tab=active\|archive` | Search | Two tabs with counts, filters (metal, brand, category, lifecycle), query preserved |
| `/portal/p/{product_uid}/{slug}` | Product (permanent link) | Swipe gallery, variants, price, ETA, countdown, description/specs, mintage, min/limits, qty, fulfillment choice, Add to Order or Join Waitlist; archived → reference view, not orderable |
| `/portal/cart` | Cart (order draft) | Items, qty, per-item fulfillment choice, customer note, live validation, "Your cart is empty" |
| `/portal/cart/review` | Review & Submit | Final check, terms reminder, "Submit Pre-Order" (no payment) |
| `/portal/orders/{order_number}/confirmation` | Confirmation | Order number, lines, what happens next |
| `/portal/orders` | My Orders | Newest first, search by item name, filters (status, date) |
| `/portal/orders/{order_number}` | Order detail | Lines with image (linked), qty ordered/available/invoiced, price, total, ETA, line status, fulfillment, box link, invoice links, edit qty before close, change fulfillment choice |
| `/portal/box` | My Box | All MP §12 columns, totals, address (change per D-3), status, tier, "Ship My Box" |
| `/portal/box/history` | Past boxes | Closed boxes with shipments and tracking |
| `/portal/invoices` | Invoices | QBO number, date, total, due, due date, payment status, Pay link, PDF |
| `/portal/invoices/{invoice_uid}/pdf` | PDF stream | Ownership-checked proxy |
| `/portal/waitlist` | Waitlist | Entries, position, offers with deadline, accept/cancel |
| `/portal/addresses` | Shipping Addresses | Add/edit/archive, set default |
| `/portal/archive` | Product Archive | Browse/search archive tab directly |
| `/portal/account` | Account / Profile | Contact info, password, consents, terms accepted (version/date) |
| `/portal/logout` | Logout | |

### 10.3 Header and navigation

- Logo, search bar (customers and staff), **Cart** button with count (customers only), account menu.
- Staff see an admin menu: Orders, Customers, Reports, Settings, Log Out (ORIG) plus a link to the full staff console.
- Mobile: bottom-sheet menu with Shop, Search, Orders, My Box, Account.

---

## 11. Staff / admin screens

All in the staff console (wp-admin). Every list has server-side search, filters, sorting, pagination, CSV export, and saved filters.

| Screen | Contents and actions |
|---|---|
| **Dashboard** | Pending approvals, presales closing in 48h, lines ready to invoice, shipment requests, waitlist offers expiring, integration errors, today's orders |
| **Customers** | List (name/company, contact, created, last order, status); Invite Customer; detail: contact, addresses, sign-up answers (staff edit audited), terms acceptances, orders, box, invoices, waitlist, QBO link, actions approve/reject/suspend/reactivate, reset password, resend invite, record history |
| **Products** | List (image, name, SKU, metal, price, lifecycle, closing, ETA); editor tabs: **Details** (name, rich description/specs, brand, metal, category, mintage, supplier, date posted, price type), **Variants** (SKU, barcode, attributes), **Pricing** (USD price per variant, MSRP optional), **Allocation** (min, total, per-customer, supplier qty ordered, live reserved/remaining), **Schedule & ETA** (lifecycle, closing date/time with timezone, ETA type/value, history), **Images** (upload, drag reorder, primary, delete), **Orders** (lines for this product), **History** |
| **Archive** | Archive search, bulk CSV import with dry-run preview and error report, reactivate |
| **Orders / Pre-Orders** | All orders and a line-level view; filters by status, product, customer, date, fulfillment, invoice state; line actions: correct qty (reason), cancel line (reason), set availability, change fulfillment |
| **Allocation & Waitlist** | Per variant: total, per-customer, reserved, remaining, waitlist queue; override (reason required); release/offer to next; offer expiry |
| **Pre-Sale Tracker** | Tab 1 Active Product Master List (inline edit ETA, supplier qty, supplier, status); Tab 2 Active Orders (grouped by product, per-buyer rows, live Qty Available); Tab 3 Closed Orders (auto from closing date); Tab 4 Ready to Invoice (available, uninvoiced lines; "Create invoice for this customer"; status column). Includes an optional **"distribute arrived quantity"** helper that proposes availability per line oldest-first and requires staff confirmation before saving (a tool, not a rule) |
| **Boxes & Shipments** | Open boxes (age, items, address), shipment request queue, process box (tier, charge, carrier, tracking, dates, status), move eligible lines between box and separate, separate shipments queue, shipment history |
| **Invoices** | New invoice wizard (pick customer → pick available uninvoiced lines with qty → optional shipping line → preview → create in QBO); invoice list with sync/payment status; refresh from QBO; retry failed |
| **Reports** | Section 1.7 RP-01 to RP-10 |
| **Integrations** | QBO connect/disconnect (sandbox/production), Sheets config + "rebuild sheet", warehouse adapter config, job queue (filter by status, see payload/error, retry, mark resolved) |
| **Staff Resources** | Upload/download staff-only files |
| **Settings** (admin) | Terms versions, sign-up questions, FB group link, announcement, rate tiers, box rules (max open boxes, auto-close days), waitlist rules, email sender + templates, closing-time default and business timezone, order-number start, feature toggles (confirmation email, name date suffix) |
| **Audit Log** | Filter by actor, object, action, date; before/after diff |

---

## 12. API and integration architecture

### 12.1 Internal REST API (`/wp-json/ss/v1`)

- **Customer routes** (`/me/*`): cart, orders, lines (amend), fulfillment choice, box, box/request-shipment, waitlist, addresses, invoices, catalog search, product. Permission callback: logged in + approved + terms accepted. Resource IDs are UIDs; every handler loads by `(uid AND user_id = current user)` and returns 404 on mismatch.
- **Staff routes** (`/staff/*`): one capability per route group (Section 6).
- **Inbound webhooks** (`/hooks/qbo`, `/hooks/warehouse`): no cookie auth; verified by signature (Intuit HMAC-SHA256 verifier token; warehouse HMAC shared secret), de-duplicated via `ss_inbound_events`, processed asynchronously.
- All WP core REST endpoints not needed are restricted to staff (users, posts, media, search).

### 12.2 QuickBooks Online

- **Auth:** Intuit OAuth 2.0 authorization-code flow from Integrations screen (admin). Access and refresh tokens encrypted at rest (libsodium, key in `wp-config.php`); refresh before expiry; refresh-token rotation stored atomically. Reconnect alert if refresh fails.
- **Mappings:** portal customer → QBO Customer (created at first invoice, matched by stored ID, never by name); variant SKU → QBO Item (strategy D-30); invoice ↔ order lines via `ss_invoice_lines`.
- **Create invoice (two-phase, idempotent):**
  1. Staff confirms selection. In one DB transaction: create `ss_invoices` (sync_status `queued`, idempotency_key = hash of customer + line IDs + qty + staff action nonce) and move qty to `qty_pending_invoice`. Lines already pending cannot be selected again.
  2. Job calls `POST /v3/company/{realm}/invoice?requestid={qbo_request_id}`. QBO's `requestid` makes retries return the same invoice instead of creating a duplicate.
  3. Success: store QBO IDs, number, totals, due date, invoice link; move pending → invoiced; status `synced`; notify customer; emit events.
  4. Failure: status `error`, pending qty released, error shown with retry. Lines are **never** marked invoiced unless step 3 completes (REV2 §10.21).
- **Inbound sync:** QBO webhooks (Invoice, Payment entities) trigger a fetch of the affected invoice; a scheduled Change Data Capture poll (every 15 min, configurable) catches anything missed. Payment status `paid` only when QBO balance = 0.
- **Pay link / PDF:** invoice link requested from QBO (requires QBO online payments and invoice delivery email set); PDF fetched via `/invoice/{id}/pdf` and streamed through an ownership-checked endpoint.

### 12.3 Google Sheets (one-way)

- **Auth:** Google Cloud service account (Sheets API). The master spreadsheet is shared with the service account email. No user OAuth required.
- **Tabs and key column (column A = stable portal UID):**
  - Customers: customer_uid, company, contact, email, phone, status, billing address, default shipping address, created_at, approved_at
  - Pre-order Lines: line_uid, order_number, order_uid, customer_uid, customer, product, variant, SKU, barcode, qty ordered / available / invoiced / shipped / cancelled, unit price, line total, submitted_at, closing_at, ETA, fulfillment choice, box_uid, line status, invoice number
  - Allocations & Waitlists: variant_uid (+ waitlist_uid rows), product/variant, total allocation, per-customer limit, reserved, remaining, waitlist customer, qty, state, override indicator
  - Open Boxes: box_uid, customer, default address, included lines, quantities, invoice refs, tier, box state
  - Shipments: shipment_uid, box_uid, customer, lines, carrier, tracking, shipped_at, delivered_at, status
- **Upsert:** row map table + verification against column A; batched `values:batchUpdate`; jobs coalesced per object so only the latest snapshot is written. Header rows and data ranges protected with a warning that the Sheet is a read-only copy.
- **Failure:** retries with backoff; visible in Integrations; never blocks ordering. "Rebuild sheet" regenerates all tabs from the database.

### 12.4 Warehouse / inventory (platform TBD)

- `WarehouseAdapter` interface: `pushOrderLines()`, `pushLineChange()`, `pushCancellation()`, `pushShipmentRequest()`, `handleInboundEvent()`.
- **V1 default `ManualWarehouseAdapter`:** staff enter availability and shipments in the portal; outbound events are recorded so the real adapter can replay them.
- Real adapter built when the platform and authority (D-11) are confirmed; all events carry stable UIDs and idempotency keys.

### 12.5 Email notifications

| Event | Template | Notes |
|---|---|---|
| Account approved | `account_approved` | Secure login link + next steps |
| Account rejected | `account_rejected` | Wording TBD (D-7) |
| Waitlist offer | `waitlist_available` | Product/variant, action, deadline |
| Item arrived and invoiced | `line_invoiced` | Lines + link to portal and QBO invoice |
| Box contents changed | `box_changed` | Debounced digest (default 15 min) summarizing added/removed items + link to My Box |
| Order submitted (optional) | `order_confirmation` | Off by default (C-3, D-15) |
| Password reset | core | Branded |

---

## 13. Security and privacy design

### 13.1 Access Gate (runs before any template)

- `template_redirect` at highest priority: allow-list of public routes only. Everything else requires login + approved + current terms (staff exempt from terms).
- Disabled/blocked for non-staff: front-end search `?s=`, feeds, XML sitemaps, oEmbed, author archives, attachment pages, XML-RPC, `wp/v2/users`, `wp/v2/media`, `wp/v2/search`, all core REST routes not required.
- `X-Robots-Tag: noindex, nofollow` and `robots.txt` disallow all.
- Page titles, Open Graph tags and error pages never contain product names or prices for unauthorized users.

### 13.2 Ownership Guard

- Customer queries are always built with `WHERE user_id = :current_user` inside the repository layer, not in templates.
- URLs use UIDs/order numbers, but ownership is still checked; mismatches return 404 (no record enumeration).
- Acceptance test: two customers with the same company name cannot see each other's data (REV2 §17.46).

### 13.3 Private media

- Product images and staff files are stored in `wp-content/uploads/ss-private/` (direct access denied by server rule) or outside the web root.
- Served through `/portal/media/{token}/{size}` after the same gate check, with `Cache-Control: private`.
- Media Library hidden from non-staff.

### 13.4 Standard protections

- Nonces on every form and REST call (CSRF); capability check in every REST `permission_callback` and admin action.
- Input sanitization and validation per field; output escaping in every template (`esc_html`, `esc_attr`, `esc_url`, `wp_kses_post`).
- Prepared statements (`$wpdb->prepare`) everywhere.
- Rate limiting on login, registration and password reset; bot protection (Cloudflare Turnstile) on registration.
- Staff 2FA enforced; strong password policy.
- Suspension destroys sessions immediately.
- Credentials encrypted at rest; secrets in `wp-config.php` / environment, never in the DB in plain text.
- Audit log is append-only.
- All timestamps stored UTC, displayed in the business timezone (D-13).

---

## 14. Unresolved business decisions

Built as **configurable settings** with the default shown, clearly marked "Unconfirmed" in the staff UI until confirmed. Nothing below becomes a permanent hard-coded rule.

| ID | Decision needed | Source | Default used for build | Where configurable |
|---|---|---|---|---|
| D-1 | Waitlist promotion: auto-reserve, hold for response window, or first-come-first-served | REV2 §19 | Hold for response window (48h), FIFO | Settings › Waitlist |
| D-2 | Open boxes per customer | REV2 §19 | 1 open box; new one opens after a shipment request | Settings › Box |
| D-3 | Address change after box creation | REV2 §19 | Customer or staff can change until "Preparing" | Settings › Box |
| D-4 | Fixed-rate tier values and which rule wins if size and weight disagree | REV2 §19, ORIG T&C | Draft tiers from ORIG ($6 Ground, $9 Priority, $9 Build A Box), flagged unconfirmed | Settings › Rate tiers |
| D-5 | Shipping invoice timing: added to existing invoice, new invoice at shipment, or separate. ORIG says Build A Box $9 is "paid with first item" | REV2 §19, ORIG T&C | Staff chooses per shipment: add shipping line to next invoice or create a shipping-only invoice | Invoice wizard |
| D-6 | Cancellation policy: qty 0 before close = cancel? Staff cancellation after close? | REV2 §19 | Qty 0 before close cancels the line; after close only staff, with reason | Settings › Orders |
| D-7 | Email sender name, reply-to, branding, final wording (incl. rejection) | REV2 §19 | Draft templates in Silver Stacker branding | Settings › Email |
| D-8 | Sales report measure | REV2 §19 | Ordered, Invoiced, Paid side by side | Reports |
| D-9 | In-stock workflow, and when in-stock orders stop being editable (no closing date) | REV2 §19 | Same as presale; in-stock lines editable until marked available or invoiced | Settings › Orders |
| D-10 | Archive data source and quality (10k+ records, photos, mintage) | REV2 §19 | CSV importer with flexible mapping; sample file requested | Archive import |
| D-11 | Warehouse platform and which system owns on-hand/reserved/available/held/shipped | REV2 §12, §19 | Manual adapter; portal is authority until decided | Integrations |
| D-12 | **Spot-based offers** ($0.01 display price): how price is shown and how the final invoice price is set (spot at what time/source?) | ORIG Q7, tracker | Price type "Spot-based" displays "Spot + $X"; staff enters final unit price at invoicing; allocation still enforced | Product › Pricing, Invoice wizard |
| D-13 | Closing time and timezone. ORIG uses dates like "(08/03)" | ORIG, REV2 §5.4 | 11:59:59 PM in business timezone **America/Chicago** (Texas). Confirm | Settings › General |
| D-14 | Order numbers: start at 1 or continue after OrderSpace (about 14600+) to avoid confusion | ORIG screenshots | Configurable start; recommend starting above last OrderSpace number | Settings › Orders |
| D-15 | Sign-up Q8 wording (mentions "checkout") and whether to send an order confirmation email | ORIG Q8, REV2 §13 | Wording updated to "Submit Pre-Order"; email off | Settings › Questions, Email |
| D-16 | SMS notifications (ORIG Q4) | ORIG Q4 | Consent stored; no SMS in V1 | Future phase |
| D-17 | Retail/Wholesale groups and volume discounts | ORIG vs REV2 §18.64 | Not built in V1 | n/a |
| D-18 | Staff "Add New Customer": allow invites? Allow staff to enter orders for a customer? | ORIG vs REV2 §2.5, §12.34 | Invites allowed (customer completes own registration); no staff-entered orders | Customers |
| D-19 | "Ship My Box" when some items are not yet available | MP §12 | Customer is warned and chooses: wait, or ship available items now (unavailable items stay in a new open box) | Settings › Box |
| D-20 | Who sets box rate tier and when; is the customer shown the charge before confirming? | REV2 §8.3 | Staff sets tier when preparing; customer sees "to be confirmed" until then | Settings › Box |
| D-21 | Final T&C text; re-acceptance required on every new version? | ORIG, MP §4 | ORIG text as v1; re-acceptance required on new version | Settings › Terms |
| D-22 | Hosting provider (must support private-folder blocking, cron, Redis) | Section 4.3 | To be selected | n/a |
| D-23 | Can sales reps view the full audit log? | REV2 §3 | Reps see history on each record; full log admin-only | Settings › Roles |
| D-24 | Meaning of "Invoice Updated" in the ORIG Ready to Invoice dropdown | ORIG p.8 | Treated as "invoice amended in QBO" (sync refresh) until confirmed | Tracker |
| D-25 | Relationship between supplier qty ordered and total allocation | ORIG p.7 | Independent fields; staff "copy to allocation" action | Product › Allocation |
| D-26 | ETA and closing date per variant or per product only | REV2 §5.5 | Product-level with optional variant override | Product editor |
| D-27 | Minimum order quantity: per order line or per customer total for the variant | REV2 §5.5 | Per customer total for the variant (sum of their lines) | Settings › Orders |
| D-28 | Payment terms (ORIG: due within 72 hours of invoice) | ORIG T&C | Set in QBO as invoice terms; portal displays QBO due date | QBO |
| D-29 | Can customers change fulfillment choice after invoicing? | REV2 §8.2 | Yes, until the line ships or its box is "Preparing" | Settings › Box |
| D-30 | QBO item mapping: one QBO item per SKU (auto-create) or a few generic items | REV2 §10 | One Non-inventory item per variant SKU; confirm with accountant | Integrations |
| D-31 | Can a rejected applicant re-apply with the same email? | n/a | No; staff can re-review a rejected account | Customers |
| D-32 | Confirm no WooCommerce / no future public retail store in this site | Section 5 | Custom plugin, no WooCommerce | n/a |

---

## 15. Implementation phases and sequence

Each phase ends with its acceptance tests passing (automated where possible) before the next starts. Order follows the MP priority list: privacy/security → data correctness → pre-sale workflow → ETA → box → allocation → QBO → reporting/integrations → UX → polish.

| Phase | Scope | Exit criteria |
|---|---|---|
| **0. Foundation** | Plugin + theme scaffold, Composer/Strauss, DB migration framework and all core tables, roles/caps, Access Gate, Ownership Guard, private media, audit log service, settings framework with encryption, job queue + event bus, WP-CLI base, test harness (PHPUnit integration + Playwright E2E), design tokens | Visitor cannot reach any non-public route, REST endpoint, feed, sitemap or media file; audit log writes; jobs run and retry |
| **1. Accounts** | Registration wizard + 8 questions, pending/approval/rejection/suspension, emails, invites, terms versions + gate, addresses, account page, branded login/reset, staff Customers screens, header/nav | AT-01 to AT-04, AT-21 (accounts part) |
| **2. Catalog, ETA, countdown, search, archive** | Product CPT + tables, variants, images, metals/brands/categories, suppliers, lifecycle machine + auto-close, ETA model + formatter + history, countdown component, search index + two-tab search, archive pages + permanent links, CSV archive import, staff product editor and lists, seed 12k archive and perf test | AT-05 to AT-07, AT-22, AT-23 |
| **3. Ordering, allocation, waitlist** | Cart, validation, transactional submit with idempotency, confirmation, order history + search + detail, amendments, closing lock, waitlist + offers, overrides, staff Orders + line corrections + Allocation & Waitlist screens, concurrency tests | AT-08 to AT-10, AT-21 (orders part) |
| **4. Availability + Pre-Sale Tracker** | Line availability (manual), tracker 4 tabs, distribute-arrivals helper, availability shown to customers | AT-11, AT-12 |
| **5. Box and shipments** | Fulfillment choices, box service, My Box, Ship My Box with confirm, staff box processing, rate tiers, separate shipments, shipment records, box digest email | AT-13 to AT-17 |
| **6. QuickBooks Online** | OAuth connect, customer/item mapping, invoice wizard, two-phase idempotent create, webhooks + CDC poll, payment status, pay link, PDF proxy, line_invoiced email, Integrations error view | AT-18 |
| **7. Google Sheets + warehouse adapter** | Sheets exporter (5 tabs), coalesced upserts, rebuild, warehouse interface + manual adapter + webhook endpoint skeleton | AT-19 |
| **8. Reports** | All RP items, shared filter/total/CSV framework, category chart, customer ranking | Report figures reconcile with DB fixtures; Paid only from QBO |
| **9. Hardening and launch** | Staff Resources, dashboard KPIs, accessibility audit (WCAG 2.2 AA), mobile polish, performance pass, security review (OWASP checklist), backup/restore drill, deployment + runbook, staff training notes | Full acceptance suite green on staging with QBO sandbox |

**Delivery format:** each phase is delivered as a zip containing the plugin, theme, migrations, tests, and a CHANGELOG, plus setup notes.

---

## 16. Acceptance test plan

| ID | Scenario (MP §26 / REV2 §17) | Phase | Type |
|---|---|---|---|
| AT-01 | Unapproved visitor cannot access products/pricing (pages, REST, media URLs, feeds, sitemap) | 0-1 | E2E + integration |
| AT-02 | Staff approves customer; approval email sent | 1 | E2E |
| AT-03 | Approved customer logs in | 1 | E2E |
| AT-04 | Customer must accept T&C (version recorded) before catalog | 1 | E2E |
| AT-05 | Customer searches private catalog (name, SKU, barcode, brand, category, lifecycle, variant) | 2 | E2E |
| AT-06 | Customer opens product and sees ETA | 2 | E2E |
| AT-07 | Countdown accurate on cards/search/product; ordering blocked server-side at zero | 2-3 | E2E + unit (clock mocked) |
| AT-08 | Customer places pre-order without payment; invalid qty/closed product blocked with clear message | 3 | E2E |
| AT-09 | Allocation decreases correctly; total and per-customer caps enforced under concurrent submissions; full allocation offers waitlist; override logged | 3 | Integration (parallel) |
| AT-10 | Customer sees order in history, searches by item name, item links to active or archive listing; amend before close, locked after | 3 | E2E |
| AT-11 | Staff marks part of a line available | 4 | E2E |
| AT-12 | Customer sees updated availability | 4 | E2E |
| AT-13 | Eligible item can be added to My Box | 5 | E2E |
| AT-14 | Products from multiple orders in one box, retaining original order references | 5 | E2E |
| AT-15 | Customer requests box shipment (confirmation required) | 5 | E2E |
| AT-16 | Staff records tier, carrier, tracking; customer sees it | 5 | E2E |
| AT-17 | Box content change triggers email + Sheets update | 5, 7 | Integration |
| AT-18 | QBO invoice created from selected lines, appears in portal with all fields, linked to correct lines; failure leaves lines uninvoiced; retry creates no duplicate | 6 | Integration (QBO sandbox) |
| AT-19 | Google Sheet receives one-way copy with no duplicate logical rows after repeated events | 7 | Integration |
| AT-20 | Warehouse event updates correct line without duplication (with mock adapter) | 7 | Integration |
| AT-21 | Customer cannot access another customer's records, even with same company name and guessed IDs | 1, 3, 5, 6 | Integration + E2E |
| AT-22 | Closed products move to/remain in Archive with permanent links | 2 | E2E |
| AT-23 | 10,000+ archive records remain searchable efficiently (target: search p95 < 300 ms server time with 12k records) | 2 | Performance |
| AT-24 | All emails, dashboards and reports respect permissions | 9 | E2E |

---

## 17. Assets and access needed from Silver Stacker

1. High-resolution **logo** and **website banner** source files (the PDF copies are low resolution).
2. Final **Terms & Conditions** text (ORIG text will be used as draft v1).
3. Answers to the decisions in Section 14 (most urgent: D-12 spot pricing, D-13 timezone, D-4/D-5 shipping, D-14 order numbers, D-11 warehouse, D-10 archive source).
4. **QuickBooks Online** sandbox access (Intuit developer app) and later production company admin for OAuth connect.
5. **Google Cloud** project for a service account, and the master Google Sheet to share with it.
6. Email sending domain and provider (with DNS access for SPF/DKIM/DMARC).
7. Hosting choice (D-22) and a staging site.
8. A sample of archive data (CSV/Excel + photo folder) to finalize the import mapping.
9. Facebook group link confirmation for sign-up question 5.
