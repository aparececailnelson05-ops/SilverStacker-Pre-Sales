# Deployment and Go-Live Checklist

## 1. Hosting

Use a managed WordPress host, or a VPS you control, that gives you all of the following:

- PHP 8.1+ (8.3 recommended), MySQL 8 / MariaDB 10.6+, HTTPS with HSTS
- The ability to add an nginx or Apache rule (section 3)
- A real cron (section 5)
- Daily backups with point-in-time restore
- A staging site for QuickBooks sandbox testing
- Redis object cache (recommended)

## 2. wp-config.php

```php
// 64 hex chars. Generate with: php -r "echo bin2hex(random_bytes(32));"
// Keep a secure copy: it decrypts the stored QuickBooks / Google / warehouse secrets.
define( 'SSP_ENCRYPTION_KEY', 'PASTE_64_HEX_CHARACTERS' );

// Optional but recommended: keep private files outside the web root.
// define( 'SSP_PRIVATE_DIR', '/home/account/ssp-private' );

define( 'DISABLE_WP_CRON', true );   // use the server cron in section 5
define( 'DISALLOW_FILE_EDIT', true );
define( 'FORCE_SSL_ADMIN', true );
define( 'WP_DEBUG', false );
```

If you set `SSP_ENCRYPTION_KEY` after secrets were already saved, you must re-enter them (the QBO client secret, webhook verifier, Google key and warehouse secret).

## 3. Private files (required)

Product images and staff resources are stored in `wp-content/uploads/ss-private/`. The plugin writes an `.htaccess` deny rule for Apache. **On nginx you must add:**

```nginx
location ^~ /wp-content/uploads/ss-private/ { deny all; return 403; }
```

Verify it: `curl -I https://YOURSITE/wp-content/uploads/ss-private/index.php` must return **403**. Images are only served through `/portal/media/...` after the access check. You can also set `SSP_PRIVATE_DIR` to a folder outside the web root, which removes this risk entirely.

## 4. Email (SMTP)

Install an SMTP plugin (e.g. WP Mail SMTP) with Postmark, Amazon SES or SendGrid. Set up SPF, DKIM and DMARC for the sending domain. Then:

- Set **Silver Stacker > Settings > Email**: sender name and address, reply-to, and the staff alert address.
- Review the wording of every template (decision D-7).

Emails are queued as jobs. Failures show in **Integrations** with a Retry button.

## 5. Cron

```
* * * * * cd /path/to/wordpress && wp cron event run --due-now --quiet
```

Each run closes due presales, expires waitlist offers, processes queued jobs (QuickBooks, Google Sheets, warehouse, email), polls QuickBooks Change Data Capture every 15 minutes, and auto-closes delivered boxes.

Closing never depends on cron: ordering is blocked by the server clock at the exact closing time.

## 6. Staff accounts

- Create sales reps in **Settings > Staff & roles**. Reps never get the WordPress administrator role.
- Enforce two-factor authentication for every staff and admin account (e.g. the "Two Factor" plugin).
- Keep WordPress, the theme and all plugins updated. Leave public registration off: **Settings > General > Membership** unchecked. Customers register through `/register/`.

## 7. QuickBooks Online

1. At developer.intuit.com, create an app with the Accounting scope.
2. Add the Redirect URI and the webhook URL. Both are shown in **Integrations > QuickBooks**. Subscribe to the **Invoice** and **Payment** entities.
3. Paste the Client ID, Client Secret and Webhook Verifier Token, choose **Sandbox**, then click **Connect**.
4. Set the **income account ID** (used for auto-created items), the **shipping item ID**, and optionally the **sales term** (for example, due in 3 days).
5. In QuickBooks, enable Automated Sales Tax and online payments (needed for pay links).
6. Run through the whole flow in sandbox. Then switch to **Production** and reconnect.

## 8. Google Sheets (optional reporting copy)

1. In Google Cloud, enable the Sheets API, create a service account and create a JSON key.
2. Create the master spreadsheet and share it with the service account email as Editor.
3. Paste the spreadsheet ID and the JSON key in **Integrations > Google Sheets** and enable it.
4. Click **Rebuild entire sheet** once. After that, updates are incremental. The Sheet is a one-way copy: edits made in the Sheet never change the portal.

## 9. Warehouse

Keep **Manual** until the platform is chosen (decision D-11). The signed webhook adapter and the inbound endpoint are described in **Integrations > Warehouse**.

## 10. Go-live checklist

- [ ] HTTPS everywhere. `/wp-content/uploads/ss-private/` returns 403.
- [ ] `SSP_ENCRYPTION_KEY` set and backed up.
- [ ] Server cron running. **Integrations** shows jobs completing.
- [ ] SMTP delivering, and test emails received.
- [ ] Staff 2FA enforced.
- [ ] Every "Unconfirmed" setting reviewed, and rate tiers marked **Confirmed**.
- [ ] Terms & Conditions final text published.
- [ ] High-resolution logo and banner replaced in `assets/img/` (the current files were extracted from the spec PDF).
- [ ] Order number start set above the last OrderSpace number (D-14).
- [ ] QuickBooks connected in Production; one real invoice tested end to end.
- [ ] Archive CSV imported (dry run first).
- [ ] `tests/acceptance.php` run on **staging** (it creates test data). Do not run it on production.
- [ ] Demo data **not** present on production. Do not run `seed_demo`.
- [ ] Backups verified with a restore test.
