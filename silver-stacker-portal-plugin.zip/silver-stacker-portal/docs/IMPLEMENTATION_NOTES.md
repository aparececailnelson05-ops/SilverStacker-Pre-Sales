# Implementation Notes (Version 1.0.0)

This document maps what was built to the plan in ARCHITECTURE.md. It also lists every place where the build differs from that plan, and why.

## Where things live

| Area | Code |
|---|---|
| Bootstrap, cron, CLI | `silver-stacker-portal.php`, `includes/Plugin.php`, `includes/CLI.php` |
| Schema (33 tables), roles, settings, encryption | `includes/Core/Installer.php`, `Roles.php`, `Settings.php`, `Crypto.php` |
| Privacy gate (site-wide), private media | `includes/Core/Security.php`, `includes/Portal/Router.php`, `includes/Core/Media.php` |
| Audit log (append-only), job queue, events, email | `includes/Core/Audit.php`, `Jobs.php`, `Events.php`, `Mailer.php` |
| Accounts, terms, addresses | `includes/Domain/Customers.php`, `Terms.php`, `Addresses.php` |
| Catalog, ETA, countdown, search, archive | `includes/Domain/Catalog.php` |
| Cart, orders, allocation, waitlist | `includes/Domain/Cart.php`, `Orders.php`, `Allocation.php`, `Waitlist.php` |
| Box and shipments | `includes/Domain/Boxes.php`, `Shipments.php` |
| Invoices, reports, tracker | `includes/Domain/Invoices.php`, `Reports.php`, `Tracker.php` |
| QuickBooks, Google Sheets, warehouse | `includes/Integrations/Qbo.php`, `Sheets.php`, `Warehouse.php`, `Listeners.php` |
| Customer pages | `includes/Portal/Pages.php` (GET), `Actions.php` (POST), `templates/` |
| Staff console | `includes/Admin/*Screen.php`, `Handlers.php` |

## Differences from the plan (all deliberate)

1. **Products are stored in custom tables, not a custom post type.** Products never pass through WordPress's public post machinery (queries, feeds, REST, sitemaps, attachments). That removes a whole class of leak risks. Revisions are replaced by the audit log, which records every field change.
2. **Product images are not in the Media Library.** They are stored in a private folder and streamed only after the access check. Visitors get a 404, even with a direct link.
3. **The staff console is server-rendered PHP inside wp-admin, not a React app.** This means no build step and no JavaScript bundle to maintain. Every list has search, filters and pagination, and the screens work on a tablet.
4. **The job queue is built in, instead of using the Action Scheduler library.** The job table has idempotency keys, retries with backoff, a "dead" state for errors that need human action, and a staff Retry button. There is no third-party dependency.
5. **ETA and closing date are per product.** There is no per-variant override (D-26 default). This can be added later without changing the data already stored.
6. **Customer actions are standard form posts with nonces (Post/Redirect/Get).** A small REST API serves the cart count and search suggestions. Pages work without JavaScript; JavaScript only adds live countdowns, the swipe gallery and dialogs.
7. **Warehouse integration ships two adapters.** *Manual* (the default) and a *signed webhook* adapter (outbound and inbound) that works with any platform or middleware. A native adapter can be added once D-11 is decided.
8. **Staff-entered orders are not supported.** This follows REV2 §2.5 / §12.34 and D-18: staff can invite customers, but every order is submitted by the customer on the website.
9. **Invoices can be "recorded manually".** This is a fallback for invoices already created by hand in QuickBooks, or for use before QuickBooks is connected. Manually recorded invoices never show as Paid, because only QuickBooks sync can mark an invoice paid.

## Business rules applied as configurable defaults

Each of these appears under **Settings > Open decisions**, with its current value. Change them in Settings; no code changes are needed.

- **D-1** Waitlist: hold freed allocation for 48 hours for the next customer in line (first in, first out). The *notify everyone* and *auto-reserve* modes are also built.
- **D-2** One open box per customer.
  - After a shipment request, new "Add to Box" items open a new box.
  - Items that have not arrived are carried into that new box.
  - Cancelling a shipment request merges the boxes back together.
- **D-3** Customers can change the box address until staff starts preparing the box. Staff can change it at any time before shipping.
- **D-4** Rate tiers are pre-loaded from the original Terms ($6, $9, $9 Build A Box) and flagged *unconfirmed*.
- **D-5** Shipping is added in the invoice wizard. Staff can link the charge to a specific shipment.
- **D-6** Setting a quantity to 0 before closing cancels the line. After closing, only staff can change quantities, and a reason is required.
- **D-9** In-stock items follow the same workflow as presale items. Customers can edit an in-stock line until staff marks it available.
- **D-12** Spot-based offers show "Spot + $X". Staff enters the final unit price in the invoice wizard, and the override is audited.
- **D-13** Closing time defaults to 11:59 PM America/Chicago. All data is stored in UTC.
- **D-14** Order numbers start at 15000. Set this above the last OrderSpace number before go-live.
- **D-15** Customers always see an on-screen confirmation. The confirmation email is off by default. The wording of sign-up question 8 was updated to say "Submit Pre-Order".
- **D-19** When some items have not arrived, the customer chooses: ship the arrived items now, or wait for everything.
- **D-23** Sales reps see the history on each record. The full audit log is for admins only, with a toggle to give reps access.
- **D-27** The minimum quantity applies to the customer's total for an item, across all their orders.
- **D-30** One QuickBooks item per SKU, created automatically. A single generic item is also supported.

## How key guarantees are enforced

- **Privacy**
  - Every portal request goes through the Router gate: logged in, approved and current Terms accepted.
  - All other WordPress URLs redirect to `/login`.
  - Visitors cannot use the REST API (except signed webhooks); customers can only use the `ssp/v1` routes.
  - Feeds, sitemaps, XML-RPC, oEmbed and site search are disabled, and `noindex` is sent on every page.
- **Ownership**
  - Every customer query is scoped with `user_id = current user`.
  - Objects are looked up by their public ID together with the owner, and a mismatch returns 404.
  - This is tested with two customers who share the same company name.
- **No overselling**
  - Variant rows are locked (`SELECT ... FOR UPDATE`) inside a transaction while limits are checked.
  - Every reservation change is written to an allocation ledger, and `wp ssp reconcile` can verify the totals.
  - This is tested with 8 parallel processes ordering at once.
- **Idempotency**
  - Order submission uses a submit key, so a double-click cannot create two orders.
  - Each invoice gets one idempotency key and one QuickBooks `requestid`, which is reused on every retry.
  - QuickBooks webhooks and warehouse events are de-duplicated.
  - Google Sheets rows are updated in place, keyed by a stable ID in column A.
- **Never marked invoiced on failure**
  - When an invoice job starts, the quantities move to *pending*. They become *invoiced* only after QuickBooks confirms.
  - If QuickBooks fails, the quantities stay pending (so they cannot be selected twice) until staff clicks Retry or Cancel.

## Known limitations

- The logo and banner were extracted from the spec PDF at low resolution. Replace `assets/img/logo.png` and `assets/img/banner.jpg` with the original files.
- SMS notifications are not sent (D-16). Customer consent is stored.
- QuickBooks and Google Sheets were tested against simulated APIs. A sandbox run is required before go-live (DEPLOYMENT.md).
- Fonts load from Google Fonts. If that is blocked, pages fall back to system fonts.
