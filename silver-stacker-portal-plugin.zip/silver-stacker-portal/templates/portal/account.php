<?php
/**
 * @var object $profile
 * @var array  $acceptances
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;

if ( ! $profile ) {
	echo '<div class="ssp-card"><h1>Staff account</h1><p>Staff profiles are managed in the staff console.</p></div>';
	return;
}
?>
<div class="ssp-pagehead"><div><h1>My Account</h1><p>Customer ID <?php echo esc_html( $profile->customer_uid ); ?> &middot; Member since <?php echo esc_html( Util::fmt_date( $profile->created_at ) ); ?></p></div></div>
<div class="ssp-grid ssp-grid--2">
	<div class="ssp-card">
		<h2>Profile</h2>
		<form method="post" action="<?php echo esc_url( ssp_url( 'account/' ) ); ?>">
			<?php ssp_form_fields( 'account_save' ); ?>
			<div class="ssp-field"><label for="c-name">Contact name</label><input id="c-name" type="text" name="contact_name" value="<?php echo esc_attr( $profile->contact_name ); ?>" required></div>
			<div class="ssp-field"><label for="c-co">Company or store name</label><input id="c-co" type="text" name="company_name" value="<?php echo esc_attr( $profile->company_name ); ?>" required></div>
			<div class="ssp-field"><label for="c-ph">Phone</label><input id="c-ph" type="tel" name="phone" value="<?php echo esc_attr( $profile->phone ); ?>" required></div>
			<div class="ssp-field"><span class="ssp-label">Email</span><span><?php echo esc_html( $profile->email ); ?></span><span class="ssp-help">Contact us to change your login email.</span></div>
			<label class="ssp-check"><input type="checkbox" name="email_consent" value="1" <?php checked( $profile->email_consent ); ?>> Email me about invoices and shipments</label>
			<label class="ssp-check"><input type="checkbox" name="sms_consent" value="1" <?php checked( $profile->sms_consent ); ?>> Text me when my items are ready to ship</label>
			<button class="ssp-btn ssp-btn--primary ssp-mt" type="submit">Save profile</button>
		</form>
	</div>
	<div>
		<div class="ssp-card">
			<h2>Change password</h2>
			<form method="post" action="<?php echo esc_url( ssp_url( 'account/' ) ); ?>">
				<?php ssp_form_fields( 'password_change' ); ?>
				<div class="ssp-field"><label for="pw0">Current password</label><input id="pw0" type="password" name="current" autocomplete="current-password" required></div>
				<div class="ssp-field"><label for="pw1">New password</label><input id="pw1" type="password" name="pass1" minlength="10" autocomplete="new-password" required></div>
				<div class="ssp-field"><label for="pw2">Confirm new password</label><input id="pw2" type="password" name="pass2" minlength="10" autocomplete="new-password" required></div>
				<button class="ssp-btn ssp-btn--primary" type="submit">Change password</button>
			</form>
		</div>
		<div class="ssp-card">
			<h2>Terms accepted</h2>
			<ul>
				<?php foreach ( $acceptances as $a ) : ?>
					<li>Version <?php echo esc_html( $a->version_label ); ?> on <?php echo esc_html( Util::fmt_dt( $a->accepted_at ) ); ?></li>
				<?php endforeach; ?>
			</ul>
			<a href="<?php echo esc_url( ssp_url( 'terms/' ) ); ?>">View Terms &amp; Conditions</a>
		</div>
	</div>
</div>
