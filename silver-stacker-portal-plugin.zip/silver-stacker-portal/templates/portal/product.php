<?php
/**
 * Product detail (also the permanent Archive listing).
 *
 * @var object $p
 * @var array  $variants
 * @var array  $images
 * @var array  $info
 * @var bool   $orderable
 * @var bool   $is_customer
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Catalog;
use SSP\Domain\Orders;

$ssp_life = Catalog::effective_lifecycle( $p );
$ssp_supplier = Catalog::supplier_name( $p->supplier_id );
?>
<nav class="ssp-small ssp-muted" aria-label="Breadcrumb" style="margin-bottom:12px">
	<a href="<?php echo esc_url( ssp_url() ); ?>">Home</a> /
	<?php if ( 'archived' === $ssp_life ) : ?>
		<a href="<?php echo esc_url( ssp_url( 'archive/' ) ); ?>">The Archive</a>
	<?php elseif ( 'in_stock' === $ssp_life ) : ?>
		<a href="<?php echo esc_url( ssp_url( 'in-stock/' ) ); ?>">In-Stock</a>
	<?php else : ?>
		<a href="<?php echo esc_url( ssp_url( 'shop/' ) ); ?>">Pre-Sales</a>
	<?php endif; ?>
	/ <?php echo esc_html( $p->name ); ?>
</nav>

<div class="ssp-product" data-orderable>
	<div>
		<div class="ssp-gallery" data-gallery tabindex="0" aria-label="Product images. Swipe or use arrow keys.">
			<div class="ssp-gallery__track">
				<?php if ( $images ) : ?>
					<?php foreach ( $images as $i => $img ) : ?>
						<div class="ssp-gallery__slide"><img src="<?php echo esc_url( Catalog::image_url( $img, 'large' ) ); ?>" alt="<?php echo esc_attr( $img->alt ? $img->alt : $p->name . ' image ' . ( $i + 1 ) ); ?>" <?php echo $i ? 'loading="lazy"' : ''; ?>></div>
					<?php endforeach; ?>
				<?php else : ?>
					<div class="ssp-gallery__slide"><img src="<?php echo esc_url( Catalog::image_url( null ) ); ?>" alt=""></div>
				<?php endif; ?>
			</div>
			<?php if ( count( $images ) > 1 ) : ?>
				<div class="ssp-gallery__nav">
					<button type="button" class="ssp-gallery__arrow" data-gallery-prev aria-label="Previous image">&#8249;</button>
					<div class="ssp-gallery__dots">
						<?php foreach ( $images as $i => $img ) : ?><button type="button" aria-label="Image <?php echo (int) ( $i + 1 ); ?>"></button><?php endforeach; ?>
					</div>
					<span class="ssp-small ssp-muted" data-gallery-count>1 / <?php echo count( $images ); ?></span>
					<button type="button" class="ssp-gallery__arrow" data-gallery-next aria-label="Next image">&#8250;</button>
				</div>
				<div class="ssp-gallery__thumbs">
					<?php foreach ( $images as $i => $img ) : ?>
						<button type="button" aria-label="Show image <?php echo (int) ( $i + 1 ); ?>"><img src="<?php echo esc_url( Catalog::image_url( $img, 'thumb' ) ); ?>" alt="" loading="lazy"></button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>

	<div>
		<div class="ssp-flex" style="margin-bottom:8px">
			<?php echo ssp_badge( Catalog::lifecycle_label( $p ), ssp_status_kind( $ssp_life ) ); // phpcs:ignore ?>
			<?php if ( $p->metal ) { echo ssp_badge( $p->metal, 'neutral' ); } // phpcs:ignore ?>
			<?php if ( 'spot_based' === $p->price_type ) { echo ssp_badge( 'Spot-based offer', 'warn' ); } // phpcs:ignore ?>
		</div>
		<h1><?php echo esc_html( Catalog::display_name( $p ) ); ?></h1>

		<?php if ( 'presale' === $p->lifecycle && $p->closing_at ) : ?>
			<p><?php echo ssp_countdown( $p->closing_at, true ); // phpcs:ignore ?></p>
			<p class="ssp-small ssp-muted">Orders close <?php echo esc_html( Util::fmt_dt( $p->closing_at, 'l, M j, Y \a\t g:i A T' ) ); ?>.</p>
		<?php endif; ?>
		<?php if ( 'archived' !== $ssp_life && Catalog::eta_label( $p ) ) : ?>
			<p><?php echo ssp_eta( $p, true ); // phpcs:ignore ?></p>
			<p class="ssp-note">The estimated arrival is provided by the mint/supplier and is not a guaranteed delivery date.</p>
		<?php endif; ?>

		<dl class="ssp-kv">
			<?php if ( $p->brand ) : ?><dt>Brand / Mint</dt><dd><?php echo esc_html( $p->brand ); ?></dd><?php endif; ?>
			<?php if ( $p->category ) : ?><dt>Category</dt><dd><?php echo esc_html( $p->category ); ?></dd><?php endif; ?>
			<?php if ( $p->mintage ) : ?><dt>Mintage</dt><dd><?php echo esc_html( $p->mintage ); ?></dd><?php endif; ?>
			<?php if ( 1 === count( $variants ) ) : ?><dt>SKU</dt><dd><?php echo esc_html( $variants[0]->sku ); ?></dd><?php endif; ?>
		</dl>

		<?php if ( 'archived' === $ssp_life ) : ?>
			<div class="ssp-alert ssp-alert--info"><div>This is an archived listing kept for reference. It is not available to order.</div></div>
		<?php endif; ?>

		<?php foreach ( $variants as $v ) : ?>
			<?php $ssp_i = $info[ $v->id ]; ?>
			<div class="ssp-variant">
				<div class="ssp-variant__head">
					<div>
						<?php if ( count( $variants ) > 1 ) : ?><strong><?php echo esc_html( $v->label ? $v->label : $v->sku ); ?></strong><br><?php endif; ?>
						<span class="ssp-small ssp-muted">SKU <?php echo esc_html( $v->sku ); ?><?php echo $v->barcode ? ' &middot; Barcode ' . esc_html( $v->barcode ) : ''; ?></span>
					</div>
					<?php if ( 'archived' !== $ssp_life ) : ?>
						<div class="ssp-variant__price"><?php echo esc_html( Catalog::price_label( $v, $p ) ); ?></div>
					<?php endif; ?>
				</div>
				<?php if ( $orderable && $is_customer ) : ?>
					<p class="ssp-small ssp-muted" style="margin:6px 0">
						<?php if ( (int) $v->min_order_qty > 1 ) : ?>Minimum <?php echo (int) $v->min_order_qty; ?>. <?php endif; ?>
						<?php if ( null !== $v->per_customer_allocation ) : ?>Limit <?php echo (int) $v->per_customer_allocation; ?> per customer. <?php endif; ?>
						<?php if ( $ssp_i['mine'] ) : ?>You have <?php echo (int) $ssp_i['mine']; ?> reserved. <?php endif; ?>
						<?php if ( 'full' === $ssp_i['label'][0] ) : ?><strong>Fully allocated.</strong><?php elseif ( 'low' === $ssp_i['label'][0] ) : ?><strong>Limited allocation remaining.</strong><?php endif; ?>
					</p>
					<?php if ( null === $ssp_i['max'] || $ssp_i['max'] > 0 ) : ?>
						<form method="post" action="<?php echo esc_url( Catalog::url( $p ) ); ?>">
							<?php ssp_form_fields( 'cart_add' ); ?>
							<input type="hidden" name="variant_id" value="<?php echo (int) $v->id; ?>">
							<div class="ssp-field">
								<span class="ssp-label">Quantity</span>
								<span class="ssp-qty">
									<button type="button" data-qty-step="-1" aria-label="Decrease quantity" data-order-control>&minus;</button>
									<input type="number" name="qty" value="<?php echo (int) max( 1, $v->min_order_qty ); ?>" min="1" <?php echo null !== $ssp_i['max'] ? 'max="' . (int) $ssp_i['max'] . '"' : ''; ?> aria-label="Quantity" data-order-control>
									<button type="button" data-qty-step="1" aria-label="Increase quantity" data-order-control>+</button>
								</span>
							</div>
							<fieldset class="ssp-field" style="border:0;padding:0;margin:0 0 12px">
								<legend class="ssp-label">When it arrives</legend>
								<div class="ssp-radios">
									<?php foreach ( Orders::FULFILLMENT as $ssp_k => $ssp_lbl ) : ?>
										<label class="ssp-radio"><input type="radio" name="fulfillment" value="<?php echo esc_attr( $ssp_k ); ?>" <?php checked( \SSP\Core\Settings::get( 'default_fulfillment_choice' ), $ssp_k ); ?> data-order-control>
											<span><?php echo esc_html( $ssp_lbl ); ?>
											<small><?php echo esc_html( array( 'box' => 'Hold it in your Build A Box with your other items and ship everything together later.', 'separate' => 'Ship this item on its own as soon as it is available.', 'decide_later' => 'Choose later from My Orders or My Box.' )[ $ssp_k ] ); ?></small></span>
										</label>
									<?php endforeach; ?>
								</div>
							</fieldset>
							<button class="ssp-btn ssp-btn--primary ssp-btn--lg ssp-btn--block" type="submit" data-order-control>Add to Order</button>
							<p class="ssp-note" data-ended-msg hidden>Pre-Sale Ended. This item can no longer be ordered.</p>
						</form>
					<?php endif; ?>
					<?php if ( null !== $ssp_i['max'] ) : ?>
						<?php if ( $ssp_i['waitlist'] ) : ?>
							<p class="ssp-small"><?php echo ssp_badge( 'On waitlist', 'warn' ); // phpcs:ignore ?> You are waitlisted for <?php echo (int) $ssp_i['waitlist']->qty_requested; ?>. <a href="<?php echo esc_url( ssp_url( 'waitlist/' ) ); ?>">Manage waitlist</a></p>
						<?php else : ?>
							<details class="ssp-mt" <?php echo 0 === $ssp_i['max'] ? 'open' : ''; ?>>
								<summary class="ssp-small"><strong><?php echo 0 === $ssp_i['max'] ? 'Join the waitlist' : 'Want more than is available? Join the waitlist'; ?></strong></summary>
								<form method="post" action="<?php echo esc_url( Catalog::url( $p ) ); ?>" class="ssp-flex ssp-mt">
									<?php ssp_form_fields( 'waitlist_join' ); ?>
									<input type="hidden" name="variant_id" value="<?php echo (int) $v->id; ?>">
									<label class="ssp-small" for="wl-<?php echo (int) $v->id; ?>">Quantity wanted</label>
									<input id="wl-<?php echo (int) $v->id; ?>" type="number" name="qty" value="<?php echo (int) max( 1, $ssp_i['max'] + 1 ); ?>" min="1" style="width:90px" data-order-control>
									<button class="ssp-btn ssp-btn--ghost ssp-btn--sm" type="submit" data-order-control>Join waitlist</button>
								</form>
							</details>
						<?php endif; ?>
					<?php endif; ?>
				<?php elseif ( 'presale_ended' === $ssp_life ) : ?>
					<p class="ssp-small"><strong>Pre-Sale Ended.</strong> New orders and quantity increases are closed for this item.</p>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>

		<?php if ( 'spot_based' === $p->price_type ) : ?>
			<div class="ssp-alert ssp-alert--warn"><div>This is a <strong>spot-based offer</strong>. The final price is based on the metal spot price as described in the details below and is confirmed on your invoice.</div></div>
		<?php endif; ?>

		<div class="ssp-card ssp-specs">
			<h2>Details &amp; specifications</h2>
			<?php echo $p->description ? wp_kses_post( wpautop( $p->description ) ) : '<p class="ssp-muted">No additional details yet.</p>'; // phpcs:ignore ?>
		</div>
	</div>
</div>
