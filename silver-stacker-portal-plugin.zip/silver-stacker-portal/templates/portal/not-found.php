<?php
/** @var string $message */
defined( 'ABSPATH' ) || exit;
?>
<div class="ssp-card ssp-empty">
	<h1>Not found</h1>
	<p><?php echo esc_html( $message ); ?></p>
	<a class="ssp-btn ssp-btn--primary" href="<?php echo esc_url( ssp_url() ); ?>">Go to dashboard</a>
</div>
