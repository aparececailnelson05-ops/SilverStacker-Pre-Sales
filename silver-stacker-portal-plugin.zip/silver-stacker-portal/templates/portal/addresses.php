<?php
/**
 * @var array       $addresses
 * @var array       $billing
 * @var object|null $edit
 */
defined( 'ABSPATH' ) || exit;

use SSP\Domain\Addresses;

$ssp_v = function ( $f ) use ( $edit ) {
	return esc_attr( $edit ? $edit->$f : '' );
};
?>
<div class="ssp-pagehead"><div><h1>Shipping Addresses</h1><p>Your default shipping address is automatically used for your open box.</p></div></div>
<div class="ssp-grid ssp-grid--2">
	<div>
		<?php foreach ( $addresses as $a ) : ?>
			<div class="ssp-card">
				<div class="ssp-between">
					<strong><?php echo esc_html( $a->label ? $a->label : 'Shipping address' ); ?></strong>
					<?php echo $a->is_default ? ssp_badge( 'Default', 'brand' ) : ''; // phpcs:ignore ?>
				</div>
				<p><?php echo nl2br( esc_html( Addresses::format( $a ) ) ); ?></p>
				<div class="ssp-flex">
					<a class="ssp-btn ssp-btn--ghost ssp-btn--sm" href="<?php echo esc_url( add_query_arg( 'edit', (int) $a->id, ssp_url( 'addresses/' ) ) ); ?>">Edit</a>
					<?php if ( ! $a->is_default ) : ?>
						<form method="post" action="<?php echo esc_url( ssp_url( 'addresses/' ) ); ?>"><?php ssp_form_fields( 'address_default' ); ?><input type="hidden" name="address_id" value="<?php echo (int) $a->id; ?>"><button class="ssp-btn ssp-btn--ghost ssp-btn--sm" type="submit">Make default</button></form>
						<form method="post" action="<?php echo esc_url( ssp_url( 'addresses/' ) ); ?>"><?php ssp_form_fields( 'address_delete' ); ?><input type="hidden" name="address_id" value="<?php echo (int) $a->id; ?>"><button class="ssp-btn ssp-btn--danger ssp-btn--sm" type="submit">Remove</button></form>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
		<?php foreach ( $billing as $a ) : ?>
			<div class="ssp-card">
				<div class="ssp-between"><strong>Billing address</strong><a class="ssp-btn ssp-btn--ghost ssp-btn--sm" href="<?php echo esc_url( add_query_arg( 'edit', (int) $a->id, ssp_url( 'addresses/' ) ) ); ?>">Edit</a></div>
				<p><?php echo nl2br( esc_html( Addresses::format( $a ) ) ); ?></p>
			</div>
		<?php endforeach; ?>
	</div>
	<div class="ssp-card">
		<h2><?php echo $edit ? 'Edit address' : 'Add a shipping address'; ?></h2>
		<form method="post" action="<?php echo esc_url( ssp_url( 'addresses/' ) ); ?>">
			<?php ssp_form_fields( 'address_save' ); ?>
			<input type="hidden" name="address_id" value="<?php echo $edit ? (int) $edit->id : 0; ?>">
			<input type="hidden" name="type" value="<?php echo $edit ? esc_attr( $edit->type ) : 'shipping'; ?>">
			<div class="ssp-field"><label for="a-label">Label (optional)</label><input id="a-label" type="text" name="address[label]" value="<?php echo $ssp_v( 'label' ); // phpcs:ignore ?>" placeholder="e.g. Store, Home"></div>
			<div class="ssp-row">
				<div class="ssp-field"><label for="a-name">Full name</label><input id="a-name" type="text" name="address[name]" value="<?php echo $ssp_v( 'name' ); // phpcs:ignore ?>" required></div>
				<div class="ssp-field"><label for="a-company">Company</label><input id="a-company" type="text" name="address[company]" value="<?php echo $ssp_v( 'company' ); // phpcs:ignore ?>"></div>
			</div>
			<div class="ssp-field"><label for="a-l1">Street address</label><input id="a-l1" type="text" name="address[line1]" value="<?php echo $ssp_v( 'line1' ); // phpcs:ignore ?>" required></div>
			<div class="ssp-field"><label for="a-l2">Apartment, suite (optional)</label><input id="a-l2" type="text" name="address[line2]" value="<?php echo $ssp_v( 'line2' ); // phpcs:ignore ?>"></div>
			<div class="ssp-row">
				<div class="ssp-field"><label for="a-city">City</label><input id="a-city" type="text" name="address[city]" value="<?php echo $ssp_v( 'city' ); // phpcs:ignore ?>" required></div>
				<div class="ssp-field"><label for="a-state">State</label><input id="a-state" type="text" name="address[state]" value="<?php echo $ssp_v( 'state' ); // phpcs:ignore ?>" required></div>
				<div class="ssp-field"><label for="a-zip">ZIP</label><input id="a-zip" type="text" name="address[postal_code]" value="<?php echo $ssp_v( 'postal_code' ); // phpcs:ignore ?>" required></div>
			</div>
			<div class="ssp-field"><label for="a-phone">Phone (optional)</label><input id="a-phone" type="tel" name="address[phone]" value="<?php echo $ssp_v( 'phone' ); // phpcs:ignore ?>"></div>
			<input type="hidden" name="address[country]" value="US">
			<?php if ( ! $edit ) : ?><label class="ssp-check"><input type="checkbox" name="make_default" value="1"> Make this my default shipping address</label><?php endif; ?>
			<div class="ssp-flex ssp-mt"><button class="ssp-btn ssp-btn--primary" type="submit">Save address</button><?php if ( $edit ) : ?><a href="<?php echo esc_url( ssp_url( 'addresses/' ) ); ?>">Cancel</a><?php endif; ?></div>
		</form>
	</div>
</div>
