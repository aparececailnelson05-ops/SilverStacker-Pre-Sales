<?php
/**
 * @var array       $closing
 * @var array       $counts
 * @var object|null $box
 * @var array|null  $box_tot
 * @var array       $recent
 * @var array       $invoices
 * @var array       $offers
 * @var object|null $profile
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Boxes;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Catalog;

$ssp_is_customer = \SSP\Core\Roles::is_customer();
?>
<div class="ssp-hero"><img src="<?php echo esc_url( SSP_URL . 'assets/img/banner.jpg' ); ?>" alt="Silver Stacker, Texas Coin Company. Silver. Gold. Bullion."></div>

<div class="ssp-pagehead">
	<div>
		<h1>Welcome<?php echo $profile ? ', ' . esc_html( $profile->contact_name ) : ''; ?></h1>
		<p><?php echo esc_html( \SSP\Core\Settings::get( 'announcement' ) ); ?></p>
	</div>
	<a class="ssp-btn ssp-btn--accent" href="<?php echo esc_url( ssp_url( 'shop/' ) ); ?>">Shop current pre-sales</a>
</div>

<?php if ( $offers ) : ?>
	<div class="ssp-alert ssp-alert--success" role="status"><div><strong>Good news:</strong> allocation opened up for <?php echo count( $offers ); ?> item(s) on your waitlist. <a href="<?php echo esc_url( ssp_url( 'waitlist/' ) ); ?>">Review the offer</a></div></div>
<?php endif; ?>

<?php if ( $ssp_is_customer ) : ?>
<div class="ssp-stats">
	<a class="ssp-stat" href="<?php echo esc_url( ssp_url( 'shop/' ) ); ?>" style="text-decoration:none"><b><?php echo (int) $counts['active']; ?></b><span>Active offers</span></a>
	<a class="ssp-stat" href="<?php echo esc_url( ssp_url( 'box/' ) ); ?>" style="text-decoration:none"><b><?php echo (int) ( $box_tot['units'] ?? 0 ); ?></b><span>Items in My Box<?php echo $box_tot ? ' (' . (int) $box_tot['available'] . ' arrived)' : ''; ?></span></a>
	<a class="ssp-stat" href="<?php echo esc_url( ssp_url( 'orders/' ) ); ?>" style="text-decoration:none"><b><?php echo count( $recent ); ?></b><span>Recent orders</span></a>
	<a class="ssp-stat" href="<?php echo esc_url( ssp_url( 'invoices/' ) ); ?>" style="text-decoration:none"><b><?php echo count( $invoices ); ?></b><span>Open invoices</span></a>
</div>
<?php endif; ?>

<div class="ssp-card">
	<div class="ssp-card__title"><h2 class="ssp-mb0">Closing soon</h2><a href="<?php echo esc_url( ssp_url( 'shop/' ) ); ?>">See all pre-sales</a></div>
	<?php if ( $closing ) : ?>
		<div class="ssp-products">
			<?php foreach ( $closing as $p ) : ?>
				<?php \SSP\Portal\View::partial( 'product-card', array( 'p' => $p, 'is_customer' => $ssp_is_customer ) ); ?>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<div class="ssp-empty"><?php echo ssp_icon( 'stack' ); // phpcs:ignore ?><p>No pre-sales are open right now. New offers are announced in our Facebook group.</p></div>
	<?php endif; ?>
</div>

<?php if ( $ssp_is_customer ) : ?>
<div class="ssp-grid ssp-grid--2 ssp-mt">
	<div class="ssp-card">
		<div class="ssp-card__title"><h2 class="ssp-mb0">Recent orders</h2><a href="<?php echo esc_url( ssp_url( 'orders/' ) ); ?>">All orders</a></div>
		<?php if ( $recent ) : ?>
			<div class="ssp-tablewrap"><table class="ssp-table">
				<thead><tr><th>Order</th><th>Date</th><th>Status</th><th class="num">Total</th></tr></thead>
				<tbody>
				<?php foreach ( array_slice( $recent, 0, 6 ) as $o ) : ?>
					<tr>
						<td><a href="<?php echo esc_url( ssp_url( 'orders/' . $o->order_number . '/' ) ); ?>">#<?php echo (int) $o->order_number; ?></a></td>
						<td><?php echo esc_html( Util::fmt_date( $o->submitted_at ) ); ?></td>
						<td><?php echo ssp_badge( Orders::ORDER_STATUSES[ $o->status ] ?? $o->status, ssp_status_kind( $o->status ) ); // phpcs:ignore ?></td>
						<td class="num"><?php echo esc_html( Util::money( $o->subtotal_usd ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
		<?php else : ?>
			<p class="ssp-muted">You have not placed any pre-orders yet.</p>
		<?php endif; ?>
	</div>
	<div class="ssp-card">
		<div class="ssp-card__title"><h2 class="ssp-mb0">My Box</h2><a href="<?php echo esc_url( ssp_url( 'box/' ) ); ?>">Open My Box</a></div>
		<?php if ( $box && $box_tot['lines'] ) : ?>
			<p>Box #<?php echo (int) $box->box_number; ?> holds <strong><?php echo (int) $box_tot['units']; ?></strong> item(s) from your orders. <strong><?php echo (int) $box_tot['available']; ?></strong> have arrived.</p>
			<p class="ssp-muted ssp-small">Keep adding items from different pre-orders and request one consolidated shipment when you are ready.</p>
		<?php else : ?>
			<p class="ssp-muted">Your box is empty. Choose "Add to My Box" when you order to consolidate items and save on shipping.</p>
		<?php endif; ?>
		<?php if ( $invoices ) : ?>
			<h3 class="ssp-mt">Open invoices</h3>
			<ul>
				<?php foreach ( $invoices as $i ) : ?>
					<li>Invoice <?php echo esc_html( $i->doc_number ); ?>: <?php echo esc_html( Util::money( $i->balance_usd ) ); ?> due <?php echo esc_html( Util::fmt_date( $i->due_date ) ); ?> <?php echo ssp_badge( Invoices::payment_label( $i ), ssp_status_kind( $i->sync_status ) ); // phpcs:ignore ?></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>
