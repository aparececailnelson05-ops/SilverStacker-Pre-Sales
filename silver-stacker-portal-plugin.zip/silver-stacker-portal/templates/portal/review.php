<?php
/**
 * Review & Submit Pre-Order (no payment).
 *
 * @var array  $rows
 * @var float  $total
 * @var string $submit_key
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Catalog;
use SSP\Domain\Orders;
?>
<div class="ssp-pagehead"><div><h1>Review &amp; Submit Pre-Order</h1><p>Please check your items. Nothing is charged today.</p></div><a href="<?php echo esc_url( ssp_url( 'cart/' ) ); ?>">Back to cart</a></div>
<div class="ssp-grid ssp-grid--review">
	<div class="ssp-card">
		<div class="ssp-tablewrap"><table class="ssp-table ssp-table--stack">
			<thead><tr><th>Item</th><th>ETA</th><th>When it arrives</th><th class="num">Qty</th><th class="num">Price</th><th class="num">Total</th></tr></thead>
			<tbody>
			<?php foreach ( $rows as $r ) : ?>
				<tr>
					<td class="ssp-cell-item"><div class="ssp-item"><img class="ssp-thumb" src="<?php echo esc_url( Catalog::image_url( $r['img'], 'thumb' ) ); ?>" alt=""><div><strong><?php echo esc_html( Catalog::display_name( $r['p'] ) . ( $r['v']->label ? ' - ' . $r['v']->label : '' ) ); ?></strong><div class="ssp-small"><?php echo 'presale' === $r['p']->lifecycle ? ssp_countdown( $r['p']->closing_at ) : ''; // phpcs:ignore ?></div></div></div></td>
					<td data-label="ETA"><?php echo esc_html( Catalog::eta_label( $r['p'] ) ? Catalog::eta_label( $r['p'] ) : 'TBD' ); ?></td>
					<td data-label="When it arrives"><?php echo esc_html( Orders::FULFILLMENT[ $r['item']->fulfillment_choice ] ?? '' ); ?></td>
					<td class="num" data-label="Qty"><?php echo (int) $r['item']->qty; ?></td>
					<td class="num" data-label="Price"><?php echo esc_html( Catalog::price_label( $r['v'], $r['p'] ) ); ?></td>
					<td class="num" data-label="Total"><?php echo esc_html( Util::money( (int) $r['item']->qty * (float) $r['v']->price_usd ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
	</div>
	<div class="ssp-card">
		<h2>Summary</h2>
		<dl class="ssp-kv"><dt>Estimated subtotal</dt><dd><?php echo esc_html( Util::money( $total ) ); ?></dd><dt>Due today</dt><dd><strong>$0.00</strong></dd></dl>
		<p class="ssp-small ssp-muted">Tax and shipping are calculated on your QuickBooks invoice when items arrive. All orders are final pending allocations and final mint availability.</p>
		<form method="post" action="<?php echo esc_url( ssp_url( 'cart/review/' ) ); ?>" data-once>
			<?php ssp_form_fields( 'submit_order' ); ?>
			<input type="hidden" name="submit_key" value="<?php echo esc_attr( $submit_key ); ?>">
			<div class="ssp-field"><label for="note">Note for Silver Stacker (optional)</label><textarea id="note" name="customer_note" rows="3" maxlength="1000"></textarea></div>
			<button class="ssp-btn ssp-btn--accent ssp-btn--lg ssp-btn--block" type="submit">Submit Pre-Order</button>
		</form>
		<p class="ssp-note ssp-mt">You will see a confirmation page with your order number once your pre-order is submitted.</p>
	</div>
</div>
