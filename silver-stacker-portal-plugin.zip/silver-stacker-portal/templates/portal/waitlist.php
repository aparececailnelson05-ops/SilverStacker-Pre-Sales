<?php
/** @var array $rows */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Catalog;
use SSP\Domain\Orders;
use SSP\Domain\Waitlist;
?>
<div class="ssp-pagehead"><div><h1>Waitlist</h1><p>When an item is fully allocated you can join its waitlist. We email you if allocation opens up.</p></div></div>
<?php if ( ! $rows ) : ?>
	<div class="ssp-card ssp-empty"><?php echo ssp_icon( 'heart' ); // phpcs:ignore ?><p>You are not on any waitlists.</p></div>
<?php else : ?>
<div class="ssp-tablewrap"><table class="ssp-table ssp-table--stack">
	<thead><tr><th>Item</th><th class="num">Qty wanted</th><th>Status</th><th>Details</th><th></th></tr></thead>
	<tbody>
	<?php foreach ( $rows as $r ) : ?>
		<?php $w = $r['w']; $p = $r['p']; ?>
		<tr>
			<td class="ssp-cell-item"><?php if ( $p ) : ?><a href="<?php echo esc_url( Catalog::url( $p ) ); ?>"><?php echo esc_html( $p->name . ( $r['v'] && $r['v']->label ? ' - ' . $r['v']->label : '' ) ); ?></a><?php endif; ?></td>
			<td class="num" data-label="Qty wanted"><?php echo (int) $w->qty_requested; ?></td>
			<td data-label="Status"><?php echo ssp_badge( Waitlist::STATUSES[ $w->status ] ?? $w->status, ssp_status_kind( $w->status ) ); // phpcs:ignore ?></td>
			<td data-label="Details">
				<?php if ( 'waiting' === $w->status ) : ?>Position <?php echo (int) $r['pos']; ?> in line<?php endif; ?>
				<?php if ( 'offered' === $w->status && $w->offered_qty ) : ?><strong><?php echo (int) $w->offered_qty; ?> held for you</strong> until <?php echo esc_html( Util::fmt_dt( $w->offer_expires_at ) ); ?><?php endif; ?>
				<?php if ( 'offered' === $w->status && ! $w->offered_qty ) : ?>Available now on a first-come, first-served basis. <a href="<?php echo esc_url( Catalog::url( $p ) ); ?>">Order now</a><?php endif; ?>
			</td>
			<td>
				<?php if ( 'offered' === $w->status && $w->offered_qty ) : ?>
					<form method="post" action="<?php echo esc_url( ssp_url( 'waitlist/' ) ); ?>" class="ssp-flex" data-once>
						<?php ssp_form_fields( 'waitlist_accept' ); ?>
						<input type="hidden" name="waitlist_uid" value="<?php echo esc_attr( $w->waitlist_uid ); ?>">
						<select name="fulfillment" aria-label="When it arrives" style="width:auto">
							<?php foreach ( Orders::FULFILLMENT as $k => $lbl ) : ?><option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $lbl ); ?></option><?php endforeach; ?>
						</select>
						<button class="ssp-btn ssp-btn--accent ssp-btn--sm" type="submit">Accept and reserve</button>
					</form>
				<?php endif; ?>
				<?php if ( in_array( $w->status, array( 'waiting', 'offered' ), true ) ) : ?>
					<form method="post" action="<?php echo esc_url( ssp_url( 'waitlist/' ) ); ?>" class="ssp-mt">
						<?php ssp_form_fields( 'waitlist_cancel' ); ?>
						<input type="hidden" name="waitlist_uid" value="<?php echo esc_attr( $w->waitlist_uid ); ?>">
						<button class="ssp-btn ssp-btn--ghost ssp-btn--sm" type="submit">Leave waitlist</button>
					</form>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table></div>
<?php endif; ?>
