<?php
/**
 * @var array $rows
 * @var array $separate
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Addresses;
use SSP\Domain\Boxes;
use SSP\Domain\Shipments;
?>
<div class="ssp-pagehead"><div><h1>Shipment History</h1><p>Closed boxes and separate shipments, with the exact items and original orders included.</p></div><a href="<?php echo esc_url( ssp_url( 'box/' ) ); ?>">Back to My Box</a></div>
<?php if ( ! $rows && ! $separate ) : ?>
	<div class="ssp-card ssp-empty"><?php echo ssp_icon( 'truck' ); // phpcs:ignore ?><p>No shipments yet.</p></div>
<?php endif; ?>
<?php foreach ( $rows as $r ) : ?>
	<?php $b = $r['box']; $s = $r['shipment']; ?>
	<div class="ssp-card">
		<div class="ssp-card__title"><h2 class="ssp-mb0">Box #<?php echo (int) $b->box_number; ?></h2><?php echo ssp_badge( Boxes::STATUSES[ $b->status ] ?? $b->status, ssp_status_kind( $b->status ) ); // phpcs:ignore ?></div>
		<?php if ( $s ) : ?>
			<dl class="ssp-kv"><dt>Carrier</dt><dd><?php echo esc_html( $s->carrier ); ?></dd><dt>Tracking</dt><dd><?php echo esc_html( $s->tracking_number ); ?></dd><dt>Shipped</dt><dd><?php echo esc_html( Util::fmt_date( $s->shipped_at ) ); ?></dd><?php if ( $s->delivered_at ) : ?><dt>Delivered</dt><dd><?php echo esc_html( Util::fmt_date( $s->delivered_at ) ); ?></dd><?php endif; ?><dt>Ship to</dt><dd><?php echo esc_html( Addresses::format( json_decode( (string) $s->address_snapshot, true ), ', ' ) ); ?></dd></dl>
		<?php endif; ?>
		<div class="ssp-tablewrap"><table class="ssp-table"><thead><tr><th>Item</th><th>Order</th><th class="num">Qty</th></tr></thead><tbody>
			<?php foreach ( $r['lines'] as $l ) : ?>
				<tr><td><?php echo esc_html( $l->name_snapshot ); ?></td><td>#<?php echo (int) $l->order_number; ?></td><td class="num"><?php echo (int) ( $l->ship_qty ?? \SSP\Domain\Orders::net( $l ) ); ?></td></tr>
			<?php endforeach; ?>
		</tbody></table></div>
	</div>
<?php endforeach; ?>
<?php foreach ( $separate as $r ) : ?>
	<?php $s = $r['shipment']; ?>
	<div class="ssp-card">
		<div class="ssp-card__title"><h2 class="ssp-mb0">Separate shipment</h2><?php echo ssp_badge( Shipments::STATUSES[ $s->status ] ?? $s->status, ssp_status_kind( $s->status ) ); // phpcs:ignore ?></div>
		<dl class="ssp-kv"><dt>Carrier</dt><dd><?php echo esc_html( $s->carrier ); ?></dd><dt>Tracking</dt><dd><?php echo esc_html( $s->tracking_number ); ?></dd><dt>Shipped</dt><dd><?php echo esc_html( Util::fmt_date( $s->shipped_at ) ); ?></dd></dl>
		<div class="ssp-tablewrap"><table class="ssp-table"><thead><tr><th>Item</th><th>Order</th><th class="num">Qty</th></tr></thead><tbody>
			<?php foreach ( $r['lines'] as $l ) : ?>
				<tr><td><?php echo esc_html( $l->name_snapshot ); ?></td><td>#<?php echo (int) $l->order_number; ?></td><td class="num"><?php echo (int) $l->ship_qty; ?></td></tr>
			<?php endforeach; ?>
		</tbody></table></div>
	</div>
<?php endforeach; ?>
