<?php
/**
 * @var array $invoices
 * @var array $lines
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Invoices;
?>
<div class="ssp-pagehead"><div><h1>Invoices</h1><p>Invoices are issued through QuickBooks Online when your items arrive. Payment status updates automatically from QuickBooks.</p></div></div>
<?php if ( ! $invoices ) : ?>
	<div class="ssp-card ssp-empty"><?php echo ssp_icon( 'invoice' ); // phpcs:ignore ?><p>No invoices yet. Nothing is due until your items arrive and are invoiced.</p></div>
<?php endif; ?>
<?php foreach ( $invoices as $i ) : ?>
	<div class="ssp-card">
		<div class="ssp-card__title">
			<div>
				<h2 class="ssp-mb0">Invoice <?php echo esc_html( $i->doc_number ? $i->doc_number : '(being created)' ); ?></h2>
				<span class="ssp-small ssp-muted"><?php echo $i->txn_date ? 'Dated ' . esc_html( Util::fmt_date( $i->txn_date ) ) : 'Created ' . esc_html( Util::fmt_date( $i->created_at ) ); ?></span>
			</div>
			<?php echo ssp_badge( Invoices::payment_label( $i ), ssp_status_kind( $i->sync_status ) ); // phpcs:ignore ?>
		</div>
		<?php if ( Invoices::is_final( $i ) ) : ?>
			<dl class="ssp-kv">
				<dt>Total</dt><dd><?php echo esc_html( Util::money( $i->total_usd ) ); ?></dd>
				<dt>Amount due</dt><dd><strong><?php echo esc_html( Util::money( $i->balance_usd ) ); ?></strong></dd>
				<?php if ( $i->due_date ) : ?><dt>Due date</dt><dd><?php echo esc_html( Util::fmt_date( $i->due_date ) ); ?></dd><?php endif; ?>
			</dl>
		<?php else : ?>
			<p class="ssp-muted">This invoice is being prepared in QuickBooks. Details will appear here shortly.</p>
		<?php endif; ?>
		<div class="ssp-tablewrap"><table class="ssp-table">
			<thead><tr><th>Item</th><th>Order</th><th class="num">Qty</th><th class="num">Price</th><th class="num">Amount</th></tr></thead>
			<tbody>
			<?php foreach ( $lines[ $i->id ] as $il ) : ?>
				<tr><td><?php echo esc_html( 'shipping' === $il->type ? $il->description : $il->name_snapshot ); ?></td><td><?php echo $il->order_number ? '<a href="' . esc_url( ssp_url( 'orders/' . $il->order_number . '/' ) ) . '">#' . (int) $il->order_number . '</a>' : ''; // phpcs:ignore ?></td><td class="num"><?php echo (int) $il->qty; ?></td><td class="num"><?php echo esc_html( Util::money( $il->unit_price_usd ) ); ?></td><td class="num"><?php echo esc_html( Util::money( $il->amount_usd ) ); ?></td></tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
		<p class="ssp-note">Tax, if any, is calculated by QuickBooks and shown on the invoice PDF.</p>
		<?php if ( Invoices::is_final( $i ) ) : ?>
		<div class="ssp-flex ssp-mt">
			<?php if ( $i->pay_link && 'paid' !== $i->sync_status ) : ?><a class="ssp-btn ssp-btn--accent" href="<?php echo esc_url( $i->pay_link ); ?>" target="_blank" rel="noopener">View &amp; pay invoice</a><?php endif; ?>
			<?php if ( $i->qbo_invoice_id ) : ?><a class="ssp-btn ssp-btn--ghost" href="<?php echo esc_url( ssp_url( 'invoices/' . strtolower( $i->invoice_uid ) . '/pdf/' ) ); ?>">Download PDF</a><?php endif; ?>
		</div>
		<?php endif; ?>
	</div>
<?php endforeach; ?>
