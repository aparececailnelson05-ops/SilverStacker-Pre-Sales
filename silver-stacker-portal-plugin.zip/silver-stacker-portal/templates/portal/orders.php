<?php
/**
 * @var array $res
 * @var array $args
 * @var array $lines
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Catalog;
use SSP\Domain\Orders;
?>
<div class="ssp-pagehead"><div><h1>My Orders</h1><p>Every pre-order you submitted through the portal, newest first.</p></div></div>

<form class="ssp-filters" method="get" action="<?php echo esc_url( ssp_url( 'orders/' ) ); ?>">
	<div class="ssp-field"><label for="o-q">Search by item name</label><input id="o-q" type="search" name="q" value="<?php echo esc_attr( $args['q'] ); ?>" placeholder="e.g. Maple Leaf"></div>
	<div class="ssp-field"><label for="o-s">Status</label>
		<select id="o-s" name="status" data-autosubmit>
			<option value="">All statuses</option>
			<?php foreach ( Orders::ORDER_STATUSES as $k => $l ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $args['status'], $k ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?>
		</select>
	</div>
	<div class="ssp-field"><label for="o-f">From</label><input id="o-f" type="date" name="from" value="<?php echo esc_attr( $args['from'] ); ?>"></div>
	<div class="ssp-field"><label for="o-t">To</label><input id="o-t" type="date" name="to" value="<?php echo esc_attr( $args['to'] ); ?>"></div>
	<button class="ssp-btn ssp-btn--primary" type="submit">Search</button>
</form>

<?php if ( ! $res['rows'] ) : ?>
	<div class="ssp-card ssp-empty"><?php echo ssp_icon( 'orders' ); // phpcs:ignore ?><p><?php echo $args['q'] ? 'No orders contain that item.' : 'You have not placed any pre-orders yet.'; ?></p></div>
<?php endif; ?>

<?php foreach ( $res['rows'] as $o ) : ?>
	<div class="ssp-card">
		<div class="ssp-card__title">
			<div>
				<h2 class="ssp-mb0"><a href="<?php echo esc_url( ssp_url( 'orders/' . $o->order_number . '/' ) ); ?>">Order #<?php echo (int) $o->order_number; ?></a></h2>
				<span class="ssp-small ssp-muted">Submitted <?php echo esc_html( Util::fmt_dt( $o->submitted_at ) ); ?></span>
			</div>
			<div class="ssp-flex"><?php echo ssp_badge( Orders::ORDER_STATUSES[ $o->status ] ?? $o->status, ssp_status_kind( $o->status ) ); // phpcs:ignore ?><strong><?php echo esc_html( Util::money( $o->subtotal_usd ) ); ?></strong></div>
		</div>
		<div class="ssp-tablewrap"><table class="ssp-table ssp-table--stack">
			<thead><tr><th>Item</th><th class="num">Ordered</th><th class="num">Available</th><th class="num">Invoiced</th><th>ETA</th><th>Status</th><th>Fulfillment</th></tr></thead>
			<tbody>
			<?php foreach ( $lines[ $o->id ] as $l ) : ?>
				<?php $p = Catalog::get( $l->product_id ); $img = $p ? Catalog::primary_image( $p->id ) : null; ?>
				<tr>
					<td class="ssp-cell-item"><div class="ssp-item">
						<?php if ( $p ) : ?><a href="<?php echo esc_url( Catalog::url( $p ) ); ?>" tabindex="-1" aria-hidden="true"><img class="ssp-thumb" src="<?php echo esc_url( Catalog::image_url( $img, 'thumb' ) ); ?>" alt=""></a><?php endif; ?>
						<div><?php if ( $p ) : ?><a href="<?php echo esc_url( Catalog::url( $p ) ); ?>"><?php echo esc_html( $l->name_snapshot ); ?></a><?php else : ?><?php echo esc_html( $l->name_snapshot ); ?><?php endif; ?>
						<div class="ssp-small ssp-muted"><?php echo esc_html( $l->sku_snapshot ); ?> &middot; <?php echo esc_html( Util::money( $l->unit_price_usd ) ); ?> each<?php echo $p && 'archived' === $p->lifecycle ? ' &middot; Archive listing' : ''; ?></div></div>
					</div></td>
					<td class="num" data-label="Ordered"><?php echo (int) Orders::net( $l ); ?></td>
					<td class="num" data-label="Available"><?php echo (int) $l->qty_available; ?></td>
					<td class="num" data-label="Invoiced"><?php echo (int) $l->qty_invoiced; ?></td>
					<td data-label="ETA"><?php echo esc_html( $p ? ( Catalog::eta_label( $p ) ? Catalog::eta_label( $p ) : 'TBD' ) : $l->eta_at_order ); ?></td>
					<td data-label="Status"><?php echo ssp_badge( Orders::LINE_STATUSES[ $l->display_status ] ?? $l->display_status, ssp_status_kind( $l->display_status ) ); // phpcs:ignore ?></td>
					<td data-label="Fulfillment"><?php echo esc_html( Orders::FULFILLMENT_BADGE[ $l->fulfillment_choice ] ?? '' ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
		<p class="ssp-right ssp-mt ssp-mb0"><a class="ssp-btn ssp-btn--ghost ssp-btn--sm" href="<?php echo esc_url( ssp_url( 'orders/' . $o->order_number . '/' ) ); ?>">View details, change quantities or fulfillment</a></p>
	</div>
<?php endforeach; ?>
<?php echo ssp_pagination( $res['total'], $res['per_page'], $res['page'], array_filter( $args, fn( $v, $k ) => $v && 'paged' !== $k, ARRAY_FILTER_USE_BOTH ), ssp_url( 'orders/' ) ); // phpcs:ignore ?>
