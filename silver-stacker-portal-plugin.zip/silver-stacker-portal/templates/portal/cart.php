<?php
/**
 * Cart (order draft). Not the box: nothing is reserved until Submit Pre-Order.
 *
 * @var array $rows
 * @var float $total
 * @var array $errors
 * @var array $line_errors
 * @var bool  $is_customer
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Catalog;
use SSP\Domain\Orders;
?>
<div class="ssp-pagehead">
	<div>
		<h1>Your Cart</h1>
		<p>Items here are not reserved yet. Submit your pre-order to reserve allocation. No payment is collected now; you will be invoiced when items arrive.</p>
	</div>
</div>

<?php if ( ! $rows ) : ?>
	<div class="ssp-card ssp-empty"><?php echo ssp_icon( 'cart' ); // phpcs:ignore ?><h2>Your cart is empty</h2><p>Browse current pre-sales and add items to your order.</p><a class="ssp-btn ssp-btn--primary" href="<?php echo esc_url( ssp_url( 'shop/' ) ); ?>">Shop pre-sales</a></div>
<?php else : ?>
<form method="post" action="<?php echo esc_url( ssp_url( 'cart/' ) ); ?>">
	<?php ssp_form_fields( 'cart_update' ); ?>
	<div class="ssp-tablewrap">
		<table class="ssp-table ssp-table--stack">
			<thead><tr><th>Item</th><th>ETA / Closes</th><th class="num">Price</th><th>Quantity</th><th>When it arrives</th><th class="num">Total</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $rows as $r ) : ?>
				<?php
				$it  = $r['item'];
				$err = $errors[ $it->id ] ?? ( $line_errors[ $it->variant_id ] ?? '' );
				?>
				<tr data-orderable>
					<td class="ssp-cell-item">
						<div class="ssp-item">
							<img class="ssp-thumb" src="<?php echo esc_url( Catalog::image_url( $r['img'], 'thumb' ) ); ?>" alt="">
							<div>
								<a href="<?php echo esc_url( Catalog::url( $r['p'] ) ); ?>"><?php echo esc_html( Catalog::display_name( $r['p'] ) . ( $r['v']->label ? ' - ' . $r['v']->label : '' ) ); ?></a>
								<div class="ssp-small ssp-muted">SKU <?php echo esc_html( $r['v']->sku ); ?><?php echo (int) $r['v']->min_order_qty > 1 ? ' &middot; Min ' . (int) $r['v']->min_order_qty : ''; ?></div>
								<?php if ( $err ) : ?><div class="ssp-badge ssp-badge--danger" role="alert" style="white-space:normal;margin-top:4px"><?php echo esc_html( $err ); ?></div><?php endif; ?>
							</div>
						</div>
					</td>
					<td data-label="ETA / Closes"><?php echo ssp_eta( $r['p'] ); // phpcs:ignore ?><br><?php echo 'presale' === $r['p']->lifecycle ? ssp_countdown( $r['p']->closing_at ) : ''; // phpcs:ignore ?></td>
					<td class="num" data-label="Price"><?php echo esc_html( Catalog::price_label( $r['v'], $r['p'] ) ); ?></td>
					<td data-label="Quantity">
						<span class="ssp-qty">
							<button type="button" data-qty-step="-1" aria-label="Decrease">&minus;</button>
							<input type="number" name="items[<?php echo (int) $it->id; ?>][qty]" value="<?php echo (int) $it->qty; ?>" min="0" aria-label="Quantity">
							<button type="button" data-qty-step="1" aria-label="Increase">+</button>
						</span>
					</td>
					<td data-label="When it arrives">
						<select name="items[<?php echo (int) $it->id; ?>][fulfillment]" aria-label="Fulfillment choice">
							<?php foreach ( Orders::FULFILLMENT as $k => $lbl ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $it->fulfillment_choice, $k ); ?>><?php echo esc_html( $lbl ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
					<td class="num" data-label="Total"><?php echo esc_html( Util::money( (int) $it->qty * (float) $r['v']->price_usd ) ); ?></td>
					<td><button class="ssp-btn ssp-btn--danger ssp-btn--sm" type="submit" form="rm-<?php echo (int) $it->id; ?>">Remove</button></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
			<tfoot><tr><td colspan="5" class="num">Estimated subtotal (before tax and shipping)</td><td class="num"><?php echo esc_html( Util::money( $total ) ); ?></td><td></td></tr></tfoot>
		</table>
	</div>
	<p class="ssp-note">Set a quantity to 0 to remove an item. Spot-based items show an estimate; the final price is confirmed on your invoice.</p>
	<div class="ssp-between ssp-mt">
		<button class="ssp-btn ssp-btn--ghost" type="submit">Update cart</button>
		<button class="ssp-btn ssp-btn--accent ssp-btn--lg" type="submit" name="to_review" value="1">Review &amp; Submit Pre-Order</button>
	</div>
</form>
<?php foreach ( $rows as $r ) : ?>
	<form id="rm-<?php echo (int) $r['item']->id; ?>" method="post" action="<?php echo esc_url( ssp_url( 'cart/' ) ); ?>" hidden>
		<?php ssp_form_fields( 'cart_remove' ); ?>
		<input type="hidden" name="cart_id" value="<?php echo (int) $r['item']->id; ?>">
	</form>
<?php endforeach; ?>
<?php endif; ?>
