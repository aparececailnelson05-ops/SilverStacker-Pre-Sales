<?php
/**
 * Order detail / confirmation.
 *
 * @var object $o
 * @var array  $lines
 * @var array  $extra
 * @var bool   $confirmation
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Boxes;
use SSP\Domain\Catalog;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
?>
<?php if ( $confirmation ) : ?>
	<div class="ssp-card" style="border-left:5px solid var(--ss-ok);margin-bottom:18px">
		<h1><?php echo ssp_icon( 'check' ); // phpcs:ignore ?> Pre-order #<?php echo (int) $o->order_number; ?> submitted</h1>
		<p>Thank you! Your allocation is reserved. No payment is due now. You will be invoiced through QuickBooks when your items arrive.</p>
		<div class="ssp-flex"><a class="ssp-btn ssp-btn--primary" href="<?php echo esc_url( ssp_url( 'shop/' ) ); ?>">Continue shopping</a><a class="ssp-btn ssp-btn--ghost" href="<?php echo esc_url( ssp_url( 'box/' ) ); ?>">View My Box</a></div>
	</div>
<?php endif; ?>

<div class="ssp-pagehead">
	<div>
		<h1>Order #<?php echo (int) $o->order_number; ?></h1>
		<p>Submitted <?php echo esc_html( Util::fmt_dt( $o->submitted_at ) ); ?> &middot; <?php echo ssp_badge( Orders::ORDER_STATUSES[ $o->status ] ?? $o->status, ssp_status_kind( $o->status ) ); // phpcs:ignore ?></p>
	</div>
	<a href="<?php echo esc_url( ssp_url( 'orders/' ) ); ?>">All orders</a>
</div>
<?php if ( $o->customer_note ) : ?><div class="ssp-announce"><strong>Your note:</strong> <?php echo esc_html( $o->customer_note ); ?></div><?php endif; ?>

<?php foreach ( $lines as $l ) : ?>
	<?php
	$x   = $extra[ $l->id ];
	$p   = $x['product'];
	$net = Orders::net( $l );
	?>
	<div class="ssp-card" data-orderable>
		<div class="ssp-orderline">
			<?php if ( $p ) : ?>
				<a href="<?php echo esc_url( Catalog::url( $p ) ); ?>"><img class="ssp-thumb" style="width:96px;height:96px" src="<?php echo esc_url( Catalog::image_url( $x['img'], 'thumb' ) ); ?>" alt="<?php echo esc_attr( $l->name_snapshot ); ?>"></a>
			<?php else : ?><span></span><?php endif; ?>
			<div>
				<div class="ssp-between">
					<div>
						<h3 class="ssp-mb0"><?php if ( $p ) : ?><a href="<?php echo esc_url( Catalog::url( $p ) ); ?>"><?php echo esc_html( $l->name_snapshot ); ?></a><?php else : ?><?php echo esc_html( $l->name_snapshot ); ?><?php endif; ?></h3>
						<span class="ssp-small ssp-muted">SKU <?php echo esc_html( $l->sku_snapshot ); ?><?php echo $p && $p->mintage ? ' &middot; Mintage ' . esc_html( $p->mintage ) : ''; ?></span>
					</div>
					<div class="ssp-flex">
						<?php echo ssp_badge( Orders::LINE_STATUSES[ $l->display_status ] ?? $l->display_status, ssp_status_kind( $l->display_status ) ); // phpcs:ignore ?>
						<?php echo ssp_badge( Orders::FULFILLMENT_BADGE[ $l->fulfillment_choice ] ?? '', 'box' === $l->fulfillment_choice ? 'brand' : 'neutral' ); // phpcs:ignore ?>
					</div>
				</div>
				<dl class="ssp-kv">
					<dt>Unit price</dt><dd><?php echo esc_html( 'spot_based' === $l->price_type ? 'Spot based (estimate ' . Util::money( $l->unit_price_usd ) . ')' : Util::money( $l->unit_price_usd ) ); ?></dd>
					<dt>Quantity</dt><dd>Ordered <?php echo (int) $net; ?> &middot; Available <?php echo (int) $l->qty_available; ?> &middot; Invoiced <?php echo (int) $l->qty_invoiced; ?><?php echo $l->qty_shipped ? ' &middot; Shipped ' . (int) $l->qty_shipped : ''; ?><?php echo $l->qty_cancelled ? ' &middot; Cancelled ' . (int) $l->qty_cancelled : ''; ?></dd>
					<dt>Line total</dt><dd><?php echo esc_html( Util::money( Orders::line_total( $l ) ) ); ?></dd>
					<?php if ( $p && Catalog::eta_label( $p ) ) : ?><dt>Estimated arrival</dt><dd><?php echo esc_html( Catalog::eta_label( $p ) ); ?></dd><?php endif; ?>
					<?php if ( $p && 'presale' === $p->lifecycle && $p->closing_at ) : ?><dt>Changes close</dt><dd><?php echo ssp_countdown( $p->closing_at ); // phpcs:ignore ?></dd><?php endif; ?>
					<?php if ( $x['box'] ) : ?><dt>Box</dt><dd><a href="<?php echo esc_url( ssp_url( 'box/' ) ); ?>">Box #<?php echo (int) $x['box']->box_number; ?></a> (<?php echo esc_html( Boxes::STATUSES[ $x['box']->status ] ?? '' ); ?>)</dd><?php endif; ?>
					<?php foreach ( $x['invoices'] as $inv ) : ?>
						<dt>Invoice</dt><dd><?php echo esc_html( $inv->doc_number ? $inv->doc_number : 'Being created' ); ?> (<?php echo (int) $inv->inv_qty; ?> unit<?php echo 1 === (int) $inv->inv_qty ? '' : 's'; ?>) &middot; <?php echo ssp_badge( Invoices::payment_label( $inv ), ssp_status_kind( $inv->sync_status ) ); // phpcs:ignore ?>
						<?php if ( Invoices::is_final( $inv ) ) : ?>
							<?php echo esc_html( Util::money( $inv->total_usd ) ); ?>, due <?php echo esc_html( Util::money( $inv->balance_usd ) ); ?><?php echo $inv->due_date ? ' by ' . esc_html( Util::fmt_date( $inv->due_date ) ) : ''; ?>
							<?php if ( $inv->pay_link && 'paid' !== $inv->sync_status ) : ?> &middot; <a href="<?php echo esc_url( $inv->pay_link ); ?>" target="_blank" rel="noopener">View / pay</a><?php endif; ?>
							<?php if ( $inv->qbo_invoice_id ) : ?> &middot; <a href="<?php echo esc_url( ssp_url( 'invoices/' . strtolower( $inv->invoice_uid ) . '/pdf/' ) ); ?>">PDF</a><?php endif; ?>
						<?php endif; ?></dd>
					<?php endforeach; ?>
					<?php foreach ( $x['shipments'] as $s ) : ?>
						<dt>Shipment</dt><dd><?php echo esc_html( ( $s->carrier ? $s->carrier . ' ' : '' ) . $s->tracking_number ); ?> (<?php echo (int) $s->ship_qty; ?>) <?php echo $s->shipped_at ? 'shipped ' . esc_html( Util::fmt_date( $s->shipped_at ) ) : ''; ?></dd>
					<?php endforeach; ?>
				</dl>

				<div class="ssp-grid ssp-grid--2">
					<div>
						<?php if ( true === $x['can_edit'] ) : ?>
							<form method="post" action="<?php echo esc_url( ssp_url( 'orders/' . $o->order_number . '/' ) ); ?>" class="ssp-flex">
								<?php ssp_form_fields( 'line_amend' ); ?>
								<input type="hidden" name="line_uid" value="<?php echo esc_attr( $l->line_uid ); ?>">
								<label class="ssp-label" for="q-<?php echo (int) $l->id; ?>">Change quantity</label>
								<span class="ssp-qty"><button type="button" data-qty-step="-1" aria-label="Decrease" data-order-control>&minus;</button><input id="q-<?php echo (int) $l->id; ?>" type="number" name="qty" value="<?php echo (int) $net; ?>" min="0" data-order-control><button type="button" data-qty-step="1" aria-label="Increase" data-order-control>+</button></span>
								<button class="ssp-btn ssp-btn--ghost ssp-btn--sm" type="submit" data-order-control>Update</button>
							</form>
							<p class="ssp-note">Set to 0 to cancel this item. Increases depend on remaining allocation.</p>
						<?php else : ?>
							<p class="ssp-note"><?php echo esc_html( is_string( $x['can_edit'] ) ? $x['can_edit'] : '' ); ?></p>
						<?php endif; ?>
					</div>
					<div>
						<?php if ( true === $x['can_ful'] ) : ?>
							<form method="post" action="<?php echo esc_url( ssp_url( 'orders/' . $o->order_number . '/' ) ); ?>" class="ssp-flex">
								<?php ssp_form_fields( 'line_fulfillment' ); ?>
								<input type="hidden" name="line_uid" value="<?php echo esc_attr( $l->line_uid ); ?>">
								<label class="ssp-label" for="f-<?php echo (int) $l->id; ?>">When it arrives</label>
								<select id="f-<?php echo (int) $l->id; ?>" name="fulfillment" style="width:auto">
									<?php foreach ( Orders::FULFILLMENT as $k => $lbl ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $l->fulfillment_choice, $k ); ?>><?php echo esc_html( $lbl ); ?></option><?php endforeach; ?>
								</select>
								<button class="ssp-btn ssp-btn--ghost ssp-btn--sm" type="submit">Save</button>
							</form>
						<?php elseif ( is_string( $x['can_ful'] ) && $net ) : ?>
							<p class="ssp-note"><?php echo esc_html( $x['can_ful'] ); ?></p>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php endforeach; ?>

<div class="ssp-card"><div class="ssp-between"><strong>Order total (before tax and shipping)</strong><strong><?php echo esc_html( Util::money( $o->subtotal_usd ) ); ?></strong></div></div>
