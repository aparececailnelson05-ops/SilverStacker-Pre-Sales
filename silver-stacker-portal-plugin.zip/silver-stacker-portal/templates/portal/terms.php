<?php
/**
 * @var object|null $terms
 * @var bool        $accepted
 */
defined( 'ABSPATH' ) || exit;
?>
<div class="ssp-terms">
	<div class="ssp-card">
		<h1>Silver Stacker LLC Pre-Sale Terms &amp; Conditions</h1>
		<?php if ( $terms ) : ?>
			<p class="ssp-muted ssp-small">Version <?php echo esc_html( $terms->version_label ); ?> &middot; Published <?php echo esc_html( \SSP\Core\Util::fmt_date( $terms->published_at ) ); ?></p>
			<div class="ssp-terms__content" tabindex="0" aria-label="Terms and Conditions text"><?php echo wp_kses_post( $terms->content ); ?></div>
			<?php if ( $accepted || \SSP\Core\Roles::is_staff() ) : ?>
				<div class="ssp-alert ssp-alert--success"><div>You have accepted this version of the Terms &amp; Conditions.</div></div>
				<a class="ssp-btn ssp-btn--primary" href="<?php echo esc_url( ssp_url() ); ?>">Continue to the portal</a>
			<?php else : ?>
				<form method="post" action="<?php echo esc_url( ssp_url( 'terms/' ) ); ?>">
					<?php ssp_form_fields( 'accept_terms' ); ?>
					<input type="hidden" name="terms_version_id" value="<?php echo (int) $terms->id; ?>">
					<label class="ssp-check" style="font-size:16px"><input type="checkbox" name="agree" value="1" required> I have read and agree to the Silver Stacker LLC Pre-Sale Terms &amp; Conditions</label>
					<button class="ssp-btn ssp-btn--accent ssp-btn--lg ssp-mt" type="submit">Agree and enter the portal</button>
				</form>
			<?php endif; ?>
		<?php else : ?>
			<p>No terms have been published yet.</p>
		<?php endif; ?>
	</div>
</div>
