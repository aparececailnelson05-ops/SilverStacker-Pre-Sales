<?php
/**
 * MY BOX: consolidated shipping box (not a cart).
 *
 * @var array  $boxes     [ box, items, ext, tot, tier ]
 * @var array  $eligible  Lines that can be added.
 * @var array  $addresses
 * @var string $mode      ship_unavailable_mode setting
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Util;
use SSP\Domain\Addresses;
use SSP\Domain\Boxes;
use SSP\Domain\Catalog;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;

$ssp_steps = array( 'open' => 'Open', 'shipment_requested' => 'Shipment requested', 'preparing' => 'Preparing', 'shipped' => 'Shipped', 'delivered' => 'Delivered', 'closed' => 'Closed' );
?>
<div class="ssp-pagehead">
	<div>
		<h1>My Box</h1>
		<p>Build A Box: hold items from different pre-orders and ship them together in one shipment. Items can be invoiced as they arrive while they wait in your box.</p>
	</div>
	<a href="<?php echo esc_url( ssp_url( 'box/history/' ) ); ?>">Shipment history</a>
</div>

<?php if ( ! $boxes ) : ?>
	<div class="ssp-card ssp-empty"><?php echo ssp_icon( 'box' ); // phpcs:ignore ?><h2>Your box is empty</h2><p>When you order, choose "Add to My Box", or add eligible items from your orders below.</p></div>
<?php endif; ?>

<?php foreach ( $boxes as $bx ) : ?>
	<?php
	$b    = $bx['box'];
	$tot  = $bx['tot'];
	$addr = Boxes::address( $b );
	$keys = array_keys( $ssp_steps );
	$pos  = array_search( $b->status, $keys, true );
	?>
	<section class="ssp-card" aria-labelledby="box-<?php echo (int) $b->id; ?>">
		<div class="ssp-boxhead">
			<div>
				<h2 id="box-<?php echo (int) $b->id; ?>">Box #<?php echo (int) $b->box_number; ?></h2>
				<div><?php echo ssp_badge( Boxes::STATUSES[ $b->status ] ?? $b->status, 'open' === $b->status ? 'ok' : 'warn' ); // phpcs:ignore ?></div>
			</div>
			<div class="ssp-boxstats">
				<div><b><?php echo (int) $tot['units']; ?></b><span>Total items in box</span></div>
				<div><b><?php echo (int) $tot['available']; ?></b><span>Arrived / available</span></div>
				<div><b><?php echo (int) $tot['lines']; ?></b><span>Order lines</span></div>
				<div><b><?php echo $bx['tier'] ? esc_html( $bx['tier']->name ) : 'TBD'; ?></b><span>Shipping tier<?php echo null !== $b->shipping_charge_usd ? ' &middot; ' . esc_html( Util::money( $b->shipping_charge_usd ) ) : ''; ?></span></div>
			</div>
		</div>
		<ol class="ssp-steps" aria-label="Box progress">
			<?php foreach ( $ssp_steps as $k => $lbl ) : ?>
				<?php $i = array_search( $k, $keys, true ); ?>
				<li class="<?php echo $i < $pos ? 'is-done' : ( $i === $pos ? 'is-current' : '' ); ?>"<?php echo $i === $pos ? ' aria-current="step"' : ''; ?>><?php echo esc_html( $lbl ); ?></li>
			<?php endforeach; ?>
		</ol>

		<div class="ssp-grid ssp-grid--2 ssp-mt">
			<div>
				<h3><?php echo ssp_icon( 'pin' ); // phpcs:ignore ?> Shipping address</h3>
				<p><?php echo $addr ? nl2br( esc_html( Addresses::format( $addr ) ) ) : '<em>No default shipping address.</em>'; // phpcs:ignore ?></p>
				<?php if ( Boxes::can_change_address( $b ) && count( $addresses ) > 1 ) : ?>
					<form method="post" action="<?php echo esc_url( ssp_url( 'box/' ) ); ?>" class="ssp-flex">
						<?php ssp_form_fields( 'box_address' ); ?>
						<input type="hidden" name="box_uid" value="<?php echo esc_attr( $b->box_uid ); ?>">
						<label class="ssp-visually-hidden" for="ba-<?php echo (int) $b->id; ?>">Ship this box to</label>
						<select id="ba-<?php echo (int) $b->id; ?>" name="address_id" style="width:auto;max-width:100%">
							<?php foreach ( $addresses as $a ) : ?><option value="<?php echo (int) $a->id; ?>" <?php selected( (int) $b->address_id, (int) $a->id ); ?>><?php echo esc_html( Addresses::format( $a, ', ' ) ); ?></option><?php endforeach; ?>
						</select>
						<button class="ssp-btn ssp-btn--ghost ssp-btn--sm" type="submit">Use this address</button>
					</form>
				<?php endif; ?>
				<p class="ssp-small"><a href="<?php echo esc_url( ssp_url( 'addresses/' ) ); ?>">Manage shipping addresses</a></p>
			</div>
			<div>
				<h3>Shipping</h3>
				<?php if ( 'open' === $b->status ) : ?>
					<p class="ssp-small ssp-muted">When you are ready, request one consolidated shipment. Staff will confirm the shipping rate tier and send tracking details.</p>
					<?php if ( $tot['lines'] ) : ?>
						<button class="ssp-btn ssp-btn--accent ssp-btn--lg" type="button" data-dialog-open="ship-<?php echo (int) $b->id; ?>"><?php echo ssp_icon( 'truck' ); // phpcs:ignore ?> SHIP MY BOX</button>
					<?php endif; ?>
				<?php elseif ( 'shipment_requested' === $b->status ) : ?>
					<p>Shipment requested <?php echo esc_html( Util::fmt_dt( $b->shipment_requested_at ) ); ?>. <?php echo 'wait_all' === $b->ship_mode ? 'We will ship once every item has arrived.' : 'We will ship the available items.'; ?></p>
					<form method="post" action="<?php echo esc_url( ssp_url( 'box/' ) ); ?>">
						<?php ssp_form_fields( 'box_cancel_request' ); ?>
						<input type="hidden" name="box_uid" value="<?php echo esc_attr( $b->box_uid ); ?>">
						<button class="ssp-btn ssp-btn--ghost ssp-btn--sm" type="submit">Cancel shipment request</button>
					</form>
				<?php else : ?>
					<p>Your box is being prepared for shipment.</p>
				<?php endif; ?>
			</div>
		</div>

		<?php if ( $bx['items'] ) : ?>
		<div class="ssp-tablewrap ssp-mt"><table class="ssp-table ssp-table--stack">
			<thead><tr><th>Item</th><th>Order</th><th class="num">Qty</th><th>Availability</th><th>ETA</th><th>Invoice</th><th>Status</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $bx['items'] as $it ) : ?>
				<?php
				$e   = $bx['ext'][ $it->id ];
				$p   = $e['p'];
				$q   = Orders::net( $it ) - (int) $it->qty_shipped;
				$av  = max( 0, (int) $it->qty_available - (int) $it->qty_shipped );
				$can = Orders::can_change_fulfillment( $it );
				?>
				<tr>
					<td class="ssp-cell-item"><div class="ssp-item">
						<img class="ssp-thumb" src="<?php echo esc_url( Catalog::image_url( $e['img'], 'thumb' ) ); ?>" alt="">
						<div><?php if ( $p ) : ?><a href="<?php echo esc_url( Catalog::url( $p ) ); ?>"><?php echo esc_html( $it->name_snapshot ); ?></a><?php else : ?><?php echo esc_html( $it->name_snapshot ); ?><?php endif; ?><div class="ssp-small ssp-muted">SKU <?php echo esc_html( $it->sku_snapshot ); ?></div></div>
					</div></td>
					<td data-label="Order"><a href="<?php echo esc_url( ssp_url( 'orders/' . $it->order_number . '/' ) ); ?>">#<?php echo (int) $it->order_number; ?></a><div class="ssp-small ssp-muted"><?php echo esc_html( Util::fmt_date( $it->submitted_at ) ); ?></div></td>
					<td class="num" data-label="Qty"><?php echo (int) $q; ?></td>
					<td data-label="Availability"><?php echo $av >= $q ? ssp_badge( 'Arrived', 'ok' ) : ( $av ? ssp_badge( $av . ' of ' . $q . ' arrived', 'warn' ) : ssp_badge( 'Awaiting arrival', 'neutral' ) ); // phpcs:ignore ?></td>
					<td data-label="ETA"><?php echo esc_html( $p && Catalog::eta_label( $p ) ? Catalog::eta_label( $p ) : 'TBD' ); ?></td>
					<td data-label="Invoice">
						<?php if ( $e['invoices'] ) : ?>
							<?php foreach ( $e['invoices'] as $inv ) : ?>
								<div><?php echo esc_html( $inv->doc_number ? $inv->doc_number : 'Pending' ); ?> <?php echo ssp_badge( Invoices::payment_label( $inv ), ssp_status_kind( $inv->sync_status ) ); // phpcs:ignore ?></div>
							<?php endforeach; ?>
						<?php else : ?><span class="ssp-muted">Not invoiced</span><?php endif; ?>
					</td>
					<td data-label="Status"><?php echo ssp_badge( Orders::LINE_STATUSES[ $it->display_status ] ?? '', ssp_status_kind( $it->display_status ) ); // phpcs:ignore ?></td>
					<td>
						<?php if ( true === $can && 'open' === $b->status ) : ?>
							<form method="post" action="<?php echo esc_url( ssp_url( 'box/' ) ); ?>">
								<?php ssp_form_fields( 'box_remove_line' ); ?>
								<input type="hidden" name="line_uid" value="<?php echo esc_attr( $it->line_uid ); ?>">
								<button class="ssp-btn ssp-btn--ghost ssp-btn--sm" type="submit">Remove</button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
		<?php endif; ?>

		<?php if ( 'open' === $b->status && $tot['lines'] ) : ?>
		<dialog class="ssp-dialog" id="ship-<?php echo (int) $b->id; ?>" aria-labelledby="ship-title-<?php echo (int) $b->id; ?>">
			<form method="post" action="<?php echo esc_url( ssp_url( 'box/' ) ); ?>" data-once>
				<div class="ssp-dialog__body">
					<h2 id="ship-title-<?php echo (int) $b->id; ?>">Ship Box #<?php echo (int) $b->box_number; ?>?</h2>
					<?php ssp_form_fields( 'box_request' ); ?>
					<input type="hidden" name="box_uid" value="<?php echo esc_attr( $b->box_uid ); ?>">
					<p><strong>Ship to:</strong><br><?php echo $addr ? nl2br( esc_html( Addresses::format( $addr ) ) ) : 'No address'; // phpcs:ignore ?></p>
					<p><strong><?php echo (int) $tot['available']; ?></strong> of <strong><?php echo (int) $tot['units']; ?></strong> item(s) have arrived.</p>
					<?php if ( $tot['unavailable'] > 0 && 'customer_choice' === $mode ) : ?>
						<div class="ssp-radios">
							<label class="ssp-radio"><input type="radio" name="mode" value="ship_available" checked <?php disabled( 0 === (int) $tot['available'] ); ?>><span>Ship the arrived items now<small>Items still on the way stay in a new open box for a later shipment.</small></span></label>
							<label class="ssp-radio"><input type="radio" name="mode" value="wait_all" <?php checked( 0 === (int) $tot['available'] ); ?>><span>Wait and ship everything together<small>We will ship once every item in the box has arrived.</small></span></label>
						</div>
					<?php else : ?>
						<input type="hidden" name="mode" value="ship_available">
					<?php endif; ?>
					<p class="ssp-small ssp-muted ssp-mt">Shipping is billed at the applicable fixed rate tier. Staff will confirm the tier and send tracking details.</p>
					<label class="ssp-check ssp-mt"><input type="checkbox" name="confirm" value="1" required> I confirm the address and contents above.</label>
				</div>
				<div class="ssp-dialog__foot">
					<button class="ssp-btn ssp-btn--ghost" type="button" data-dialog-close>Cancel</button>
					<button class="ssp-btn ssp-btn--accent" type="submit">Request shipment</button>
				</div>
			</form>
		</dialog>
		<?php endif; ?>
	</section>
<?php endforeach; ?>

<?php if ( $eligible ) : ?>
<section class="ssp-card">
	<h2>Add items from your orders</h2>
	<p class="ssp-muted ssp-small">These items are waiting for a fulfillment decision or are set to ship separately.</p>
	<div class="ssp-tablewrap"><table class="ssp-table ssp-table--stack">
		<thead><tr><th>Item</th><th>Order</th><th class="num">Qty</th><th>Current choice</th><th>Status</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $eligible as $l ) : ?>
			<tr>
				<td class="ssp-cell-item"><strong><?php echo esc_html( $l->name_snapshot ); ?></strong></td>
				<td data-label="Order"><a href="<?php echo esc_url( ssp_url( 'orders/' . $l->order_number . '/' ) ); ?>">#<?php echo (int) $l->order_number; ?></a></td>
				<td class="num" data-label="Qty"><?php echo (int) ( Orders::net( $l ) - $l->qty_shipped ); ?></td>
				<td data-label="Current choice"><?php echo esc_html( Orders::FULFILLMENT_BADGE[ $l->fulfillment_choice ] ?? '' ); ?></td>
				<td data-label="Status"><?php echo ssp_badge( Orders::LINE_STATUSES[ $l->display_status ] ?? '', ssp_status_kind( $l->display_status ) ); // phpcs:ignore ?></td>
				<td><form method="post" action="<?php echo esc_url( ssp_url( 'box/' ) ); ?>"><?php ssp_form_fields( 'box_add_line' ); ?><input type="hidden" name="line_uid" value="<?php echo esc_attr( $l->line_uid ); ?>"><button class="ssp-btn ssp-btn--primary ssp-btn--sm" type="submit">Add to My Box</button></form></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
</section>
<?php endif; ?>
