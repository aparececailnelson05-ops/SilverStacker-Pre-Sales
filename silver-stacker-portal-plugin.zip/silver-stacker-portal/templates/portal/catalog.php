<?php
/**
 * Shop / In-Stock / Archive / Search results (tabs: Active Items | The Archive).
 *
 * @var array  $res
 * @var array  $args
 * @var bool   $is_search
 * @var string $base
 * @var string $title
 * @var string $lifecycle_fixed
 * @var string $announcement
 */
defined( 'ABSPATH' ) || exit;

use SSP\Domain\Catalog;

$ssp_is_customer = \SSP\Core\Roles::is_customer();
$ssp_keep        = array_filter(
	array(
		'q'         => $args['q'],
		'metal'     => $args['metal'],
		'brand'     => $args['brand'],
		'category'  => $args['category'],
		'sort'      => $args['sort'],
		'lifecycle' => $lifecycle_fixed ? '' : $args['lifecycle'],
	)
);
$ssp_tab_url = function ( $tab ) use ( $ssp_keep, $is_search ) {
	if ( $is_search ) {
		return add_query_arg( array_merge( $ssp_keep, array( 'tab' => $tab ) ), ssp_url( 'search/' ) );
	}
	return add_query_arg( array_diff_key( $ssp_keep, array( 'lifecycle' => 1 ) ), 'archive' === $tab ? ssp_url( 'archive/' ) : ssp_url( 'search/' ) );
};
$ssp_tab = $res['tab'];
?>
<div class="ssp-pagehead">
	<div>
		<h1><?php echo esc_html( $is_search && $args['q'] ? 'Results for "' . $args['q'] . '"' : $title ); ?></h1>
		<p><?php echo (int) $res['total']; ?> item(s)</p>
	</div>
</div>

<?php if ( ! $is_search && 'presale' === $lifecycle_fixed && $announcement ) : ?>
	<div class="ssp-announce"><?php echo esc_html( $announcement ); ?></div>
<?php endif; ?>

<div class="ssp-tabs" role="tablist" aria-label="Search scope">
	<a role="tab" href="<?php echo esc_url( $ssp_tab_url( 'active' ) ); ?>" aria-selected="<?php echo 'active' === $ssp_tab ? 'true' : 'false'; ?>">Active Items <span class="ssp-count"><?php echo (int) $res['counts']['active']; ?></span></a>
	<a role="tab" href="<?php echo esc_url( $ssp_tab_url( 'archive' ) ); ?>" aria-selected="<?php echo 'archive' === $ssp_tab ? 'true' : 'false'; ?>">The Archive <span class="ssp-count"><?php echo (int) $res['counts']['archive']; ?></span></a>
</div>

<form class="ssp-filters" method="get" action="<?php echo esc_url( $base ); ?>">
	<?php if ( $is_search ) : ?><input type="hidden" name="tab" value="<?php echo esc_attr( $ssp_tab ); ?>"><?php endif; ?>
	<div class="ssp-field"><label for="f-q">Search</label><input id="f-q" type="search" name="q" value="<?php echo esc_attr( $args['q'] ); ?>" placeholder="Name, SKU, barcode, brand"></div>
	<div class="ssp-field"><label for="f-metal">Metal</label>
		<select id="f-metal" name="metal" data-autosubmit>
			<option value="">All metals</option>
			<?php foreach ( (array) \SSP\Core\Settings::get( 'metals' ) as $m ) : ?>
				<option value="<?php echo esc_attr( $m ); ?>" <?php selected( $args['metal'], $m ); ?>><?php echo esc_html( $m ); ?></option>
			<?php endforeach; ?>
		</select>
	</div>
	<div class="ssp-field"><label for="f-brand">Brand</label>
		<select id="f-brand" name="brand" data-autosubmit>
			<option value="">All brands</option>
			<?php foreach ( Catalog::distinct( 'brand' ) as $b ) : ?>
				<option value="<?php echo esc_attr( $b ); ?>" <?php selected( $args['brand'], $b ); ?>><?php echo esc_html( $b ); ?></option>
			<?php endforeach; ?>
		</select>
	</div>
	<div class="ssp-field"><label for="f-cat">Category</label>
		<select id="f-cat" name="category" data-autosubmit>
			<option value="">All categories</option>
			<?php foreach ( Catalog::distinct( 'category' ) as $c ) : ?>
				<option value="<?php echo esc_attr( $c ); ?>" <?php selected( $args['category'], $c ); ?>><?php echo esc_html( $c ); ?></option>
			<?php endforeach; ?>
		</select>
	</div>
	<?php if ( 'active' === $ssp_tab && ! $lifecycle_fixed ) : ?>
	<div class="ssp-field"><label for="f-life">Status</label>
		<select id="f-life" name="lifecycle" data-autosubmit>
			<option value="">Presale and In Stock</option>
			<option value="presale" <?php selected( $args['lifecycle'], 'presale' ); ?>>Presale (open)</option>
			<option value="in_stock" <?php selected( $args['lifecycle'], 'in_stock' ); ?>>In Stock</option>
			<option value="presale_ended" <?php selected( $args['lifecycle'], 'presale_ended' ); ?>>Pre-Sale Ended</option>
		</select>
	</div>
	<?php endif; ?>
	<div class="ssp-field"><label for="f-sort">Sort</label>
		<select id="f-sort" name="sort" data-autosubmit>
			<?php if ( 'archive' === $ssp_tab ) : ?>
				<option value="">Recently archived</option>
				<option value="name" <?php selected( $args['sort'], 'name' ); ?>>Name A-Z</option>
			<?php else : ?>
				<option value="closing">Closing soonest</option>
				<option value="newest" <?php selected( $args['sort'], 'newest' ); ?>>Newest</option>
				<option value="name" <?php selected( $args['sort'], 'name' ); ?>>Name A-Z</option>
			<?php endif; ?>
		</select>
	</div>
	<button class="ssp-btn ssp-btn--primary" type="submit">Apply</button>
</form>

<?php if ( 'archive' === $ssp_tab ) : ?>
	<p class="ssp-note">The Archive is a reference of items previously offered. Archived items cannot be ordered unless Silver Stacker re-opens them.</p>
<?php endif; ?>

<?php if ( $res['rows'] ) : ?>
	<div class="ssp-products">
		<?php foreach ( $res['rows'] as $p ) : ?>
			<?php \SSP\Portal\View::partial( 'product-card', array( 'p' => $p, 'is_customer' => $ssp_is_customer ) ); ?>
		<?php endforeach; ?>
	</div>
	<?php echo ssp_pagination( $res['total'], $res['per_page'], $res['page'], array_merge( $ssp_keep, $is_search ? array( 'tab' => $ssp_tab ) : array() ), $base ); // phpcs:ignore ?>
<?php else : ?>
	<div class="ssp-empty ssp-card"><?php echo ssp_icon( 'search' ); // phpcs:ignore ?><p>No items match your search<?php echo 'active' === $ssp_tab && $res['counts']['archive'] ? '. ' : '.'; ?>
	<?php if ( 'active' === $ssp_tab && $res['counts']['archive'] ) : ?>
		<a href="<?php echo esc_url( $ssp_tab_url( 'archive' ) ); ?>">See <?php echo (int) $res['counts']['archive']; ?> result(s) in The Archive</a>
	<?php endif; ?>
	</p></div>
<?php endif; ?>
