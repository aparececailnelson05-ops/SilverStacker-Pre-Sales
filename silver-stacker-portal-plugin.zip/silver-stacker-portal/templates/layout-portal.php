<?php
/**
 * Portal layout (logged-in customers and staff).
 *
 * @var string $content
 * @var string $page_title
 */
defined( 'ABSPATH' ) || exit;

use SSP\Core\Roles;
use SSP\Domain\Cart;
use SSP\Domain\Customers;
use SSP\Domain\Terms;

$ssp_uid      = get_current_user_id();
$ssp_staff    = Roles::is_staff( $ssp_uid );
$ssp_customer = Roles::is_customer( $ssp_uid );
$ssp_gate_ok  = $ssp_staff || ( $ssp_customer && Customers::is_approved( $ssp_uid ) && Terms::has_accepted_current( $ssp_uid ) );
$ssp_route    = trim( (string) get_query_var( 'ssp_route' ), '/' );
$ssp_cart     = $ssp_customer ? Cart::count( $ssp_uid ) : 0;
$ssp_q        = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
$ssp_cur      = function ( $prefix ) use ( $ssp_route ) {
	return ( $ssp_route === $prefix || ( 'portal' !== $prefix && strpos( $ssp_route, $prefix ) === 0 ) ) ? ' aria-current="page"' : '';
};
$ssp_nav = array(
	'portal'           => 'Dashboard',
	'portal/shop'      => 'Shop / Pre-Sales',
	'portal/in-stock'  => 'In-Stock',
	'portal/orders'    => 'My Orders',
	'portal/box'       => 'My Box',
	'portal/invoices'  => 'Invoices',
	'portal/waitlist'  => 'Waitlist',
	'portal/archive'   => 'Product Archive',
	'portal/addresses' => 'Shipping Addresses',
	'portal/account'   => 'Account',
);
if ( $ssp_staff ) {
	unset( $ssp_nav['portal/box'], $ssp_nav['portal/invoices'], $ssp_nav['portal/waitlist'], $ssp_nav['portal/addresses'], $ssp_nav['portal/orders'], $ssp_nav['portal/account'] );
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( ( $page_title ? $page_title . ' | ' : '' ) . 'Silver Stacker Pre-Sale Portal' ); ?></title>
<link rel="icon" href="<?php echo esc_url( SSP_URL . 'assets/img/logo.png' ); ?>">
<?php wp_head(); ?>
</head>
<body class="ssp ssp-portal" data-server-now="<?php echo (int) time(); ?>">
<a class="ssp-skip" href="#ssp-main">Skip to content</a>
<header class="ssp-header">
	<div class="ssp-header__inner">
		<a class="ssp-brand" href="<?php echo esc_url( ssp_url() ); ?>">
			<img src="<?php echo esc_url( SSP_URL . 'assets/img/logo.png' ); ?>" alt="Silver Stacker LLC" width="44" height="52">
			<span>Silver Stacker<small>Private Pre-Sale Portal</small></span>
		</a>
		<?php if ( $ssp_gate_ok ) : ?>
		<form class="ssp-search" role="search" action="<?php echo esc_url( ssp_url( 'search/' ) ); ?>" method="get">
			<label class="ssp-visually-hidden" for="ssp-q">Search products</label>
			<?php echo ssp_icon( 'search' ); // phpcs:ignore ?>
			<input id="ssp-q" type="search" name="q" value="<?php echo esc_attr( $ssp_q ); ?>" placeholder="Search products, SKU, barcode, brand..." autocomplete="off">
			<button type="submit">Search</button>
		</form>
		<?php endif; ?>
		<div class="ssp-header__actions">
			<?php if ( $ssp_customer && $ssp_gate_ok ) : ?>
				<a class="ssp-cartbtn" href="<?php echo esc_url( ssp_url( 'cart/' ) ); ?>"><?php echo ssp_icon( 'cart' ); // phpcs:ignore ?> Cart <span class="ssp-count" aria-label="<?php echo esc_attr( $ssp_cart . ' items' ); ?>"><?php echo (int) $ssp_cart; ?></span></a>
			<?php endif; ?>
			<details class="ssp-menu">
				<summary><?php echo ssp_icon( 'user' ); // phpcs:ignore ?> <span><?php echo esc_html( wp_get_current_user()->display_name ); ?></span></summary>
				<div class="ssp-menu__panel">
					<?php if ( $ssp_staff ) : ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-orders' ) ); ?>"><?php echo ssp_icon( 'orders' ); // phpcs:ignore ?> Orders</a>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-customers' ) ); ?>"><?php echo ssp_icon( 'users' ); // phpcs:ignore ?> Customers</a>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-reports' ) ); ?>"><?php echo ssp_icon( 'chart' ); // phpcs:ignore ?> Reports</a>
						<?php if ( current_user_can( 'ssp_manage_settings' ) ) : ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-settings' ) ); ?>"><?php echo ssp_icon( 'gear' ); // phpcs:ignore ?> Settings</a>
						<?php endif; ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-dashboard' ) ); ?>"><?php echo ssp_icon( 'home' ); // phpcs:ignore ?> Staff console</a>
						<hr>
					<?php elseif ( $ssp_gate_ok ) : ?>
						<a href="<?php echo esc_url( ssp_url( 'orders/' ) ); ?>"><?php echo ssp_icon( 'orders' ); // phpcs:ignore ?> My Orders</a>
						<a href="<?php echo esc_url( ssp_url( 'box/' ) ); ?>"><?php echo ssp_icon( 'box' ); // phpcs:ignore ?> My Box</a>
						<a href="<?php echo esc_url( ssp_url( 'invoices/' ) ); ?>"><?php echo ssp_icon( 'invoice' ); // phpcs:ignore ?> Invoices</a>
						<a href="<?php echo esc_url( ssp_url( 'account/' ) ); ?>"><?php echo ssp_icon( 'user' ); // phpcs:ignore ?> Account</a>
						<hr>
					<?php endif; ?>
					<a href="<?php echo esc_url( wp_nonce_url( ssp_url( 'logout/' ), 'ssp_logout' ) ); ?>"><?php echo ssp_icon( 'logout' ); // phpcs:ignore ?> Log out</a>
				</div>
			</details>
		</div>
	</div>
</header>
<?php if ( $ssp_gate_ok ) : ?>
<nav class="ssp-nav" aria-label="Portal">
	<div class="ssp-nav__inner">
		<?php foreach ( $ssp_nav as $ssp_path => $ssp_label ) : ?>
			<a href="<?php echo esc_url( home_url( '/' . $ssp_path . '/' ) ); ?>"<?php echo $ssp_cur( $ssp_path ); // phpcs:ignore ?>><?php echo esc_html( $ssp_label ); ?></a>
		<?php endforeach; ?>
	</div>
</nav>
<?php endif; ?>
<main id="ssp-main" class="ssp-main" tabindex="-1">
	<?php \SSP\Portal\View::partial( 'flash', array( 'flash' => $flash ?? array() ) ); ?>
	<?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput -- templates escape their own output. ?>
</main>
<footer class="ssp-footer">
	<div class="ssp-footer__inner">
		<div>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> Silver Stacker LLC &middot; Texas Coin Company &middot; Silver. Gold. Bullion.</div>
		<div>Private portal. Pricing is confidential and may not be shared. ETAs are estimates, not guaranteed delivery dates.</div>
		<?php if ( $ssp_gate_ok ) : ?><div><a href="<?php echo esc_url( ssp_url( 'terms/' ) ); ?>">Terms &amp; Conditions</a></div><?php endif; ?>
	</div>
</footer>
<?php if ( $ssp_customer && $ssp_gate_ok ) : ?>
<nav class="ssp-bottombar" aria-label="Quick navigation">
	<a href="<?php echo esc_url( ssp_url() ); ?>"<?php echo $ssp_cur( 'portal' ); // phpcs:ignore ?>><?php echo ssp_icon( 'home' ); // phpcs:ignore ?>Home</a>
	<a href="<?php echo esc_url( ssp_url( 'shop/' ) ); ?>"<?php echo $ssp_cur( 'portal/shop' ); // phpcs:ignore ?>><?php echo ssp_icon( 'stack' ); // phpcs:ignore ?>Shop</a>
	<a href="<?php echo esc_url( ssp_url( 'orders/' ) ); ?>"<?php echo $ssp_cur( 'portal/orders' ); // phpcs:ignore ?>><?php echo ssp_icon( 'orders' ); // phpcs:ignore ?>Orders</a>
	<a href="<?php echo esc_url( ssp_url( 'box/' ) ); ?>"<?php echo $ssp_cur( 'portal/box' ); // phpcs:ignore ?>><?php echo ssp_icon( 'box' ); // phpcs:ignore ?>My Box</a>
	<a href="<?php echo esc_url( ssp_url( 'account/' ) ); ?>"<?php echo $ssp_cur( 'portal/account' ); // phpcs:ignore ?>><?php echo ssp_icon( 'user' ); // phpcs:ignore ?>Account</a>
</nav>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
