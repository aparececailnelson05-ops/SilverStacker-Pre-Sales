<?php
/**
 * Public layout (login, registration, account status). Contains no catalog or pricing data.
 *
 * @var string $content
 * @var string $page_title
 */
defined( 'ABSPATH' ) || exit;
$ssp_wide = in_array( $page_title, array( 'Request access' ), true );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( ( $page_title ? $page_title . ' | ' : '' ) . 'Silver Stacker Pre-Sale Portal' ); ?></title>
<link rel="icon" href="<?php echo esc_url( SSP_URL . 'assets/img/logo.png' ); ?>">
<?php wp_head(); ?>
</head>
<body class="ssp ssp-public">
<div class="ssp-auth<?php echo $ssp_wide ? ' ssp-auth--wide' : ''; ?>">
	<div class="ssp-auth__art" style="background-image:url('<?php echo esc_url( SSP_URL . 'assets/img/banner.jpg' ); ?>')">
		<div>
			<h2>Private Pre-Sale Portal</h2>
			<p>Approved members order new releases before they arrive, consolidate items with Build A Box, and track every order from mint to mailbox.</p>
		</div>
	</div>
	<div class="ssp-auth__panel">
		<div class="ssp-auth__box<?php echo $ssp_wide ? ' ssp-auth__box--wide' : ''; ?>">
			<img class="ssp-auth__logo" src="<?php echo esc_url( SSP_URL . 'assets/img/logo.png' ); ?>" alt="Silver Stacker LLC, Texas Coin Company">
			<?php \SSP\Portal\View::partial( 'flash', array( 'flash' => $flash ?? array() ) ); ?>
			<?php echo $content; // phpcs:ignore ?>
		</div>
	</div>
</div>
<?php wp_footer(); ?>
</body>
</html>
