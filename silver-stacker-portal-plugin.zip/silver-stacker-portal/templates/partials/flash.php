<?php
defined( 'ABSPATH' ) || exit;
/** @var array $flash */
if ( empty( $flash ) ) {
	return;
}
foreach ( $flash as $ssp_f ) :
	$ssp_type = in_array( $ssp_f['type'], array( 'success', 'error', 'info', 'warn' ), true ) ? $ssp_f['type'] : 'info';
	?>
	<div class="ssp-alert ssp-alert--<?php echo esc_attr( $ssp_type ); ?>" role="<?php echo 'error' === $ssp_type ? 'alert' : 'status'; ?>">
		<div>
			<?php echo esc_html( $ssp_f['message'] ); ?>
			<?php if ( ! empty( $ssp_f['extra']['link'] ) ) : ?>
				<a href="<?php echo esc_url( $ssp_f['extra']['link'] ); ?>"><strong><?php echo esc_html( $ssp_f['extra']['link_text'] ?? 'View' ); ?></strong></a>
			<?php endif; ?>
		</div>
		<button type="button" class="ssp-btn ssp-btn--sm ssp-btn--ghost" data-dismiss aria-label="Dismiss message">&times;</button>
	</div>
<?php endforeach; ?>
