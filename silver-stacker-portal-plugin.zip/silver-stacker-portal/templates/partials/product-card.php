<?php
/**
 * Product card used on Shop, In-Stock, Search and Archive pages.
 *
 * @var object $p    Product row.
 * @var bool   $is_customer
 */
defined( 'ABSPATH' ) || exit;

use SSP\Domain\Allocation;
use SSP\Domain\Catalog;

$ssp_life     = Catalog::effective_lifecycle( $p );
$ssp_img      = Catalog::primary_image( $p->id );
$ssp_variants = Catalog::variants( $p->id, true );
$ssp_single   = 1 === count( $ssp_variants ) ? $ssp_variants[0] : null;
$ssp_order    = Catalog::is_orderable( $p );
$ssp_url      = Catalog::url( $p );
$ssp_alloc    = $ssp_single ? Allocation::availability_label( $ssp_single ) : null;
$ssp_max      = ( $ssp_single && $is_customer ) ? Allocation::max_addable( $ssp_single, get_current_user_id() ) : null;
?>
<article class="ssp-pcard" data-orderable>
	<a class="ssp-pcard__img" href="<?php echo esc_url( $ssp_url ); ?>" tabindex="-1" aria-hidden="true">
		<img src="<?php echo esc_url( Catalog::image_url( $ssp_img, 'thumb' ) ); ?>" alt="" loading="lazy" width="480" height="480">
		<span class="ssp-pcard__flags">
			<?php
			if ( 'archived' === $ssp_life ) {
				echo ssp_badge( 'Archive', 'muted' ); // phpcs:ignore
			} elseif ( 'in_stock' === $ssp_life ) {
				echo ssp_badge( 'In Stock', 'ok' ); // phpcs:ignore
			} elseif ( 'presale' === $ssp_life ) {
				echo ssp_badge( 'Presale', 'brand' ); // phpcs:ignore
			} else {
				echo ssp_badge( 'Pre-Sale Ended', 'neutral' ); // phpcs:ignore
			}
			if ( $p->metal ) {
				echo ssp_badge( $p->metal, 'neutral' ); // phpcs:ignore
			}
			?>
		</span>
	</a>
	<div class="ssp-pcard__body">
		<a class="ssp-pcard__name" href="<?php echo esc_url( $ssp_url ); ?>"><?php echo esc_html( Catalog::display_name( $p ) ); ?></a>
		<?php if ( 'archived' !== $ssp_life ) : ?>
			<div class="ssp-pcard__price"><?php echo esc_html( Catalog::price_range_label( $p ) ); ?></div>
		<?php endif; ?>
		<?php if ( 'presale' === $p->lifecycle && $p->closing_at ) : ?>
			<div><?php echo ssp_countdown( $p->closing_at ); // phpcs:ignore ?></div>
		<?php endif; ?>
		<?php if ( 'archived' !== $ssp_life ) : ?>
			<div><?php echo ssp_eta( $p ); // phpcs:ignore ?></div>
		<?php endif; ?>
		<?php if ( 'archived' === $ssp_life && $p->mintage ) : ?>
			<div class="ssp-pcard__meta">Mintage: <?php echo esc_html( $p->mintage ); ?></div>
		<?php endif; ?>
		<?php if ( $ssp_alloc && 'full' === $ssp_alloc[0] && $ssp_order ) : ?>
			<div><?php echo ssp_badge( 'Fully allocated: waitlist open', 'warn' ); // phpcs:ignore ?></div>
		<?php elseif ( $ssp_alloc && 'low' === $ssp_alloc[0] && $ssp_order ) : ?>
			<div><?php echo ssp_badge( 'Limited allocation', 'warn' ); // phpcs:ignore ?></div>
		<?php endif; ?>

		<?php if ( $is_customer && $ssp_order && $ssp_single && ( null === $ssp_max || $ssp_max > 0 ) ) : ?>
			<form method="post" action="<?php echo esc_url( $ssp_url ); ?>">
				<?php ssp_form_fields( 'cart_add' ); ?>
				<input type="hidden" name="variant_id" value="<?php echo (int) $ssp_single->id; ?>">
				<span class="ssp-qty">
					<button type="button" data-qty-step="-1" aria-label="Decrease quantity" data-order-control>&minus;</button>
					<input type="number" name="qty" value="<?php echo (int) max( 1, $ssp_single->min_order_qty ); ?>" min="1" <?php echo null !== $ssp_max ? 'max="' . (int) $ssp_max . '"' : ''; ?> aria-label="Quantity" data-order-control>
					<button type="button" data-qty-step="1" aria-label="Increase quantity" data-order-control>+</button>
				</span>
				<button class="ssp-btn ssp-btn--primary ssp-btn--sm" type="submit" data-order-control>Add to Order</button>
			</form>
			<p class="ssp-note" data-ended-msg hidden>Pre-Sale Ended. This item can no longer be ordered.</p>
		<?php elseif ( $is_customer && $ssp_order ) : ?>
			<a class="ssp-btn ssp-btn--ghost ssp-btn--sm" href="<?php echo esc_url( $ssp_url ); ?>"><?php echo $ssp_single ? 'Join waitlist' : 'Choose option'; ?></a>
		<?php else : ?>
			<a class="ssp-btn ssp-btn--ghost ssp-btn--sm" href="<?php echo esc_url( $ssp_url ); ?>">View details</a>
		<?php endif; ?>
	</div>
</article>
