<?php
/**
 * Registration wizard: (1) account, (2) business and addresses, (3) qualification questions.
 *
 * @var array  $questions
 * @var array  $old
 * @var array|null $invite
 * @var string $invite_token
 */
defined( 'ABSPATH' ) || exit;

use SSP\Domain\Customers;

$ssp_o  = function ( $k, $sub = null ) use ( $old ) {
	$v = $sub ? ( $old[ $k ][ $sub ] ?? '' ) : ( $old[ $k ] ?? '' );
	return esc_attr( is_string( $v ) ? $v : '' );
};
$ssp_email = $old['email'] ?? ( $invite['email'] ?? '' );
$ssp_name  = $old['contact_name'] ?? ( $invite['name'] ?? '' );
$ssp_same  = ! $old || ! empty( $old['shipping_same'] );

$ssp_addr = function ( $prefix, $required ) use ( $ssp_o ) {
	$req = $required ? ' required' : ' data-req';
	?>
	<div class="ssp-row">
		<div class="ssp-field"><label for="<?php echo esc_attr( $prefix ); ?>-name">Full name</label><input id="<?php echo esc_attr( $prefix ); ?>-name" type="text" name="<?php echo esc_attr( $prefix ); ?>[name]" value="<?php echo $ssp_o( $prefix, 'name' ); // phpcs:ignore ?>" autocomplete="name"<?php echo $req; // phpcs:ignore ?>></div>
		<div class="ssp-field"><label for="<?php echo esc_attr( $prefix ); ?>-company">Company (optional)</label><input id="<?php echo esc_attr( $prefix ); ?>-company" type="text" name="<?php echo esc_attr( $prefix ); ?>[company]" value="<?php echo $ssp_o( $prefix, 'company' ); // phpcs:ignore ?>" autocomplete="organization"></div>
	</div>
	<div class="ssp-field"><label for="<?php echo esc_attr( $prefix ); ?>-line1">Street address</label><input id="<?php echo esc_attr( $prefix ); ?>-line1" type="text" name="<?php echo esc_attr( $prefix ); ?>[line1]" value="<?php echo $ssp_o( $prefix, 'line1' ); // phpcs:ignore ?>" autocomplete="address-line1"<?php echo $req; // phpcs:ignore ?>></div>
	<div class="ssp-field"><label for="<?php echo esc_attr( $prefix ); ?>-line2">Apartment, suite, etc. (optional)</label><input id="<?php echo esc_attr( $prefix ); ?>-line2" type="text" name="<?php echo esc_attr( $prefix ); ?>[line2]" value="<?php echo $ssp_o( $prefix, 'line2' ); // phpcs:ignore ?>" autocomplete="address-line2"></div>
	<div class="ssp-row">
		<div class="ssp-field"><label for="<?php echo esc_attr( $prefix ); ?>-city">City</label><input id="<?php echo esc_attr( $prefix ); ?>-city" type="text" name="<?php echo esc_attr( $prefix ); ?>[city]" value="<?php echo $ssp_o( $prefix, 'city' ); // phpcs:ignore ?>" autocomplete="address-level2"<?php echo $req; // phpcs:ignore ?>></div>
		<div class="ssp-field"><label for="<?php echo esc_attr( $prefix ); ?>-state">State</label><input id="<?php echo esc_attr( $prefix ); ?>-state" type="text" name="<?php echo esc_attr( $prefix ); ?>[state]" value="<?php echo $ssp_o( $prefix, 'state' ); // phpcs:ignore ?>" autocomplete="address-level1" maxlength="50"<?php echo $req; // phpcs:ignore ?>></div>
		<div class="ssp-field"><label for="<?php echo esc_attr( $prefix ); ?>-zip">ZIP / postal code</label><input id="<?php echo esc_attr( $prefix ); ?>-zip" type="text" name="<?php echo esc_attr( $prefix ); ?>[postal_code]" value="<?php echo $ssp_o( $prefix, 'postal_code' ); // phpcs:ignore ?>" autocomplete="postal-code"<?php echo $req; // phpcs:ignore ?>></div>
	</div>
	<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[country]" value="US">
	<?php
};
?>
<h1 style="text-align:center">Request Pre-Sale Access</h1>
<p class="ssp-muted" style="text-align:center">Create your individual account. Our team reviews every request before access is granted.</p>

<div class="ssp-wizard__steps" aria-hidden="true"><span class="is-active"></span><span></span><span></span></div>

<form method="post" action="<?php echo esc_url( home_url( '/register/' ) ); ?>" class="ssp-wizard" novalidate data-once>
	<?php ssp_form_fields( 'register' ); ?>
	<input type="hidden" name="invite_token" value="<?php echo esc_attr( $invite_token ); ?>">
	<div class="ssp-hp" aria-hidden="true"><label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>

	<section data-step class="is-active" aria-labelledby="step1">
		<fieldset class="ssp-fieldset">
			<legend id="step1">Step 1 of 3: Your account</legend>
			<div class="ssp-row">
				<div class="ssp-field"><label for="contact_name">Contact name</label><input id="contact_name" type="text" name="contact_name" value="<?php echo esc_attr( $ssp_name ); ?>" autocomplete="name" required></div>
				<div class="ssp-field"><label for="phone">Phone</label><input id="phone" type="tel" name="phone" value="<?php echo $ssp_o( 'phone' ); // phpcs:ignore ?>" autocomplete="tel" required></div>
			</div>
			<div class="ssp-field"><label for="email">Email address</label><input id="email" type="email" name="email" value="<?php echo esc_attr( $ssp_email ); ?>" autocomplete="email" required><span class="ssp-help">This is your login. It must be your own email address.</span></div>
			<div class="ssp-row">
				<div class="ssp-field"><label for="password">Password</label><input id="password" type="password" name="password" autocomplete="new-password" minlength="10" required><span class="ssp-help">At least 10 characters.</span></div>
				<div class="ssp-field"><label for="password_confirm">Confirm password</label><input id="password_confirm" type="password" name="password_confirm" autocomplete="new-password" minlength="10" required></div>
			</div>
			<label class="ssp-check"><input type="checkbox" name="agree_individual" value="1" required <?php checked( ! empty( $old['agree_individual'] ) ); ?>> This account is for me individually. I will not share my login with anyone.</label>
		</fieldset>
		<div class="ssp-between"><a href="<?php echo esc_url( home_url( '/login/' ) ); ?>">Already approved? Log in</a><button class="ssp-btn ssp-btn--primary ssp-btn--lg" data-next type="button">Continue</button></div>
	</section>

	<section data-step aria-labelledby="step2">
		<fieldset class="ssp-fieldset">
			<legend id="step2">Step 2 of 3: Business and addresses</legend>
			<div class="ssp-field"><label for="company_name">Company or store name</label><input id="company_name" type="text" name="company_name" value="<?php echo $ssp_o( 'company_name' ); // phpcs:ignore ?>" autocomplete="organization" required><span class="ssp-help">If you do not have a business, enter your name.</span></div>
			<h3>Billing address</h3>
			<?php $ssp_addr( 'billing', true ); ?>
			<label class="ssp-check ssp-mt"><input type="checkbox" name="shipping_same" value="1" <?php checked( $ssp_same ); ?>> Shipping address is the same as billing</label>
			<div data-shipping-block class="ssp-mt">
				<h3>Shipping address</h3>
				<?php $ssp_addr( 'shipping', false ); ?>
			</div>
		</fieldset>
		<div class="ssp-between"><button class="ssp-btn ssp-btn--ghost" data-prev type="button">Back</button><button class="ssp-btn ssp-btn--primary ssp-btn--lg" data-next type="button">Continue</button></div>
	</section>

	<section data-step aria-labelledby="step3">
		<fieldset class="ssp-fieldset">
			<legend id="step3">Step 3 of 3: A few questions</legend>
			<p class="ssp-muted">This is a private, trust-based pre-sale group. Please answer every question.</p>
			<?php foreach ( $questions as $ssp_i => $q ) : ?>
				<?php $ssp_val = (string) ( $old['answers'][ $q->id ] ?? '' ); ?>
				<div class="ssp-question">
					<p><?php echo (int) ( $ssp_i + 1 ); ?>. <?php echo wp_kses( make_clickable( esc_html( Customers::question_text( $q ) ) ), array( 'a' => array( 'href' => array(), 'rel' => array() ) ) ); ?></p>
					<?php if ( 'yesno' === $q->answer_type ) : ?>
						<div class="ssp-yesno" role="radiogroup">
							<label><input type="radio" name="answers[<?php echo (int) $q->id; ?>]" value="Yes" required <?php checked( 'Yes', $ssp_val ); ?>> Yes</label>
							<label><input type="radio" name="answers[<?php echo (int) $q->id; ?>]" value="No" <?php checked( 'No', $ssp_val ); ?>> No</label>
						</div>
					<?php else : ?>
						<textarea name="answers[<?php echo (int) $q->id; ?>]" rows="2" required aria-label="Your answer"><?php echo esc_textarea( $ssp_val ); ?></textarea>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</fieldset>
		<div class="ssp-between"><button class="ssp-btn ssp-btn--ghost" data-prev type="button">Back</button><button class="ssp-btn ssp-btn--accent ssp-btn--lg" type="submit">Submit request</button></div>
	</section>
</form>
