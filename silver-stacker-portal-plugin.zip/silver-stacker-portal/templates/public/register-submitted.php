<?php defined( 'ABSPATH' ) || exit; ?>
<div class="ssp-card" style="text-align:center">
	<h1>Thank you!</h1>
	<p>Your request has been received and is <strong>pending approval</strong>.</p>
	<p class="ssp-muted">Our team reviews every account personally. You will receive an email as soon as a decision is made. Until then, the catalog and pricing are not visible.</p>
	<a class="ssp-btn ssp-btn--primary" href="<?php echo esc_url( home_url( '/login/' ) ); ?>">Back to log in</a>
</div>
