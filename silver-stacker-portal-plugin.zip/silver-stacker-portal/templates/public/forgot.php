<?php defined( 'ABSPATH' ) || exit; ?>
<h1 style="text-align:center">Reset your password</h1>
<form method="post" action="<?php echo esc_url( home_url( '/forgot-password/' ) ); ?>" class="ssp-card" data-once>
	<?php ssp_form_fields( 'forgot' ); ?>
	<div class="ssp-field">
		<label for="user_login">Email address</label>
		<input id="user_login" type="email" name="user_login" autocomplete="email" required>
		<span class="ssp-help">We will email you a link to choose a new password.</span>
	</div>
	<button class="ssp-btn ssp-btn--primary ssp-btn--block" type="submit">Send reset link</button>
</form>
<p style="text-align:center" class="ssp-mt"><a href="<?php echo esc_url( home_url( '/login/' ) ); ?>">Back to log in</a></p>
