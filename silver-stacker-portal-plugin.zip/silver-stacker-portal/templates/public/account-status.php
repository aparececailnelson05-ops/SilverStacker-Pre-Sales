<?php
/**
 * @var string|null $status
 * @var object|null $profile
 */
defined( 'ABSPATH' ) || exit;
$ssp_msgs = array(
	'pending'   => array( 'Pending approval', 'Thanks for registering. Your account is waiting for review by our team. We will email you when it is approved.' ),
	'rejected'  => array( 'Not approved', 'We were unable to approve this account request. If you believe this is a mistake, please contact us.' ),
	'suspended' => array( 'Access paused', 'Pre-sale access for this account is currently paused. Please contact us for more information.' ),
	'none'      => array( 'No customer account', 'This login is not linked to a pre-sale customer account.' ),
);
$ssp_m = $ssp_msgs[ $status ] ?? null;
?>
<div class="ssp-card" style="text-align:center">
	<?php if ( $ssp_m ) : ?>
		<p><?php echo ssp_badge( $ssp_m[0], ssp_status_kind( $status ) ); // phpcs:ignore ?></p>
		<h1>Account status</h1>
		<p><?php echo esc_html( $ssp_m[1] ); ?></p>
		<?php if ( $profile && 'pending' === $status ) : ?>
			<p class="ssp-muted ssp-small">Registered <?php echo esc_html( \SSP\Core\Util::fmt_dt( $profile->created_at ) ); ?> as <?php echo esc_html( $profile->company_name ); ?>.</p>
		<?php endif; ?>
		<a class="ssp-btn ssp-btn--ghost" href="<?php echo esc_url( wp_nonce_url( home_url( '/portal/logout/' ), 'ssp_logout' ) ); ?>">Log out</a>
	<?php else : ?>
		<h1>Account status</h1>
		<p>Please log in to see your account status.</p>
		<a class="ssp-btn ssp-btn--primary" href="<?php echo esc_url( home_url( '/login/' ) ); ?>">Log in</a>
	<?php endif; ?>
</div>
