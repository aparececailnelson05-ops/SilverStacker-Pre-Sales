<?php
/**
 * @var bool   $valid
 * @var string $login
 * @var string $key
 */
defined( 'ABSPATH' ) || exit;
?>
<h1 style="text-align:center">Choose a new password</h1>
<?php if ( ! $valid ) : ?>
	<div class="ssp-alert ssp-alert--error" role="alert"><div>This reset link is invalid or has expired.</div></div>
	<p style="text-align:center"><a class="ssp-btn ssp-btn--primary" href="<?php echo esc_url( home_url( '/forgot-password/' ) ); ?>">Request a new link</a></p>
<?php else : ?>
<form method="post" action="<?php echo esc_url( home_url( '/reset-password/' ) ); ?>" class="ssp-card" data-once>
	<?php ssp_form_fields( 'reset' ); ?>
	<input type="hidden" name="login" value="<?php echo esc_attr( $login ); ?>">
	<input type="hidden" name="key" value="<?php echo esc_attr( $key ); ?>">
	<div class="ssp-field"><label for="pass1">New password</label><input id="pass1" type="password" name="pass1" minlength="10" autocomplete="new-password" required></div>
	<div class="ssp-field"><label for="pass2">Confirm new password</label><input id="pass2" type="password" name="pass2" minlength="10" autocomplete="new-password" required></div>
	<button class="ssp-btn ssp-btn--primary ssp-btn--block" type="submit">Save password</button>
</form>
<?php endif; ?>
