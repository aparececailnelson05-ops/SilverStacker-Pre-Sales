<?php
defined( 'ABSPATH' ) || exit;
$ssp_redirect = isset( $_GET['redirect_to'] ) ? sanitize_text_field( wp_unslash( $_GET['redirect_to'] ) ) : '';
?>
<h1 style="text-align:center">Member Log In</h1>
<p class="ssp-muted" style="text-align:center">This is a private portal for approved Silver Stacker customers.</p>
<?php if ( isset( $_GET['loggedout'] ) ) : ?>
	<div class="ssp-alert ssp-alert--info" role="status"><div>You have been logged out.</div></div>
<?php endif; ?>
<form method="post" action="<?php echo esc_url( home_url( '/login/' ) ); ?>" class="ssp-card" data-once>
	<?php ssp_form_fields( 'login' ); ?>
	<input type="hidden" name="redirect_to" value="<?php echo esc_attr( $ssp_redirect ); ?>">
	<div class="ssp-field">
		<label for="log">Email or username</label>
		<input id="log" name="log" type="text" autocomplete="username" required autofocus>
	</div>
	<div class="ssp-field">
		<label for="pwd">Password</label>
		<input id="pwd" name="pwd" type="password" autocomplete="current-password" required>
	</div>
	<div class="ssp-between">
		<label class="ssp-check"><input type="checkbox" name="rememberme" value="1"> Keep me logged in</label>
		<a href="<?php echo esc_url( home_url( '/forgot-password/' ) ); ?>">Forgot password?</a>
	</div>
	<button class="ssp-btn ssp-btn--primary ssp-btn--block ssp-btn--lg ssp-mt" type="submit">Log In</button>
</form>
<p style="text-align:center" class="ssp-mt">New to Silver Stacker Pre-Sales? <a href="<?php echo esc_url( home_url( '/register/' ) ); ?>"><strong>Request access</strong></a></p>
<p class="ssp-note" style="text-align:center">Every person needs their own account. Accounts and passwords may not be shared.</p>
