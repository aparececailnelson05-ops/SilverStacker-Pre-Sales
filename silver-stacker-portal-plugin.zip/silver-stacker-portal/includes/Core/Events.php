<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Domain events. Services emit events after their database transaction commits;
 * integration listeners turn them into queued jobs so external failures never block customers.
 *
 * Event names: customer.created, customer.status_changed, order.submitted, line.changed,
 * line.availability_changed, box.changed, box.status_changed, shipment.changed,
 * invoice.changed, waitlist.changed, variant.allocation_changed, product.changed
 */
class Events {

	public static function emit( $name, array $data = array() ) {
		do_action( 'ssp_event', $name, $data );
		do_action( 'ssp_event_' . str_replace( '.', '_', $name ), $data );
	}
}
