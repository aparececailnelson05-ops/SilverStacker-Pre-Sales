<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Private file storage. Product images and staff resources are never placed in the
 * public Media Library. They are stored under uploads/ss-private (denied by .htaccess;
 * add the equivalent nginx rule, see docs/DEPLOYMENT.md) and streamed by PHP after
 * an access check. Define SSP_PRIVATE_DIR to store files outside the web root.
 */
class Media {

	const SIZES = array(
		'thumb' => 480,
		'large' => 1400,
	);

	public static function base_dir() {
		if ( defined( 'SSP_PRIVATE_DIR' ) ) {
			return trailingslashit( SSP_PRIVATE_DIR );
		}
		$u = wp_upload_dir( null, false );
		return trailingslashit( $u['basedir'] ) . 'ss-private/';
	}

	public static function ensure_private_dir() {
		$dir = self::base_dir();
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! file_exists( $dir . '.htaccess' ) ) {
			file_put_contents( $dir . '.htaccess', "# Silver Stacker private files\nRequire all denied\nDeny from all\n" );
		}
		if ( ! file_exists( $dir . 'index.php' ) ) {
			file_put_contents( $dir . 'index.php', "<?php // Silence.\n" );
		}
		foreach ( array( 'products', 'resources', 'invoices' ) as $sub ) {
			if ( ! is_dir( $dir . $sub ) ) {
				wp_mkdir_p( $dir . $sub );
				file_put_contents( $dir . $sub . '/index.php', "<?php // Silence.\n" );
			}
		}
	}

	/**
	 * Stores an uploaded image (an element of $_FILES) privately and creates resized copies.
	 *
	 * @return array|\WP_Error { file_path, sizes, mime }
	 */
	public static function store_image( array $file ) {
		self::ensure_private_dir();
		if ( ! empty( $file['error'] ) ) {
			return new \WP_Error( 'upload', 'Upload failed (code ' . (int) $file['error'] . ').' );
		}
		$check   = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], array(
			'jpg|jpeg' => 'image/jpeg',
			'png'      => 'image/png',
			'gif'      => 'image/gif',
			'webp'     => 'image/webp',
		) );
		$allowed = array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' );
		if ( empty( $check['type'] ) || ! in_array( $check['type'], $allowed, true ) ) {
			return new \WP_Error( 'type', 'Only JPEG, PNG, GIF or WEBP images are allowed.' );
		}
		if ( ! @getimagesize( $file['tmp_name'] ) ) {
			return new \WP_Error( 'type', 'The file is not a valid image.' );
		}
		$ext  = $check['ext'];
		$sub  = 'products/' . gmdate( 'Y/m' ) . '/';
		$dir  = self::base_dir() . $sub;
		wp_mkdir_p( $dir );
		$name = strtolower( Util::ulid() ) . '.' . $ext;
		$dest = $dir . $name;
		if ( is_uploaded_file( $file['tmp_name'] ) ) {
			$ok = move_uploaded_file( $file['tmp_name'], $dest );
		} else {
			$ok = copy( $file['tmp_name'], $dest ); // CLI imports.
		}
		if ( ! $ok ) {
			return new \WP_Error( 'move', 'Could not store the image.' );
		}
		$sizes = array();
		foreach ( self::SIZES as $size => $px ) {
			$editor = wp_get_image_editor( $dest );
			if ( is_wp_error( $editor ) ) {
				continue;
			}
			$editor->resize( $px, $px, false );
			$out   = $dir . pathinfo( $name, PATHINFO_FILENAME ) . '-' . $size . '.' . $ext;
			$saved = $editor->save( $out );
			if ( ! is_wp_error( $saved ) ) {
				$sizes[ $size ] = $sub . basename( $saved['path'] );
			}
		}
		return array(
			'file_path' => $sub . $name,
			'sizes'     => $sizes,
			'mime'      => $check['type'],
		);
	}

	public static function store_resource( array $file ) {
		self::ensure_private_dir();
		if ( ! empty( $file['error'] ) ) {
			return new \WP_Error( 'upload', 'Upload failed.' );
		}
		$check = wp_check_filetype( $file['name'] );
		$blocked = array( 'php', 'phtml', 'phar', 'exe', 'sh', 'js', 'html', 'htm', 'svg' );
		$ext   = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		if ( in_array( $ext, $blocked, true ) ) {
			return new \WP_Error( 'type', 'That file type is not allowed.' );
		}
		$sub  = 'resources/' . gmdate( 'Y/m' ) . '/';
		wp_mkdir_p( self::base_dir() . $sub );
		$name = strtolower( Util::ulid() ) . ( $ext ? '.' . $ext : '' );
		$ok   = is_uploaded_file( $file['tmp_name'] ) ? move_uploaded_file( $file['tmp_name'], self::base_dir() . $sub . $name ) : copy( $file['tmp_name'], self::base_dir() . $sub . $name );
		if ( ! $ok ) {
			return new \WP_Error( 'move', 'Could not store the file.' );
		}
		return array(
			'file_path' => $sub . $name,
			'file_name' => sanitize_file_name( $file['name'] ),
			'mime'      => $check['type'] ? $check['type'] : 'application/octet-stream',
			'size'      => (int) filesize( self::base_dir() . $sub . $name ),
		);
	}

	public static function delete_relative( $rel ) {
		$path = self::safe_path( $rel );
		if ( $path && file_exists( $path ) ) {
			wp_delete_file( $path );
		}
	}

	/** Resolves a relative path inside the private dir, refusing traversal. */
	public static function safe_path( $rel ) {
		$rel  = ltrim( str_replace( '\\', '/', (string) $rel ), '/' );
		if ( '' === $rel || strpos( $rel, '..' ) !== false ) {
			return false;
		}
		$full = self::base_dir() . $rel;
		$real = realpath( $full );
		$base = realpath( self::base_dir() );
		if ( ! $real || ! $base || strpos( $real, $base ) !== 0 ) {
			return false;
		}
		return $real;
	}

	public static function stream( $rel, $mime, $download_name = '', $cache_seconds = 3600 ) {
		$path = self::safe_path( $rel );
		if ( ! $path || ! is_readable( $path ) ) {
			status_header( 404 );
			exit;
		}
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		header( 'Content-Type: ' . $mime );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Cache-Control: private, max-age=' . (int) $cache_seconds );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		if ( $download_name ) {
			header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $download_name ) . '"' );
		}
		readfile( $path );
		exit;
	}
}
