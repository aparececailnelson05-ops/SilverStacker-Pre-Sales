<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Branded transactional email. Messages are queued as jobs (reliable, retryable) and logged.
 * Templates are editable in Settings > Email (decision D-7: final wording to be confirmed).
 */
class Mailer {

	const OPTION = 'ssp_email_templates';

	public static function default_templates() {
		return array(
			'account_approved'   => array(
				'label'   => 'Account approved',
				'subject' => 'Your Silver Stacker Pre-Sale account is approved',
				'body'    => "<p>Hi {name},</p><p>Good news! Your Silver Stacker LLC Pre-Sale Portal account has been approved.</p><p><a href=\"{login_url}\">Log in to the Pre-Sale Portal</a></p><p><strong>Next steps</strong></p><ol><li>Log in with the email and password you registered with.</li><li>Read and accept the Pre-Sale Terms &amp; Conditions.</li><li>Browse current offers, choose quantities, and click <strong>Submit Pre-Order</strong>. No payment is due until you are invoiced.</li></ol><p>Thank you,<br>Silver Stacker LLC</p>",
			),
			'account_rejected'   => array(
				'label'   => 'Account rejected',
				'subject' => 'Your Silver Stacker Pre-Sale account request',
				'body'    => "<p>Hi {name},</p><p>Thank you for your interest in the Silver Stacker LLC Pre-Sale Portal. We are unable to approve your account request at this time.</p><p>{reason}</p><p>If you believe this is a mistake, please reply to this email.</p><p>Silver Stacker LLC</p>",
			),
			'account_suspended'  => array(
				'label'   => 'Account suspended',
				'subject' => 'Your Silver Stacker Pre-Sale account',
				'body'    => "<p>Hi {name},</p><p>Your Pre-Sale Portal access has been paused.</p><p>{reason}</p><p>Please reply to this email if you have questions.</p><p>Silver Stacker LLC</p>",
			),
			'customer_invite'    => array(
				'label'   => 'Customer invitation',
				'subject' => 'You are invited to the Silver Stacker Pre-Sale Portal',
				'body'    => "<p>Hi {name},</p><p>You have been invited to register for the Silver Stacker LLC Pre-Sale Portal.</p><p><a href=\"{invite_url}\">Complete your registration</a> (link valid for 7 days).</p><p>Silver Stacker LLC</p>",
			),
			'waitlist_available' => array(
				'label'   => 'Waitlist item available',
				'subject' => 'Good news: {product} is available for you',
				'body'    => "<p>Hi {name},</p><p>Allocation has opened up for <strong>{product}</strong> that you are waitlisted for.</p><p>{action_text}</p><p><a href=\"{waitlist_url}\">Go to my waitlist</a></p><p>Silver Stacker LLC</p>",
			),
			'line_invoiced'      => array(
				'label'   => 'Item arrived and invoiced',
				'subject' => 'Your items have arrived: invoice {invoice_number}',
				'body'    => "<p>Hi {name},</p><p>The following items have arrived and have been invoiced:</p>{lines_table}<p>Invoice {invoice_number} total: {invoice_total}. QuickBooks will send the formal invoice with payment options.</p><p><a href=\"{invoices_url}\">View invoices in the portal</a></p><p>Silver Stacker LLC</p>",
			),
			'box_changed'        => array(
				'label'   => 'Box contents changed',
				'subject' => 'Your Silver Stacker box was updated',
				'body'    => "<p>Hi {name},</p><p>Your box #{box_number} contents changed:</p>{changes}<p><a href=\"{box_url}\">View My Box</a></p><p>Silver Stacker LLC</p>",
			),
			'box_shipped'        => array(
				'label'   => 'Box / shipment shipped',
				'subject' => 'Your Silver Stacker shipment is on the way',
				'body'    => "<p>Hi {name},</p><p>Your shipment has been sent via {carrier}. Tracking number: <strong>{tracking}</strong>.</p><p><a href=\"{box_url}\">View details</a></p><p>Silver Stacker LLC</p>",
			),
			'order_confirmation' => array(
				'label'   => 'Order confirmation (optional, off by default)',
				'subject' => 'Pre-order #{order_number} received',
				'body'    => "<p>Hi {name},</p><p>We received your pre-order #{order_number}.</p>{lines_table}<p>No payment is due until your items arrive and are invoiced.</p><p><a href=\"{order_url}\">View order</a></p><p>Silver Stacker LLC</p>",
			),
			'staff_new_registration' => array(
				'label'   => 'Staff alert: new registration',
				'subject' => 'New Pre-Sale registration awaiting approval: {company}',
				'body'    => "<p>{name} ({company}) registered and is awaiting approval.</p><p><a href=\"{admin_url}\">Review registration</a></p>",
			),
		);
	}

	public static function templates() {
		$saved = get_option( self::OPTION );
		$def   = self::default_templates();
		if ( is_array( $saved ) ) {
			foreach ( $saved as $k => $v ) {
				if ( isset( $def[ $k ] ) ) {
					$def[ $k ]['subject'] = $v['subject'] ?? $def[ $k ]['subject'];
					$def[ $k ]['body']    = $v['body'] ?? $def[ $k ]['body'];
				}
			}
		}
		return $def;
	}

	/**
	 * Queue a templated email.
	 *
	 * @param string $template Template key.
	 * @param string $to       Email address.
	 * @param array  $vars     Placeholder values (already escaped HTML where noted: lines_table, changes).
	 */
	public static function queue( $template, $to, array $vars, $user_id = null, $object_type = '', $object_id = '', $dedupe_key = null ) {
		global $wpdb;
		if ( ! is_email( $to ) ) {
			return 0;
		}
		$tpls = self::templates();
		if ( ! isset( $tpls[ $template ] ) ) {
			return 0;
		}
		$vars = array_merge(
			array(
				'portal_url'   => home_url( '/portal/' ),
				'login_url'    => home_url( '/login/' ),
				'box_url'      => home_url( '/portal/box/' ),
				'invoices_url' => home_url( '/portal/invoices/' ),
				'waitlist_url' => home_url( '/portal/waitlist/' ),
			),
			$vars
		);
		$html_keys = array( 'lines_table', 'changes' );
		$replace   = array();
		foreach ( $vars as $k => $v ) {
			$replace[ '{' . $k . '}' ] = in_array( $k, $html_keys, true ) ? (string) $v : esc_html( (string) $v );
		}
		// URLs are inserted into href attributes; esc_html is safe there, but use esc_url for clarity.
		foreach ( array( 'portal_url', 'login_url', 'box_url', 'invoices_url', 'waitlist_url', 'invite_url', 'order_url', 'admin_url' ) as $uk ) {
			if ( isset( $vars[ $uk ] ) ) {
				$replace[ '{' . $uk . '}' ] = esc_url( $vars[ $uk ] );
			}
		}
		$subject = wp_strip_all_tags( strtr( $tpls[ $template ]['subject'], array_map( 'html_entity_decode', $replace ) ) );
		$body    = strtr( $tpls[ $template ]['body'], $replace );

		$wpdb->insert(
			Installer::tables()['notifications'],
			array(
				'user_id'     => $user_id,
				'email'       => $to,
				'template'    => $template,
				'subject'     => substr( $subject, 0, 255 ),
				'object_type' => $object_type,
				'object_id'   => (string) $object_id,
				'status'      => 'queued',
				'created_at'  => Util::now(),
			)
		);
		$nid = (int) $wpdb->insert_id;
		Jobs::enqueue(
			'email',
			'email.send',
			'notification',
			$nid,
			array(
				'notification_id' => $nid,
				'to'              => $to,
				'subject'         => $subject,
				'body'            => $body,
			),
			$dedupe_key ? $dedupe_key : 'email:' . $nid
		);
		return $nid;
	}

	/** Job handler. */
	public static function send_job( array $p ) {
		global $wpdb;
		$from_name = Settings::get( 'email_from_name' );
		$from      = Settings::get( 'email_from_address' );
		$reply     = Settings::get( 'email_reply_to' );
		$headers   = array( 'Content-Type: text/html; charset=UTF-8' );
		if ( $from && is_email( $from ) ) {
			$headers[] = 'From: ' . $from_name . ' <' . $from . '>';
		}
		if ( $reply && is_email( $reply ) ) {
			$headers[] = 'Reply-To: ' . $reply;
		}
		$ok = wp_mail( $p['to'], $p['subject'], self::wrap( $p['body'] ), $headers );
		$wpdb->update(
			Installer::tables()['notifications'],
			array(
				'status'  => $ok ? 'sent' : 'failed',
				'sent_at' => $ok ? Util::now() : null,
				'error'   => $ok ? null : 'wp_mail returned false',
			),
			array( 'id' => (int) $p['notification_id'] )
		);
		if ( ! $ok ) {
			return new \WP_Error( 'mail', 'wp_mail failed. Check SMTP configuration.' );
		}
		return true;
	}

	public static function wrap( $inner ) {
		$logo = esc_url( SSP_URL . 'assets/img/logo.png' );
		return '<!doctype html><html><body style="margin:0;background:#f4f4f7;font-family:Roboto,Arial,sans-serif;color:#120f10">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px">'
			. '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:8px;overflow:hidden;max-width:600px">'
			. '<tr><td style="background:#07067b;padding:16px 24px;border-bottom:4px solid #b90c1c"><img src="' . $logo . '" alt="Silver Stacker" height="56"></td></tr>'
			. '<tr><td style="padding:24px;font-size:15px;line-height:1.55">' . $inner . '</td></tr>'
			. '<tr><td style="padding:16px 24px;font-size:12px;color:#666;background:#fafafa">Silver Stacker LLC &middot; Texas Coin Company &middot; Silver. Gold. Bullion.<br>Pricing in this message is confidential.</td></tr>'
			. '</table></td></tr></table></body></html>';
	}

	public static function lines_table( array $rows ) {
		$h = '<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;width:100%;font-size:14px"><tr style="background:#f0f0f6"><th align="left">Item</th><th align="right">Qty</th><th align="right">Price</th></tr>';
		foreach ( $rows as $r ) {
			$h .= '<tr style="border-bottom:1px solid #eee"><td>' . esc_html( $r['name'] ) . '</td><td align="right">' . (int) $r['qty'] . '</td><td align="right">' . esc_html( Util::money( $r['price'] ) ) . '</td></tr>';
		}
		return $h . '</table>';
	}
}
