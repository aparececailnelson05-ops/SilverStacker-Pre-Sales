<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/** Thrown by job handlers for errors that retrying cannot fix (moves the job to "dead"). */
class PermanentJobError extends \RuntimeException {}
