<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Configuration. Items flagged "unconfirmed" correspond to open business decisions (D-xx)
 * and are shown with a warning in the staff Settings screen until confirmed.
 */
class Settings {

	const OPTION = 'ssp_settings';

	public static function defaults() {
		return array(
			// General.
			'business_timezone'          => 'America/Chicago',          // D-13
			'default_closing_time'       => '23:59',                    // D-13
			'announcement'               => 'Welcome to Silver Stacker LLC Pre-Sales. Below are the current offers available. The date shown on each offer is the last day it will be available to order.',
			'append_closing_date_to_name'=> 1,                          // C-6
			'fb_group_link'              => 'https://www.facebook.com/share/g/1DA5pv3Jt7/',
			'metals'                     => array( 'Silver', 'Gold', 'Copper', 'Platinum' ),
			// Orders.
			'order_number_start'         => 15000,                      // D-14
			'min_qty_scope'              => 'customer_total',           // D-27: customer_total | per_line
			'zero_qty_cancels'           => 1,                          // D-6
			'instock_editable_until'     => 'available',                // D-9: available | invoiced | never
			'order_confirmation_email'   => 0,                          // D-15 / C-3
			'default_fulfillment_choice' => 'decide_later',
			// Waitlist.
			'waitlist_mode'              => 'hold',                     // D-1: hold | fcfs | auto
			'waitlist_hold_hours'        => 48,
			// Box.
			'max_open_boxes'             => 1,                          // D-2
			'address_change_until'       => 'preparing',                // D-3: preparing | shipment_requested | never
			'ship_unavailable_mode'      => 'customer_choice',          // D-19: customer_choice | wait_all | ship_available
			'fulfillment_change_until'   => 'preparing',                // D-29
			'box_auto_close_days'        => 14,
			'box_digest_minutes'         => 15,
			// Email.
			'email_from_name'            => 'Silver Stacker LLC',       // D-7
			'email_from_address'         => '',
			'email_reply_to'             => '',
			'staff_alert_email'          => '',
			// Roles.
			'reps_can_view_audit_log'    => 0,                          // D-23
			// QuickBooks.
			'qbo_environment'            => 'sandbox',
			'qbo_client_id'              => '',
			'qbo_client_secret'          => '',                         // encrypted
			'qbo_webhook_verifier'       => '',                         // encrypted
			'qbo_income_account_id'      => '',
			'qbo_shipping_item_id'       => '',
			'qbo_item_strategy'          => 'per_sku',                  // D-30: per_sku | generic
			'qbo_generic_item_id'        => '',
			'qbo_send_invoice_email'     => 1,
			'qbo_term_id'                => '',                         // D-28
			// Google Sheets.
			'sheets_enabled'             => 0,
			'sheets_spreadsheet_id'      => '',
			'sheets_service_account'     => '',                         // encrypted JSON
			// Warehouse.
			'warehouse_adapter'          => 'manual',                   // D-11: manual | webhook
			'warehouse_url'              => '',
			'warehouse_webhook_secret'   => '',                         // encrypted
			// Feature flags.
			'require_terms_reaccept'     => 1,                          // D-21
		);
	}

	public static function encrypted_keys() {
		return array( 'qbo_client_secret', 'qbo_webhook_verifier', 'sheets_service_account', 'warehouse_webhook_secret' );
	}

	public static function unconfirmed() {
		return array(
			'business_timezone'        => 'D-13 Closing time and timezone',
			'default_closing_time'     => 'D-13 Closing time and timezone',
			'order_number_start'       => 'D-14 Order numbering',
			'min_qty_scope'            => 'D-27 Minimum quantity scope',
			'zero_qty_cancels'         => 'D-6 Cancellation policy',
			'instock_editable_until'   => 'D-9 In-stock workflow',
			'order_confirmation_email' => 'D-15 Confirmation email',
			'waitlist_mode'            => 'D-1 Waitlist promotion',
			'waitlist_hold_hours'      => 'D-1 Waitlist promotion',
			'max_open_boxes'           => 'D-2 Open-box count',
			'address_change_until'     => 'D-3 Address change after box creation',
			'ship_unavailable_mode'    => 'D-19 Ship My Box with unavailable items',
			'fulfillment_change_until' => 'D-29 Fulfillment change',
			'reps_can_view_audit_log'  => 'D-23 Audit log visibility',
			'qbo_item_strategy'        => 'D-30 QuickBooks item mapping',
		);
	}

	public static function ensure_defaults() {
		$current = get_option( self::OPTION );
		if ( ! is_array( $current ) ) {
			add_option( self::OPTION, self::defaults(), '', false );
			return;
		}
		update_option( self::OPTION, array_merge( self::defaults(), $current ), false );
	}

	public static function all() {
		$v = get_option( self::OPTION );
		return array_merge( self::defaults(), is_array( $v ) ? $v : array() );
	}

	public static function get( $key ) {
		$all = self::all();
		$val = $all[ $key ] ?? null;
		if ( in_array( $key, self::encrypted_keys(), true ) && is_string( $val ) && '' !== $val ) {
			return Crypto::decrypt( $val );
		}
		return $val;
	}

	public static function set( $key, $value ) {
		$all = self::all();
		if ( in_array( $key, self::encrypted_keys(), true ) && is_string( $value ) && '' !== $value ) {
			$value = Crypto::encrypt( $value );
		}
		$all[ $key ] = $value;
		update_option( self::OPTION, $all, false );
	}

	/** Private option store (tokens, etc.) encrypted. */
	public static function secret_get( $name ) {
		$v = get_option( 'ssp_secret_' . $name );
		return $v ? Crypto::decrypt( $v ) : '';
	}

	public static function secret_set( $name, $value ) {
		update_option( 'ssp_secret_' . $name, Crypto::encrypt( (string) $value ), false );
	}
}
