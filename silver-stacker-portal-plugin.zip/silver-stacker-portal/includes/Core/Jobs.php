<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Durable, idempotent background job queue for integrations (QuickBooks, Google Sheets,
 * warehouse, email). Jobs are keyed by idempotency_key so repeating an event never creates
 * a duplicate job while one is pending. Failures retry with backoff and remain visible to
 * staff in Integrations > Job queue, where they can be retried safely.
 */
class Jobs {

	const BACKOFF_MINUTES = array( 1, 5, 15, 60, 240, 720, 1440 );
	const MAX_ATTEMPTS    = 8;

	/** @var array<string,callable> */
	private static $handlers = array();

	public static function register( $action, callable $handler ) {
		self::$handlers[ $action ] = $handler;
	}

	/**
	 * Enqueue a job. If a job with the same key is already queued/failed, it is refreshed
	 * (payload replaced, kept pending) rather than duplicated. Succeeded jobs with the same
	 * key are left alone unless $allow_repeat is true (used for "latest snapshot" exports).
	 */
	public static function enqueue( $integration, $action, $object_type, $object_id, array $payload = array(), $key = null, $delay_seconds = 0, $allow_repeat = false ) {
		global $wpdb;
		$t   = Installer::tables()['jobs'];
		$key = $key ? $key : $action . ':' . $object_type . ':' . $object_id;
		$now = Util::now();
		$next = Util::now( $delay_seconds );

		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT id,status FROM {$t} WHERE idempotency_key=%s", $key ) );
		if ( $existing ) {
			if ( in_array( $existing->status, array( 'queued', 'failed' ), true ) ) {
				$wpdb->update( $t, array( 'payload' => wp_json_encode( $payload ), 'updated_at' => $now ), array( 'id' => $existing->id ) );
				return (int) $existing->id;
			}
			if ( 'running' === $existing->status ) {
				// Re-run after the current run so the latest snapshot is exported.
				if ( $allow_repeat ) {
					$wpdb->update( $t, array( 'payload' => wp_json_encode( $payload ), 'updated_at' => $now, 'last_error' => 'rerun_requested' ), array( 'id' => $existing->id ) );
				}
				return (int) $existing->id;
			}
			if ( $allow_repeat || 'dead' === $existing->status ) {
				$wpdb->update(
					$t,
					array(
						'payload'         => wp_json_encode( $payload ),
						'status'          => 'queued',
						'attempts'        => 0,
						'next_attempt_at' => $next,
						'last_error'      => null,
						'updated_at'      => $now,
					),
					array( 'id' => $existing->id )
				);
			}
			return (int) $existing->id;
		}
		$wpdb->insert(
			$t,
			array(
				'integration'     => $integration,
				'action'          => $action,
				'object_type'     => $object_type,
				'object_id'       => (string) $object_id,
				'idempotency_key' => substr( $key, 0, 190 ),
				'payload'         => wp_json_encode( $payload ),
				'status'          => 'queued',
				'attempts'        => 0,
				'next_attempt_at' => $next,
				'created_at'      => $now,
				'updated_at'      => $now,
			)
		);
		return (int) $wpdb->insert_id;
	}

	/** Process due jobs. Safe to call concurrently; each job is claimed atomically. */
	public static function run( $limit = 25, $only_integration = null ) {
		global $wpdb;
		$t   = Installer::tables()['jobs'];
		$now = Util::now();
		$where_int = $only_integration ? $wpdb->prepare( ' AND integration=%s', $only_integration ) : '';
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM {$t} WHERE ( (status IN ('queued','failed') AND next_attempt_at <= %s) OR (status='running' AND locked_until < %s) ) {$where_int} ORDER BY next_attempt_at ASC, id ASC LIMIT %d",
				$now,
				$now,
				$limit
			)
		);
		$done = 0;
		foreach ( $ids as $id ) {
			$claimed = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$t} SET status='running', locked_until=%s, attempts=attempts+1, updated_at=%s WHERE id=%d AND ( status IN ('queued','failed') OR (status='running' AND locked_until < %s) )",
					Util::now( 300 ),
					$now,
					$id,
					$now
				)
			);
			if ( ! $claimed ) {
				continue;
			}
			self::execute( (int) $id );
			++$done;
		}
		return $done;
	}

	public static function execute( $id ) {
		global $wpdb;
		$t   = Installer::tables()['jobs'];
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
		if ( ! $job ) {
			return;
		}
		$handler = self::$handlers[ $job->action ] ?? null;
		try {
			if ( ! $handler ) {
				throw new \RuntimeException( 'No handler registered for ' . $job->action );
			}
			$payload = json_decode( (string) $job->payload, true );
			$result  = call_user_func( $handler, is_array( $payload ) ? $payload : array(), $job );
			if ( is_wp_error( $result ) ) {
				throw new \RuntimeException( $result->get_error_message() );
			}
			$rerun = ( 'rerun_requested' === $wpdb->get_var( $wpdb->prepare( "SELECT last_error FROM {$t} WHERE id=%d", $id ) ) );
			$wpdb->update(
				$t,
				array(
					'status'          => $rerun ? 'queued' : 'succeeded',
					'locked_until'    => null,
					'last_error'      => null,
					'attempts'        => $rerun ? 0 : $job->attempts,
					'next_attempt_at' => Util::now(),
					'updated_at'      => Util::now(),
				),
				array( 'id' => $id )
			);
		} catch ( \Throwable $e ) {
			$attempts = (int) $job->attempts;
			$dead     = $attempts >= self::MAX_ATTEMPTS || $e instanceof PermanentJobError;
			$delay    = self::BACKOFF_MINUTES[ min( $attempts - 1, count( self::BACKOFF_MINUTES ) - 1 ) ] ?? 60;
			$wpdb->update(
				$t,
				array(
					'status'          => $dead ? 'dead' : 'failed',
					'locked_until'    => null,
					'last_error'      => substr( $e->getMessage(), 0, 2000 ),
					'next_attempt_at' => Util::now( $delay * 60 ),
					'updated_at'      => Util::now(),
				),
				array( 'id' => $id )
			);
			if ( $dead ) {
				do_action( 'ssp_job_dead', $job, $e->getMessage() );
			}
		}
	}

	/** Staff-initiated safe retry. Handlers are idempotent so this never duplicates records. */
	public static function retry( $id ) {
		global $wpdb;
		$t = Installer::tables()['jobs'];
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status='queued', attempts=0, next_attempt_at=%s, updated_at=%s WHERE id=%d AND status IN ('failed','dead')", Util::now(), Util::now(), $id ) );
		Audit::log( 'job.retry', 'job', $id );
		// Run this job now (atomically claimed so a concurrent cron run cannot execute it twice).
		$claimed = $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status='running', locked_until=%s, attempts=attempts+1 WHERE id=%d AND status='queued'", Util::now( 300 ), $id ) );
		if ( $claimed ) {
			self::execute( (int) $id );
		}
	}

	public static function counts() {
		global $wpdb;
		$t    = Installer::tables()['jobs'];
		$rows = $wpdb->get_results( "SELECT integration, status, COUNT(*) c FROM {$t} GROUP BY integration, status" );
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ $r->integration ][ $r->status ] = (int) $r->c;
		}
		return $out;
	}

	public static function failing_count() {
		global $wpdb;
		$t = Installer::tables()['jobs'];
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status IN ('failed','dead')" );
	}
}
