<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Site-wide privacy hardening. The whole site is private: no public catalog, feeds,
 * sitemaps, search, author pages, oEmbed, XML-RPC or REST data for visitors.
 * Portal routes are additionally gated by \SSP\Portal\Router (approval + terms).
 */
class Security {

	public static function init() {
		add_filter( 'xmlrpc_enabled', '__return_false' );
		add_filter( 'wp_sitemaps_enabled', '__return_false' );
		add_filter( 'rest_authentication_errors', array( __CLASS__, 'rest_gate' ), 99 );
		add_filter( 'rest_endpoints', array( __CLASS__, 'rest_endpoints' ) );
		add_filter( 'wp_is_application_passwords_available_for_user', array( __CLASS__, 'app_passwords' ), 10, 2 );
		add_action( 'template_redirect', array( __CLASS__, 'gate_non_portal' ), 0 );
		add_action( 'admin_init', array( __CLASS__, 'block_admin_for_customers' ), 1 );
		add_filter( 'show_admin_bar', array( __CLASS__, 'admin_bar' ) );
		add_filter( 'robots_txt', array( __CLASS__, 'robots' ), 99, 2 );
		add_filter( 'wp_robots', array( __CLASS__, 'wp_robots' ), 99 );
		add_action( 'send_headers', array( __CLASS__, 'headers' ) );
		add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 10, 3 );
		add_filter( 'authenticate', array( __CLASS__, 'throttle_check' ), 30, 3 );
		add_action( 'wp_login_failed', array( __CLASS__, 'record_failed_login' ) );
		add_filter( 'login_url', array( __CLASS__, 'login_url' ), 10, 3 );
		add_filter( 'lostpassword_url', array( __CLASS__, 'lostpassword_url' ), 10, 2 );

		// Remove discovery links that could reveal content.
		remove_action( 'wp_head', 'feed_links', 2 );
		remove_action( 'wp_head', 'feed_links_extra', 3 );
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'wlwmanifest_link' );
		remove_action( 'wp_head', 'rest_output_link_wp_head' );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		remove_action( 'wp_head', 'wp_generator' );
		remove_action( 'template_redirect', 'rest_output_link_header', 11 );
		foreach ( array( 'do_feed', 'do_feed_rdf', 'do_feed_rss', 'do_feed_rss2', 'do_feed_atom', 'do_feed_rss2_comments', 'do_feed_atom_comments' ) as $feed ) {
			remove_all_actions( $feed );
			add_action( $feed, array( __CLASS__, 'deny_feed' ), 1 );
		}
	}

	public static function deny_feed() {
		status_header( 404 );
		exit;
	}

	/**
	 * Visitors: REST denied except signed inbound webhooks.
	 * Customers: only the ssp/v1 namespace (each route performs its own ownership checks).
	 * Staff: full access (wp-admin editor needs core routes).
	 */
	public static function rest_gate( $result ) {
		if ( ! empty( $result ) ) {
			return $result;
		}
		$route = self::current_rest_route();
		if ( strpos( $route, '/ssp/v1/hooks/' ) === 0 ) {
			return $result;
		}
		if ( ! is_user_logged_in() ) {
			return new \WP_Error( 'rest_forbidden', 'Authentication required.', array( 'status' => 401 ) );
		}
		if ( Roles::is_staff() ) {
			return $result;
		}
		if ( strpos( $route, '/ssp/v1/' ) === 0 ) {
			return $result;
		}
		return new \WP_Error( 'rest_forbidden', 'Not allowed.', array( 'status' => 403 ) );
	}

	private static function current_rest_route() {
		$route = '';
		if ( isset( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
			$route = $GLOBALS['wp']->query_vars['rest_route'];
		} elseif ( isset( $_GET['rest_route'] ) ) {
			$route = sanitize_text_field( wp_unslash( $_GET['rest_route'] ) );
		} elseif ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$uri    = wp_unslash( $_SERVER['REQUEST_URI'] );
			$prefix = '/' . rest_get_url_prefix();
			$pos    = strpos( $uri, $prefix );
			if ( false !== $pos ) {
				$route = strtok( substr( $uri, $pos + strlen( $prefix ) ), '?' );
			}
		}
		return '/' . ltrim( (string) $route, '/' );
	}

	public static function rest_endpoints( $endpoints ) {
		if ( ! Roles::is_staff() ) {
			foreach ( array_keys( $endpoints ) as $route ) {
				if ( preg_match( '#^/wp/v2/(users|media|search|comments|posts|pages|types|taxonomies|categories|tags|settings|plugins|themes|block-renderer)#', $route ) ) {
					unset( $endpoints[ $route ] );
				}
			}
			unset( $endpoints['/oembed/1.0/embed'], $endpoints['/oembed/1.0/proxy'] );
		}
		return $endpoints;
	}

	public static function app_passwords( $available, $user ) {
		return $user && user_can( $user, 'ssp_staff' ) ? $available : false;
	}

	/**
	 * Any normal WordPress front-end request (posts, pages, archives, search, attachments,
	 * author pages) is redirected into the portal flow. Only /portal and the public account
	 * routes render content, handled by the Router.
	 */
	public static function gate_non_portal() {
		if ( get_query_var( 'ssp_route' ) !== '' && null !== get_query_var( 'ssp_route', null ) ) {
			return;
		}
		if ( is_robots() || is_favicon() ) {
			return;
		}
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( home_url( '/login/' ) );
			exit;
		}
		wp_safe_redirect( home_url( '/portal/' ) );
		exit;
	}

	public static function block_admin_for_customers() {
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}
		if ( is_user_logged_in() && ! current_user_can( 'ssp_staff' ) && ! current_user_can( 'manage_options' ) ) {
			$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( wp_unslash( $_SERVER['SCRIPT_NAME'] ) ) : '';
			if ( 'admin-post.php' === $script ) {
				return;
			}
			wp_safe_redirect( home_url( '/portal/' ) );
			exit;
		}
	}

	public static function admin_bar( $show ) {
		return current_user_can( 'ssp_staff' ) ? $show : false;
	}

	public static function robots( $output, $public ) {
		return "User-agent: *\nDisallow: /\n";
	}

	public static function wp_robots( $robots ) {
		$robots['noindex']  = true;
		$robots['nofollow'] = true;
		unset( $robots['max-image-preview'] );
		return $robots;
	}

	public static function headers() {
		header( 'X-Robots-Tag: noindex, nofollow', true );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		if ( is_ssl() ) {
			header( 'Strict-Transport-Security: max-age=31536000; includeSubDomains' );
		}
	}

	public static function login_redirect( $redirect_to, $requested, $user ) {
		if ( $user instanceof \WP_User && ! user_can( $user, 'ssp_staff' ) && ! user_can( $user, 'manage_options' ) ) {
			return home_url( '/portal/' );
		}
		return $redirect_to;
	}

	public static function login_url( $url, $redirect, $force ) {
		// Keep wp-login.php available for staff; customers use the branded /login page.
		return $url;
	}

	public static function lostpassword_url( $url, $redirect ) {
		return home_url( '/forgot-password/' );
	}

	/* ---------- Brute-force throttling (per IP + username) ---------- */

	private static function throttle_key( $username ) {
		return 'ssp_lf_' . md5( strtolower( (string) $username ) . '|' . Util::ip() );
	}

	public static function record_failed_login( $username ) {
		$k = self::throttle_key( $username );
		$n = (int) get_transient( $k );
		set_transient( $k, $n + 1, 15 * MINUTE_IN_SECONDS );
		$ipk = 'ssp_lfip_' . md5( Util::ip() );
		set_transient( $ipk, (int) get_transient( $ipk ) + 1, 15 * MINUTE_IN_SECONDS );
	}

	public static function throttle_check( $user, $username, $password ) {
		if ( empty( $username ) ) {
			return $user;
		}
		if ( (int) get_transient( self::throttle_key( $username ) ) >= 5 || (int) get_transient( 'ssp_lfip_' . md5( Util::ip() ) ) >= 20 ) {
			return new \WP_Error( 'too_many', 'Too many failed login attempts. Please wait 15 minutes and try again.' );
		}
		return $user;
	}

	/** Generic rate limiter for public forms (registration, password reset). */
	public static function rate_limited( $bucket, $max, $window_seconds ) {
		$k = 'ssp_rl_' . $bucket . '_' . md5( Util::ip() );
		$n = (int) get_transient( $k );
		if ( $n >= $max ) {
			return true;
		}
		set_transient( $k, $n + 1, $window_seconds );
		return false;
	}
}
