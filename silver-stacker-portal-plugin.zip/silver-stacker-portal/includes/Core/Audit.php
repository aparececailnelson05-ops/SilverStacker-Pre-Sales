<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/** Append-only audit log. There is intentionally no update or delete API. */
class Audit {

	public static function log( $action, $object_type, $object_id, $before = null, $after = null, $reason = null, $actor_id = null ) {
		global $wpdb;
		$actor_id = null === $actor_id ? get_current_user_id() : $actor_id;
		$role     = '';
		if ( $actor_id ) {
			$u    = get_userdata( $actor_id );
			$role = $u ? implode( ',', (array) $u->roles ) : '';
		} else {
			$role = 'system';
		}
		$wpdb->insert(
			Installer::tables()['audit'],
			array(
				'actor_user_id' => $actor_id ? $actor_id : null,
				'actor_role'    => substr( $role, 0, 40 ),
				'action'        => substr( $action, 0, 80 ),
				'object_type'   => $object_type,
				'object_id'     => (string) $object_id,
				'before_json'   => null === $before ? null : wp_json_encode( $before ),
				'after_json'    => null === $after ? null : wp_json_encode( $after ),
				'reason'        => $reason,
				'ip'            => Util::ip(),
				'user_agent'    => Util::ua(),
				'created_at'    => Util::now(),
			)
		);
	}

	/** Returns only keys whose values differ, for compact before/after records. */
	public static function diff( array $before, array $after ) {
		$b = array();
		$a = array();
		foreach ( $after as $k => $v ) {
			$old = $before[ $k ] ?? null;
			if ( (string) $old !== (string) $v ) {
				$b[ $k ] = $old;
				$a[ $k ] = $v;
			}
		}
		return array( $b, $a );
	}

	public static function for_object( $object_type, $object_id, $limit = 100 ) {
		global $wpdb;
		$t = Installer::tables()['audit'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE object_type=%s AND object_id=%s ORDER BY id DESC LIMIT %d", $object_type, (string) $object_id, $limit ) );
	}
}
