<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

class Util {

	/** Current UTC time as MySQL DATETIME. */
	public static function now( $offset_seconds = 0 ) {
		return gmdate( 'Y-m-d H:i:s', time() + $offset_seconds );
	}

	/** ULID: 26 chars, Crockford base32, time-sortable, stable IDs for integrations. */
	public static function ulid() {
		$alphabet = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
		$ms       = (int) floor( microtime( true ) * 1000 );
		$time     = '';
		for ( $i = 9; $i >= 0; $i-- ) {
			$time = $alphabet[ $ms % 32 ] . $time;
			$ms   = intdiv( $ms, 32 );
		}
		$rand  = '';
		$bytes = random_bytes( 16 );
		for ( $i = 0; $i < 16; $i++ ) {
			$rand .= $alphabet[ ord( $bytes[ $i ] ) % 32 ];
		}
		return $time . $rand;
	}

	public static function money( $amount ) {
		if ( null === $amount || '' === $amount ) {
			return '';
		}
		return '$' . number_format( (float) $amount, 2 );
	}

	public static function business_tz() {
		$tz = Settings::get( 'business_timezone' );
		try {
			return new \DateTimeZone( $tz ? $tz : 'America/Chicago' );
		} catch ( \Exception $e ) {
			return new \DateTimeZone( 'America/Chicago' );
		}
	}

	/** Format a UTC DATETIME for display in business timezone. */
	public static function fmt_dt( $utc, $format = 'M j, Y g:i A T' ) {
		if ( empty( $utc ) ) {
			return '';
		}
		$d = new \DateTime( $utc, new \DateTimeZone( 'UTC' ) );
		$d->setTimezone( self::business_tz() );
		return $d->format( $format );
	}

	public static function fmt_date( $utc_or_date, $format = 'M j, Y' ) {
		if ( empty( $utc_or_date ) ) {
			return '';
		}
		if ( strlen( $utc_or_date ) <= 10 ) {
			$d = new \DateTime( $utc_or_date, self::business_tz() );
			return $d->format( $format );
		}
		return self::fmt_dt( $utc_or_date, $format );
	}

	/** Convert a business-timezone local datetime string (Y-m-d H:i[:s]) to UTC DATETIME. */
	public static function local_to_utc( $local ) {
		if ( empty( $local ) ) {
			return null;
		}
		try {
			$d = new \DateTime( $local, self::business_tz() );
		} catch ( \Exception $e ) {
			return null;
		}
		$d->setTimezone( new \DateTimeZone( 'UTC' ) );
		return $d->format( 'Y-m-d H:i:s' );
	}

	/** Convert UTC DATETIME to local input value Y-m-d\TH:i for datetime-local fields. */
	public static function utc_to_local_input( $utc ) {
		if ( empty( $utc ) ) {
			return '';
		}
		$d = new \DateTime( $utc, new \DateTimeZone( 'UTC' ) );
		$d->setTimezone( self::business_tz() );
		return $d->format( 'Y-m-d\TH:i' );
	}

	public static function iso_utc( $utc ) {
		if ( empty( $utc ) ) {
			return '';
		}
		return gmdate( 'c', strtotime( $utc . ' UTC' ) );
	}

	public static function ts( $utc ) {
		return $utc ? strtotime( $utc . ' UTC' ) : 0;
	}

	public static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return substr( $ip, 0, 45 );
	}

	public static function ua() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		return substr( $ua, 0, 255 );
	}

	/** Atomically increments a named sequence (order and box numbers). Must run inside a transaction-safe context. */
	public static function next_sequence( $name ) {
		global $wpdb;
		$t     = Installer::tables()['sequences'];
		$start = 0;
		if ( 'order_number' === $name ) {
			$start = max( 0, (int) Settings::get( 'order_number_start' ) - 1 );
		} elseif ( 'box_number' === $name ) {
			$start = 1000;
		}
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET value = GREATEST(value, %d) + 1 WHERE name = %s", $start, $name ) );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT value FROM {$t} WHERE name = %s", $name ) );
	}

	public static function csv_download( $filename, array $headers, array $rows ) {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, $headers, ",", "\"", "\\" );
		foreach ( $rows as $row ) {
			$clean = array();
			foreach ( (array) $row as $cell ) {
				$cell = (string) $cell;
				// Neutralize spreadsheet formula injection.
				if ( '' !== $cell && in_array( $cell[0], array( '=', '+', '-', '@' ), true ) && ! is_numeric( $cell ) ) {
					$cell = "'" . $cell;
				}
				$clean[] = $cell;
			}
			fputcsv( $out, $clean, ",", "\"", "\\" );
		}
		fclose( $out );
		exit;
	}

	public static function int_or_null( $v ) {
		if ( null === $v || '' === $v ) {
			return null;
		}
		return max( 0, (int) $v );
	}

	public static function dec_or_null( $v ) {
		if ( null === $v || '' === $v ) {
			return null;
		}
		return round( (float) preg_replace( '/[^0-9.\-]/', '', (string) $v ), 2 );
	}
}
