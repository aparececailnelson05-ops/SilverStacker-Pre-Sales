<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Roles and capabilities (see Architecture §6).
 * Customer access additionally requires account status = approved and current terms accepted.
 */
class Roles {

	public static function rep_caps() {
		return array(
			'ssp_staff',
			'ssp_view_catalog',
			'ssp_view_all_customers',
			'ssp_view_all_orders',
			'ssp_approve_customers',
			'ssp_invite_customers',
			'ssp_manage_products',
			'ssp_manage_prices',
			'ssp_manage_allocations',
			'ssp_override_allocation',
			'ssp_manage_waitlists',
			'ssp_manage_availability',
			'ssp_correct_order_lines',
			'ssp_manage_boxes',
			'ssp_manage_shipments',
			'ssp_create_invoices',
			'ssp_retry_integration_jobs',
			'ssp_view_reports',
			'ssp_export_data',
			'ssp_view_staff_resources',
			'ssp_manage_staff_resources',
			'ssp_view_record_history',
		);
	}

	public static function admin_only_caps() {
		return array(
			'ssp_view_audit_log',
			'ssp_manage_integrations',
			'ssp_manage_settings',
			'ssp_manage_staff_users',
		);
	}

	public static function install() {
		$customer_caps = array(
			'read'              => true,
			'ssp_customer'      => true,
		);
		remove_role( 'ss_customer' );
		add_role( 'ss_customer', 'Pre-Sale Customer', $customer_caps );

		$rep = array( 'read' => true );
		foreach ( self::rep_caps() as $cap ) {
			$rep[ $cap ] = true;
		}
		remove_role( 'ss_sales_rep' );
		add_role( 'ss_sales_rep', 'Sales Representative', $rep );

		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( array_merge( self::rep_caps(), self::admin_only_caps() ) as $cap ) {
				$admin->add_cap( $cap );
			}
		}
	}

	/** Dynamic: reps may be allowed the full audit log via setting D-23. */
	public static function filter_caps( $allcaps, $caps, $args, $user ) {
		if ( in_array( 'ssp_view_audit_log', $caps, true ) && ! empty( $allcaps['ssp_staff'] ) && Settings::get( 'reps_can_view_audit_log' ) ) {
			$allcaps['ssp_view_audit_log'] = true;
		}
		return $allcaps;
	}

	public static function is_staff( $user_id = null ) {
		$user_id = $user_id ? $user_id : get_current_user_id();
		return $user_id && user_can( $user_id, 'ssp_staff' );
	}

	public static function is_customer( $user_id = null ) {
		$user_id = $user_id ? $user_id : get_current_user_id();
		if ( ! $user_id ) {
			return false;
		}
		$u = get_userdata( $user_id );
		return $u && in_array( 'ss_customer', (array) $u->roles, true );
	}
}
