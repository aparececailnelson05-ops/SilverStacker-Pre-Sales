<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Creates/updates database tables, roles and capabilities, seed data.
 * All timestamps are stored in UTC (DATETIME). Money is DECIMAL(12,2) USD.
 */
class Installer {

	public static function activate() {
		self::install_schema();
		Roles::install();
		self::seed();
		Media::ensure_private_dir();
		update_option( 'ssp_db_version', SSP_DB_VERSION );
		\SSP\Portal\Router::add_rewrites();
		flush_rewrite_rules();
		if ( ! wp_next_scheduled( 'ssp_cron_minutely' ) ) {
			wp_schedule_event( time() + 60, 'ssp_minute', 'ssp_cron_minutely' );
		}
		if ( ! wp_next_scheduled( 'ssp_cron_quarter_hour' ) ) {
			wp_schedule_event( time() + 900, 'ssp_quarter_hour', 'ssp_cron_quarter_hour' );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'ssp_cron_minutely' );
		wp_clear_scheduled_hook( 'ssp_cron_quarter_hour' );
		flush_rewrite_rules();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'ssp_db_version' ) !== SSP_DB_VERSION ) {
			self::activate();
		}
	}

	public static function tables() {
		global $wpdb;
		$p = $wpdb->prefix . 'ss_';
		return array(
			'profiles'        => $p . 'customer_profiles',
			'addresses'       => $p . 'addresses',
			'questions'       => $p . 'signup_questions',
			'answers'         => $p . 'signup_answers',
			'terms'           => $p . 'terms_versions',
			'acceptances'     => $p . 'terms_acceptances',
			'suppliers'       => $p . 'suppliers',
			'products'        => $p . 'products',
			'variants'        => $p . 'product_variants',
			'images'          => $p . 'product_images',
			'eta_history'     => $p . 'eta_history',
			'cart'            => $p . 'cart_items',
			'orders'          => $p . 'orders',
			'lines'           => $p . 'order_lines',
			'amendments'      => $p . 'line_amendments',
			'ledger'          => $p . 'allocation_ledger',
			'overrides'       => $p . 'allocation_overrides',
			'waitlist'        => $p . 'waitlist',
			'boxes'           => $p . 'boxes',
			'box_items'       => $p . 'box_items',
			'shipments'       => $p . 'shipments',
			'shipment_lines'  => $p . 'shipment_lines',
			'rate_tiers'      => $p . 'rate_tiers',
			'invoices'        => $p . 'invoices',
			'invoice_lines'   => $p . 'invoice_lines',
			'jobs'            => $p . 'integration_jobs',
			'map'             => $p . 'integration_map',
			'inbound'         => $p . 'inbound_events',
			'sheet_rows'      => $p . 'sheet_row_map',
			'audit'           => $p . 'audit_log',
			'notifications'   => $p . 'notifications',
			'resources'       => $p . 'staff_resources',
			'sequences'       => $p . 'sequences',
		);
	}

	public static function install_schema() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t  = self::tables();
		$cs = $wpdb->get_charset_collate();

		$sql = array();

		$sql[] = "CREATE TABLE {$t['profiles']} (
			user_id BIGINT UNSIGNED NOT NULL,
			customer_uid CHAR(26) NOT NULL,
			contact_name VARCHAR(190) NOT NULL DEFAULT '',
			company_name VARCHAR(190) NOT NULL DEFAULT '',
			phone VARCHAR(50) NOT NULL DEFAULT '',
			email VARCHAR(190) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			status_reason TEXT NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			rejected_at DATETIME NULL,
			suspended_at DATETIME NULL,
			email_consent TINYINT(1) NOT NULL DEFAULT 0,
			sms_consent TINYINT(1) NOT NULL DEFAULT 0,
			last_login_at DATETIME NULL,
			last_order_at DATETIME NULL,
			qbo_customer_id VARCHAR(64) NULL,
			invited_by BIGINT UNSIGNED NULL,
			staff_notes TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (user_id),
			UNIQUE KEY customer_uid (customer_uid),
			KEY status (status),
			KEY company_name (company_name)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['addresses']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			address_uid CHAR(26) NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			type VARCHAR(10) NOT NULL DEFAULT 'shipping',
			label VARCHAR(100) NOT NULL DEFAULT '',
			name VARCHAR(190) NOT NULL DEFAULT '',
			company VARCHAR(190) NOT NULL DEFAULT '',
			line1 VARCHAR(190) NOT NULL DEFAULT '',
			line2 VARCHAR(190) NOT NULL DEFAULT '',
			city VARCHAR(100) NOT NULL DEFAULT '',
			state VARCHAR(100) NOT NULL DEFAULT '',
			postal_code VARCHAR(20) NOT NULL DEFAULT '',
			country VARCHAR(2) NOT NULL DEFAULT 'US',
			phone VARCHAR(50) NOT NULL DEFAULT '',
			is_default TINYINT(1) NOT NULL DEFAULT 0,
			archived_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY address_uid (address_uid),
			KEY user_type (user_id,type)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['questions']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			question_key VARCHAR(50) NOT NULL,
			text TEXT NOT NULL,
			answer_type VARCHAR(20) NOT NULL DEFAULT 'text',
			sort INT NOT NULL DEFAULT 0,
			active TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY active_sort (active,sort)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['answers']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			question_id BIGINT UNSIGNED NOT NULL,
			question_text TEXT NOT NULL,
			answer_text TEXT NOT NULL,
			edited_by BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['terms']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			version_label VARCHAR(50) NOT NULL,
			content LONGTEXT NOT NULL,
			is_current TINYINT(1) NOT NULL DEFAULT 0,
			published_by BIGINT UNSIGNED NULL,
			published_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY is_current (is_current)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['acceptances']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			terms_version_id BIGINT UNSIGNED NOT NULL,
			accepted_at DATETIME NOT NULL,
			ip VARCHAR(45) NOT NULL DEFAULT '',
			user_agent VARCHAR(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			UNIQUE KEY user_terms (user_id,terms_version_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['suppliers']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL,
			contact VARCHAR(190) NOT NULL DEFAULT '',
			notes TEXT NULL,
			active TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY name (name)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['products']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_uid CHAR(26) NOT NULL,
			slug VARCHAR(190) NOT NULL,
			name VARCHAR(255) NOT NULL,
			description LONGTEXT NULL,
			brand VARCHAR(190) NOT NULL DEFAULT '',
			metal VARCHAR(50) NOT NULL DEFAULT '',
			category VARCHAR(190) NOT NULL DEFAULT '',
			mintage VARCHAR(100) NOT NULL DEFAULT '',
			lifecycle VARCHAR(20) NOT NULL DEFAULT 'draft',
			closing_at DATETIME NULL,
			eta_type VARCHAR(10) NOT NULL DEFAULT 'none',
			eta_start DATE NULL,
			eta_end DATE NULL,
			eta_text VARCHAR(190) NOT NULL DEFAULT '',
			supplier_id BIGINT UNSIGNED NULL,
			date_posted DATE NULL,
			price_type VARCHAR(20) NOT NULL DEFAULT 'fixed',
			spot_premium_usd DECIMAL(12,2) NULL,
			search_text TEXT NULL,
			archived_at DATETIME NULL,
			created_by BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY product_uid (product_uid),
			KEY lifecycle_closing (lifecycle,closing_at),
			KEY metal (metal),
			KEY name (name(100)),
			FULLTEXT KEY ft_search (name,brand,category,search_text)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['variants']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			variant_uid CHAR(26) NOT NULL,
			product_id BIGINT UNSIGNED NOT NULL,
			label VARCHAR(190) NOT NULL DEFAULT '',
			sku VARCHAR(100) NOT NULL,
			barcode VARCHAR(100) NOT NULL DEFAULT '',
			price_usd DECIMAL(12,2) NOT NULL DEFAULT 0.00,
			msrp_usd DECIMAL(12,2) NULL,
			min_order_qty INT UNSIGNED NOT NULL DEFAULT 1,
			total_allocation INT UNSIGNED NULL,
			per_customer_allocation INT UNSIGNED NULL,
			supplier_qty_ordered INT UNSIGNED NULL,
			reserved_qty INT UNSIGNED NOT NULL DEFAULT 0,
			held_qty INT UNSIGNED NOT NULL DEFAULT 0,
			weight_oz DECIMAL(10,3) NULL,
			sort INT NOT NULL DEFAULT 0,
			active TINYINT(1) NOT NULL DEFAULT 1,
			qbo_item_id VARCHAR(64) NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY variant_uid (variant_uid),
			UNIQUE KEY sku (sku),
			KEY product_id (product_id),
			KEY barcode (barcode)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['images']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			image_uid CHAR(26) NOT NULL,
			product_id BIGINT UNSIGNED NOT NULL,
			file_path VARCHAR(255) NOT NULL,
			sizes TEXT NULL,
			mime VARCHAR(50) NOT NULL DEFAULT 'image/jpeg',
			alt VARCHAR(255) NOT NULL DEFAULT '',
			sort INT NOT NULL DEFAULT 0,
			is_primary TINYINT(1) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY image_uid (image_uid),
			KEY product_sort (product_id,sort)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['eta_history']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id BIGINT UNSIGNED NOT NULL,
			old_value VARCHAR(255) NOT NULL DEFAULT '',
			new_value VARCHAR(255) NOT NULL DEFAULT '',
			changed_by BIGINT UNSIGNED NULL,
			changed_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY product_id (product_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['cart']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			variant_id BIGINT UNSIGNED NOT NULL,
			qty INT UNSIGNED NOT NULL DEFAULT 1,
			fulfillment_choice VARCHAR(20) NOT NULL DEFAULT 'decide_later',
			added_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY user_variant (user_id,variant_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['orders']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			order_uid CHAR(26) NOT NULL,
			order_number BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			status VARCHAR(30) NOT NULL DEFAULT 'submitted',
			customer_note TEXT NULL,
			terms_version_id BIGINT UNSIGNED NULL,
			subtotal_usd DECIMAL(12,2) NOT NULL DEFAULT 0.00,
			submit_key VARCHAR(64) NOT NULL,
			source VARCHAR(20) NOT NULL DEFAULT 'portal',
			submitted_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY order_uid (order_uid),
			UNIQUE KEY order_number (order_number),
			UNIQUE KEY submit_key (submit_key),
			KEY user_submitted (user_id,submitted_at),
			KEY status (status),
			KEY submitted_at (submitted_at)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['lines']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			line_uid CHAR(26) NOT NULL,
			order_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			product_id BIGINT UNSIGNED NOT NULL,
			variant_id BIGINT UNSIGNED NOT NULL,
			name_snapshot VARCHAR(255) NOT NULL,
			sku_snapshot VARCHAR(100) NOT NULL,
			unit_price_usd DECIMAL(12,2) NOT NULL,
			price_type VARCHAR(20) NOT NULL DEFAULT 'fixed',
			qty_ordered INT UNSIGNED NOT NULL DEFAULT 0,
			qty_cancelled INT UNSIGNED NOT NULL DEFAULT 0,
			qty_available INT UNSIGNED NOT NULL DEFAULT 0,
			qty_invoiced INT UNSIGNED NOT NULL DEFAULT 0,
			qty_pending_invoice INT UNSIGNED NOT NULL DEFAULT 0,
			qty_shipped INT UNSIGNED NOT NULL DEFAULT 0,
			fulfillment_choice VARCHAR(20) NOT NULL DEFAULT 'decide_later',
			locked_at DATETIME NULL,
			eta_at_order VARCHAR(190) NOT NULL DEFAULT '',
			display_status VARCHAR(30) NOT NULL DEFAULT 'reserved',
			row_version INT UNSIGNED NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY line_uid (line_uid),
			KEY order_id (order_id),
			KEY user_id (user_id),
			KEY variant_id (variant_id),
			KEY product_id (product_id),
			KEY display_status (display_status),
			KEY name_snapshot (name_snapshot(100))
		) $cs;";

		$sql[] = "CREATE TABLE {$t['amendments']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			line_id BIGINT UNSIGNED NOT NULL,
			old_qty INT UNSIGNED NOT NULL,
			new_qty INT UNSIGNED NOT NULL,
			actor_id BIGINT UNSIGNED NOT NULL,
			actor_type VARCHAR(20) NOT NULL,
			reason TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY line_id (line_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['ledger']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			variant_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			order_line_id BIGINT UNSIGNED NULL,
			type VARCHAR(20) NOT NULL,
			qty_delta INT NOT NULL,
			actor_id BIGINT UNSIGNED NULL,
			reason TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY variant_user (variant_id,user_id),
			KEY order_line_id (order_line_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['overrides']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			variant_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NULL,
			order_line_id BIGINT UNSIGNED NULL,
			override_type VARCHAR(20) NOT NULL,
			qty INT NOT NULL DEFAULT 0,
			reason TEXT NOT NULL,
			staff_id BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY variant_user (variant_id,user_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['waitlist']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			waitlist_uid CHAR(26) NOT NULL,
			variant_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			qty_requested INT UNSIGNED NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'waiting',
			offered_qty INT UNSIGNED NOT NULL DEFAULT 0,
			offered_at DATETIME NULL,
			offer_expires_at DATETIME NULL,
			converted_line_id BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY waitlist_uid (waitlist_uid),
			KEY variant_status (variant_id,status,created_at),
			KEY user_id (user_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['boxes']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			box_uid CHAR(26) NOT NULL,
			box_number BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			status VARCHAR(30) NOT NULL DEFAULT 'open',
			address_id BIGINT UNSIGNED NULL,
			address_snapshot TEXT NULL,
			rate_tier_id BIGINT UNSIGNED NULL,
			shipping_charge_usd DECIMAL(12,2) NULL,
			ship_mode VARCHAR(20) NULL,
			shipment_requested_at DATETIME NULL,
			shipment_requested_by BIGINT UNSIGNED NULL,
			preparing_at DATETIME NULL,
			shipped_at DATETIME NULL,
			delivered_at DATETIME NULL,
			closed_at DATETIME NULL,
			shipment_id BIGINT UNSIGNED NULL,
			last_digest_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY box_uid (box_uid),
			UNIQUE KEY box_number (box_number),
			KEY user_status (user_id,status),
			KEY status (status)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['box_items']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			box_id BIGINT UNSIGNED NOT NULL,
			order_line_id BIGINT UNSIGNED NOT NULL,
			added_at DATETIME NOT NULL,
			added_by BIGINT UNSIGNED NULL,
			removed_at DATETIME NULL,
			removed_by BIGINT UNSIGNED NULL,
			PRIMARY KEY  (id),
			KEY box_id (box_id),
			KEY order_line_id (order_line_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['shipments']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			shipment_uid CHAR(26) NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			box_id BIGINT UNSIGNED NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			address_snapshot TEXT NULL,
			rate_tier_id BIGINT UNSIGNED NULL,
			shipping_charge_usd DECIMAL(12,2) NULL,
			carrier VARCHAR(100) NOT NULL DEFAULT '',
			tracking_number VARCHAR(190) NOT NULL DEFAULT '',
			shipped_at DATETIME NULL,
			delivered_at DATETIME NULL,
			shipping_invoice_id BIGINT UNSIGNED NULL,
			notes TEXT NULL,
			created_by BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY shipment_uid (shipment_uid),
			KEY user_id (user_id),
			KEY box_id (box_id),
			KEY status (status)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['shipment_lines']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			shipment_id BIGINT UNSIGNED NOT NULL,
			order_line_id BIGINT UNSIGNED NOT NULL,
			qty INT UNSIGNED NOT NULL,
			PRIMARY KEY  (id),
			KEY shipment_id (shipment_id),
			KEY order_line_id (order_line_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['rate_tiers']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(100) NOT NULL,
			basis VARCHAR(10) NOT NULL DEFAULT 'size',
			min_value DECIMAL(10,2) NULL,
			max_value DECIMAL(10,2) NULL,
			unit VARCHAR(20) NOT NULL DEFAULT '',
			charge_usd DECIMAL(12,2) NOT NULL DEFAULT 0.00,
			priority INT NOT NULL DEFAULT 0,
			active TINYINT(1) NOT NULL DEFAULT 1,
			confirmed TINYINT(1) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['invoices']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			invoice_uid CHAR(26) NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			source VARCHAR(20) NOT NULL DEFAULT 'qbo',
			qbo_invoice_id VARCHAR(64) NULL,
			doc_number VARCHAR(64) NOT NULL DEFAULT '',
			txn_date DATE NULL,
			due_date DATE NULL,
			total_usd DECIMAL(12,2) NULL,
			balance_usd DECIMAL(12,2) NULL,
			sync_status VARCHAR(20) NOT NULL DEFAULT 'queued',
			pay_link TEXT NULL,
			idempotency_key VARCHAR(64) NOT NULL,
			qbo_request_id VARCHAR(64) NOT NULL,
			created_by BIGINT UNSIGNED NULL,
			last_synced_at DATETIME NULL,
			error_message TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY invoice_uid (invoice_uid),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY user_id (user_id),
			KEY sync_status (sync_status),
			KEY qbo_invoice_id (qbo_invoice_id),
			KEY txn_date (txn_date)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['invoice_lines']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			invoice_id BIGINT UNSIGNED NOT NULL,
			order_line_id BIGINT UNSIGNED NULL,
			type VARCHAR(20) NOT NULL DEFAULT 'product',
			description VARCHAR(255) NOT NULL DEFAULT '',
			qty INT UNSIGNED NOT NULL DEFAULT 1,
			unit_price_usd DECIMAL(12,2) NOT NULL,
			amount_usd DECIMAL(12,2) NOT NULL,
			shipment_id BIGINT UNSIGNED NULL,
			PRIMARY KEY  (id),
			KEY invoice_id (invoice_id),
			KEY order_line_id (order_line_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['jobs']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			integration VARCHAR(20) NOT NULL,
			action VARCHAR(60) NOT NULL,
			object_type VARCHAR(40) NOT NULL DEFAULT '',
			object_id VARCHAR(64) NOT NULL DEFAULT '',
			idempotency_key VARCHAR(190) NOT NULL,
			payload LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'queued',
			attempts INT UNSIGNED NOT NULL DEFAULT 0,
			next_attempt_at DATETIME NOT NULL,
			locked_until DATETIME NULL,
			last_error TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY status_next (status,next_attempt_at),
			KEY integration (integration,status)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['map']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			integration VARCHAR(20) NOT NULL,
			object_type VARCHAR(40) NOT NULL,
			portal_uid VARCHAR(64) NOT NULL,
			external_id VARCHAR(190) NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY portal (integration,object_type,portal_uid),
			KEY external (integration,object_type,external_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['inbound']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			source VARCHAR(20) NOT NULL,
			external_event_id VARCHAR(190) NOT NULL,
			payload LONGTEXT NULL,
			received_at DATETIME NOT NULL,
			processed_at DATETIME NULL,
			result TEXT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY source_event (source,external_event_id)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['sheet_rows']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			tab VARCHAR(60) NOT NULL,
			portal_uid VARCHAR(64) NOT NULL,
			row_index INT UNSIGNED NOT NULL,
			last_hash CHAR(32) NOT NULL DEFAULT '',
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY tab_uid (tab,portal_uid)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['audit']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			actor_user_id BIGINT UNSIGNED NULL,
			actor_role VARCHAR(40) NOT NULL DEFAULT '',
			action VARCHAR(80) NOT NULL,
			object_type VARCHAR(40) NOT NULL,
			object_id VARCHAR(64) NOT NULL,
			before_json LONGTEXT NULL,
			after_json LONGTEXT NULL,
			reason TEXT NULL,
			ip VARCHAR(45) NOT NULL DEFAULT '',
			user_agent VARCHAR(255) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY object (object_type,object_id),
			KEY actor (actor_user_id),
			KEY created_at (created_at),
			KEY action (action)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['notifications']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NULL,
			email VARCHAR(190) NOT NULL DEFAULT '',
			template VARCHAR(60) NOT NULL,
			subject VARCHAR(255) NOT NULL DEFAULT '',
			object_type VARCHAR(40) NOT NULL DEFAULT '',
			object_id VARCHAR(64) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'queued',
			error TEXT NULL,
			created_at DATETIME NOT NULL,
			sent_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY template (template)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['resources']} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			resource_uid CHAR(26) NOT NULL,
			title VARCHAR(255) NOT NULL,
			description TEXT NULL,
			file_path VARCHAR(255) NOT NULL,
			file_name VARCHAR(255) NOT NULL,
			mime VARCHAR(100) NOT NULL DEFAULT 'application/octet-stream',
			size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
			uploaded_by BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY resource_uid (resource_uid)
		) $cs;";

		$sql[] = "CREATE TABLE {$t['sequences']} (
			name VARCHAR(40) NOT NULL,
			value BIGINT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY  (name)
		) $cs;";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
	}

	public static function seed() {
		global $wpdb;
		$t   = self::tables();
		$now = Util::now();

		// Sequences.
		foreach ( array( 'order_number', 'box_number' ) as $seq ) {
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['sequences']} WHERE name=%s", $seq ) );
			if ( ! $exists ) {
				$wpdb->insert( $t['sequences'], array( 'name' => $seq, 'value' => 0 ) );
			}
		}

		// Sign-up questions from the original Silver Stacker specification.
		if ( ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['questions']}" ) ) {
			$questions = array(
				array( 'previous_business', 'Have you ever done business with Silver Stacker LLC before? If not, how did you hear about us?', 'text' ),
				array( 'presale_understanding', 'This is a Pre-Sale Portal. You order items now and are invoiced when they are in hand. The lead times vary depending on the item. Do you understand this?', 'yesno' ),
				array( 'trust_payment', 'This is a TRUST relationship. If you order an item you are expected to pay within a timely manner. Do you agree?', 'yesno' ),
				array( 'contact_permission', 'You will receive an Invoice via Email and a text when your items are ready to ship. Do you give us permission to contact you?', 'yesno' ),
				array( 'facebook_group', 'We post new offers in our FB Group. If you haven\'t joined, use this link: {fb_group_link}. Did you request to join?', 'yesno' ),
				array( 'pricing_confidentiality', 'There is absolutely no sharing our pricing outside of this group. If you do so, we have ways to find out and you will be removed without question. Do you understand this?', 'yesno' ),
				array( 'spot_based', 'If you see an offer that has a 0.01 price, this is a Spot Based offer and the pricing is in the details of the item offer. Do you understand?', 'yesno' ),
				array( 'submit_orders', 'Lastly, once approved and you place an order, make sure you click the "Submit Pre-Order" button and submit your order. You will see a confirmation if you do it correctly. Do you understand?', 'yesno' ),
			);
			foreach ( $questions as $i => $q ) {
				$wpdb->insert(
					$t['questions'],
					array(
						'question_key' => $q[0],
						'text'         => $q[1],
						'answer_type'  => $q[2],
						'sort'         => $i + 1,
						'active'       => 1,
						'created_at'   => $now,
					)
				);
			}
		}

		// Terms & Conditions v1 from the original specification (draft; confirm final wording).
		if ( ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['terms']}" ) ) {
			$content = '<h2>Silver Stacker LLC Pre-Sale Terms &amp; Conditions</h2>'
				. '<ul>'
				. '<li>All orders are final pending allocations and final mint availability.</li>'
				. '<li>Payments are due within 72 hrs of being invoiced once items are in hand. No money is due until invoiced.</li>'
				. '<li>Shipping is $6 Ground or $9 Priority and will be billed with your invoice when your items arrive.</li>'
				. '<li>Build A Box Program available for flat $9 one-time shipping paid with first item.</li>'
				. '<li>Failure to uphold BIN commitments, make timely payments or any of the above will result in removal from pre-sale access and possible removal from the Pre-Sale Group in general. Communication is key.</li>'
				. '<li>Estimated arrival dates (ETAs) are estimates provided by our suppliers and mints, not guaranteed delivery dates.</li>'
				. '<li>Pricing shown in this portal is confidential and may not be shared outside the group.</li>'
				. '</ul>';
			$wpdb->insert(
				$t['terms'],
				array(
					'version_label' => '1.0',
					'content'       => $content,
					'is_current'    => 1,
					'published_at'  => $now,
				)
			);
		}

		// Draft (UNCONFIRMED) shipping tiers taken from the original T&C. See decision D-4.
		if ( ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['rate_tiers']}" ) ) {
			$tiers = array(
				array( 'Ground (single shipment)', 'size', 6.00, 10 ),
				array( 'Priority (single shipment)', 'size', 9.00, 20 ),
				array( 'Build A Box flat rate', 'size', 9.00, 30 ),
			);
			foreach ( $tiers as $tier ) {
				$wpdb->insert(
					$t['rate_tiers'],
					array(
						'name'       => $tier[0],
						'basis'      => $tier[1],
						'charge_usd' => $tier[2],
						'priority'   => $tier[3],
						'active'     => 1,
						'confirmed'  => 0,
						'created_at' => $now,
					)
				);
			}
		}

		Settings::ensure_defaults();
	}
}
