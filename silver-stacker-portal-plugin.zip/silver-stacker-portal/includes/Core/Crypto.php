<?php
namespace SSP\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Encrypts integration credentials at rest using libsodium.
 * Define SSP_ENCRYPTION_KEY (64 hex chars) in wp-config.php in production.
 * Fallback derives a key from WordPress salts.
 */
class Crypto {

	private static function key() {
		if ( defined( 'SSP_ENCRYPTION_KEY' ) && strlen( SSP_ENCRYPTION_KEY ) >= 64 ) {
			return hex2bin( substr( SSP_ENCRYPTION_KEY, 0, 64 ) );
		}
		return sodium_crypto_generichash( wp_salt( 'auth' ) . wp_salt( 'secure_auth' ), '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES );
	}

	public static function encrypt( $plain ) {
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$c     = sodium_crypto_secretbox( (string) $plain, $nonce, self::key() );
		return 'enc:' . base64_encode( $nonce . $c );
	}

	public static function decrypt( $stored ) {
		if ( ! is_string( $stored ) || strpos( $stored, 'enc:' ) !== 0 ) {
			return (string) $stored;
		}
		$raw = base64_decode( substr( $stored, 4 ), true );
		if ( false === $raw || strlen( $raw ) < SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
			return '';
		}
		$nonce = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$c     = substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$p     = sodium_crypto_secretbox_open( $c, $nonce, self::key() );
		return false === $p ? '' : $p;
	}
}
