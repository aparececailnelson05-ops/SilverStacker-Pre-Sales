<?php
namespace SSP\Admin;

use SSP\Core\Util;
use SSP\Domain\Catalog;

defined( 'ABSPATH' ) || exit;

class ArchiveScreen {

	public static function render() {
		$args = array(
			'q'        => UI::get( 'q' ),
			'metal'    => UI::get( 'metal' ),
			'tab'      => 'archive',
			'paged'    => (int) UI::get( 'paged', 1 ),
			'per_page' => 50,
			'sort'     => UI::get( 'sort' ),
		);
		$t0  = microtime( true );
		$res = Catalog::search( $args );
		$ms  = round( ( microtime( true ) - $t0 ) * 1000 );
		UI::open( 'The Archive', 'Reference listings for every item previously offered (' . number_format( $res['counts']['archive'] ) . ' records). Archived items keep their permanent links and are not orderable unless re-opened.', '<button type="button" class="ssa-btn" data-toggle="#ssa-import">Import CSV</button>' );
		?>
		<div id="ssa-import" class="ssa-card" hidden>
			<h2>Import archive records</h2>
			<p class="ssa-muted">CSV with a header row. Columns (by name): <code>name</code> (required), <code>sku</code>, <code>barcode</code>, <code>brand</code>, <code>metal</code>, <code>category</code>, <code>mintage</code>, <code>description</code>, <code>image</code> (URL), <code>date_posted</code>. Existing SKUs are skipped, so re-running an import is safe. Run a dry run first.</p>
			<?php UI::form( 'archive_import', '', true ); ?>
				<input type="file" name="csv" accept=".csv,text/csv" required>
				<label><input type="checkbox" name="dry_run" value="1" checked> Dry run (validate only)</label>
				<button class="ssa-btn" type="submit">Upload</button>
			<?php UI::end(); ?>
			<p class="ssa-muted ssa-small">Large imports can also run from the server: <code>wp ssp import_archive file.csv</code></p>
		</div>
		<form class="ssa-filters" method="get">
			<input type="hidden" name="page" value="ssp-archive">
			<input type="search" name="q" value="<?php echo esc_attr( $args['q'] ); ?>" placeholder="Search name, SKU, barcode, brand">
			<?php echo UI::select( 'metal', array( '' => 'All metals' ) + array_combine( (array) \SSP\Core\Settings::get( 'metals' ), (array) \SSP\Core\Settings::get( 'metals' ) ), $args['metal'] ); // phpcs:ignore ?>
			<button class="ssa-btn ssa-btn--ghost" type="submit">Search</button>
			<span class="ssa-muted"><?php echo (int) $res['total']; ?> match(es) in <?php echo (int) $ms; ?> ms</span>
		</form>
		<table class="ssa-table ssa-table--hover">
			<thead><tr><th></th><th>Name</th><th>SKU</th><th>Brand</th><th>Metal</th><th>Mintage</th><th>Archived</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $res['rows'] as $p ) : ?>
				<?php $vs = Catalog::variants( $p->id ); ?>
				<tr>
					<td><img class="ssa-thumb" src="<?php echo esc_url( Catalog::image_url( Catalog::primary_image( $p->id ), 'thumb' ) ); ?>" alt="" loading="lazy"></td>
					<td><a href="<?php echo esc_url( UI::url( 'ssp-products', array( 'edit' => $p->id ) ) ); ?>"><?php echo esc_html( $p->name ); ?></a></td>
					<td><?php echo esc_html( implode( ', ', wp_list_pluck( $vs, 'sku' ) ) ); ?></td>
					<td><?php echo esc_html( $p->brand ); ?></td>
					<td><?php echo esc_html( $p->metal ); ?></td>
					<td><?php echo esc_html( $p->mintage ); ?></td>
					<td><?php echo esc_html( Util::fmt_date( $p->archived_at ) ); ?></td>
					<td><a href="<?php echo esc_url( Catalog::url( $p ) ); ?>" target="_blank">Portal listing</a></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		UI::pager( $res['total'], 50, $res['page'], 'ssp-archive', array_filter( array( 'q' => $args['q'], 'metal' => $args['metal'] ) ) );
		UI::close();
	}
}
