<?php
namespace SSP\Admin;

use SSP\Core\Util;
use SSP\Domain\Addresses;
use SSP\Domain\Boxes;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Shipments;

defined( 'ABSPATH' ) || exit;

class BoxesScreen {

	private static function tier_options() {
		$o = array( '' => 'Choose rate tier' );
		foreach ( Shipments::tiers() as $t ) {
			$o[ $t->id ] = $t->name . ' (' . Util::money( $t->charge_usd ) . ')' . ( $t->confirmed ? '' : ' [unconfirmed]' );
		}
		return $o;
	}

	public static function render() {
		if ( UI::get( 'box' ) ) {
			self::detail( (int) UI::get( 'box' ) );
			return;
		}
		$tab = UI::get( 'tab', 'boxes' );
		UI::open( 'Boxes & Shipments', 'Build A Box consolidation boxes, shipment requests, separate shipments and tracking.' );
		UI::tabs( 'ssp-boxes', array( 'boxes' => 'Boxes', 'separate' => 'Separate shipments queue', 'shipments' => 'All shipments' ), $tab );
		if ( 'separate' === $tab ) {
			self::separate();
		} elseif ( 'shipments' === $tab ) {
			self::shipments();
		} else {
			self::boxes();
		}
		UI::close();
	}

	private static function boxes() {
		$status = UI::get( 'status', 'active' );
		$rows   = Boxes::staff_list( array( 'status' => $status, 'q' => UI::get( 'q' ) ) );
		?>
		<div class="ssa-statusbar">
			<?php foreach ( array( 'active' => 'Active', 'open' => 'Open', 'shipment_requested' => 'Shipment requested', 'preparing' => 'Preparing', 'shipped' => 'Shipped', 'delivered' => 'Delivered', 'closed' => 'Closed', '' => 'All' ) as $k => $l ) : ?>
				<a class="<?php echo $status === $k ? 'is-active' : ''; ?>" href="<?php echo esc_url( UI::url( 'ssp-boxes', array( 'status' => $k ) ) ); ?>"><?php echo esc_html( $l ); ?></a>
			<?php endforeach; ?>
		</div>
		<form class="ssa-filters" method="get"><input type="hidden" name="page" value="ssp-boxes"><input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>"><input type="search" name="q" value="<?php echo esc_attr( UI::get( 'q' ) ); ?>" placeholder="Customer or box #"><button class="ssa-btn ssa-btn--ghost">Search</button></form>
		<table class="ssa-table ssa-table--hover">
			<thead><tr><th>Box #</th><th>Customer</th><th>Status</th><th class="num">Lines</th><th class="num">Units</th><th class="num">Available</th><th>Ship to</th><th>Age</th><th>Requested</th></tr></thead>
			<tbody>
			<?php foreach ( $rows as $b ) : ?>
				<?php $tt = Boxes::totals( $b->id ); ?>
				<tr>
					<td><a href="<?php echo esc_url( UI::url( 'ssp-boxes', array( 'box' => $b->id ) ) ); ?>"><strong>#<?php echo (int) $b->box_number; ?></strong></a></td>
					<td><?php echo UI::customer_link( $b->user_id, $b->company_name . ' (' . $b->contact_name . ')' ); // phpcs:ignore ?></td>
					<td><?php echo ssp_badge( Boxes::STATUSES[ $b->status ], ssp_status_kind( $b->status ) ); // phpcs:ignore ?></td>
					<td class="num"><?php echo (int) $tt['lines']; ?></td>
					<td class="num"><?php echo (int) $tt['units']; ?></td>
					<td class="num"><?php echo (int) $tt['available']; ?></td>
					<td class="ssa-small"><?php echo esc_html( Addresses::format( Boxes::address( $b ), ', ' ) ); ?></td>
					<td><?php echo (int) floor( ( time() - Util::ts( $b->created_at ) ) / DAY_IN_SECONDS ); ?>d</td>
					<td><?php echo esc_html( Util::fmt_dt( $b->shipment_requested_at ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( ! $rows ) : ?><tr><td colspan="9" class="ssa-muted">No boxes.</td></tr><?php endif; ?>
			</tbody>
		</table>
		<?php
	}

	private static function detail( $id ) {
		$b = Boxes::get( $id );
		if ( ! $b ) {
			UI::open( 'Box not found' );
			UI::close();
			return;
		}
		$c     = Customers::profile( $b->user_id );
		$items = Boxes::items( $id );
		$tt    = Boxes::totals( $id );
		$other = array_filter( Boxes::active_boxes( (int) $b->user_id ), fn( $x ) => (int) $x->id !== (int) $id );
		UI::open( 'Box #' . $b->box_number, UI::customer_link( $b->user_id, Customers::display_name( $c ) ) . ' &middot; ' . ssp_badge( Boxes::STATUSES[ $b->status ], ssp_status_kind( $b->status ) ), '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::url( 'ssp-boxes' ) ) . '">&larr; Boxes</a>' );
		?>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Process</h2>
				<p><?php echo (int) $tt['units']; ?> units in <?php echo (int) $tt['lines']; ?> lines; <?php echo (int) $tt['available']; ?> available to ship. <?php echo $tt['weight_oz'] ? 'Approx. ' . esc_html( number_format( $tt['weight_oz'], 1 ) ) . ' oz.' : ''; ?> <?php echo 'wait_all' === $b->ship_mode ? '<strong>Customer asked to ship when everything has arrived.</strong>' : ''; ?></p>
				<div class="ssa-flex">
					<?php if ( 'open' === $b->status && $tt['lines'] ) : ?><?php UI::button( 'box_request', array( 'box_id' => $id ), 'Request shipment for customer', 'ssa-btn ssa-btn--ghost' ); ?><?php endif; ?>
					<?php if ( 'shipment_requested' === $b->status ) : ?><?php UI::button( 'box_cancel_request', array( 'box_id' => $id ), 'Cancel request (reopen)', 'ssa-btn ssa-btn--ghost' ); ?><?php endif; ?>
					<?php if ( in_array( $b->status, array( 'open', 'shipment_requested' ), true ) ) : ?><?php UI::button( 'box_preparing', array( 'box_id' => $id ), 'Start preparing', 'ssa-btn' ); ?><?php endif; ?>
					<?php if ( 'shipped' === $b->status ) : ?><?php UI::button( 'box_delivered', array( 'box_id' => $id ), 'Mark delivered', 'ssa-btn' ); ?><?php endif; ?>
					<?php if ( 'delivered' === $b->status || ( 'open' === $b->status && ! $tt['lines'] ) ) : ?><?php UI::button( 'box_close', array( 'box_id' => $id ), 'Close box', 'ssa-btn ssa-btn--ghost' ); ?><?php endif; ?>
				</div>
				<?php if ( in_array( $b->status, array( 'open', 'shipment_requested', 'preparing' ), true ) ) : ?>
					<h3>Rate tier</h3>
					<?php UI::form( 'box_rate', 'class="ssa-row"' ); ?>
						<input type="hidden" name="box_id" value="<?php echo (int) $id; ?>">
						<?php echo UI::select( 'rate_tier_id', self::tier_options(), $b->rate_tier_id ); // phpcs:ignore ?>
						<label>Charge override <input type="text" name="shipping_charge_usd" value="<?php echo esc_attr( (string) $b->shipping_charge_usd ); ?>" size="7" placeholder="tier default"></label>
						<button class="ssa-btn ssa-btn--ghost" type="submit">Save tier</button>
					<?php UI::end(); ?>
					<h3>Ship this box</h3>
					<?php UI::form( 'box_ship' ); ?>
						<input type="hidden" name="box_id" value="<?php echo (int) $id; ?>">
						<div class="ssa-row">
							<label>Rate tier <?php echo UI::select( 'rate_tier_id', self::tier_options(), $b->rate_tier_id ); // phpcs:ignore ?></label>
							<label>Shipping charge <input type="text" name="shipping_charge_usd" value="<?php echo esc_attr( (string) $b->shipping_charge_usd ); ?>" size="7"></label>
							<label>Carrier <input type="text" name="carrier" list="ssa-carriers" required></label>
							<label>Tracking number <input type="text" name="tracking_number" required></label>
							<label>Ship date <input type="datetime-local" name="shipped_at" value="<?php echo esc_attr( Util::utc_to_local_input( Util::now() ) ); ?>"></label>
						</div>
						<label class="ssa-block">Notes <input type="text" name="notes"></label>
						<p><button class="ssa-btn" type="submit">Record shipment &amp; notify customer</button></p>
						<p class="ssa-muted ssa-small">Ships every available, unshipped unit in the box. Remaining units are carried into the customer's open box automatically. To bill shipping, add the charge in the invoice wizard (decision D-5).</p>
					<?php UI::end(); ?>
					<datalist id="ssa-carriers"><option value="USPS"><option value="UPS"><option value="FedEx"><option value="DHL"></datalist>
				<?php endif; ?>
				<?php if ( $b->shipment_id ) : ?><?php $s = Shipments::get( $b->shipment_id ); ?><p>Shipment: <?php echo esc_html( $s->carrier . ' ' . $s->tracking_number ); ?> &middot; <?php echo esc_html( Util::fmt_dt( $s->shipped_at ) ); ?></p><?php endif; ?>
			</div>
			<div class="ssa-card">
				<h2>Ship to</h2>
				<p><?php echo nl2br( esc_html( Addresses::format( Boxes::address( $b ) ) ) ); ?></p>
				<?php if ( Boxes::can_change_address( $b, true ) ) : ?>
					<?php UI::form( 'box_address', 'class="ssa-row"' ); ?>
						<input type="hidden" name="box_id" value="<?php echo (int) $id; ?>">
						<?php
						$opts = array();
						foreach ( Addresses::list_for( (int) $b->user_id, 'shipping' ) as $a ) {
							$opts[ $a->id ] = Addresses::format( $a, ', ' );
						}
						echo UI::select( 'address_id', $opts, $b->address_id ); // phpcs:ignore
						?>
						<button class="ssa-btn ssa-btn--ghost" type="submit">Change address</button>
					<?php UI::end(); ?>
				<?php endif; ?>
				<p class="ssa-muted ssa-small">Customers may change the address until "<?php echo esc_html( \SSP\Core\Settings::get( 'address_change_until' ) ); ?>" (decision D-3).</p>
			</div>
		</div>
		<div class="ssa-card">
			<h2>Contents</h2>
			<table class="ssa-table"><thead><tr><th>Order</th><th>Item</th><th class="num">Qty</th><th class="num">Available</th><th class="num">Shipped</th><th>Invoice</th><th>Added</th><th></th></tr></thead><tbody>
			<?php foreach ( $items as $it ) : ?>
				<tr>
					<td><a href="<?php echo esc_url( UI::url( 'ssp-orders', array( 'order' => $it->order_number ) ) ); ?>">#<?php echo (int) $it->order_number; ?></a></td>
					<td><?php echo esc_html( $it->name_snapshot ); ?><br><span class="ssa-muted ssa-small"><?php echo esc_html( $it->sku_snapshot ); ?></span></td>
					<td class="num"><?php echo (int) Orders::net( $it ); ?></td>
					<td class="num"><?php echo (int) $it->qty_available; ?></td>
					<td class="num"><?php echo (int) $it->qty_shipped; ?></td>
					<td><?php foreach ( Invoices::for_line( $it->id ) as $i ) { echo ssp_badge( ( $i->doc_number ? $i->doc_number . ' ' : '' ) . Invoices::payment_label( $i ), ssp_status_kind( $i->sync_status ) ) . ' '; } // phpcs:ignore ?></td>
					<td><?php echo esc_html( Util::fmt_dt( $it->added_at ) ); ?></td>
					<td class="ssa-nowrap">
						<?php if ( in_array( $b->status, Boxes::ACTIVE, true ) ) : ?>
							<?php UI::button( 'box_remove_line', array( 'line_id' => $it->id, 'to' => 'separate' ), 'Ship separately', 'ssa-btn ssa-btn--sm ssa-btn--ghost' ); ?>
							<?php UI::button( 'box_remove_line', array( 'line_id' => $it->id, 'to' => 'decide_later' ), 'Remove', 'ssa-btn ssa-btn--sm ssa-btn--ghost' ); ?>
							<?php foreach ( $other as $ob ) : ?>
								<?php UI::button( 'box_move_line', array( 'line_id' => $it->id, 'to_box_id' => $ob->id, 'reason' => 'Staff move' ), 'Move to #' . $ob->box_number, 'ssa-btn ssa-btn--sm ssa-btn--ghost' ); ?>
							<?php endforeach; ?>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			<?php if ( ! $items ) : ?><tr><td colspan="8" class="ssa-muted">Empty.</td></tr><?php endif; ?>
			</tbody></table>
			<?php $removed = array_filter( Boxes::items( $id, true ), fn( $x ) => $x->removed_at ); ?>
			<?php if ( $removed ) : ?><details><summary>Removed / carried items (<?php echo count( $removed ); ?>)</summary><ul><?php foreach ( $removed as $r ) : ?><li><?php echo esc_html( '#' . $r->order_number . ' ' . $r->name_snapshot . ' removed ' . Util::fmt_dt( $r->removed_at ) ); ?></li><?php endforeach; ?></ul></details><?php endif; ?>
		</div>
		<?php
		UI::history( 'box', $id );
		UI::close();
	}

	private static function separate() {
		$rows = Shipments::separate_queue();
		$by   = array();
		foreach ( $rows as $r ) {
			$by[ $r->user_id ][] = $r;
		}
		if ( ! $by ) {
			echo '<div class="ssa-card ssa-muted">No available "ship separately" lines waiting.</div>';
			return;
		}
		foreach ( $by as $uid => $lines ) {
			?>
			<div class="ssa-card">
				<h2><?php echo UI::customer_link( $uid, $lines[0]->company_name . ' (' . $lines[0]->contact_name . ')' ); // phpcs:ignore ?></h2>
				<?php UI::form( 'shipment_create' ); ?>
					<input type="hidden" name="user_id" value="<?php echo (int) $uid; ?>">
					<table class="ssa-table"><thead><tr><th>Order</th><th>Item</th><th class="num">Ready to ship</th><th class="num">Ship qty</th></tr></thead><tbody>
					<?php foreach ( $lines as $l ) : ?>
						<?php $ready = (int) $l->qty_available - (int) $l->qty_shipped; ?>
						<tr><td>#<?php echo (int) $l->order_number; ?></td><td><?php echo esc_html( $l->name_snapshot ); ?></td><td class="num"><?php echo (int) $ready; ?></td><td class="num"><input type="number" name="ship[<?php echo (int) $l->id; ?>]" value="<?php echo (int) $ready; ?>" min="0" max="<?php echo (int) $ready; ?>" style="width:70px"></td></tr>
					<?php endforeach; ?>
					</tbody></table>
					<p class="ssa-muted">Ship to: <?php echo esc_html( Addresses::format( Addresses::default_for( $uid, 'shipping' ), ', ' ) ); ?></p>
					<div class="ssa-row">
						<label>Rate tier <?php echo UI::select( 'rate_tier_id', self::tier_options(), '' ); // phpcs:ignore ?></label>
						<label>Charge <input type="text" name="shipping_charge_usd" size="7"></label>
						<label>Carrier <input type="text" name="carrier" list="ssa-carriers2"></label>
						<label>Tracking <input type="text" name="tracking_number"></label>
						<label>Status <?php echo UI::select( 'status', array( 'shipped' => 'Shipped now', 'preparing' => 'Preparing (no tracking yet)' ), 'shipped' ); // phpcs:ignore ?></label>
					</div>
					<p><button class="ssa-btn" type="submit">Record shipment</button></p>
				<?php UI::end(); ?>
				<datalist id="ssa-carriers2"><option value="USPS"><option value="UPS"><option value="FedEx"></datalist>
			</div>
			<?php
		}
	}

	private static function shipments() {
		$rows = Shipments::staff_list( array( 'status' => UI::get( 'status' ), 'q' => UI::get( 'q' ) ) );
		?>
		<form class="ssa-filters" method="get"><input type="hidden" name="page" value="ssp-boxes"><input type="hidden" name="tab" value="shipments"><?php echo UI::select( 'status', array( '' => 'Any status' ) + Shipments::STATUSES, UI::get( 'status' ) ); // phpcs:ignore ?><input type="search" name="q" value="<?php echo esc_attr( UI::get( 'q' ) ); ?>" placeholder="Customer or tracking"><button class="ssa-btn ssa-btn--ghost">Filter</button></form>
		<table class="ssa-table"><thead><tr><th>Customer</th><th>Type</th><th>Lines</th><th>Status</th><th>Carrier / tracking</th><th>Tier / charge</th><th>Shipped</th><th>Update</th></tr></thead><tbody>
		<?php foreach ( $rows as $s ) : ?>
			<?php $b = $s->box_id ? Boxes::get( $s->box_id ) : null; ?>
			<tr>
				<td><?php echo UI::customer_link( $s->user_id, $s->company_name ); // phpcs:ignore ?></td>
				<td><?php echo $b ? '<a href="' . esc_url( UI::url( 'ssp-boxes', array( 'box' => $b->id ) ) ) . '">Box #' . (int) $b->box_number . '</a>' : 'Separate'; // phpcs:ignore ?></td>
				<td class="ssa-small"><?php foreach ( Shipments::lines( $s->id ) as $l ) { echo esc_html( '#' . $l->order_number . ' ' . $l->sku_snapshot . ' x' . $l->ship_qty ) . '<br>'; } ?></td>
				<td><?php echo ssp_badge( Shipments::STATUSES[ $s->status ], ssp_status_kind( $s->status ) ); // phpcs:ignore ?></td>
				<td colspan="4">
					<?php UI::form( 'shipment_update', 'class="ssa-row"' ); ?>
						<input type="hidden" name="shipment_id" value="<?php echo (int) $s->id; ?>">
						<input type="text" name="carrier" value="<?php echo esc_attr( $s->carrier ); ?>" size="8" placeholder="Carrier">
						<input type="text" name="tracking_number" value="<?php echo esc_attr( $s->tracking_number ); ?>" size="16" placeholder="Tracking">
						<?php echo UI::select( 'rate_tier_id', self::tier_options(), $s->rate_tier_id ); // phpcs:ignore ?>
						<input type="text" name="shipping_charge_usd" value="<?php echo esc_attr( (string) $s->shipping_charge_usd ); ?>" size="6" placeholder="$">
						<span class="ssa-small"><?php echo esc_html( Util::fmt_date( $s->shipped_at ) ); ?></span>
						<?php echo UI::select( 'status', array( '' => 'Keep status' ) + Shipments::STATUSES, '' ); // phpcs:ignore ?>
						<button class="ssa-btn ssa-btn--sm" type="submit">Save</button>
					<?php UI::end(); ?>
				</td>
			</tr>
		<?php endforeach; ?>
		<?php if ( ! $rows ) : ?><tr><td colspan="8" class="ssa-muted">No shipments.</td></tr><?php endif; ?>
		</tbody></table>
		<?php
	}
}
