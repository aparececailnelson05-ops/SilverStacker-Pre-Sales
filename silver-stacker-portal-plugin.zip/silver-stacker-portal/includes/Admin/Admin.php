<?php
namespace SSP\Admin;

defined( 'ABSPATH' ) || exit;

/** Staff console bootstrap (menus, assets, form handlers). */
class Admin {

	public static function init() {
		add_action( 'admin_menu', array( Menu::class, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_ssp_admin', array( Handlers::class, 'dispatch' ) );
		add_action( 'admin_post_ssp_qbo_callback', array( Handlers::class, 'qbo_callback' ) );
		add_action( 'admin_init', array( Handlers::class, 'downloads' ) );
	}

	public static function assets( $hook ) {
		if ( strpos( (string) $hook, 'ssp-' ) === false && strpos( (string) $hook, 'silver-stacker' ) === false ) {
			return;
		}
		wp_enqueue_style( 'ssp-fonts', 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap', array(), null );
		wp_enqueue_style( 'ssp-admin', SSP_URL . 'assets/css/admin.css', array(), SSP_VERSION );
		wp_enqueue_script( 'ssp-admin', SSP_URL . 'assets/js/admin.js', array(), SSP_VERSION, true );
	}
}
