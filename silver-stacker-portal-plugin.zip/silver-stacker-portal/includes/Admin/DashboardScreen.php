<?php
namespace SSP\Admin;

use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\Util;
use SSP\Domain\Boxes;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;

defined( 'ABSPATH' ) || exit;

class DashboardScreen {

	public static function render() {
		global $wpdb;
		$t       = Installer::tables();
		$now     = Util::now();
		$counts  = Customers::count_by_status();
		$closing = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['products']} WHERE lifecycle='presale' AND closing_at BETWEEN %s AND %s ORDER BY closing_at ASC LIMIT 10", $now, Util::now( 2 * DAY_IN_SECONDS ) ) );
		$ready   = Invoices::customers_ready();
		$req     = Boxes::staff_list( array( 'status' => 'shipment_requested' ) );
		$expiring = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['waitlist']} WHERE status='offered' AND offer_expires_at < %s", Util::now( DAY_IN_SECONDS ) ) );
		$today_start = Util::local_to_utc( current_time( 'Y-m-d' ) . ' 00:00:00' );
		$today   = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(DISTINCT o.id) c, COALESCE(SUM((l.qty_ordered-l.qty_cancelled)*l.unit_price_usd),0) v FROM {$t['orders']} o JOIN {$t['lines']} l ON l.order_id=o.id WHERE o.submitted_at >= %s", $today_start ) );
		$errors  = Jobs::failing_count();
		$recent  = Orders::staff_orders( array( 'per_page' => 10 ) )['rows'];

		UI::open( 'Silver Stacker Operations', 'Private pre-sale portal staff console. <a href="' . esc_url( home_url( '/portal/' ) ) . '">View the customer portal</a>' );
		?>
		<div class="ssa-kpis">
			<a class="ssa-kpi<?php echo $counts['pending'] ? ' is-alert' : ''; ?>" href="<?php echo esc_url( UI::url( 'ssp-customers', array( 'status' => 'pending' ) ) ); ?>"><b><?php echo (int) $counts['pending']; ?></b><span>Registrations awaiting approval</span></a>
			<a class="ssa-kpi" href="<?php echo esc_url( UI::url( 'ssp-tracker' ) ); ?>"><b><?php echo count( $closing ); ?></b><span>Pre-sales closing in 48 hours</span></a>
			<a class="ssa-kpi" href="<?php echo esc_url( UI::url( 'ssp-invoices' ) ); ?>"><b><?php echo count( $ready ); ?></b><span>Customers with lines ready to invoice</span></a>
			<a class="ssa-kpi<?php echo $req ? ' is-alert' : ''; ?>" href="<?php echo esc_url( UI::url( 'ssp-boxes', array( 'status' => 'shipment_requested' ) ) ); ?>"><b><?php echo count( $req ); ?></b><span>Box shipment requests</span></a>
			<a class="ssa-kpi" href="<?php echo esc_url( UI::url( 'ssp-allocation', array( 'tab' => 'waitlist' ) ) ); ?>"><b><?php echo (int) $expiring; ?></b><span>Waitlist offers expiring in 24h</span></a>
			<a class="ssa-kpi<?php echo $errors ? ' is-danger' : ''; ?>" href="<?php echo esc_url( UI::url( 'ssp-integrations' ) ); ?>"><b><?php echo (int) $errors; ?></b><span>Integration errors</span></a>
			<a class="ssa-kpi" href="<?php echo esc_url( UI::url( 'ssp-orders' ) ); ?>"><b><?php echo (int) $today->c; ?></b><span>Orders today (<?php echo esc_html( Util::money( $today->v ) ); ?> ordered)</span></a>
			<a class="ssa-kpi" href="<?php echo esc_url( UI::url( 'ssp-customers', array( 'status' => 'approved' ) ) ); ?>"><b><?php echo (int) $counts['approved']; ?></b><span>Approved customers</span></a>
		</div>

		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Closing soon</h2>
				<?php if ( $closing ) : ?>
				<table class="ssa-table"><thead><tr><th>Product</th><th>Closes</th><th class="num">Reserved</th></tr></thead><tbody>
				<?php foreach ( $closing as $p ) : ?>
					<?php $res = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(reserved_qty),0) FROM {$t['variants']} WHERE product_id=%d", $p->id ) ); ?>
					<tr><td><a href="<?php echo esc_url( UI::url( 'ssp-products', array( 'edit' => $p->id ) ) ); ?>"><?php echo esc_html( $p->name ); ?></a></td><td><?php echo ssp_countdown( $p->closing_at ); // phpcs:ignore ?></td><td class="num"><?php echo (int) $res; ?></td></tr>
				<?php endforeach; ?>
				</tbody></table>
				<?php else : ?><p class="ssa-muted">No presales close in the next 48 hours.</p><?php endif; ?>
			</div>
			<div class="ssa-card">
				<h2>Shipment requests</h2>
				<?php if ( $req ) : ?>
				<table class="ssa-table"><thead><tr><th>Box</th><th>Customer</th><th>Requested</th></tr></thead><tbody>
				<?php foreach ( $req as $b ) : ?>
					<tr><td><a href="<?php echo esc_url( UI::url( 'ssp-boxes', array( 'box' => $b->id ) ) ); ?>">#<?php echo (int) $b->box_number; ?></a></td><td><?php echo esc_html( $b->company_name ); ?></td><td><?php echo esc_html( Util::fmt_dt( $b->shipment_requested_at ) ); ?></td></tr>
				<?php endforeach; ?>
				</tbody></table>
				<?php else : ?><p class="ssa-muted">No pending shipment requests.</p><?php endif; ?>
			</div>
		</div>

		<div class="ssa-card">
			<h2>Latest pre-orders</h2>
			<table class="ssa-table"><thead><tr><th>Order #</th><th>Customer</th><th>Date</th><th class="num">Total</th><th>Status</th></tr></thead><tbody>
			<?php foreach ( $recent as $o ) : ?>
				<tr><td><a href="<?php echo esc_url( UI::url( 'ssp-orders', array( 'order' => $o->order_number ) ) ); ?>">#<?php echo (int) $o->order_number; ?></a></td><td><?php echo UI::customer_link( $o->user_id, $o->company_name . ' (' . $o->contact_name . ')' ); // phpcs:ignore ?></td><td><?php echo esc_html( Util::fmt_dt( $o->submitted_at ) ); ?></td><td class="num"><?php echo esc_html( Util::money( $o->subtotal_usd ) ); ?></td><td><?php echo ssp_badge( Orders::ORDER_STATUSES[ $o->status ] ?? $o->status, ssp_status_kind( $o->status ) ); // phpcs:ignore ?></td></tr>
			<?php endforeach; ?>
			<?php if ( ! $recent ) : ?><tr><td colspan="5" class="ssa-muted">No orders yet.</td></tr><?php endif; ?>
			</tbody></table>
		</div>
		<?php
		UI::close();
	}
}
