<?php
namespace SSP\Admin;

use SSP\Core\Audit;
use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\Mailer;
use SSP\Core\Media;
use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Allocation;
use SSP\Domain\Boxes;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Reports;
use SSP\Domain\Shipments;
use SSP\Domain\Terms;
use SSP\Domain\Waitlist;
use SSP\Integrations\Qbo;
use SSP\Integrations\Sheets;
use SSP\Portal\Flash;

defined( 'ABSPATH' ) || exit;

/**
 * Staff console form handlers (admin-post.php?action=ssp_admin&do=...).
 * Each handler: nonce check (CSRF) + capability check + domain service call + audit (in service).
 */
class Handlers {

	const CAPS = array(
		'customer_status'          => 'ssp_approve_customers',
		'customer_update'          => 'ssp_view_all_customers',
		'customer_answer'          => 'ssp_approve_customers',
		'customer_invite'          => 'ssp_invite_customers',
		'customer_reset_password'  => 'ssp_approve_customers',
		'product_save'             => 'ssp_manage_products',
		'product_lifecycle'        => 'ssp_manage_products',
		'product_delete'           => 'ssp_manage_products',
		'variant_save'             => 'ssp_manage_prices',
		'variant_delete'           => 'ssp_manage_products',
		'image_upload'             => 'ssp_manage_products',
		'image_delete'             => 'ssp_manage_products',
		'image_primary'            => 'ssp_manage_products',
		'image_order'              => 'ssp_manage_products',
		'supplier_save'            => 'ssp_manage_products',
		'archive_import'           => 'ssp_manage_products',
		'line_qty'                 => 'ssp_correct_order_lines',
		'line_availability'        => 'ssp_manage_availability',
		'line_fulfillment'         => 'ssp_manage_boxes',
		'availability_bulk'        => 'ssp_manage_availability',
		'distribute_apply'         => 'ssp_manage_availability',
		'tracker_master_save'      => 'ssp_manage_products',
		'override_add'             => 'ssp_override_allocation',
		'waitlist_cancel'          => 'ssp_manage_waitlists',
		'waitlist_process'         => 'ssp_manage_waitlists',
		'box_preparing'            => 'ssp_manage_boxes',
		'box_rate'                 => 'ssp_manage_boxes',
		'box_ship'                 => 'ssp_manage_shipments',
		'box_delivered'            => 'ssp_manage_shipments',
		'box_close'                => 'ssp_manage_boxes',
		'box_request'              => 'ssp_manage_boxes',
		'box_cancel_request'       => 'ssp_manage_boxes',
		'box_move_line'            => 'ssp_manage_boxes',
		'box_remove_line'          => 'ssp_manage_boxes',
		'box_address'              => 'ssp_manage_boxes',
		'shipment_create'          => 'ssp_manage_shipments',
		'shipment_update'          => 'ssp_manage_shipments',
		'invoice_create'           => 'ssp_create_invoices',
		'invoice_cancel'           => 'ssp_create_invoices',
		'invoice_refresh'          => 'ssp_create_invoices',
		'job_retry'                => 'ssp_retry_integration_jobs',
		'jobs_run'                 => 'ssp_retry_integration_jobs',
		'qbo_settings'             => 'ssp_manage_integrations',
		'qbo_connect'              => 'ssp_manage_integrations',
		'qbo_disconnect'           => 'ssp_manage_integrations',
		'sheets_settings'          => 'ssp_manage_integrations',
		'sheets_rebuild'           => 'ssp_manage_integrations',
		'warehouse_settings'       => 'ssp_manage_integrations',
		'resource_upload'          => 'ssp_manage_staff_resources',
		'resource_delete'          => 'ssp_manage_staff_resources',
		'settings_save'            => 'ssp_manage_settings',
		'terms_publish'            => 'ssp_manage_settings',
		'question_save'            => 'ssp_manage_settings',
		'tier_save'                => 'ssp_manage_settings',
		'email_templates_save'     => 'ssp_manage_settings',
		'staff_user_create'        => 'ssp_manage_staff_users',
	);

	private static function p( $k, $d = '' ) {
		return isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : $d; // phpcs:ignore
	}

	private static function back( $url = '' ) {
		$ref = $url ? $url : wp_get_referer();
		wp_safe_redirect( $ref ? $ref : admin_url( 'admin.php?page=ssp-dashboard' ) );
		exit;
	}

	private static function res( $r, $ok, $url = '' ) {
		if ( is_wp_error( $r ) ) {
			Flash::from_error( $r );
		} elseif ( $ok ) {
			Flash::add( 'success', $ok );
		}
		self::back( $url );
	}

	public static function dispatch() {
		$do = sanitize_key( self::p( 'do' ) );
		if ( ! isset( self::CAPS[ $do ] ) ) {
			wp_die( 'Unknown action.', 400 );
		}
		check_admin_referer( 'ssp_admin_' . $do );
		if ( ! current_user_can( self::CAPS[ $do ] ) ) {
			wp_die( 'You do not have permission to do that.', 403 );
		}
		$method = 'do_' . $do;
		self::$method();
	}

	/* ---------------- Customers ---------------- */

	private static function do_customer_status() {
		$uid = (int) self::p( 'user_id' );
		self::res( Customers::set_status( $uid, sanitize_key( self::p( 'status' ) ), self::p( 'reason' ), ! empty( $_POST['notify'] ) ), 'Customer status updated.' );
	}

	private static function do_customer_update() {
		$uid = (int) self::p( 'user_id' );
		$r   = Customers::update_profile( $uid, array( 'contact_name' => self::p( 'contact_name' ), 'company_name' => self::p( 'company_name' ), 'phone' => self::p( 'phone' ), 'staff_notes' => self::p( 'staff_notes' ) ), true );
		self::res( $r, 'Customer updated.' );
	}

	private static function do_customer_answer() {
		self::res( Customers::update_answer( (int) self::p( 'answer_id' ), self::p( 'answer_text' ) ) ? true : new \WP_Error( 'x', 'Answer not found.' ), 'Answer updated.' );
	}

	private static function do_customer_invite() {
		$r = Customers::create_invite( self::p( 'email' ), self::p( 'name' ) );
		self::res( is_wp_error( $r ) ? $r : true, 'Invitation sent. The customer must complete registration and will appear as Pending approval.' );
	}

	private static function do_customer_reset_password() {
		$u = get_userdata( (int) self::p( 'user_id' ) );
		if ( ! $u ) {
			self::res( new \WP_Error( 'x', 'User not found.' ), '' );
		}
		$key = get_password_reset_key( $u );
		if ( is_wp_error( $key ) ) {
			self::res( $key, '' );
		}
		$url = home_url( '/reset-password/?login=' . rawurlencode( $u->user_login ) . '&key=' . rawurlencode( $key ) );
		wp_mail( $u->user_email, 'Reset your Silver Stacker Pre-Sale password', Mailer::wrap( '<p>A password reset was requested for your account by Silver Stacker staff.</p><p><a href="' . esc_url( $url ) . '">Choose a new password</a></p>' ), array( 'Content-Type: text/html; charset=UTF-8' ) );
		Audit::log( 'customer.password_reset_sent', 'customer', $u->ID );
		self::res( true, 'Password reset email sent.' );
	}

	/* ---------------- Products ---------------- */

	private static function do_product_save() {
		$id = (int) self::p( 'product_id' );
		$in = array(
			'name'               => self::p( 'name' ),
			'description'        => self::p( 'description' ),
			'brand'              => self::p( 'brand' ),
			'metal'              => self::p( 'metal' ),
			'category'           => self::p( 'category' ),
			'mintage'            => self::p( 'mintage' ),
			'eta_type'           => self::p( 'eta_type' ),
			'eta_start'          => self::p( 'eta_start_' . self::p( 'eta_type' ) ) ? self::p( 'eta_start_' . self::p( 'eta_type' ) ) : self::p( 'eta_start' ),
			'eta_end'            => self::p( 'eta_end' ),
			'eta_text'           => self::p( 'eta_text' ),
			'supplier_id'        => self::p( 'supplier_id' ),
			'date_posted'        => self::p( 'date_posted' ),
			'price_type'         => self::p( 'price_type' ),
			'spot_premium_usd'   => self::p( 'spot_premium_usd' ),
			'closing_at'         => self::p( 'closing_at' ),
			'reopen_if_extended' => self::p( 'reopen_if_extended' ),
		);
		if ( '' !== trim( (string) self::p( 'new_supplier' ) ) ) {
			$sid = Catalog::save_supplier( self::p( 'new_supplier' ) );
			if ( ! is_wp_error( $sid ) ) {
				$in['supplier_id'] = $sid;
			}
		}
		$r = Catalog::save_product( $in, $id ? $id : null );
		if ( is_wp_error( $r ) ) {
			self::res( $r, '' );
		}
		// First variant for a brand-new product (simple products have one default variant).
		if ( ! $id && '' !== trim( (string) self::p( 'sku' ) ) ) {
			$v = Catalog::save_variant(
				$r,
				array(
					'sku'                     => self::p( 'sku' ),
					'barcode'                 => self::p( 'barcode' ),
					'price_usd'               => self::p( 'price_usd' ),
					'min_order_qty'           => self::p( 'min_order_qty', 1 ),
					'total_allocation'        => self::p( 'total_allocation' ),
					'per_customer_allocation' => self::p( 'per_customer_allocation' ),
					'supplier_qty_ordered'    => self::p( 'supplier_qty_ordered' ),
				)
			);
			if ( is_wp_error( $v ) ) {
				Flash::from_error( $v );
			}
		}
		$tab = sanitize_key( self::p( 'tab', 'details' ) );
		self::res( true, 'Product saved.', admin_url( 'admin.php?page=ssp-products&edit=' . $r . '&tab=' . $tab ) );
	}

	private static function do_product_lifecycle() {
		$r = Catalog::set_lifecycle( (int) self::p( 'product_id' ), sanitize_key( self::p( 'lifecycle' ) ), sanitize_textarea_field( self::p( 'reason' ) ) );
		self::res( $r, 'Lifecycle updated.' );
	}

	private static function do_product_delete() {
		$r = Catalog::delete_product( (int) self::p( 'product_id' ) );
		self::res( $r, 'Draft product deleted.', is_wp_error( $r ) ? '' : admin_url( 'admin.php?page=ssp-products' ) );
	}

	private static function do_variant_save() {
		$pid = (int) self::p( 'product_id' );
		$vid = (int) self::p( 'variant_id' );
		$in  = (array) self::p( 'v', array() );
		$in['active_present'] = 1;
		$r = Catalog::save_variant( $pid, $in, $vid ? $vid : null );
		self::res( $r, 'Variant saved.' );
	}

	private static function do_variant_delete() {
		self::res( Catalog::delete_variant( (int) self::p( 'variant_id' ) ), 'Variant removed (deactivated if it has orders).' );
	}

	private static function do_image_upload() {
		$pid = (int) self::p( 'product_id' );
		if ( empty( $_FILES['images'] ) ) {
			self::res( new \WP_Error( 'x', 'Choose at least one image.' ), '' );
		}
		$files = $_FILES['images']; // phpcs:ignore
		$n     = 0;
		foreach ( (array) $files['name'] as $i => $name ) {
			$one = array(
				'name'     => $name,
				'type'     => $files['type'][ $i ],
				'tmp_name' => $files['tmp_name'][ $i ],
				'error'    => $files['error'][ $i ],
				'size'     => $files['size'][ $i ],
			);
			$r = Catalog::add_image( $pid, $one );
			if ( is_wp_error( $r ) ) {
				Flash::add( 'error', $name . ': ' . $r->get_error_message() );
			} else {
				++$n;
			}
		}
		self::res( true, $n . ' image(s) uploaded.' );
	}

	private static function do_image_delete() {
		Catalog::delete_image( (int) self::p( 'image_id' ) );
		self::res( true, 'Image deleted.' );
	}

	private static function do_image_primary() {
		Catalog::set_primary_image( (int) self::p( 'product_id' ), (int) self::p( 'image_id' ) );
		self::res( true, 'Primary image set.' );
	}

	private static function do_image_order() {
		$ids = array_map( 'intval', explode( ',', (string) self::p( 'order' ) ) );
		Catalog::reorder_images( (int) self::p( 'product_id' ), $ids );
		self::res( true, 'Image order saved.' );
	}

	private static function do_supplier_save() {
		self::res( Catalog::save_supplier( self::p( 'name' ), self::p( 'contact' ), self::p( 'notes' ) ), 'Supplier saved.' );
	}

	private static function do_archive_import() {
		if ( empty( $_FILES['csv']['tmp_name'] ) ) {
			self::res( new \WP_Error( 'x', 'Choose a CSV file.' ), '' );
		}
		$res = ArchiveImport::import( $_FILES['csv']['tmp_name'], ! empty( $_POST['dry_run'] ) ); // phpcs:ignore
		foreach ( array_slice( $res['errors'], 0, 20 ) as $e ) {
			Flash::add( 'error', $e );
		}
		self::res( true, sprintf( '%s: %d row(s) ready/imported, %d skipped.', ! empty( $_POST['dry_run'] ) ? 'Dry run' : 'Import complete', $res['imported'], $res['skipped'] ) );
	}

	/* ---------------- Orders / availability ---------------- */

	private static function do_line_qty() {
		$r = Orders::staff_set_qty( (int) self::p( 'line_id' ), (int) self::p( 'qty' ), self::p( 'reason' ), ! empty( $_POST['allow_over'] ) && current_user_can( 'ssp_override_allocation' ) );
		self::res( $r, 'Line quantity corrected.' );
	}

	private static function do_line_availability() {
		self::res( Orders::set_availability( (int) self::p( 'line_id' ), (int) self::p( 'qty_available' ), 'staff', sanitize_textarea_field( self::p( 'note' ) ) ), 'Availability updated.' );
	}

	private static function do_availability_bulk() {
		$rows = (array) self::p( 'avail', array() );
		$ok   = 0;
		foreach ( $rows as $lid => $qty ) {
			if ( '' === $qty ) {
				continue;
			}
			$line = Orders::line( (int) $lid );
			if ( $line && (int) $qty !== (int) $line->qty_available ) {
				$r = Orders::set_availability( (int) $lid, (int) $qty, 'staff', 'Bulk update' );
				if ( is_wp_error( $r ) ) {
					Flash::add( 'error', $line->name_snapshot . ' (#' . $lid . '): ' . $r->get_error_message() );
				} else {
					++$ok;
				}
			}
		}
		self::res( true, $ok . ' line(s) updated.' );
	}

	private static function do_distribute_apply() {
		$plan = (array) self::p( 'plan', array() );
		$ok   = 0;
		foreach ( $plan as $lid => $qty ) {
			$r = Orders::set_availability( (int) $lid, (int) $qty, 'staff', 'Arrival distribution (confirmed by staff)' );
			if ( ! is_wp_error( $r ) ) {
				++$ok;
			} else {
				Flash::add( 'error', 'Line ' . (int) $lid . ': ' . $r->get_error_message() );
			}
		}
		self::res( true, $ok . ' line(s) marked available.' );
	}

	private static function do_line_fulfillment() {
		self::res( Orders::set_fulfillment( (int) self::p( 'line_id' ), sanitize_key( self::p( 'fulfillment' ) ) ), 'Fulfillment choice updated.' );
	}

	private static function do_tracker_master_save() {
		$rows = (array) self::p( 'm', array() );
		$n    = 0;
		foreach ( $rows as $vid => $row ) {
			$v = Catalog::variant( (int) $vid );
			if ( ! $v ) {
				continue;
			}
			$p = Catalog::get( $v->product_id );
			if ( isset( $row['supplier_qty_ordered'] ) && (string) $row['supplier_qty_ordered'] !== (string) $v->supplier_qty_ordered ) {
				$data = (array) $v;
				$data['supplier_qty_ordered'] = $row['supplier_qty_ordered'];
				$data['active_present']       = 1;
				$r = Catalog::save_variant( $v->product_id, $data, $v->id );
				if ( is_wp_error( $r ) ) {
					Flash::from_error( $r );
				} else {
					++$n;
				}
			}
			if ( isset( $row['eta_text'] ) || isset( $row['supplier_id'] ) ) {
				$pd = (array) $p;
				$changed = false;
				if ( isset( $row['eta_text'] ) && $row['eta_text'] !== Catalog::eta_label( $p ) ) {
					$pd['eta_type'] = '' === trim( $row['eta_text'] ) ? 'none' : 'text';
					$pd['eta_text'] = $row['eta_text'];
					$changed = true;
				}
				if ( isset( $row['supplier_id'] ) && (int) $row['supplier_id'] !== (int) $p->supplier_id ) {
					$pd['supplier_id'] = $row['supplier_id'];
					$changed = true;
				}
				if ( $changed ) {
					unset( $pd['closing_at'] );
					$r = Catalog::save_product( $pd, $p->id );
					if ( is_wp_error( $r ) ) {
						Flash::from_error( $r );
					} else {
						++$n;
					}
				}
			}
		}
		self::res( true, $n . ' change(s) saved.' );
	}

	private static function do_override_add() {
		$r = Allocation::add_override( (int) self::p( 'variant_id' ), (int) self::p( 'user_id' ), sanitize_key( self::p( 'override_type' ) ), (int) self::p( 'qty' ), self::p( 'reason' ) );
		self::res( $r, 'Override recorded.' );
	}

	private static function do_waitlist_cancel() {
		self::res( Waitlist::cancel( (int) self::p( 'waitlist_id' ), get_current_user_id(), self::p( 'reason' ) ), 'Waitlist entry cancelled.' );
	}

	private static function do_waitlist_process() {
		Waitlist::process_variant( (int) self::p( 'variant_id' ) );
		self::res( true, 'Waitlist processed against current allocation.' );
	}

	/* ---------------- Boxes & shipments ---------------- */

	private static function do_box_preparing() {
		self::res( Boxes::set_preparing( (int) self::p( 'box_id' ) ), 'Box marked as preparing.' );
	}

	private static function do_box_rate() {
		self::res( Boxes::set_rate( (int) self::p( 'box_id' ), (int) self::p( 'rate_tier_id' ), self::p( 'shipping_charge_usd' ) ), 'Shipping tier saved.' );
	}

	private static function do_box_ship() {
		$r = Boxes::ship(
			(int) self::p( 'box_id' ),
			array(
				'rate_tier_id'        => self::p( 'rate_tier_id' ),
				'shipping_charge_usd' => self::p( 'shipping_charge_usd' ),
				'carrier'             => self::p( 'carrier' ),
				'tracking_number'     => self::p( 'tracking_number' ),
				'shipped_at'          => self::p( 'shipped_at' ),
				'notes'               => self::p( 'notes' ),
			)
		);
		self::res( is_wp_error( $r ) ? $r : true, 'Box shipped and tracking recorded. The customer has been notified.' );
	}

	private static function do_box_delivered() {
		self::res( Boxes::set_delivered( (int) self::p( 'box_id' ) ), 'Marked delivered.' );
	}

	private static function do_box_close() {
		self::res( Boxes::close( (int) self::p( 'box_id' ), self::p( 'reason' ) ), 'Box closed.' );
	}

	private static function do_box_request() {
		self::res( Boxes::request_shipment( (int) self::p( 'box_id' ), get_current_user_id(), sanitize_key( self::p( 'mode', 'ship_available' ) ) ), 'Shipment requested on behalf of the customer.' );
	}

	private static function do_box_cancel_request() {
		self::res( Boxes::cancel_request( (int) self::p( 'box_id' ), get_current_user_id() ), 'Shipment request cancelled.' );
	}

	private static function do_box_move_line() {
		self::res( Boxes::move_line( (int) self::p( 'line_id' ), (int) self::p( 'to_box_id' ), self::p( 'reason' ) ), 'Line moved.' );
	}

	private static function do_box_remove_line() {
		self::res( Orders::set_fulfillment( (int) self::p( 'line_id' ), sanitize_key( self::p( 'to', 'decide_later' ) ) ), 'Line removed from box.' );
	}

	private static function do_box_address() {
		self::res( Boxes::set_address( (int) self::p( 'box_id' ), (int) self::p( 'address_id' ), get_current_user_id(), true ), 'Box address updated.' );
	}

	private static function do_shipment_create() {
		$sel = array();
		foreach ( (array) self::p( 'ship', array() ) as $lid => $q ) {
			if ( (int) $q > 0 ) {
				$sel[ (int) $lid ] = (int) $q;
			}
		}
		$r = Shipments::create(
			(int) self::p( 'user_id' ),
			$sel,
			array(
				'rate_tier_id'        => self::p( 'rate_tier_id' ),
				'shipping_charge_usd' => self::p( 'shipping_charge_usd' ),
				'carrier'             => self::p( 'carrier' ),
				'tracking_number'     => self::p( 'tracking_number' ),
				'shipped_at'          => self::p( 'shipped_at' ),
				'status'              => self::p( 'status', 'shipped' ),
				'notes'               => self::p( 'notes' ),
			)
		);
		self::res( is_wp_error( $r ) ? $r : true, 'Shipment recorded.' );
	}

	private static function do_shipment_update() {
		self::res(
			Shipments::update(
				(int) self::p( 'shipment_id' ),
				array(
					'carrier'             => self::p( 'carrier' ),
					'tracking_number'     => self::p( 'tracking_number' ),
					'rate_tier_id'        => self::p( 'rate_tier_id' ),
					'shipping_charge_usd' => self::p( 'shipping_charge_usd' ),
					'status'              => sanitize_key( self::p( 'status' ) ),
					'notes'               => self::p( 'notes' ),
				)
			),
			'Shipment updated.'
		);
	}

	/* ---------------- Invoices ---------------- */

	private static function do_invoice_create() {
		$uid = (int) self::p( 'user_id' );
		$sel = array();
		foreach ( (array) self::p( 'sel', array() ) as $lid => $row ) {
			if ( empty( $row['on'] ) ) {
				continue;
			}
			$sel[ (int) $lid ] = array(
				'qty'        => (int) ( $row['qty'] ?? 0 ),
				'unit_price' => ( $row['unit_price'] ?? '' ) === '' ? null : $row['unit_price'],
			);
		}
		$ship = array();
		if ( (float) self::p( 'shipping_amount', 0 ) > 0 ) {
			$ship = array(
				'amount'      => (float) self::p( 'shipping_amount' ),
				'description' => sanitize_text_field( self::p( 'shipping_description', 'Shipping' ) ),
				'shipment_id' => (int) self::p( 'shipment_id' ),
			);
		}
		$mode = 'manual' === self::p( 'mode' ) ? 'manual' : 'qbo';
		$r    = Invoices::create( $uid, $sel, $ship, sanitize_text_field( self::p( 'action_nonce' ) ), $mode, (array) self::p( 'manual', array() ) );
		if ( is_wp_error( $r ) ) {
			self::res( $r, '', admin_url( 'admin.php?page=ssp-invoices&new=' . $uid ) );
		}
		$inv = Invoices::get( $r );
		$msg = Invoices::is_final( $inv ) ? 'Invoice ' . $inv->doc_number . ' created and linked to the selected lines.' : ( 'error' === $inv->sync_status ? 'The invoice could not be created in QuickBooks yet: ' . $inv->error_message . ' Lines were NOT marked invoiced. You can retry or cancel.' : 'Invoice queued for QuickBooks.' );
		Flash::add( 'error' === $inv->sync_status ? 'error' : 'success', $msg );
		self::back( admin_url( 'admin.php?page=ssp-invoices&invoice=' . $r ) );
	}

	private static function do_invoice_cancel() {
		self::res( Invoices::cancel_unsynced( (int) self::p( 'invoice_id' ), self::p( 'reason' ) ), 'Invoice cancelled; quantities released.' );
	}

	private static function do_invoice_refresh() {
		$id  = (int) self::p( 'invoice_id' );
		$inv = Invoices::get( $id );
		if ( $inv && in_array( $inv->sync_status, array( 'queued', 'error', 'creating' ), true ) ) {
			global $wpdb;
			$jt  = Installer::tables()['jobs'];
			$jid = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$jt} WHERE idempotency_key=%s", 'qbo_create_invoice:' . $id ) );
			if ( $jid ) {
				Jobs::retry( (int) $jid );
			} else {
				Jobs::enqueue( 'qbo', 'qbo.create_invoice', 'invoice', $id, array( 'invoice_id' => $id ), 'qbo_create_invoice:' . $id );
				Jobs::run( 3, 'qbo' );
			}
		} else {
			Jobs::enqueue( 'qbo', 'qbo.refresh_invoice', 'invoice', $id, array( 'invoice_id' => $id ), null, 0, true );
			Jobs::run( 3, 'qbo' );
		}
		$inv = Invoices::get( $id );
		self::res( 'error' === $inv->sync_status ? new \WP_Error( 'qbo', 'QuickBooks: ' . $inv->error_message ) : true, 'Invoice synchronized with QuickBooks.' );
	}

	/* ---------------- Integrations ---------------- */

	private static function do_job_retry() {
		Jobs::retry( (int) self::p( 'job_id' ) );
		self::res( true, 'Job retried. Check its status below.' );
	}

	private static function do_jobs_run() {
		$n = Jobs::run( 50 );
		self::res( true, $n . ' due job(s) processed.' );
	}

	private static function do_qbo_settings() {
		foreach ( array( 'qbo_environment', 'qbo_client_id', 'qbo_income_account_id', 'qbo_shipping_item_id', 'qbo_item_strategy', 'qbo_generic_item_id', 'qbo_term_id' ) as $k ) {
			Settings::set( $k, sanitize_text_field( self::p( $k ) ) );
		}
		Settings::set( 'qbo_send_invoice_email', empty( $_POST['qbo_send_invoice_email'] ) ? 0 : 1 );
		foreach ( array( 'qbo_client_secret', 'qbo_webhook_verifier' ) as $k ) {
			if ( '' !== (string) self::p( $k ) ) {
				Settings::set( $k, trim( (string) self::p( $k ) ) );
			}
		}
		Audit::log( 'settings.qbo_saved', 'settings', 'qbo' );
		self::res( true, 'QuickBooks settings saved.' );
	}

	private static function do_qbo_connect() {
		if ( ! Settings::get( 'qbo_client_id' ) || ! Settings::get( 'qbo_client_secret' ) ) {
			self::res( new \WP_Error( 'x', 'Enter the Intuit app Client ID and Client Secret first.' ), '' );
		}
		wp_redirect( Qbo::authorize_url() ); // phpcs:ignore WordPress.Security.SafeRedirect -- Intuit domain.
		exit;
	}

	public static function qbo_callback() {
		if ( ! current_user_can( 'ssp_manage_integrations' ) ) {
			wp_die( 'Not allowed', 403 );
		}
		$code  = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
		$realm = isset( $_GET['realmId'] ) ? sanitize_text_field( wp_unslash( $_GET['realmId'] ) ) : '';
		$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		$r     = $code ? Qbo::handle_callback( $code, $realm, $state ) : new \WP_Error( 'x', 'QuickBooks did not return an authorization code.' );
		self::res( $r, 'QuickBooks Online connected.', admin_url( 'admin.php?page=ssp-integrations' ) );
	}

	private static function do_qbo_disconnect() {
		Qbo::disconnect();
		self::res( true, 'QuickBooks disconnected.' );
	}

	private static function do_sheets_settings() {
		Settings::set( 'sheets_enabled', empty( $_POST['sheets_enabled'] ) ? 0 : 1 );
		Settings::set( 'sheets_spreadsheet_id', sanitize_text_field( self::p( 'sheets_spreadsheet_id' ) ) );
		$json = trim( (string) self::p( 'sheets_service_account' ) );
		if ( '' !== $json ) {
			$d = json_decode( $json, true );
			if ( empty( $d['client_email'] ) || empty( $d['private_key'] ) ) {
				self::res( new \WP_Error( 'x', 'That does not look like a Google service account JSON key.' ), '' );
			}
			Settings::set( 'sheets_service_account', $json );
			delete_transient( 'ssp_gs_token' );
		}
		delete_transient( 'ssp_gs_tabs_ok' );
		Audit::log( 'settings.sheets_saved', 'settings', 'sheets' );
		self::res( true, 'Google Sheets settings saved.' );
	}

	private static function do_sheets_rebuild() {
		try {
			Sheets::rebuild();
			self::res( true, 'Google Sheet rebuilt from portal data.' );
		} catch ( \Throwable $e ) {
			self::res( new \WP_Error( 'x', $e->getMessage() ), '' );
		}
	}

	private static function do_warehouse_settings() {
		Settings::set( 'warehouse_adapter', 'webhook' === self::p( 'warehouse_adapter' ) ? 'webhook' : 'manual' );
		Settings::set( 'warehouse_url', esc_url_raw( self::p( 'warehouse_url' ) ) );
		if ( '' !== (string) self::p( 'warehouse_webhook_secret' ) ) {
			Settings::set( 'warehouse_webhook_secret', trim( (string) self::p( 'warehouse_webhook_secret' ) ) );
		}
		Audit::log( 'settings.warehouse_saved', 'settings', 'warehouse' );
		self::res( true, 'Warehouse settings saved.' );
	}

	/* ---------------- Staff resources ---------------- */

	private static function do_resource_upload() {
		global $wpdb;
		if ( empty( $_FILES['file']['tmp_name'] ) ) {
			self::res( new \WP_Error( 'x', 'Choose a file.' ), '' );
		}
		$s = Media::store_resource( $_FILES['file'] ); // phpcs:ignore
		if ( is_wp_error( $s ) ) {
			self::res( $s, '' );
		}
		$wpdb->insert(
			Installer::tables()['resources'],
			array(
				'resource_uid' => Util::ulid(),
				'title'        => sanitize_text_field( self::p( 'title' ) ) ? sanitize_text_field( self::p( 'title' ) ) : $s['file_name'],
				'description'  => sanitize_textarea_field( self::p( 'description' ) ),
				'file_path'    => $s['file_path'],
				'file_name'    => $s['file_name'],
				'mime'         => $s['mime'],
				'size_bytes'   => $s['size'],
				'uploaded_by'  => get_current_user_id(),
				'created_at'   => Util::now(),
			)
		);
		Audit::log( 'resource.uploaded', 'resource', $wpdb->insert_id, null, array( 'file' => $s['file_name'] ) );
		self::res( true, 'Resource uploaded.' );
	}

	private static function do_resource_delete() {
		global $wpdb;
		$t = Installer::tables()['resources'];
		$r = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", (int) self::p( 'resource_id' ) ) );
		if ( $r ) {
			Media::delete_relative( $r->file_path );
			$wpdb->delete( $t, array( 'id' => $r->id ) );
			Audit::log( 'resource.deleted', 'resource', $r->id, array( 'file' => $r->file_name ), null );
		}
		self::res( true, 'Resource deleted.' );
	}

	/* ---------------- Settings ---------------- */

	private static function do_settings_save() {
		$in       = (array) self::p( 's', array() );
		$defaults = Settings::defaults();
		$before   = Settings::all();
		$allowed  = array( 'business_timezone', 'default_closing_time', 'announcement', 'append_closing_date_to_name', 'fb_group_link', 'order_number_start', 'min_qty_scope', 'zero_qty_cancels', 'instock_editable_until', 'order_confirmation_email', 'default_fulfillment_choice', 'waitlist_mode', 'waitlist_hold_hours', 'max_open_boxes', 'address_change_until', 'ship_unavailable_mode', 'fulfillment_change_until', 'box_auto_close_days', 'box_digest_minutes', 'email_from_name', 'email_from_address', 'email_reply_to', 'staff_alert_email', 'reps_can_view_audit_log', 'require_terms_reaccept', 'metals' );
		$checkboxes = array( 'append_closing_date_to_name', 'zero_qty_cancels', 'order_confirmation_email', 'reps_can_view_audit_log', 'require_terms_reaccept' );
		$section  = sanitize_key( self::p( 'section' ) );
		$present  = array_map( 'sanitize_key', (array) self::p( 'present', array() ) );
		foreach ( $allowed as $k ) {
			if ( ! in_array( $k, $present, true ) ) {
				continue;
			}
			if ( in_array( $k, $checkboxes, true ) ) {
				Settings::set( $k, empty( $in[ $k ] ) ? 0 : 1 );
				continue;
			}
			$v = $in[ $k ] ?? '';
			if ( 'metals' === $k ) {
				$v = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', (string) $v ) ) ) ) );
			} elseif ( is_int( $defaults[ $k ] ) ) {
				$v = (int) $v;
			} elseif ( 'announcement' === $k ) {
				$v = sanitize_textarea_field( $v );
			} elseif ( 'fb_group_link' === $k ) {
				$v = esc_url_raw( $v );
			} elseif ( 'business_timezone' === $k ) {
				$v = in_array( $v, timezone_identifiers_list(), true ) ? $v : 'America/Chicago';
			} else {
				$v = sanitize_text_field( $v );
			}
			Settings::set( $k, $v );
		}
		list( $b, $a ) = Audit::diff( array_map( fn( $x ) => is_array( $x ) ? implode( ',', $x ) : $x, $before ), array_map( fn( $x ) => is_array( $x ) ? implode( ',', $x ) : $x, array_intersect_key( Settings::all(), array_flip( $allowed ) ) ) );
		if ( $a ) {
			Audit::log( 'settings.saved', 'settings', $section, $b, $a );
		}
		self::res( true, 'Settings saved.' );
	}

	private static function do_terms_publish() {
		$r = Terms::publish( self::p( 'version_label' ), self::p( 'content' ) );
		self::res( is_wp_error( $r ) ? $r : true, 'New terms version published. Customers must accept it on their next visit.' );
	}

	private static function do_question_save() {
		global $wpdb;
		$t   = Installer::tables()['questions'];
		$qs  = (array) self::p( 'q', array() );
		foreach ( $qs as $id => $row ) {
			$wpdb->update(
				$t,
				array(
					'text'        => sanitize_textarea_field( $row['text'] ?? '' ),
					'answer_type' => 'yesno' === ( $row['answer_type'] ?? '' ) ? 'yesno' : 'text',
					'sort'        => (int) ( $row['sort'] ?? 0 ),
					'active'      => empty( $row['active'] ) ? 0 : 1,
				),
				array( 'id' => (int) $id )
			);
		}
		$new = trim( (string) self::p( 'new_text' ) );
		if ( '' !== $new ) {
			$wpdb->insert( $t, array( 'question_key' => 'custom_' . time(), 'text' => sanitize_textarea_field( $new ), 'answer_type' => 'yesno' === self::p( 'new_type' ) ? 'yesno' : 'text', 'sort' => 99, 'active' => 1, 'created_at' => Util::now() ) );
		}
		Audit::log( 'settings.questions_saved', 'settings', 'questions' );
		self::res( true, 'Sign-up questions saved. Existing answers keep the question text they were given with.' );
	}

	private static function do_tier_save() {
		$rows = (array) self::p( 't', array() );
		foreach ( $rows as $id => $row ) {
			if ( 'new' === $id ) {
				if ( '' !== trim( (string) ( $row['name'] ?? '' ) ) ) {
					Shipments::save_tier( $row );
				}
				continue;
			}
			Shipments::save_tier( $row, (int) $id );
		}
		self::res( true, 'Shipping rate tiers saved.' );
	}

	private static function do_email_templates_save() {
		$in  = (array) self::p( 'tpl', array() );
		$out = array();
		foreach ( Mailer::default_templates() as $k => $d ) {
			if ( isset( $in[ $k ] ) ) {
				$out[ $k ] = array(
					'subject' => sanitize_text_field( $in[ $k ]['subject'] ?? $d['subject'] ),
					'body'    => wp_kses_post( $in[ $k ]['body'] ?? $d['body'] ),
				);
			}
		}
		update_option( Mailer::OPTION, $out, false );
		Audit::log( 'settings.email_templates_saved', 'settings', 'email' );
		self::res( true, 'Email templates saved.' );
	}

	private static function do_staff_user_create() {
		$email = sanitize_email( self::p( 'email' ) );
		$name  = sanitize_text_field( self::p( 'name' ) );
		if ( ! is_email( $email ) || email_exists( $email ) ) {
			self::res( new \WP_Error( 'x', 'Enter a new, valid email address.' ), '' );
		}
		$uid = wp_insert_user( array( 'user_login' => sanitize_user( strstr( $email, '@', true ) . '_staff', true ), 'user_email' => $email, 'display_name' => $name, 'user_pass' => wp_generate_password( 24 ), 'role' => 'ss_sales_rep' ) );
		if ( is_wp_error( $uid ) ) {
			self::res( $uid, '' );
		}
		wp_new_user_notification( $uid, null, 'user' );
		Audit::log( 'staff.created', 'user', $uid, null, array( 'email' => $email, 'role' => 'ss_sales_rep' ) );
		self::res( true, 'Sales representative created. They received an email to set their password.' );
	}

	/* ---------------- CSV downloads (GET) ---------------- */

	public static function downloads() {
		if ( empty( $_GET['ssp_export'] ) ) {
			return;
		}
		$what = sanitize_key( wp_unslash( $_GET['ssp_export'] ) );
		check_admin_referer( 'ssp_export_' . $what );
		if ( ! current_user_can( 'ssp_export_data' ) ) {
			wp_die( 'Not allowed', 403 );
		}
		Audit::log( 'export.downloaded', 'export', $what );
		$from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to   = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
		$stamp = gmdate( 'Ymd-His' );
		switch ( $what ) {
			case 'orders':
			case 'invoices':
			case 'customers':
			case 'products':
				list( $h, $rows ) = Reports::export( $what );
				Util::csv_download( "silver-stacker-{$what}-{$stamp}.csv", $h, $rows );
				break;
			case 'report':
				$csv = ReportsScreen::csv( sanitize_key( wp_unslash( $_GET['report'] ?? '' ) ), $_GET ); // phpcs:ignore
				Util::csv_download( 'silver-stacker-report-' . sanitize_key( wp_unslash( $_GET['report'] ?? '' ) ) . "-{$stamp}.csv", $csv[0], $csv[1] );
				break;
		}
		exit;
	}
}
