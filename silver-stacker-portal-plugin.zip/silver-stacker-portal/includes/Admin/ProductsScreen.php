<?php
namespace SSP\Admin;

use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Allocation;
use SSP\Domain\Catalog;
use SSP\Domain\Orders;

defined( 'ABSPATH' ) || exit;

class ProductsScreen {

	public static function render() {
		$edit = UI::get( 'edit' );
		if ( '' !== $edit ) {
			self::editor( 'new' === $edit ? 0 : (int) $edit );
			return;
		}
		$args = array(
			'q'         => UI::get( 'q' ),
			'lifecycle' => UI::get( 'lifecycle' ),
			'metal'     => UI::get( 'metal' ),
			'paged'     => (int) UI::get( 'paged', 1 ),
		);
		$res  = Catalog::admin_list( $args );
		UI::open( 'Products', 'Active and upcoming catalog. Archived items live in the Archive screen.', '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::export_url( 'products' ) ) . '">Export CSV</a> <a class="ssa-btn" href="' . esc_url( UI::url( 'ssp-products', array( 'edit' => 'new' ) ) ) . '">+ New product</a>' );
		?>
		<form class="ssa-filters" method="get">
			<input type="hidden" name="page" value="ssp-products">
			<input type="search" name="q" value="<?php echo esc_attr( $args['q'] ); ?>" placeholder="Search product, SKU or barcode">
			<?php echo UI::select( 'lifecycle', array( '' => 'Any status (not archived)' ) + Catalog::LIFECYCLES, $args['lifecycle'] ); // phpcs:ignore ?>
			<?php echo UI::select( 'metal', array( '' => 'All categories' ) + array_combine( (array) Settings::get( 'metals' ), (array) Settings::get( 'metals' ) ), $args['metal'] ); // phpcs:ignore ?>
			<button class="ssa-btn ssa-btn--ghost" type="submit">Filter</button>
		</form>
		<table class="ssa-table ssa-table--hover">
			<thead><tr><th></th><th>Product title</th><th>SKU / code</th><th>Category</th><th class="num">Price</th><th>Closes</th><th>ETA</th><th class="num">Reserved / Allocation</th><th>Status</th></tr></thead>
			<tbody>
			<?php foreach ( $res['rows'] as $p ) : ?>
				<?php
				$vs  = Catalog::variants( $p->id );
				$img = Catalog::primary_image( $p->id );
				$res_q = array_sum( array_map( fn( $v ) => (int) $v->reserved_qty, $vs ) );
				$tot   = array_map( fn( $v ) => $v->total_allocation, $vs );
				$tot_s = in_array( null, $tot, true ) ? 'Unlimited' : array_sum( $tot );
				?>
				<tr>
					<td><img class="ssa-thumb" src="<?php echo esc_url( Catalog::image_url( $img, 'thumb' ) ); ?>" alt=""></td>
					<td><a href="<?php echo esc_url( UI::url( 'ssp-products', array( 'edit' => $p->id ) ) ); ?>"><strong><?php echo esc_html( Catalog::display_name( $p ) ); ?></strong></a></td>
					<td><?php echo esc_html( implode( ', ', array_map( fn( $v ) => $v->sku, $vs ) ) ); ?></td>
					<td><?php echo esc_html( $p->metal ); ?></td>
					<td class="num"><?php echo esc_html( Catalog::price_range_label( $p ) ); ?></td>
					<td><?php echo $p->closing_at ? esc_html( Util::fmt_dt( $p->closing_at, 'M j g:i A' ) ) : ''; ?></td>
					<td><?php echo esc_html( Catalog::eta_label( $p ) ); ?></td>
					<td class="num"><?php echo (int) $res_q; ?> / <?php echo esc_html( (string) $tot_s ); ?></td>
					<td><?php echo ssp_badge( Catalog::lifecycle_label( $p ), ssp_status_kind( Catalog::effective_lifecycle( $p ) ) ); // phpcs:ignore ?></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( ! $res['rows'] ) : ?><tr><td colspan="9" class="ssa-muted">No products. <a href="<?php echo esc_url( UI::url( 'ssp-products', array( 'edit' => 'new' ) ) ); ?>">Create the first one</a>.</td></tr><?php endif; ?>
			</tbody>
		</table>
		<?php
		UI::pager( $res['total'], 50, $args['paged'], 'ssp-products', array_filter( $args ) );
		UI::close();
	}

	private static function editor( $id ) {
		$p   = $id ? Catalog::get( $id ) : null;
		$tab = UI::get( 'tab', 'details' );
		if ( $id && ! $p ) {
			UI::open( 'Product not found' );
			UI::close();
			return;
		}
		$title = $p ? $p->name : 'New product';
		$sub   = $p ? ssp_badge( Catalog::lifecycle_label( $p ), ssp_status_kind( Catalog::effective_lifecycle( $p ) ) ) . ' &middot; <a href="' . esc_url( Catalog::url( $p ) ) . '" target="_blank">View in portal</a>' : '';
		UI::open( $title, $sub, '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::url( 'archived' === ( $p->lifecycle ?? '' ) ? 'ssp-archive' : 'ssp-products' ) ) . '">&larr; Back</a>' );
		if ( $p ) {
			UI::tabs( 'ssp-products', array( 'details' => 'Details', 'variants' => 'Variants, Pricing &amp; Allocation', 'images' => 'Images', 'orders' => 'Orders', 'history' => 'History' ), $tab, array( 'edit' => $id ) );
		}
		if ( ! $p || 'details' === $tab ) {
			self::details_tab( $p );
		} elseif ( 'variants' === $tab ) {
			self::variants_tab( $p );
		} elseif ( 'images' === $tab ) {
			self::images_tab( $p );
		} elseif ( 'orders' === $tab ) {
			self::orders_tab( $p );
		} else {
			UI::history( 'product', $p->id );
			foreach ( Catalog::variants( $p->id ) as $v ) {
				echo '<h3>Variant ' . esc_html( $v->sku ) . '</h3>';
				UI::history( 'variant', $v->id );
			}
		}
		UI::close();
	}

	private static function details_tab( $p ) {
		$v       = fn( $k, $d = '' ) => $p ? $p->$k : $d;
		$metals  = (array) Settings::get( 'metals' );
		$life    = $p ? Catalog::effective_lifecycle( $p ) : 'draft';
		$eta_t   = $v( 'eta_type', 'none' );
		?>
		<div class="ssa-grid2" style="grid-template-columns:minmax(0,2fr) minmax(0,1fr)">
			<div class="ssa-card">
				<?php UI::form( 'product_save' ); ?>
					<input type="hidden" name="product_id" value="<?php echo $p ? (int) $p->id : 0; ?>">
					<input type="hidden" name="tab" value="details">
					<label class="ssa-block">Name <input type="text" name="name" value="<?php echo esc_attr( $v( 'name' ) ); ?>" required></label>
					<div class="ssa-row">
						<label>Category (metal) <?php echo UI::select( 'metal', array( '' => 'Choose' ) + array_combine( $metals, $metals ), $v( 'metal' ) ); // phpcs:ignore ?></label>
						<label>Sub-category <input type="text" name="category" value="<?php echo esc_attr( $v( 'category' ) ); ?>" placeholder="Coins, Bars, Rounds..."></label>
						<label>Brand / mint <input type="text" name="brand" value="<?php echo esc_attr( $v( 'brand' ) ); ?>" list="ssa-brands"></label>
						<label>Mintage <input type="text" name="mintage" value="<?php echo esc_attr( $v( 'mintage' ) ); ?>" placeholder="e.g. 3,000"></label>
					</div>
					<datalist id="ssa-brands"><?php foreach ( Catalog::distinct( 'brand' ) as $b ) : ?><option value="<?php echo esc_attr( $b ); ?>"><?php endforeach; ?></datalist>
					<label class="ssa-block">Description / specifications</label>
					<?php wp_editor( (string) $v( 'description' ), 'ssp_description', array( 'textarea_name' => 'description', 'textarea_rows' => 10, 'media_buttons' => false, 'teeny' => true ) ); ?>

					<h3>Pre-sale schedule</h3>
					<div class="ssa-row">
						<label>Pre-order closing date &amp; time (<?php echo esc_html( Settings::get( 'business_timezone' ) ); ?>)
							<input type="datetime-local" name="closing_at" value="<?php echo esc_attr( $p ? Util::utc_to_local_input( $p->closing_at ) : '' ); ?>" data-default-time="<?php echo esc_attr( Settings::get( 'default_closing_time' ) ); ?>">
						</label>
						<label>Date posted <input type="date" name="date_posted" value="<?php echo esc_attr( $v( 'date_posted', current_time( 'Y-m-d' ) ) ); ?>"></label>
					</div>
					<?php if ( $p && 'presale_ended' === $life ) : ?><label><input type="checkbox" name="reopen_if_extended" value="1"> Re-open the presale if the new closing date is in the future</label><?php endif; ?>

					<h3>Estimated time of arrival (ETA)</h3>
					<p class="ssa-muted">Shown to customers everywhere this product appears. Changing it never alters the customer's original order; all views show the current ETA.</p>
					<div class="ssa-row" data-eta>
						<label>ETA format <?php echo UI::select( 'eta_type', Catalog::ETA_TYPES, $eta_t, 'data-eta-type' ); // phpcs:ignore ?></label>
						<label data-eta-show="month">Month <input type="month" name="eta_start_month" value="<?php echo esc_attr( $p && $p->eta_start ? substr( $p->eta_start, 0, 7 ) : '' ); ?>"></label>
						<label data-eta-show="date">Date <input type="date" name="eta_start_date" value="<?php echo esc_attr( (string) $v( 'eta_start' ) ); ?>"></label>
						<label data-eta-show="range">From <input type="date" name="eta_start_range" value="<?php echo esc_attr( (string) $v( 'eta_start' ) ); ?>"></label>
						<label data-eta-show="range">To <input type="date" name="eta_end" value="<?php echo esc_attr( (string) $v( 'eta_end' ) ); ?>"></label>
						<label data-eta-show="text">Text <input type="text" name="eta_text" value="<?php echo esc_attr( $v( 'eta_text' ) ); ?>" placeholder="e.g. Late October"></label>
					</div>
					<?php if ( $p ) : ?><p>Currently shown: <strong><?php echo esc_html( Catalog::eta_label( $p ) ? 'Estimated Arrival: ' . Catalog::eta_label( $p ) : 'No ETA' ); ?></strong></p><?php endif; ?>

					<h3>Pricing type</h3>
					<div class="ssa-row">
						<label>Price type <?php echo UI::select( 'price_type', array( 'fixed' => 'Fixed USD price', 'spot_based' => 'Spot-based offer' ), $v( 'price_type', 'fixed' ) ); // phpcs:ignore ?></label>
						<label>Spot premium (USD, spot-based only) <input type="text" name="spot_premium_usd" value="<?php echo esc_attr( (string) $v( 'spot_premium_usd' ) ); ?>" placeholder="e.g. 34.00"></label>
					</div>
					<p class="ssa-muted">Spot-based offers show "Spot + $X" to customers. The final unit price is entered by staff in the invoice wizard (decision D-12).</p>

					<h3>Supplier</h3>
					<div class="ssa-row">
						<label>Supplier <?php echo UI::select( 'supplier_id', array( '' => 'None' ) + wp_list_pluck( Catalog::suppliers(), 'name', 'id' ), $v( 'supplier_id' ) ); // phpcs:ignore ?></label>
						<label>Or add new supplier <input type="text" name="new_supplier" placeholder="Supplier name"></label>
					</div>

					<?php if ( ! $p ) : ?>
						<h3>First variant (SKU, price, allocation)</h3>
						<div class="ssa-row">
							<label>SKU / product code <input type="text" name="sku" required></label>
							<label>Barcode <input type="text" name="barcode"></label>
							<label>USD price <input type="text" name="price_usd" required placeholder="0.00"></label>
							<label>Minimum qty <input type="number" name="min_order_qty" value="1" min="1"></label>
							<label>Total allocation <input type="number" name="total_allocation" min="0" placeholder="blank = unlimited"></label>
							<label>Per-customer allocation <input type="number" name="per_customer_allocation" min="0" placeholder="blank = unlimited"></label>
							<label>Qty ordered from supplier <input type="number" name="supplier_qty_ordered" min="0"></label>
						</div>
					<?php endif; ?>
					<p><button class="ssa-btn" type="submit"><?php echo $p ? 'Save details' : 'Create product (draft)'; ?></button></p>
				<?php UI::end(); ?>
			</div>
			<div>
				<?php if ( $p ) : ?>
				<div class="ssa-card">
					<h2>Lifecycle</h2>
					<p>Current: <?php echo ssp_badge( Catalog::lifecycle_label( $p ), ssp_status_kind( $life ) ); // phpcs:ignore ?></p>
					<?php if ( 'presale' === $p->lifecycle && $p->closing_at ) : ?><p><?php echo ssp_countdown( $p->closing_at ); // phpcs:ignore ?></p><?php endif; ?>
					<?php foreach ( Catalog::TRANSITIONS[ $life ] ?? array() as $to ) : ?>
						<?php UI::form( 'product_lifecycle', 'class="ssa-stack"' ); ?>
							<input type="hidden" name="product_id" value="<?php echo (int) $p->id; ?>">
							<input type="hidden" name="lifecycle" value="<?php echo esc_attr( $to ); ?>">
							<button class="ssa-btn <?php echo in_array( $to, array( 'presale', 'in_stock' ), true ) ? '' : 'ssa-btn--ghost'; ?>" type="submit"><?php echo esc_html( array( 'presale' => 'Publish as Presale', 'in_stock' => 'Publish as In Stock', 'presale_ended' => 'End presale now', 'archived' => 'Move to Archive', 'draft' => 'Unpublish (draft)' )[ $to ] ?? $to ); ?></button>
						<?php UI::end(); ?>
					<?php endforeach; ?>
					<p class="ssa-muted ssa-small">Presales end automatically when the countdown reaches zero; customer lines lock at that moment. Archived listings stay visible to approved customers as reference and keep their permanent links.</p>
					<?php if ( 'draft' === $p->lifecycle ) : ?>
						<?php UI::button( 'product_delete', array( 'product_id' => $p->id ), 'Delete draft', 'ssa-btn ssa-btn--danger', 'Delete this draft product permanently?' ); ?>
					<?php endif; ?>
				</div>
				<div class="ssa-card">
					<h2>Allocation summary</h2>
					<?php foreach ( Catalog::variants( $p->id ) as $vv ) : ?>
						<?php $s = Allocation::summary( $vv ); ?>
						<p><strong><?php echo esc_html( $vv->sku ); ?></strong><br>Reserved <?php echo (int) $s['reserved']; ?> &middot; Held <?php echo (int) $s['held']; ?> &middot; Remaining <?php echo null === $s['remaining'] ? 'unlimited' : (int) $s['remaining']; ?> of <?php echo null === $s['total'] ? 'unlimited' : (int) $s['total']; ?></p>
					<?php endforeach; ?>
					<a class="ssa-btn ssa-btn--ghost" href="<?php echo esc_url( UI::url( 'ssp-products', array( 'edit' => $p->id, 'tab' => 'variants' ) ) ); ?>">Edit variants &amp; allocation</a>
				</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	private static function variants_tab( $p ) {
		$variants = Catalog::variants( $p->id );
		?>
		<div class="ssa-card">
			<h2>Variants</h2>
			<p class="ssa-muted">Each variant is a sellable unit (size, color, finish) with its own SKU, barcode, USD price (same for every approved customer), minimum quantity and allocations. Leave allocation blank for unlimited.</p>
			<table class="ssa-table">
				<thead><tr><th>Label</th><th>SKU</th><th>Barcode</th><th>USD price</th><th>MSRP</th><th>Min qty</th><th>Total alloc.</th><th>Per customer</th><th>Supplier qty</th><th>Weight (oz)</th><th>Active</th><th>Reserved</th><th></th></tr></thead>
				<tbody>
				<?php foreach ( array_merge( $variants, array( null ) ) as $vv ) : ?>
					<?php $fid = 'vf' . ( $vv ? $vv->id : 'new' ); ?>
					<tr>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="text" name="v[label]" value="<?php echo esc_attr( $vv->label ?? '' ); ?>" placeholder="<?php echo $vv ? '' : 'New variant'; ?>" size="12"></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="text" name="v[sku]" value="<?php echo esc_attr( $vv->sku ?? '' ); ?>" size="14" <?php echo $vv ? 'required' : ''; ?>></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="text" name="v[barcode]" value="<?php echo esc_attr( $vv->barcode ?? '' ); ?>" size="12"></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="text" name="v[price_usd]" value="<?php echo esc_attr( $vv->price_usd ?? '' ); ?>" size="7"></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="text" name="v[msrp_usd]" value="<?php echo esc_attr( (string) ( $vv->msrp_usd ?? '' ) ); ?>" size="6"></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="number" name="v[min_order_qty]" value="<?php echo esc_attr( $vv->min_order_qty ?? 1 ); ?>" min="1" style="width:60px"></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="number" name="v[total_allocation]" value="<?php echo esc_attr( (string) ( $vv->total_allocation ?? '' ) ); ?>" min="0" style="width:75px"></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="number" name="v[per_customer_allocation]" value="<?php echo esc_attr( (string) ( $vv->per_customer_allocation ?? '' ) ); ?>" min="0" style="width:70px"></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="number" name="v[supplier_qty_ordered]" value="<?php echo esc_attr( (string) ( $vv->supplier_qty_ordered ?? '' ) ); ?>" min="0" style="width:70px"></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="text" name="v[weight_oz]" value="<?php echo esc_attr( (string) ( $vv->weight_oz ?? '' ) ); ?>" size="5"></td>
						<td><input form="<?php echo esc_attr( $fid ); ?>" type="checkbox" name="v[active]" value="1" <?php checked( $vv ? (int) $vv->active : 1, 1 ); ?>></td>
						<td class="num"><?php echo $vv ? (int) $vv->reserved_qty : ''; ?></td>
						<td class="ssa-nowrap">
							<?php UI::form( 'variant_save', 'id="' . esc_attr( $fid ) . '" class="ssa-inline"' ); ?>
								<input type="hidden" name="product_id" value="<?php echo (int) $p->id; ?>">
								<input type="hidden" name="variant_id" value="<?php echo $vv ? (int) $vv->id : 0; ?>">
								<button class="ssa-btn ssa-btn--sm" type="submit"><?php echo $vv ? 'Save' : 'Add'; ?></button>
							<?php UI::end(); ?>
							<?php if ( $vv ) : ?><?php UI::button( 'variant_delete', array( 'variant_id' => $vv->id ), 'Remove', 'ssa-btn ssa-btn--sm ssa-btn--danger', 'Remove this variant? Variants with orders are deactivated, not deleted.' ); ?><?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="ssa-muted ssa-small">Price changes apply to new orders only. Existing order lines keep the price at the time of order. Every change is recorded in the audit log.</p>
		</div>
		<?php
	}

	private static function images_tab( $p ) {
		$imgs = Catalog::images( $p->id );
		?>
		<div class="ssa-card">
			<h2>Images</h2>
			<p class="ssa-muted">Images are stored privately and only shown to logged-in approved customers and staff. Drag to reorder. For best results upload images at least 600px wide (JPEG, PNG, GIF or WEBP).</p>
			<div class="ssa-images" data-sortable data-product="<?php echo (int) $p->id; ?>">
				<?php foreach ( $imgs as $img ) : ?>
					<figure class="ssa-image" draggable="true" data-id="<?php echo (int) $img->id; ?>">
						<img src="<?php echo esc_url( Catalog::image_url( $img, 'thumb' ) ); ?>" alt="">
						<figcaption>
							<?php if ( $img->is_primary ) : ?><?php echo ssp_badge( 'Primary', 'brand' ); // phpcs:ignore ?><?php else : ?><?php UI::button( 'image_primary', array( 'product_id' => $p->id, 'image_id' => $img->id ), 'Make primary', 'ssa-btn ssa-btn--sm ssa-btn--ghost' ); ?><?php endif; ?>
							<?php UI::button( 'image_delete', array( 'image_id' => $img->id ), 'Delete', 'ssa-btn ssa-btn--sm ssa-btn--danger', 'Delete this image?' ); ?>
						</figcaption>
					</figure>
				<?php endforeach; ?>
			</div>
			<?php if ( count( $imgs ) > 1 ) : ?>
				<?php UI::form( 'image_order', 'data-order-form' ); ?>
					<input type="hidden" name="product_id" value="<?php echo (int) $p->id; ?>">
					<input type="hidden" name="order" value="<?php echo esc_attr( implode( ',', wp_list_pluck( $imgs, 'id' ) ) ); ?>">
					<button class="ssa-btn ssa-btn--ghost" type="submit">Save image order</button>
				<?php UI::end(); ?>
			<?php endif; ?>
			<h3>Add product images</h3>
			<?php UI::form( 'image_upload', '', true ); ?>
				<input type="hidden" name="product_id" value="<?php echo (int) $p->id; ?>">
				<input type="file" name="images[]" accept="image/jpeg,image/png,image/gif,image/webp" multiple required>
				<button class="ssa-btn" type="submit">Upload</button>
			<?php UI::end(); ?>
		</div>
		<?php
	}

	private static function orders_tab( $p ) {
		$res = Orders::staff_lines( array( 'product_id' => $p->id, 'per_page' => 500, 'order' => 'o.submitted_at ASC' ) );
		?>
		<div class="ssa-card">
			<h2>Order lines for this product (<?php echo (int) $res['total']; ?>)</h2>
			<table class="ssa-table"><thead><tr><th>Order #</th><th>Date</th><th>Customer</th><th>SKU</th><th class="num">Qty</th><th class="num">Available</th><th class="num">Invoiced</th><th>Status</th><th>Fulfillment</th></tr></thead><tbody>
			<?php foreach ( $res['rows'] as $l ) : ?>
				<tr><td><a href="<?php echo esc_url( UI::url( 'ssp-orders', array( 'order' => $l->order_number ) ) ); ?>">#<?php echo (int) $l->order_number; ?></a></td><td><?php echo esc_html( Util::fmt_date( $l->submitted_at ) ); ?></td><td><?php echo esc_html( $l->company_name ); ?></td><td><?php echo esc_html( $l->sku_snapshot ); ?></td><td class="num"><?php echo (int) Orders::net( $l ); ?></td><td class="num"><?php echo (int) $l->qty_available; ?></td><td class="num"><?php echo (int) $l->qty_invoiced; ?></td><td><?php echo ssp_badge( Orders::LINE_STATUSES[ $l->display_status ] ?? '', ssp_status_kind( $l->display_status ) ); // phpcs:ignore ?></td><td><?php echo esc_html( Orders::FULFILLMENT_BADGE[ $l->fulfillment_choice ] ?? '' ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
		</div>
		<?php
	}
}
