<?php
namespace SSP\Admin;

use SSP\Core\Installer;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/** Staff-only downloads and sales materials (never visible to customers). */
class ResourcesScreen {

	public static function render() {
		global $wpdb;
		$t    = Installer::tables()['resources'];
		$rows = $wpdb->get_results( "SELECT * FROM {$t} ORDER BY id DESC" );
		UI::open( 'Staff Resources', 'Sales materials and downloads for staff only. Files are stored privately and served only to staff.' );
		if ( current_user_can( 'ssp_manage_staff_resources' ) ) {
			echo '<div class="ssa-card"><h2>Upload</h2>';
			UI::form( 'resource_upload', 'class="ssa-row"', true );
			echo '<label>Title <input type="text" name="title"></label><label>Description <input type="text" name="description"></label><input type="file" name="file" required><button class="ssa-btn" type="submit">Upload</button>';
			UI::end();
			echo '</div>';
		}
		?>
		<table class="ssa-table"><thead><tr><th>Title</th><th>File</th><th>Size</th><th>Uploaded</th><th></th></tr></thead><tbody>
		<?php foreach ( $rows as $r ) : ?>
			<tr><td><strong><?php echo esc_html( $r->title ); ?></strong><br><span class="ssa-muted ssa-small"><?php echo esc_html( (string) $r->description ); ?></span></td><td><a href="<?php echo esc_url( home_url( '/portal/resource/' . strtolower( $r->resource_uid ) . '/' ) ); ?>"><?php echo esc_html( $r->file_name ); ?></a></td><td><?php echo esc_html( size_format( (int) $r->size_bytes ) ); ?></td><td><?php echo esc_html( Util::fmt_dt( $r->created_at ) ); ?></td>
			<td><?php if ( current_user_can( 'ssp_manage_staff_resources' ) ) { UI::button( 'resource_delete', array( 'resource_id' => $r->id ), 'Delete', 'ssa-btn ssa-btn--sm ssa-btn--danger', 'Delete this file?' ); } ?></td></tr>
		<?php endforeach; ?>
		<?php if ( ! $rows ) : ?><tr><td colspan="5" class="ssa-muted">No resources yet.</td></tr><?php endif; ?>
		</tbody></table>
		<?php
		UI::close();
	}
}
