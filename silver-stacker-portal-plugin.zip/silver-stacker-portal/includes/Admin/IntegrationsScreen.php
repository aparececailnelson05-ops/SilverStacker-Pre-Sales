<?php
namespace SSP\Admin;

use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Integrations\Qbo;
use SSP\Integrations\Sheets;

defined( 'ABSPATH' ) || exit;

class IntegrationsScreen {

	public static function render() {
		$tab = UI::get( 'tab', 'status' );
		UI::open( 'Integrations', 'QuickBooks Online (financial authority), Google Sheets (one-way reporting copy) and warehouse/inventory. Failed events never block customers; they are listed here with a safe retry.' );
		UI::tabs( 'ssp-integrations', array( 'status' => 'Status &amp; job queue', 'qbo' => 'QuickBooks Online', 'sheets' => 'Google Sheets', 'warehouse' => 'Warehouse' ), $tab );
		$admin = current_user_can( 'ssp_manage_integrations' );
		if ( 'qbo' === $tab && $admin ) {
			self::qbo();
		} elseif ( 'sheets' === $tab && $admin ) {
			self::sheets();
		} elseif ( 'warehouse' === $tab && $admin ) {
			self::warehouse();
		} elseif ( 'status' !== $tab ) {
			echo '<div class="ssa-card">Only administrators can change integration settings.</div>';
		} else {
			self::status();
		}
		UI::close();
	}

	private static function status() {
		global $wpdb;
		$t      = Installer::tables()['jobs'];
		$counts = Jobs::counts();
		$filter = UI::get( 'jstatus', 'problems' );
		$where  = 'problems' === $filter ? "status IN ('failed','dead')" : ( 'all' === $filter ? '1=1' : $wpdb->prepare( 'status=%s', $filter ) );
		$int    = UI::get( 'integration' );
		if ( $int ) {
			$where .= $wpdb->prepare( ' AND integration=%s', $int );
		}
		$jobs = $wpdb->get_results( "SELECT * FROM {$t} WHERE {$where} ORDER BY updated_at DESC LIMIT 200" );
		?>
		<div class="ssa-kpis">
			<div class="ssa-kpi"><b><?php echo Qbo::is_connected() ? 'Connected' : 'Not connected'; ?></b><span>QuickBooks Online (<?php echo esc_html( Settings::get( 'qbo_environment' ) ); ?>)</span></div>
			<div class="ssa-kpi"><b><?php echo Sheets::enabled() ? 'Enabled' : 'Off'; ?></b><span>Google Sheets reporting copy</span></div>
			<div class="ssa-kpi"><b><?php echo esc_html( ucfirst( Settings::get( 'warehouse_adapter' ) ) ); ?></b><span>Warehouse adapter</span></div>
			<?php foreach ( array( 'qbo', 'sheets', 'warehouse', 'email' ) as $i ) : ?>
				<?php $c = $counts[ $i ] ?? array(); ?>
				<div class="ssa-kpi<?php echo ( ( $c['failed'] ?? 0 ) + ( $c['dead'] ?? 0 ) ) ? ' is-danger' : ''; ?>"><b><?php echo (int) ( ( $c['failed'] ?? 0 ) + ( $c['dead'] ?? 0 ) ); ?></b><span><?php echo esc_html( strtoupper( $i ) ); ?> failed &middot; <?php echo (int) ( $c['queued'] ?? 0 ); ?> queued &middot; <?php echo (int) ( $c['succeeded'] ?? 0 ); ?> done</span></div>
			<?php endforeach; ?>
		</div>
		<form class="ssa-filters" method="get"><input type="hidden" name="page" value="ssp-integrations">
			<?php echo UI::select( 'jstatus', array( 'problems' => 'Failed / dead', 'queued' => 'Queued', 'running' => 'Running', 'succeeded' => 'Succeeded', 'all' => 'All' ), $filter ); // phpcs:ignore ?>
			<?php echo UI::select( 'integration', array( '' => 'All integrations', 'qbo' => 'QuickBooks', 'sheets' => 'Google Sheets', 'warehouse' => 'Warehouse', 'email' => 'Email' ), $int ); // phpcs:ignore ?>
			<button class="ssa-btn ssa-btn--ghost">Filter</button>
		</form>
		<p><?php UI::button( 'jobs_run', array(), 'Run due jobs now', 'ssa-btn ssa-btn--ghost' ); ?></p>
		<table class="ssa-table"><thead><tr><th>ID</th><th>Integration</th><th>Action</th><th>Object</th><th>Status</th><th class="num">Attempts</th><th>Next attempt</th><th>Error</th><th></th></tr></thead><tbody>
		<?php foreach ( $jobs as $j ) : ?>
			<tr>
				<td><?php echo (int) $j->id; ?></td><td><?php echo esc_html( $j->integration ); ?></td><td><code><?php echo esc_html( $j->action ); ?></code></td>
				<td><?php echo esc_html( $j->object_type . ' ' . $j->object_id ); ?><?php echo 'invoice' === $j->object_type ? ' <a href="' . esc_url( UI::url( 'ssp-invoices', array( 'invoice' => $j->object_id ) ) ) . '">open</a>' : ''; // phpcs:ignore ?></td>
				<td><?php echo ssp_badge( $j->status, in_array( $j->status, array( 'failed', 'dead' ), true ) ? 'danger' : ( 'succeeded' === $j->status ? 'ok' : 'neutral' ) ); // phpcs:ignore ?></td>
				<td class="num"><?php echo (int) $j->attempts; ?></td>
				<td><?php echo esc_html( Util::fmt_dt( $j->next_attempt_at ) ); ?></td>
				<td class="ssa-small ssa-err"><?php echo esc_html( (string) $j->last_error ); ?></td>
				<td><?php if ( in_array( $j->status, array( 'failed', 'dead' ), true ) ) : ?><?php UI::button( 'job_retry', array( 'job_id' => $j->id ), 'Retry', 'ssa-btn ssa-btn--sm' ); ?><?php endif; ?></td>
			</tr>
		<?php endforeach; ?>
		<?php if ( ! $jobs ) : ?><tr><td colspan="9" class="ssa-muted">Nothing to show.</td></tr><?php endif; ?>
		</tbody></table>
		<p class="ssa-muted ssa-small">Background jobs run every minute via cron. For reliable timing on production, disable WP-Cron and call <code>wp cron event run --due-now</code> from a real server cron every minute (see docs/DEPLOYMENT.md).</p>
		<?php
	}

	private static function qbo() {
		$tokens = Qbo::tokens();
		?>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Connection</h2>
				<?php if ( Qbo::is_connected() ) : ?>
					<p><?php echo ssp_badge( 'Connected', 'ok' ); // phpcs:ignore ?> Company (realm) ID <code><?php echo esc_html( $tokens['realm_id'] ); ?></code>, <?php echo esc_html( Settings::get( 'qbo_environment' ) ); ?>. Refresh token valid until <?php echo esc_html( gmdate( 'Y-m-d', (int) ( $tokens['refresh_expires_at'] ?? 0 ) ) ); ?>.</p>
					<?php UI::button( 'qbo_disconnect', array(), 'Disconnect QuickBooks', 'ssa-btn ssa-btn--danger', 'Disconnect QuickBooks? Invoicing will pause until reconnected.' ); ?>
				<?php else : ?>
					<p><?php echo ssp_badge( 'Not connected', 'danger' ); // phpcs:ignore ?></p>
					<?php UI::button( 'qbo_connect', array(), 'Connect to QuickBooks', 'ssa-btn' ); ?>
				<?php endif; ?>
				<h3>Intuit app setup</h3>
				<ol class="ssa-small">
					<li>Create an app at developer.intuit.com with the Accounting scope.</li>
					<li>Add this Redirect URI: <code><?php echo esc_html( Qbo::redirect_uri() ); ?></code></li>
					<li>Add this Webhook endpoint (Invoice and Payment entities): <code><?php echo esc_html( rest_url( 'ssp/v1/hooks/qbo' ) ); ?></code></li>
					<li>Paste the Client ID, Client Secret and Webhook Verifier Token here, then Connect.</li>
				</ol>
			</div>
			<div class="ssa-card">
				<h2>Settings</h2>
				<?php UI::form( 'qbo_settings' ); ?>
					<label class="ssa-block">Environment <?php echo UI::select( 'qbo_environment', array( 'sandbox' => 'Sandbox (testing)', 'production' => 'Production' ), Settings::get( 'qbo_environment' ) ); // phpcs:ignore ?></label>
					<label class="ssa-block">Client ID <input type="text" name="qbo_client_id" value="<?php echo esc_attr( Settings::get( 'qbo_client_id' ) ); ?>"></label>
					<label class="ssa-block">Client Secret <input type="password" name="qbo_client_secret" placeholder="<?php echo Settings::get( 'qbo_client_secret' ) ? 'Saved (leave blank to keep)' : ''; ?>" autocomplete="off"></label>
					<label class="ssa-block">Webhook Verifier Token <input type="password" name="qbo_webhook_verifier" placeholder="<?php echo Settings::get( 'qbo_webhook_verifier' ) ? 'Saved (leave blank to keep)' : ''; ?>" autocomplete="off"></label>
					<label class="ssa-block">Item mapping (D-30) <?php echo UI::select( 'qbo_item_strategy', array( 'per_sku' => 'One QuickBooks item per SKU (auto-created)', 'generic' => 'One generic QuickBooks item for all products' ), Settings::get( 'qbo_item_strategy' ) ); // phpcs:ignore ?></label>
					<label class="ssa-block">Income account ID (for auto-created items) <input type="text" name="qbo_income_account_id" value="<?php echo esc_attr( Settings::get( 'qbo_income_account_id' ) ); ?>"></label>
					<label class="ssa-block">Generic item ID (if generic) <input type="text" name="qbo_generic_item_id" value="<?php echo esc_attr( Settings::get( 'qbo_generic_item_id' ) ); ?>"></label>
					<label class="ssa-block">Shipping item ID <input type="text" name="qbo_shipping_item_id" value="<?php echo esc_attr( Settings::get( 'qbo_shipping_item_id' ) ); ?>"></label>
					<label class="ssa-block">Sales term ID (e.g. due in 3 days, D-28) <input type="text" name="qbo_term_id" value="<?php echo esc_attr( Settings::get( 'qbo_term_id' ) ); ?>"></label>
					<label><input type="checkbox" name="qbo_send_invoice_email" value="1" <?php checked( Settings::get( 'qbo_send_invoice_email' ) ); ?>> Ask QuickBooks to email each new invoice to the customer</label>
					<p><button class="ssa-btn" type="submit">Save</button></p>
				<?php UI::end(); ?>
				<p class="ssa-muted ssa-small">Secrets are encrypted at rest. Tax is calculated by QuickBooks (enable Automated Sales Tax in QuickBooks). Online payments must be enabled in QuickBooks for pay links.</p>
			</div>
		</div>
		<?php
	}

	private static function sheets() {
		$sa = json_decode( (string) Settings::get( 'sheets_service_account' ), true );
		?>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Google Sheets reporting copy</h2>
				<?php UI::form( 'sheets_settings' ); ?>
					<label><input type="checkbox" name="sheets_enabled" value="1" <?php checked( Settings::get( 'sheets_enabled' ) ); ?>> Enabled</label>
					<label class="ssa-block">Spreadsheet ID (from the sheet URL) <input type="text" name="sheets_spreadsheet_id" value="<?php echo esc_attr( Settings::get( 'sheets_spreadsheet_id' ) ); ?>"></label>
					<label class="ssa-block">Service account JSON key <textarea name="sheets_service_account" rows="5" placeholder="<?php echo $sa ? 'Saved for ' . esc_attr( $sa['client_email'] ?? '' ) . ' (paste a new key to replace)' : 'Paste the JSON key file contents'; ?>"></textarea></label>
					<p><button class="ssa-btn" type="submit">Save</button></p>
				<?php UI::end(); ?>
				<?php if ( Sheets::enabled() ) : ?><?php UI::button( 'sheets_rebuild', array(), 'Rebuild entire sheet from portal data', 'ssa-btn ssa-btn--ghost', 'Rewrite every tab from the database?' ); ?><?php endif; ?>
			</div>
			<div class="ssa-card">
				<h2>How it works</h2>
				<ul class="ssa-small">
					<li>One-way only: WordPress writes; editing the Sheet never changes portal records.</li>
					<li>Tabs: <?php echo esc_html( implode( ', ', array_keys( Sheets::TABS ) ) ); ?>.</li>
					<li>Column A holds the stable portal ID; rows are updated in place, never duplicated.</li>
					<li>Updates are queued on: order submitted, quantity or box changes, status changes, availability or invoicing changes.</li>
					<li>Share the spreadsheet with the service account email<?php echo $sa ? ' (<code>' . esc_html( $sa['client_email'] ?? '' ) . '</code>)' : ''; ?> as Editor.</li>
				</ul>
			</div>
		</div>
		<?php
	}

	private static function warehouse() {
		?>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Warehouse / inventory</h2>
				<p class="ssa-muted">The warehouse platform and which system controls on-hand/reserved/available/held/shipped quantities are still to be confirmed (decision D-11). Until then use <strong>Manual</strong>: staff record availability and shipments in the portal.</p>
				<?php UI::form( 'warehouse_settings' ); ?>
					<label class="ssa-block">Adapter <?php echo UI::select( 'warehouse_adapter', array( 'manual' => 'Manual (portal is the record)', 'webhook' => 'Signed webhook to warehouse / middleware' ), Settings::get( 'warehouse_adapter' ) ); // phpcs:ignore ?></label>
					<label class="ssa-block">Outbound webhook URL <input type="url" name="warehouse_url" value="<?php echo esc_attr( Settings::get( 'warehouse_url' ) ); ?>"></label>
					<label class="ssa-block">Shared secret (HMAC-SHA256) <input type="password" name="warehouse_webhook_secret" placeholder="<?php echo Settings::get( 'warehouse_webhook_secret' ) ? 'Saved (leave blank to keep)' : ''; ?>" autocomplete="off"></label>
					<p><button class="ssa-btn" type="submit">Save</button></p>
				<?php UI::end(); ?>
			</div>
			<div class="ssa-card">
				<h2>Inbound endpoint</h2>
				<p><code><?php echo esc_html( rest_url( 'ssp/v1/hooks/warehouse' ) ); ?></code></p>
				<p class="ssa-small">Signed with header <code>X-SSP-Signature</code> (hex HMAC-SHA256 of the raw body). Every event needs a unique <code>event_id</code>; repeats are ignored, so availability and shipments are never double counted.</p>
				<pre class="ssa-code">{"event_id":"wh-123","type":"line.availability","line_id":"&lt;line ID&gt;","qty_available":5}
{"event_id":"wh-124","type":"shipment.shipped","line_ids":{"&lt;line ID&gt;":2},"carrier":"UPS","tracking":"1Z..."}</pre>
			</div>
		</div>
		<?php
	}
}
