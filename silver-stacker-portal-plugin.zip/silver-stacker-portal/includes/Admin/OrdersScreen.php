<?php
namespace SSP\Admin;

use SSP\Core\Util;
use SSP\Domain\Boxes;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Shipments;

defined( 'ABSPATH' ) || exit;

class OrdersScreen {

	public static function render() {
		if ( UI::get( 'order' ) ) {
			self::detail( (int) UI::get( 'order' ) );
			return;
		}
		$view = UI::get( 'view', 'orders' );
		UI::open( 'Orders / Pre-Orders', 'All customer pre-orders submitted through the portal. Off-platform requests (phone, email, text) are not orders; direct customers to the website.', '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::export_url( 'orders' ) ) . '">Export CSV</a>' );
		UI::tabs( 'ssp-orders', array( 'orders' => 'Orders', 'lines' => 'Order lines (availability)' ), 'lines' === $view ? 'lines' : 'orders', array(), 'view' );
		if ( 'lines' === $view ) {
			self::lines();
		} else {
			self::orders();
		}
		UI::close();
	}

	private static function orders() {
		$args = array(
			'q'      => UI::get( 'q' ),
			'status' => UI::get( 'status' ),
			'from'   => UI::get( 'from' ),
			'to'     => UI::get( 'to' ),
			'paged'  => (int) UI::get( 'paged', 1 ),
		);
		$res = Orders::staff_orders( $args );
		?>
		<form class="ssa-filters" method="get">
			<input type="hidden" name="page" value="ssp-orders">
			<input type="search" name="q" value="<?php echo esc_attr( $args['q'] ); ?>" placeholder="Order #, customer, item or SKU">
			<?php echo UI::select( 'status', array( '' => 'All statuses', 'not_cancelled' => 'All except cancelled' ) + Orders::ORDER_STATUSES, $args['status'] ); // phpcs:ignore ?>
			<label>From <input type="date" name="from" value="<?php echo esc_attr( $args['from'] ); ?>"></label>
			<label>To <input type="date" name="to" value="<?php echo esc_attr( $args['to'] ); ?>"></label>
			<button class="ssa-btn ssa-btn--ghost" type="submit">Search</button>
		</form>
		<table class="ssa-table ssa-table--hover">
			<thead><tr><th>#</th><th>Customer</th><th>Order date</th><th class="num">Total</th><th>Invoices</th><th>Status</th></tr></thead>
			<tbody>
			<?php foreach ( $res['rows'] as $o ) : ?>
				<?php $invs = array(); foreach ( Orders::lines( $o->id ) as $l ) { foreach ( Invoices::for_line( $l->id ) as $i ) { $invs[ $i->doc_number ? $i->doc_number : 'pending' ] = 1; } } ?>
				<tr>
					<td><a href="<?php echo esc_url( UI::url( 'ssp-orders', array( 'order' => $o->order_number ) ) ); ?>"><strong><?php echo (int) $o->order_number; ?></strong></a></td>
					<td><?php echo UI::customer_link( $o->user_id, $o->company_name . ' (' . $o->contact_name . ')' ); // phpcs:ignore ?></td>
					<td><?php echo esc_html( Util::fmt_dt( $o->submitted_at ) ); ?></td>
					<td class="num"><?php echo esc_html( Util::money( $o->subtotal_usd ) ); ?></td>
					<td><?php echo esc_html( implode( ', ', array_keys( $invs ) ) ); ?></td>
					<td><?php echo ssp_badge( Orders::ORDER_STATUSES[ $o->status ] ?? $o->status, ssp_status_kind( $o->status ) ); // phpcs:ignore ?></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( ! $res['rows'] ) : ?><tr><td colspan="6" class="ssa-muted">No orders found.</td></tr><?php endif; ?>
			</tbody>
		</table>
		<?php
		UI::pager( $res['total'], 50, $args['paged'], 'ssp-orders', array_filter( $args ) );
	}

	private static function lines() {
		$args = array(
			'q'             => UI::get( 'q' ),
			'status'        => UI::get( 'status' ),
			'fulfillment'   => UI::get( 'fulfillment' ),
			'invoice_state' => UI::get( 'invoice_state' ),
			'paged'         => (int) UI::get( 'paged', 1 ),
			'per_page'      => 100,
		);
		$res = Orders::staff_lines( $args );
		?>
		<form class="ssa-filters" method="get">
			<input type="hidden" name="page" value="ssp-orders"><input type="hidden" name="view" value="lines">
			<input type="search" name="q" value="<?php echo esc_attr( $args['q'] ); ?>" placeholder="Item, SKU, customer, order #">
			<?php echo UI::select( 'status', array( '' => 'Any line status' ) + Orders::LINE_STATUSES, $args['status'] ); // phpcs:ignore ?>
			<?php echo UI::select( 'fulfillment', array( '' => 'Any fulfillment' ) + Orders::FULFILLMENT_BADGE, $args['fulfillment'] ); // phpcs:ignore ?>
			<?php echo UI::select( 'invoice_state', array( '' => 'Any invoice state', 'uninvoiced_available' => 'Available, not invoiced', 'invoiced' => 'Invoiced', 'not_invoiced' => 'Not invoiced' ), $args['invoice_state'] ); // phpcs:ignore ?>
			<button class="ssa-btn ssa-btn--ghost" type="submit">Filter</button>
		</form>
		<?php UI::form( 'availability_bulk' ); ?>
		<table class="ssa-table ssa-table--hover">
			<thead><tr><th>Order #</th><th>Customer</th><th>Item</th><th class="num">Qty</th><th class="num">Available</th><th class="num">Invoiced</th><th class="num">Shipped</th><th>ETA</th><th>Status</th><th>Fulfillment</th></tr></thead>
			<tbody>
			<?php foreach ( $res['rows'] as $l ) : ?>
				<?php $p = Catalog::get( $l->product_id ); ?>
				<tr>
					<td><a href="<?php echo esc_url( UI::url( 'ssp-orders', array( 'order' => $l->order_number ) ) ); ?>">#<?php echo (int) $l->order_number; ?></a></td>
					<td><?php echo esc_html( $l->company_name ); ?></td>
					<td><?php echo esc_html( $l->name_snapshot ); ?><br><span class="ssa-muted ssa-small"><?php echo esc_html( $l->sku_snapshot ); ?></span></td>
					<td class="num"><?php echo (int) Orders::net( $l ); ?></td>
					<td class="num"><input type="number" name="avail[<?php echo (int) $l->id; ?>]" value="<?php echo (int) $l->qty_available; ?>" min="0" max="<?php echo (int) Orders::net( $l ); ?>" style="width:64px" <?php disabled( 0 === Orders::net( $l ) ); ?>></td>
					<td class="num"><?php echo (int) $l->qty_invoiced; ?><?php echo $l->qty_pending_invoice ? ' (+' . (int) $l->qty_pending_invoice . ' pending)' : ''; ?></td>
					<td class="num"><?php echo (int) $l->qty_shipped; ?></td>
					<td><?php echo esc_html( $p ? Catalog::eta_label( $p ) : '' ); ?></td>
					<td><?php echo ssp_badge( Orders::LINE_STATUSES[ $l->display_status ] ?? '', ssp_status_kind( $l->display_status ) ); // phpcs:ignore ?></td>
					<td><?php echo esc_html( Orders::FULFILLMENT_BADGE[ $l->fulfillment_choice ] ?? '' ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p><button class="ssa-btn" type="submit">Save availability changes</button> <span class="ssa-muted">Only changed values are saved; each change is audited.</span></p>
		<?php
		UI::end();
		UI::pager( $res['total'], 100, $args['paged'], 'ssp-orders', array_filter( array_merge( $args, array( 'view' => 'lines' ) ) ) );
	}

	private static function detail( $number ) {
		$o = Orders::by_number( $number );
		if ( ! $o ) {
			UI::open( 'Order not found' );
			UI::close();
			return;
		}
		$c     = Customers::profile( $o->user_id );
		$lines = Orders::lines( $o->id );
		UI::open( 'Order #' . $o->order_number, UI::customer_link( $o->user_id, Customers::display_name( $c ) ) . ' &middot; ' . esc_html( Util::fmt_dt( $o->submitted_at ) ) . ' &middot; ' . ssp_badge( Orders::ORDER_STATUSES[ $o->status ] ?? $o->status, ssp_status_kind( $o->status ) ), '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::url( 'ssp-orders' ) ) . '">&larr; All orders</a> <a class="ssa-btn" href="' . esc_url( UI::url( 'ssp-invoices', array( 'new' => $o->user_id ) ) ) . '">Invoice available lines</a>' );
		if ( $o->customer_note ) {
			echo '<div class="ssa-card"><strong>Customer note:</strong> ' . esc_html( $o->customer_note ) . '</div>';
		}
		foreach ( $lines as $l ) {
			$p    = Catalog::get( $l->product_id );
			$box  = Boxes::line_box( $l->id );
			$boxr = $box ? Boxes::get( $box ) : null;
			$net  = Orders::net( $l );
			?>
			<div class="ssa-card">
				<div class="ssa-between">
					<div>
						<h2 class="ssa-mb0"><?php echo esc_html( $l->name_snapshot ); ?></h2>
						<span class="ssa-muted">SKU <?php echo esc_html( $l->sku_snapshot ); ?> &middot; <?php echo esc_html( Util::money( $l->unit_price_usd ) ); ?> each <?php echo 'spot_based' === $l->price_type ? '(spot-based estimate)' : ''; ?> &middot; ETA <?php echo esc_html( $p ? ( Catalog::eta_label( $p ) ? Catalog::eta_label( $p ) : 'TBD' ) : '' ); ?> (at order: <?php echo esc_html( $l->eta_at_order ? $l->eta_at_order : 'none' ); ?>)</span>
					</div>
					<div><?php echo ssp_badge( Orders::LINE_STATUSES[ $l->display_status ] ?? '', ssp_status_kind( $l->display_status ) ); // phpcs:ignore ?> <?php echo ssp_badge( Orders::FULFILLMENT_BADGE[ $l->fulfillment_choice ] ?? '', 'neutral' ); // phpcs:ignore ?></div>
				</div>
				<table class="ssa-kv ssa-mt">
					<tr><th>Ordered</th><td><?php echo (int) $net; ?><?php echo $l->qty_cancelled ? ' (' . (int) $l->qty_cancelled . ' cancelled)' : ''; ?></td><th>Available</th><td><?php echo (int) $l->qty_available; ?></td><th>Invoiced</th><td><?php echo (int) $l->qty_invoiced; ?><?php echo $l->qty_pending_invoice ? ' + ' . (int) $l->qty_pending_invoice . ' pending' : ''; ?></td><th>Shipped</th><td><?php echo (int) $l->qty_shipped; ?></td><th>Total</th><td><?php echo esc_html( Util::money( Orders::line_total( $l ) ) ); ?></td></tr>
					<tr><th>Box</th><td colspan="3"><?php echo $boxr ? '<a href="' . esc_url( UI::url( 'ssp-boxes', array( 'box' => $boxr->id ) ) ) . '">Box #' . (int) $boxr->box_number . '</a> (' . esc_html( Boxes::STATUSES[ $boxr->status ] ) . ')' : 'None'; // phpcs:ignore ?></td>
					<th>Invoices</th><td colspan="5"><?php foreach ( Invoices::for_line( $l->id ) as $i ) { echo '<a href="' . esc_url( UI::url( 'ssp-invoices', array( 'invoice' => $i->id ) ) ) . '">' . esc_html( $i->doc_number ? $i->doc_number : 'Invoice ' . $i->id ) . '</a> (' . (int) $i->inv_qty . ') ' . ssp_badge( Invoices::payment_label( $i ), ssp_status_kind( $i->sync_status ) ) . ' '; } // phpcs:ignore ?></td></tr>
					<tr><th>Shipments</th><td colspan="9"><?php foreach ( Shipments::for_line( $l->id ) as $s ) { echo esc_html( $s->carrier . ' ' . $s->tracking_number . ' (' . $s->ship_qty . ') ' . Shipments::STATUSES[ $s->status ] ) . '; '; } ?></td></tr>
				</table>
				<div class="ssa-grid3 ssa-mt">
					<?php UI::form( 'line_availability', 'class="ssa-mini"' ); ?>
						<input type="hidden" name="line_id" value="<?php echo (int) $l->id; ?>">
						<h4>Availability</h4>
						<label>Qty available <input type="number" name="qty_available" value="<?php echo (int) $l->qty_available; ?>" min="0" max="<?php echo (int) $net; ?>" style="width:80px"></label>
						<label class="ssa-block">Note <input type="text" name="note" placeholder="optional"></label>
						<button class="ssa-btn ssa-btn--sm" type="submit">Update availability</button>
					<?php UI::end(); ?>
					<?php UI::form( 'line_qty', 'class="ssa-mini"' ); ?>
						<input type="hidden" name="line_id" value="<?php echo (int) $l->id; ?>">
						<h4>Correct quantity</h4>
						<label>New quantity <input type="number" name="qty" value="<?php echo (int) $net; ?>" min="0" style="width:80px"></label>
						<label class="ssa-block">Reason (required) <input type="text" name="reason" required></label>
						<?php if ( current_user_can( 'ssp_override_allocation' ) ) : ?><label><input type="checkbox" name="allow_over" value="1"> Allow over allocation (logged override)</label><?php endif; ?>
						<button class="ssa-btn ssa-btn--sm ssa-btn--ghost" type="submit">Save correction</button>
						<p class="ssa-muted ssa-small">Set 0 to cancel the line. Allowed after closing; always audited.</p>
					<?php UI::end(); ?>
					<?php UI::form( 'line_fulfillment', 'class="ssa-mini"' ); ?>
						<input type="hidden" name="line_id" value="<?php echo (int) $l->id; ?>">
						<h4>Fulfillment</h4>
						<?php echo UI::select( 'fulfillment', Orders::FULFILLMENT, $l->fulfillment_choice ); // phpcs:ignore ?>
						<button class="ssa-btn ssa-btn--sm ssa-btn--ghost" type="submit">Set</button>
					<?php UI::end(); ?>
				</div>
				<?php $am = Orders::amendments( $l->id ); ?>
				<?php if ( $am ) : ?>
					<details class="ssa-mt"><summary>Quantity changes (<?php echo count( $am ); ?>)</summary><ul><?php foreach ( $am as $a ) : ?><li><?php echo esc_html( Util::fmt_dt( $a->created_at ) . ': ' . $a->old_qty . ' → ' . $a->new_qty . ' by ' . $a->actor_type . ( $a->reason ? ' (' . $a->reason . ')' : '' ) ); ?></li><?php endforeach; ?></ul></details>
				<?php endif; ?>
			</div>
			<?php
		}
		UI::history( 'order', $o->id );
		UI::close();
	}
}
