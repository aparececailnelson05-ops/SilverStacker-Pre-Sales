<?php
namespace SSP\Admin;

use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Boxes;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Reports;

defined( 'ABSPATH' ) || exit;

/**
 * Reports. Ordered, Invoiced and Paid are always separate columns; "Paid" only reflects
 * invoices QuickBooks reports as fully paid. Every report has date/customer/product/category
 * filters where relevant, sorting, on-screen totals and CSV export.
 */
class ReportsScreen {

	const REPORTS = array(
		'summary'     => 'Sales Summary',
		'product'     => 'Sales by Product',
		'category'    => 'Sales by Category',
		'customer'    => 'Sales by Customer',
		'po_customer' => 'Pre-orders by Customer',
		'po_product'  => 'Pre-orders by Product (allocation & availability)',
		'boxes'       => 'Open Boxes & Shipments',
		'export'      => 'Data Export',
	);

	private static function filters( array $in ) {
		return array(
			'from'        => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $in['from'] ?? '' ) ) ? $in['from'] : gmdate( 'Y-01-01' ),
			'to'          => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $in['to'] ?? '' ) ) ? $in['to'] : current_time( 'Y-m-d' ),
			'metal'       => sanitize_text_field( $in['metal'] ?? '' ),
			'lifecycle'   => sanitize_key( $in['lifecycle'] ?? '' ),
			'sort'        => sanitize_key( $in['sort'] ?? 'name' ),
			'granularity' => sanitize_key( $in['granularity'] ?? 'month' ),
			'rank_by'     => sanitize_key( $in['rank_by'] ?? 'value' ),
			'user_id'     => (int) ( $in['user_id'] ?? 0 ),
			'box_status'  => sanitize_key( $in['box_status'] ?? 'active' ),
		);
	}

	/** @return array [headers, rows, totals_row|null] */
	public static function data( $report, array $f ) {
		switch ( $report ) {
			case 'summary':
				$rows = Reports::sales_summary( $f['from'], $f['to'] );
				$out  = array();
				$t    = array( 'Total', 0, 0, 0, 0, 0 );
				foreach ( $rows as $r ) {
					$out[] = array( $r['period'], $r['orders'], round( $r['ordered'], 2 ), round( $r['invoiced'], 2 ), round( $r['received'], 2 ), round( $r['paid'], 2 ) );
					$t[1] += $r['orders'];
					$t[2] += $r['ordered'];
					$t[3] += $r['invoiced'];
					$t[4] += $r['received'];
					$t[5] += $r['paid'];
				}
				return array( array( 'Month', 'No. orders', 'Ordered USD', 'Invoiced USD', 'Payments received USD', 'Paid in full USD' ), $out, $t );
			case 'product':
				$rows = Reports::sales_by_product( $f['from'], $f['to'], $f );
				$out  = array();
				$t    = array( 'Total', '', '', '', 0, 0, 0, 0, 0, 0 );
				foreach ( $rows as $r ) {
					$out[] = array( $r->name, $r->codes, $r->metal, Util::fmt_date( $r->date_posted, 'Y-m-d' ), (int) $r->qty_ordered, round( (float) $r->ordered, 2 ), (int) $r->qty_available, (int) $r->qty_invoiced, round( $r->invoiced, 2 ), round( $r->paid, 2 ) );
					$t[4] += (int) $r->qty_ordered;
					$t[5] += (float) $r->ordered;
					$t[6] += (int) $r->qty_available;
					$t[7] += (int) $r->qty_invoiced;
					$t[8] += $r->invoiced;
					$t[9] += $r->paid;
				}
				return array( array( 'Product', 'Code', 'Category', 'Date posted', 'Qty sold (ordered)', 'Ordered USD', 'Qty available', 'Qty invoiced', 'Invoiced USD', 'Paid USD' ), $out, $t );
			case 'category':
				$rows = Reports::sales_by_category( $f['from'], $f['to'], $f['granularity'] );
				$out  = array();
				$t    = array( 'Total', '', 0, 0, 0 );
				foreach ( $rows as $r ) {
					$out[] = array( $r->period, $r->metal, (int) $r->orders, (int) $r->qty, round( (float) $r->ordered, 2 ) );
					$t[2] += (int) $r->orders;
					$t[3] += (int) $r->qty;
					$t[4] += (float) $r->ordered;
				}
				return array( array( 'Period', 'Category', 'Orders', 'Qty', 'Ordered USD' ), $out, $t );
			case 'customer':
				$grouped = Reports::sales_by_customer( $f['from'], $f['to'], $f['granularity'], $f['rank_by'] );
				$out     = array();
				$t       = array( 'Total', '', '', 0, 0, 0, 0, 0 );
				foreach ( $grouped as $period => $list ) {
					foreach ( $list as $r ) {
						$out[] = array( $period, $r->rank, Customers::display_name( $r ), (int) $r->orders, (int) $r->qty, round( (float) $r->ordered, 2 ), null === $r->invoiced ? '' : round( $r->invoiced, 2 ), null === $r->paid ? '' : round( $r->paid, 2 ) );
						$t[3] += (int) $r->orders;
						$t[4] += (int) $r->qty;
						$t[5] += (float) $r->ordered;
						$t[6] += (float) $r->invoiced;
						$t[7] += (float) $r->paid;
					}
				}
				return array( array( 'Period', 'Rank', 'Customer', 'No. orders', 'Qty', 'Ordered USD', 'Invoiced USD', 'Paid USD' ), $out, $t );
			case 'po_customer':
				$rows = Reports::preorders_by_customer( $f['from'], $f['to'], $f['user_id'] );
				$out  = array();
				$t    = array( 'Total', 0, 0, 0, 0, 0, 0, 0 );
				foreach ( $rows as $r ) {
					$out[] = array( Customers::display_name( $r ), (int) $r->orders, (int) $r->lines_count, (int) $r->qty_ordered, (int) $r->qty_available, (int) $r->qty_invoiced, (int) $r->qty_shipped, round( (float) $r->ordered, 2 ) );
					for ( $i = 1; $i <= 7; $i++ ) {
						$t[ $i ] += $out[ count( $out ) - 1 ][ $i ];
					}
				}
				return array( array( 'Customer', 'Orders', 'Lines', 'Qty ordered', 'Qty available', 'Qty invoiced', 'Qty shipped', 'Ordered USD' ), $out, $t );
			case 'po_product':
				$rows = Reports::preorders_by_product( $f['from'], $f['to'], $f['metal'] );
				$out  = array();
				foreach ( $rows as $r ) {
					$out[] = array( $r->name, $r->sku, Catalog::LIFECYCLES[ $r->lifecycle ] ?? $r->lifecycle, null === $r->total_allocation ? 'Unlimited' : (int) $r->total_allocation, null === $r->per_customer_allocation ? 'Unlimited' : (int) $r->per_customer_allocation, (int) $r->reserved_qty, null === $r->remaining ? 'Unlimited' : (int) $r->remaining, (int) $r->waitlist, (int) $r->customers, (int) $r->qty_ordered, (int) $r->qty_available, (int) $r->qty_invoiced );
				}
				return array( array( 'Product', 'SKU', 'Status', 'Total allocation', 'Per customer', 'Reserved', 'Remaining', 'Waitlist', 'Customers', 'Qty ordered', 'Qty available', 'Qty invoiced' ), $out, null );
			case 'boxes':
				$rows = Reports::boxes_report( $f['box_status'] );
				$out  = array();
				foreach ( $rows as $b ) {
					$out[] = array( $b->box_number, Customers::display_name( $b ), Boxes::STATUSES[ $b->status ] ?? $b->status, (int) $b->lines, (int) $b->units, (int) $b->available, $b->address, (string) Util::fmt_dt( $b->shipment_requested_at ), $b->tier, $b->carrier, $b->tracking, $b->age_days );
				}
				return array( array( 'Box #', 'Customer', 'Status', 'Lines', 'Held units', 'Available', 'Default address', 'Shipment requested', 'Tier', 'Carrier', 'Tracking', 'Age (days)' ), $out, null );
		}
		return array( array(), array(), null );
	}

	public static function csv( $report, array $in ) {
		list( $h, $rows, $t ) = self::data( $report, self::filters( $in ) );
		if ( $t ) {
			$rows[] = $t;
		}
		return array( $h, $rows );
	}

	public static function render() {
		$report = UI::get( 'report', 'summary' );
		$f      = self::filters( $_GET ); // phpcs:ignore
		UI::open( 'Reports', 'Ordered, Invoiced and Paid are reported separately. Paid reflects only invoices QuickBooks reports as paid.' );
		UI::tabs( 'ssp-reports', self::REPORTS, $report, array(), 'report' );
		if ( 'export' === $report ) {
			echo '<div class="ssa-card"><h2>Data export</h2><ul class="ssa-list">';
			foreach ( array( 'orders' => 'Orders (line level)', 'invoices' => 'Invoices', 'customers' => 'Customers', 'products' => 'Products' ) as $k => $l ) {
				echo '<li><a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::export_url( $k ) ) . '">Download ' . esc_html( $l ) . ' CSV</a></li>';
			}
			echo '</ul></div>';
			UI::close();
			return;
		}
		?>
		<form class="ssa-filters" method="get">
			<input type="hidden" name="page" value="ssp-reports"><input type="hidden" name="report" value="<?php echo esc_attr( $report ); ?>">
			<?php if ( 'boxes' !== $report ) : ?>
				<label>Date range <input type="date" name="from" value="<?php echo esc_attr( $f['from'] ); ?>"></label>
				<label>to <input type="date" name="to" value="<?php echo esc_attr( $f['to'] ); ?>"></label>
			<?php endif; ?>
			<?php if ( in_array( $report, array( 'product', 'po_product' ), true ) ) : ?>
				<label>Category <?php echo UI::select( 'metal', array( '' => 'All' ) + array_combine( (array) Settings::get( 'metals' ), (array) Settings::get( 'metals' ) ), $f['metal'] ); // phpcs:ignore ?></label>
			<?php endif; ?>
			<?php if ( 'product' === $report ) : ?>
				<label>Pre-order window <?php echo UI::select( 'lifecycle', array( '' => 'All' ) + Catalog::LIFECYCLES, $f['lifecycle'] ); // phpcs:ignore ?></label>
				<label>Order by <?php echo UI::select( 'sort', array( 'name' => 'Product name (A to Z)', 'name_desc' => 'Product name (Z to A)', 'code' => 'Product code', 'qty' => 'Quantity sold', 'value' => 'Ordered value', 'posted' => 'Date posted' ), $f['sort'] ); // phpcs:ignore ?></label>
			<?php endif; ?>
			<?php if ( in_array( $report, array( 'product', 'po_customer' ), true ) ) : ?>
				<label>Customer <?php $o = array( '' => 'All customers' ); foreach ( Customers::all_approved() as $c ) { $o[ $c->user_id ] = Customers::display_name( $c ); } echo UI::select( 'user_id', $o, $f['user_id'] ); // phpcs:ignore ?></label>
			<?php endif; ?>
			<?php if ( 'category' === $report ) : ?>
				<label>Graph by <?php echo UI::select( 'granularity', array( 'week' => 'Weekly', 'month' => 'Monthly', 'year' => 'Annual' ), $f['granularity'] ); // phpcs:ignore ?></label>
			<?php endif; ?>
			<?php if ( 'customer' === $report ) : ?>
				<label>Ranking per <?php echo UI::select( 'granularity', array( 'total' => 'Whole range', 'day' => 'Day', 'month' => 'Month', 'year' => 'Year' ), $f['granularity'] ); // phpcs:ignore ?></label>
				<label>Rank by <?php echo UI::select( 'rank_by', array( 'value' => 'Value of products ordered', 'qty' => 'Quantity ordered' ), $f['rank_by'] ); // phpcs:ignore ?></label>
			<?php endif; ?>
			<?php if ( 'boxes' === $report ) : ?>
				<label>Box status <?php echo UI::select( 'box_status', array( 'active' => 'Active (open, requested, preparing)', 'shipment_requested' => 'Shipment requested', 'shipped' => 'Shipped', 'delivered' => 'Delivered', '' => 'All' ), $f['box_status'] ); // phpcs:ignore ?></label>
			<?php endif; ?>
			<button class="ssa-btn" type="submit">Go</button>
			<a class="ssa-btn ssa-btn--ghost" href="<?php echo esc_url( UI::export_url( 'report', array_merge( $f, array( 'report' => $report ) ) ) ); ?>">Export CSV</a>
			<button class="ssa-btn ssa-btn--ghost" type="button" onclick="window.print()">Print</button>
		</form>
		<?php
		list( $h, $rows, $tot ) = self::data( $report, $f );
		if ( 'category' === $report && $rows ) {
			self::chart( $rows );
		}
		echo '<div class="ssa-card"><h2>' . esc_html( self::REPORTS[ $report ] ?? '' ) . '</h2><p class="ssa-muted">' . esc_html( Util::fmt_date( $f['from'] ) . ' - ' . Util::fmt_date( $f['to'] ) ) . '</p>';
		echo '<table class="ssa-table ssa-table--hover"><thead><tr>';
		foreach ( $h as $i => $col ) {
			echo '<th' . ( $i && self::numeric_col( $col ) ? ' class="num"' : '' ) . '>' . esc_html( $col ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr>';
			foreach ( $r as $i => $cell ) {
				$num = $i && self::numeric_col( $h[ $i ] );
				echo '<td' . ( $num ? ' class="num"' : '' ) . '>' . esc_html( $num && is_float( $cell ) ? number_format( $cell, 2 ) : (string) $cell ) . '</td>';
			}
			echo '</tr>';
		}
		if ( ! $rows ) {
			echo '<tr><td colspan="' . count( $h ) . '" class="ssa-muted">No data for this range.</td></tr>';
		}
		echo '</tbody>';
		if ( $tot && $rows ) {
			echo '<tfoot><tr>';
			foreach ( $tot as $i => $cell ) {
				$num = $i && self::numeric_col( $h[ $i ] );
				echo '<td' . ( $num ? ' class="num"' : '' ) . '><strong>' . esc_html( $num && is_numeric( $cell ) && strpos( $h[ $i ], 'USD' ) !== false ? number_format( (float) $cell, 2 ) : (string) $cell ) . '</strong></td>';
			}
			echo '</tr></tfoot>';
		}
		echo '</table></div>';
		UI::close();
	}

	private static function numeric_col( $label ) {
		return (bool) preg_match( '/USD|Qty|No\.|Orders|Lines|Rank|Reserved|Remaining|Waitlist|Customers|allocation|Per customer|units|Available|Age/i', $label );
	}

	/** Grouped bar chart of ordered USD per category per period (inline SVG, no external libs). */
	private static function chart( array $rows ) {
		$periods = array();
		$metals  = array();
		$data    = array();
		foreach ( $rows as $r ) {
			$periods[ $r[0] ]         = true;
			$metals[ $r[1] ]          = true;
			$data[ $r[0] ][ $r[1] ]   = (float) $r[4];
		}
		$periods = array_keys( $periods );
		$metals  = array_keys( $metals );
		$max     = 0;
		foreach ( $data as $p ) {
			$max = max( $max, max( $p ) );
		}
		$max     = $max > 0 ? $max : 1;
		$colors  = array( 'Silver' => '#8a93a6', 'Gold' => '#c9a227', 'Copper' => '#b8733d', 'Platinum' => '#07067b', 'Uncategorized' => '#b90c1c' );
		$w       = max( 640, count( $periods ) * ( count( $metals ) * 14 + 24 ) + 80 );
		$h       = 260;
		$plot_h  = 200;
		$x       = 60;
		echo '<div class="ssa-card"><h2>Ordered value by category</h2><div class="ssa-chart"><svg width="' . (int) $w . '" height="' . (int) $h . '" viewBox="0 0 ' . (int) $w . ' ' . (int) $h . '" role="img" aria-label="Bar chart of ordered value by category and period">';
		for ( $g = 0; $g <= 4; $g++ ) {
			$y = 20 + $plot_h - ( $plot_h * $g / 4 );
			echo '<line x1="50" x2="' . (int) ( $w - 10 ) . '" y1="' . esc_attr( $y ) . '" y2="' . esc_attr( $y ) . '" stroke="#e3e5ee"/><text x="46" y="' . esc_attr( $y + 4 ) . '" font-size="10" text-anchor="end" fill="#666">$' . esc_html( number_format( $max * $g / 4 ) ) . '</text>';
		}
		foreach ( $periods as $p ) {
			foreach ( $metals as $m ) {
				$v  = $data[ $p ][ $m ] ?? 0;
				$bh = $plot_h * $v / $max;
				echo '<rect x="' . (int) $x . '" y="' . esc_attr( 20 + $plot_h - $bh ) . '" width="12" height="' . esc_attr( $bh ) . '" fill="' . esc_attr( $colors[ $m ] ?? '#555' ) . '"><title>' . esc_html( $p . ' ' . $m . ': $' . number_format( $v, 2 ) ) . '</title></rect>';
				$x += 14;
			}
			echo '<text x="' . (int) ( $x - count( $metals ) * 7 ) . '" y="' . (int) ( $plot_h + 36 ) . '" font-size="10" text-anchor="middle" fill="#333">' . esc_html( $p ) . '</text>';
			$x += 24;
		}
		echo '</svg></div><p class="ssa-legend">';
		foreach ( $metals as $m ) {
			echo '<span><i style="background:' . esc_attr( $colors[ $m ] ?? '#555' ) . '"></i>' . esc_html( $m ) . '</span> ';
		}
		echo '</p></div>';
	}
}
