<?php
namespace SSP\Admin;

use SSP\Core\Installer;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

class AuditScreen {

	public static function render() {
		global $wpdb;
		$t      = Installer::tables()['audit'];
		$where  = array( '1=1' );
		$params = array();
		foreach ( array( 'object_type', 'object_id', 'action' ) as $k ) {
			if ( UI::get( $k ) ) {
				$where[]  = "{$k} LIKE %s";
				$params[] = '%' . $wpdb->esc_like( UI::get( $k ) ) . '%';
			}
		}
		if ( UI::get( 'actor' ) ) {
			$where[]  = 'actor_user_id=%d';
			$params[] = (int) UI::get( 'actor' );
		}
		if ( UI::get( 'from' ) ) {
			$where[]  = 'created_at >= %s';
			$params[] = Util::local_to_utc( UI::get( 'from' ) . ' 00:00:00' );
		}
		$page = max( 1, (int) UI::get( 'paged', 1 ) );
		$w    = implode( ' AND ', $where );
		$sql  = "SELECT * FROM {$t} WHERE {$w} ORDER BY id DESC LIMIT 100 OFFSET " . ( ( $page - 1 ) * 100 );
		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );
		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE {$w}", $params ) ) : $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ) );
		UI::open( 'Audit Log', 'Append-only record of staff and system changes: prices, allocations, overrides, availability, quantities, fulfillment choices, boxes, shipments, invoice links, approvals and settings. Times shown in ' . esc_html( Util::business_tz()->getName() ) . '.' );
		?>
		<form class="ssa-filters" method="get"><input type="hidden" name="page" value="ssp-audit">
			<input type="text" name="action" value="<?php echo esc_attr( UI::get( 'action' ) ); ?>" placeholder="Action (e.g. allocation)">
			<input type="text" name="object_type" value="<?php echo esc_attr( UI::get( 'object_type' ) ); ?>" placeholder="Object type">
			<input type="text" name="object_id" value="<?php echo esc_attr( UI::get( 'object_id' ) ); ?>" placeholder="Object ID">
			<label>From <input type="date" name="from" value="<?php echo esc_attr( UI::get( 'from' ) ); ?>"></label>
			<button class="ssa-btn ssa-btn--ghost">Filter</button></form>
		<table class="ssa-table"><thead><tr><th>When</th><th>Who</th><th>Role</th><th>Action</th><th>Object</th><th>Change</th><th>Reason</th><th>IP</th></tr></thead><tbody>
		<?php foreach ( $rows as $r ) : ?>
			<?php $u = $r->actor_user_id ? get_userdata( $r->actor_user_id ) : null; ?>
			<tr><td class="ssa-nowrap"><?php echo esc_html( Util::fmt_dt( $r->created_at ) ); ?></td><td><?php echo esc_html( $u ? $u->display_name : 'System' ); ?></td><td class="ssa-small"><?php echo esc_html( $r->actor_role ); ?></td><td><code><?php echo esc_html( $r->action ); ?></code></td><td><?php echo esc_html( $r->object_type . ' ' . $r->object_id ); ?></td><td class="ssa-small"><?php echo esc_html( UI::diff_text( $r ) ); ?></td><td><?php echo esc_html( (string) $r->reason ); ?></td><td class="ssa-small"><?php echo esc_html( $r->ip ); ?></td></tr>
		<?php endforeach; ?>
		</tbody></table>
		<?php
		UI::pager( $total, 100, $page, 'ssp-audit', array_filter( array( 'action' => UI::get( 'action' ), 'object_type' => UI::get( 'object_type' ), 'object_id' => UI::get( 'object_id' ), 'from' => UI::get( 'from' ) ) ) );
		UI::close();
	}
}
