<?php
namespace SSP\Admin;

use SSP\Core\Util;
use SSP\Domain\Catalog;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Tracker;

defined( 'ABSPATH' ) || exit;

/** Pre-Sale Tracker: replaces the shared spreadsheet with live line-level data. */
class TrackerScreen {

	public static function render() {
		$tab = UI::get( 'tab', 'master' );
		UI::open( 'Pre-Sale Tracker', 'Active product master list, active orders, closed orders and ready to invoice. Line-level so items in one order can arrive and invoice at different times.' );
		UI::tabs( 'ssp-tracker', array( 'master' => 'Active Product Master List', 'active' => 'Active Orders', 'closed' => 'Closed Orders', 'ready' => 'Ready to Invoice' ), $tab );
		?>
		<form class="ssa-filters" method="get"><input type="hidden" name="page" value="ssp-tracker"><input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>"><input type="search" name="q" value="<?php echo esc_attr( UI::get( 'q' ) ); ?>" placeholder="Product, SKU or buyer"><button class="ssa-btn ssa-btn--ghost">Search</button></form>
		<?php
		if ( 'master' === $tab ) {
			self::master();
		} elseif ( 'distribute' === $tab ) {
			self::distribute();
		} else {
			self::grouped( $tab );
		}
		UI::close();
	}

	private static function master() {
		$rows      = Tracker::master_list( array( 'q' => UI::get( 'q' ) ) );
		$suppliers = array( '' => 'None' ) + wp_list_pluck( Catalog::suppliers(), 'name', 'id' );
		UI::form( 'tracker_master_save' );
		?>
		<table class="ssa-table ssa-table--sheet">
			<thead><tr><th>Item description</th><th>ETA</th><th class="num">Price</th><th>Date posted</th><th class="num">Qty ordered (supplier)</th><th class="num">Customer qty</th><th class="num">Qty available</th><th>Order by date</th><th>Status</th><th>Supplier</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $rows as $r ) : ?>
				<tr>
					<td><a href="<?php echo esc_url( UI::url( 'ssp-products', array( 'edit' => $r->id ) ) ); ?>"><?php echo esc_html( $r->name . ( $r->label ? ' - ' . $r->label : '' ) ); ?></a><br><span class="ssa-muted ssa-small"><?php echo esc_html( $r->sku ); ?></span></td>
					<td><input type="text" name="m[<?php echo (int) $r->variant_id; ?>][eta_text]" value="<?php echo esc_attr( Catalog::eta_label( $r ) ); ?>" size="14" title="Typing here sets a free-text ETA. Use the product editor for month/date/range."></td>
					<td class="num"><?php echo esc_html( 'spot_based' === $r->price_type ? 'Spot + ' . Util::money( $r->spot_premium_usd ) : Util::money( $r->price_usd ) ); ?></td>
					<td><?php echo esc_html( Util::fmt_date( $r->date_posted, 'm/d/Y' ) ); ?></td>
					<td class="num"><input type="number" name="m[<?php echo (int) $r->variant_id; ?>][supplier_qty_ordered]" value="<?php echo esc_attr( (string) $r->supplier_qty_ordered ); ?>" min="0" style="width:80px"></td>
					<td class="num"><?php echo (int) $r->reserved_qty; ?><?php echo null !== $r->total_allocation ? ' / ' . (int) $r->total_allocation : ''; ?></td>
					<td class="num"><?php echo (int) $r->qty_available_lines; ?></td>
					<td><?php echo esc_html( $r->closing_at ? Util::fmt_dt( $r->closing_at, 'm/d' ) : '' ); ?></td>
					<td><?php echo ssp_badge( $r->tracker_status, 'Active' === $r->tracker_status ? 'brand' : 'neutral' ); // phpcs:ignore ?></td>
					<td><?php echo UI::select( 'm[' . (int) $r->variant_id . '][supplier_id]', $suppliers, $r->supplier_id ); // phpcs:ignore ?></td>
					<td><a class="ssa-btn ssa-btn--sm ssa-btn--ghost" href="<?php echo esc_url( UI::url( 'ssp-tracker', array( 'tab' => 'distribute', 'variant_id' => $r->variant_id ) ) ); ?>">Mark arrivals&hellip;</a></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( ! $rows ) : ?><tr><td colspan="11" class="ssa-muted">No active products.</td></tr><?php endif; ?>
			</tbody>
		</table>
		<p><button class="ssa-btn" type="submit">Save changes</button> <span class="ssa-muted">Supplier quantity and allocation are separate fields (decision D-25). ETA edits update every customer view immediately.</span></p>
		<?php
		UI::end();
	}

	private static function grouped( $mode ) {
		$groups = Tracker::grouped_lines( $mode, array( 'q' => UI::get( 'q' ), 'include_invoiced' => 'ready' === $mode && UI::get( 'all' ) ) );
		if ( 'ready' === $mode ) {
			echo '<p><a href="' . esc_url( UI::url( 'ssp-tracker', array( 'tab' => 'ready', 'all' => UI::get( 'all' ) ? '' : 1 ) ) ) . '">' . ( UI::get( 'all' ) ? 'Show only lines waiting to be invoiced' : 'Include already invoiced lines' ) . '</a></p>';
		}
		if ( ! $groups ) {
			echo '<div class="ssa-card ssa-muted">Nothing here right now.</div>';
			return;
		}
		UI::form( 'availability_bulk' );
		?>
		<table class="ssa-table ssa-table--sheet">
			<thead><tr><th>Item description</th><th>Order date</th><th>Order no.</th><th>Buyer</th><th class="num">Qty ordered</th><th class="num">Price</th><th class="num">Total</th><th class="num">Qty avail.</th><th>Close date</th><th>Customer note</th><th>ETA</th><?php if ( 'ready' === $mode ) : ?><th>Status</th><?php endif; ?></tr></thead>
			<tbody>
			<?php foreach ( $groups as $g ) : ?>
				<tr class="ssa-group"><td colspan="<?php echo 'ready' === $mode ? 12 : 11; ?>"><strong><?php echo esc_html( $g['name'] ); ?></strong> &middot; <?php echo (int) $g['qty']; ?> units &middot; <?php echo esc_html( Util::money( $g['total'] ) ); ?> <?php if ( 'ready' !== $mode ) : ?><a class="ssa-small" href="<?php echo esc_url( UI::url( 'ssp-tracker', array( 'tab' => 'distribute', 'variant_id' => $g['variant_id'] ) ) ); ?>">Mark arrivals&hellip;</a><?php endif; ?></td></tr>
				<?php foreach ( $g['lines'] as $l ) : ?>
					<?php $invs = Invoices::for_line( $l->id ); ?>
					<tr>
						<td></td>
						<td><?php echo esc_html( Util::fmt_date( $l->submitted_at, 'M j, Y' ) ); ?></td>
						<td><a href="<?php echo esc_url( UI::url( 'ssp-orders', array( 'order' => $l->order_number ) ) ); ?>"><?php echo (int) $l->order_number; ?></a></td>
						<td><?php echo UI::customer_link( $l->user_id, $l->contact_name ? $l->contact_name : $l->company_name ); // phpcs:ignore ?></td>
						<td class="num"><?php echo (int) Orders::net( $l ); ?></td>
						<td class="num"><?php echo esc_html( number_format( (float) $l->unit_price_usd, 2 ) ); ?></td>
						<td class="num"><?php echo esc_html( number_format( Orders::line_total( $l ), 2 ) ); ?></td>
						<td class="num"><input type="number" name="avail[<?php echo (int) $l->id; ?>]" value="<?php echo (int) $l->qty_available; ?>" min="0" max="<?php echo (int) Orders::net( $l ); ?>" style="width:64px"></td>
						<td><?php echo esc_html( $l->closing_at ? Util::fmt_dt( $l->closing_at, 'm/d' ) : '' ); ?></td>
						<td class="ssa-small"><?php echo esc_html( (string) $l->customer_note ); ?></td>
						<td><?php echo esc_html( Catalog::eta_label( $g['product'] ) ); ?></td>
						<?php if ( 'ready' === $mode ) : ?>
							<td>
								<?php if ( $invs ) : ?>
									<?php foreach ( $invs as $i ) : ?><?php echo ssp_badge( ( $i->doc_number ? $i->doc_number . ' ' : '' ) . Invoices::payment_label( $i ), ssp_status_kind( $i->sync_status ) ); // phpcs:ignore ?> <?php endforeach; ?>
								<?php endif; ?>
								<?php if ( Invoices::invoiceable_qty( $l ) > 0 ) : ?>
									<a class="ssa-btn ssa-btn--sm" href="<?php echo esc_url( UI::url( 'ssp-invoices', array( 'new' => $l->user_id ) ) ); ?>">Invoice <?php echo (int) Invoices::invoiceable_qty( $l ); ?></a>
								<?php endif; ?>
							</td>
						<?php endif; ?>
					</tr>
				<?php endforeach; ?>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p><button class="ssa-btn" type="submit">Save quantity available</button> <span class="ssa-muted">Partial availability is supported per line.</span></p>
		<?php
		UI::end();
	}

	/** Arrival helper: proposes availability oldest-order-first; staff must confirm. */
	private static function distribute() {
		$vid = (int) UI::get( 'variant_id' );
		$v   = Catalog::variant( $vid );
		if ( ! $v ) {
			echo '<div class="ssa-card">Variant not found.</div>';
			return;
		}
		$p       = Catalog::get( $v->product_id );
		$arrived = (int) UI::get( 'arrived' );
		?>
		<div class="ssa-card">
			<h2>Mark arrivals: <?php echo esc_html( $p->name . ' / ' . $v->sku ); ?></h2>
			<p class="ssa-muted">Enter how many units arrived. The portal proposes availability for open lines, oldest order first. Nothing changes until you review and confirm. (This is a convenience tool; you can edit each line individually.)</p>
			<form method="get" class="ssa-filters"><input type="hidden" name="page" value="ssp-tracker"><input type="hidden" name="tab" value="distribute"><input type="hidden" name="variant_id" value="<?php echo (int) $vid; ?>"><label>Units arrived <input type="number" name="arrived" value="<?php echo (int) $arrived; ?>" min="0"></label><button class="ssa-btn ssa-btn--ghost">Preview</button></form>
			<?php if ( $arrived > 0 ) : ?>
				<?php $plan = Orders::propose_distribution( $vid, $arrived ); ?>
				<?php UI::form( 'distribute_apply' ); ?>
				<table class="ssa-table"><thead><tr><th>Order</th><th>Date</th><th>Line</th><th class="num">Ordered</th><th class="num">Currently available</th><th class="num">Proposed available</th></tr></thead><tbody>
				<?php foreach ( $plan['plan'] as $row ) : ?>
					<?php $l = $row['line']; ?>
					<tr><td>#<?php echo (int) $l->order_number; ?></td><td><?php echo esc_html( Util::fmt_date( $l->submitted_at ) ); ?></td><td><?php echo esc_html( $l->name_snapshot ); ?></td><td class="num"><?php echo (int) Orders::net( $l ); ?></td><td class="num"><?php echo (int) $row['current']; ?></td><td class="num"><input type="number" name="plan[<?php echo (int) $l->id; ?>]" value="<?php echo (int) $row['proposed']; ?>" min="0" max="<?php echo (int) Orders::net( $l ); ?>" style="width:70px"></td></tr>
				<?php endforeach; ?>
				</tbody></table>
				<?php if ( $plan['unassigned'] ) : ?><p><?php echo (int) $plan['unassigned']; ?> unit(s) not needed by open lines (available for In-Stock sale).</p><?php endif; ?>
				<p><button class="ssa-btn" type="submit">Confirm and save availability</button></p>
				<?php UI::end(); ?>
			<?php endif; ?>
		</div>
		<?php
	}
}
