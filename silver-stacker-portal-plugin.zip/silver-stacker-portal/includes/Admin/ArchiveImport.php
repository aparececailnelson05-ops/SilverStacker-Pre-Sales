<?php
namespace SSP\Admin;

use SSP\Core\Audit;
use SSP\Core\Installer;
use SSP\Core\Util;
use SSP\Domain\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Archive (historical product reference) CSV import. The final data source is still to be
 * confirmed (decision D-10); the column mapping below is flexible by header name.
 * Required: name. Optional: sku, barcode, brand, metal, category, mintage, description, image.
 * The image column may be a local path on the server or a URL (downloaded once, stored privately).
 */
class ArchiveImport {

	const COLUMNS = array( 'name', 'sku', 'barcode', 'brand', 'metal', 'category', 'mintage', 'description', 'image', 'date_posted' );

	public static function import( $file, $dry_run = false ) {
		global $wpdb;
		$out = array( 'imported' => 0, 'skipped' => 0, 'errors' => array() );
		$fh  = @fopen( $file, 'r' );
		if ( ! $fh ) {
			$out['errors'][] = 'Cannot read file.';
			return $out;
		}
		$header = fgetcsv( $fh, 0, ",", "\"", "\\" );
		if ( ! $header ) {
			$out['errors'][] = 'The file is empty.';
			return $out;
		}
		$header = array_map( fn( $h ) => strtolower( trim( preg_replace( '/^\xEF\xBB\xBF/', '', (string) $h ) ) ), $header );
		$map    = array();
		foreach ( self::COLUMNS as $c ) {
			$i = array_search( $c, $header, true );
			if ( false !== $i ) {
				$map[ $c ] = $i;
			}
		}
		if ( ! isset( $map['name'] ) ) {
			$out['errors'][] = 'A "name" column is required.';
			return $out;
		}
		$vt  = Installer::tables()['variants'];
		$row = 1;
		$now = Util::now();
		while ( ( $data = fgetcsv( $fh, 0, ",", "\"", "\\" ) ) !== false ) {
			++$row;
			$get  = fn( $c ) => isset( $map[ $c ] ) ? trim( (string) ( $data[ $map[ $c ] ] ?? '' ) ) : '';
			$name = sanitize_text_field( $get( 'name' ) );
			if ( '' === $name ) {
				++$out['skipped'];
				continue;
			}
			$sku = strtoupper( preg_replace( '/[^A-Za-z0-9\-_.]/', '', $get( 'sku' ) ) );
			if ( '' === $sku ) {
				$sku = 'ARC-' . strtoupper( substr( md5( $name . '|' . $get( 'mintage' ) ), 0, 10 ) );
			}
			if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$vt} WHERE sku=%s", $sku ) ) ) {
				++$out['skipped'];
				$out['errors'][] = "Row {$row}: SKU {$sku} already exists, skipped.";
				continue;
			}
			if ( $dry_run ) {
				++$out['imported'];
				continue;
			}
			$pid = Catalog::save_product(
				array(
					'name'        => $name,
					'description' => $get( 'description' ),
					'brand'       => $get( 'brand' ),
					'metal'       => ucfirst( strtolower( $get( 'metal' ) ) ),
					'category'    => $get( 'category' ),
					'mintage'     => $get( 'mintage' ),
					'date_posted' => $get( 'date_posted' ),
				)
			);
			if ( is_wp_error( $pid ) ) {
				$out['errors'][] = "Row {$row}: " . $pid->get_error_message();
				++$out['skipped'];
				continue;
			}
			Catalog::save_variant( $pid, array( 'sku' => $sku, 'barcode' => $get( 'barcode' ), 'price_usd' => 0 ) );
			$wpdb->update( Installer::tables()['products'], array( 'lifecycle' => 'archived', 'archived_at' => $now ), array( 'id' => $pid ) );
			$img = $get( 'image' );
			if ( $img ) {
				$tmp = self::fetch_image( $img );
				if ( $tmp ) {
					$r = Catalog::add_image( $pid, array( 'name' => basename( wp_parse_url( $img, PHP_URL_PATH ) ), 'tmp_name' => $tmp, 'error' => 0, 'size' => filesize( $tmp ), 'type' => '' ) );
					if ( is_wp_error( $r ) ) {
						$out['errors'][] = "Row {$row}: image " . $r->get_error_message();
					}
					if ( strpos( $tmp, get_temp_dir() ) === 0 ) {
						wp_delete_file( $tmp );
					}
				}
			}
			Catalog::reindex( $pid );
			++$out['imported'];
		}
		fclose( $fh );
		if ( ! $dry_run ) {
			Audit::log( 'archive.imported', 'archive', 'csv', null, array( 'imported' => $out['imported'], 'skipped' => $out['skipped'] ) );
		}
		return $out;
	}

	private static function fetch_image( $src ) {
		if ( preg_match( '#^https?://#i', $src ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$tmp = download_url( $src, 30 );
			return is_wp_error( $tmp ) ? null : $tmp;
		}
		return is_readable( $src ) ? $src : null;
	}
}
