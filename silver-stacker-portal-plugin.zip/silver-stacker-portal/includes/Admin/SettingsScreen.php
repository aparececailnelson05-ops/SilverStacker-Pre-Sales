<?php
namespace SSP\Admin;

use SSP\Core\Mailer;
use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Customers;
use SSP\Domain\Orders;
use SSP\Domain\Shipments;
use SSP\Domain\Terms;

defined( 'ABSPATH' ) || exit;

class SettingsScreen {

	private static function field( $key, $label, $type = 'text', array $options = array(), $help = '' ) {
		$val   = Settings::get( $key );
		$unc   = Settings::unconfirmed()[ $key ] ?? '';
		echo '<div class="ssa-field"><input type="hidden" name="present[]" value="' . esc_attr( $key ) . '">';
		if ( 'checkbox' === $type ) {
			echo '<label><input type="checkbox" name="s[' . esc_attr( $key ) . ']" value="1" ' . checked( (bool) $val, true, false ) . '> ' . esc_html( $label ) . '</label>';
		} else {
			echo '<label class="ssa-block">' . esc_html( $label );
			if ( 'select' === $type ) {
				echo UI::select( 's[' . $key . ']', $options, $val ); // phpcs:ignore
			} elseif ( 'textarea' === $type ) {
				echo '<textarea name="s[' . esc_attr( $key ) . ']" rows="3">' . esc_textarea( (string) $val ) . '</textarea>';
			} else {
				echo '<input type="' . esc_attr( $type ) . '" name="s[' . esc_attr( $key ) . ']" value="' . esc_attr( is_array( $val ) ? implode( ', ', $val ) : (string) $val ) . '">';
			}
			echo '</label>';
		}
		if ( $unc ) {
			echo '<span class="ssa-unconfirmed" title="Business decision still to confirm">Unconfirmed: ' . esc_html( $unc ) . '</span>';
		}
		if ( $help ) {
			echo '<span class="ssa-help">' . esc_html( $help ) . '</span>';
		}
		echo '</div>';
	}

	private static function settings_form( $section, callable $fields ) {
		echo '<div class="ssa-card">';
		UI::form( 'settings_save' );
		echo '<input type="hidden" name="section" value="' . esc_attr( $section ) . '">';
		$fields();
		echo '<p><button class="ssa-btn" type="submit">Save settings</button></p>';
		UI::end();
		echo '</div>';
	}

	public static function render() {
		$tab = UI::get( 'tab', 'general' );
		UI::open( 'Settings', 'Items marked "Unconfirmed" are open business decisions from the specification (Section 19 / D-xx). Defaults are the proposed values; change them here once decided.' );
		UI::tabs(
			'ssp-settings',
			array(
				'general'   => 'General',
				'orders'    => 'Orders',
				'waitlist'  => 'Waitlist',
				'box'       => 'Box &amp; shipping',
				'tiers'     => 'Rate tiers',
				'email'     => 'Email',
				'terms'     => 'Terms &amp; Conditions',
				'questions' => 'Sign-up questions',
				'staff'     => 'Staff &amp; roles',
				'decisions' => 'Open decisions',
			),
			$tab
		);
		switch ( $tab ) {
			case 'orders':
				self::settings_form(
					'orders',
					function () {
						self::field( 'order_number_start', 'First order number', 'number', array(), 'Recommended: start above the last OrderSpace order number to avoid confusion.' );
						self::field( 'min_qty_scope', 'Minimum quantity applies to', 'select', array( 'customer_total' => "The customer's total for the item (all their orders)", 'per_line' => 'Each order line' ) );
						self::field( 'zero_qty_cancels', 'Customers can cancel a line by setting quantity to 0 before closing', 'checkbox' );
						self::field( 'instock_editable_until', 'In-stock lines can be edited by customers until', 'select', array( 'available' => 'Marked available', 'invoiced' => 'Invoiced', 'never' => 'Never (contact staff)' ) );
						self::field( 'default_fulfillment_choice', 'Default fulfillment choice', 'select', Orders::FULFILLMENT );
						self::field( 'order_confirmation_email', 'Send an order confirmation email (on-screen confirmation is always shown)', 'checkbox' );
					}
				);
				break;
			case 'waitlist':
				self::settings_form(
					'waitlist',
					function () {
						self::field( 'waitlist_mode', 'When allocation becomes available', 'select', array( 'hold' => 'Hold it for the next waitlisted customer for a response window (FIFO)', 'fcfs' => 'Notify all waitlisted customers; first to order gets it', 'auto' => 'Automatically reserve it on a new pre-order for the next customer' ) );
						self::field( 'waitlist_hold_hours', 'Response window (hours)', 'number' );
					}
				);
				break;
			case 'box':
				self::settings_form(
					'box',
					function () {
						self::field( 'max_open_boxes', 'Maximum open boxes per customer', 'number' );
						self::field( 'address_change_until', 'Customers can change the box address until', 'select', array( 'preparing' => 'Staff starts preparing', 'shipment_requested' => 'Shipment is requested', 'never' => 'Never (default address only)' ) );
						self::field( 'ship_unavailable_mode', 'When a customer requests shipment and some items have not arrived', 'select', array( 'customer_choice' => 'Let the customer choose', 'ship_available' => 'Ship arrived items; keep the rest in a new open box', 'wait_all' => 'Wait until everything has arrived' ) );
						self::field( 'fulfillment_change_until', 'Customers can change fulfillment choice until', 'select', array( 'preparing' => 'Box preparation starts', 'shipment_requested' => 'Shipment is requested' ) );
						self::field( 'box_auto_close_days', 'Auto-close delivered boxes after (days, 0 = never)', 'number' );
						self::field( 'box_digest_minutes', 'Group box-change emails over (minutes)', 'number', array(), 'Prevents one email per change when several items move at once.' );
					}
				);
				break;
			case 'tiers':
				self::tiers();
				break;
			case 'email':
				self::settings_form(
					'email',
					function () {
						self::field( 'email_from_name', 'Sender name' );
						self::field( 'email_from_address', 'Sender email address', 'email' );
						self::field( 'email_reply_to', 'Reply-to address', 'email' );
						self::field( 'staff_alert_email', 'Notify this address about new registrations', 'email' );
					}
				);
				self::templates();
				break;
			case 'terms':
				self::terms();
				break;
			case 'questions':
				self::questions();
				break;
			case 'staff':
				self::staff();
				break;
			case 'decisions':
				self::decisions();
				break;
			default:
				self::settings_form(
					'general',
					function () {
						self::field( 'business_timezone', 'Business timezone (closing times and displays)', 'text', array(), 'IANA name, e.g. America/Chicago. All data is stored in UTC.' );
						self::field( 'default_closing_time', 'Default closing time of day (HH:MM)', 'text' );
						self::field( 'announcement', 'Pre-sale announcement (below the header)', 'textarea' );
						self::field( 'append_closing_date_to_name', 'Show the closing date after product names, e.g. "(08/03)"', 'checkbox' );
						self::field( 'metals', 'Primary categories (comma separated)', 'text' );
						self::field( 'fb_group_link', 'Facebook group link (sign-up question 5)', 'url' );
						self::field( 'require_terms_reaccept', 'Require customers to accept each new Terms version', 'checkbox' );
					}
				);
		}
		UI::close();
	}

	private static function tiers() {
		echo '<div class="ssa-card"><h2>Fixed shipping rate tiers</h2><p class="ssa-muted">Tier values and which rule wins when size and weight disagree are still to be confirmed (D-4). The draft tiers come from the original Terms ($6 Ground, $9 Priority, $9 Build A Box). Tick "Confirmed" once approved.</p>';
		UI::form( 'tier_save' );
		echo '<table class="ssa-table"><thead><tr><th>Name</th><th>Basis</th><th>Min</th><th>Max</th><th>Unit</th><th>Charge USD</th><th>Priority</th><th>Active</th><th>Confirmed</th></tr></thead><tbody>';
		foreach ( array_merge( Shipments::tiers( false ), array( (object) array( 'id' => 'new', 'name' => '', 'basis' => 'size', 'min_value' => '', 'max_value' => '', 'unit' => '', 'charge_usd' => '', 'priority' => 50, 'active' => 1, 'confirmed' => 0 ) ) ) as $t ) {
			$n = 't[' . $t->id . ']';
			echo '<tr><td><input type="text" name="' . esc_attr( $n ) . '[name]" value="' . esc_attr( $t->name ) . '" placeholder="' . ( 'new' === $t->id ? 'Add tier' : '' ) . '"></td><td>' . UI::select( $n . '[basis]', array( 'size' => 'Box size', 'weight' => 'Weight' ), $t->basis ) . '</td><td><input type="text" name="' . esc_attr( $n ) . '[min_value]" value="' . esc_attr( (string) $t->min_value ) . '" size="5"></td><td><input type="text" name="' . esc_attr( $n ) . '[max_value]" value="' . esc_attr( (string) $t->max_value ) . '" size="5"></td><td><input type="text" name="' . esc_attr( $n ) . '[unit]" value="' . esc_attr( $t->unit ) . '" size="5" placeholder="oz, in"></td><td><input type="text" name="' . esc_attr( $n ) . '[charge_usd]" value="' . esc_attr( (string) $t->charge_usd ) . '" size="6"></td><td><input type="number" name="' . esc_attr( $n ) . '[priority]" value="' . esc_attr( (string) $t->priority ) . '" style="width:60px"></td><td><input type="checkbox" name="' . esc_attr( $n ) . '[active]" value="1" ' . checked( (int) $t->active, 1, false ) . '></td><td><input type="checkbox" name="' . esc_attr( $n ) . '[confirmed]" value="1" ' . checked( (int) $t->confirmed, 1, false ) . '></td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table><p><button class="ssa-btn" type="submit">Save tiers</button></p>';
		UI::end();
		echo '</div>';
	}

	private static function templates() {
		echo '<div class="ssa-card"><h2>Email templates</h2><p class="ssa-muted">Placeholders such as {name}, {product}, {invoice_number}, {box_number}, {lines_table}, {changes}, {login_url} are filled automatically. QuickBooks sends the formal invoice email.</p>';
		UI::form( 'email_templates_save' );
		foreach ( Mailer::templates() as $k => $t ) {
			echo '<details class="ssa-tpl"><summary><strong>' . esc_html( $t['label'] ) . '</strong></summary>';
			echo '<label class="ssa-block">Subject <input type="text" name="tpl[' . esc_attr( $k ) . '][subject]" value="' . esc_attr( $t['subject'] ) . '"></label>';
			echo '<label class="ssa-block">Body (HTML) <textarea name="tpl[' . esc_attr( $k ) . '][body]" rows="6">' . esc_textarea( $t['body'] ) . '</textarea></label></details>';
		}
		echo '<p><button class="ssa-btn" type="submit">Save templates</button></p>';
		UI::end();
		echo '</div>';
	}

	private static function terms() {
		$cur = Terms::current();
		?>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Publish a new version</h2>
				<p class="ssa-muted">Publishing creates a new version. Customers must tick the agreement box again before using the portal (if enabled). Acceptance is recorded with customer ID, timestamp and version.</p>
				<?php UI::form( 'terms_publish' ); ?>
					<label class="ssa-block">Version label <input type="text" name="version_label" value="<?php echo esc_attr( $cur ? (string) ( (float) $cur->version_label + 0.1 ) : '1.0' ); ?>" required></label>
					<?php wp_editor( $cur ? $cur->content : '', 'ssp_terms', array( 'textarea_name' => 'content', 'textarea_rows' => 12, 'media_buttons' => false, 'teeny' => true ) ); ?>
					<p><button class="ssa-btn" type="submit">Publish new version</button></p>
				<?php UI::end(); ?>
			</div>
			<div class="ssa-card">
				<h2>Versions</h2>
				<table class="ssa-table"><thead><tr><th>Version</th><th>Published</th><th>Current</th></tr></thead><tbody>
				<?php foreach ( Terms::all() as $t ) : ?><tr><td><?php echo esc_html( $t->version_label ); ?></td><td><?php echo esc_html( Util::fmt_dt( $t->published_at ) ); ?></td><td><?php echo $t->is_current ? ssp_badge( 'Current', 'ok' ) : ''; // phpcs:ignore ?></td></tr><?php endforeach; ?>
				</tbody></table>
			</div>
		</div>
		<?php
	}

	private static function questions() {
		echo '<div class="ssa-card"><h2>Registration qualification questions</h2><p class="ssa-muted">Shown in step 3 of registration. Use {fb_group_link} to insert the Facebook group link. Answers keep the exact question text they were given with.</p>';
		UI::form( 'question_save' );
		echo '<table class="ssa-table"><thead><tr><th>Order</th><th>Question</th><th>Answer type</th><th>Active</th></tr></thead><tbody>';
		foreach ( Customers::questions( false ) as $q ) {
			echo '<tr><td><input type="number" name="q[' . (int) $q->id . '][sort]" value="' . (int) $q->sort . '" style="width:60px"></td><td><textarea name="q[' . (int) $q->id . '][text]" rows="2" style="width:100%">' . esc_textarea( $q->text ) . '</textarea></td><td>' . UI::select( 'q[' . (int) $q->id . '][answer_type]', array( 'yesno' => 'Yes / No', 'text' => 'Free text' ), $q->answer_type ) . '</td><td><input type="checkbox" name="q[' . (int) $q->id . '][active]" value="1" ' . checked( (int) $q->active, 1, false ) . '></td></tr>'; // phpcs:ignore
		}
		echo '<tr><td>New</td><td><textarea name="new_text" rows="2" style="width:100%" placeholder="Add a question"></textarea></td><td>' . UI::select( 'new_type', array( 'yesno' => 'Yes / No', 'text' => 'Free text' ), 'yesno' ) . '</td><td></td></tr>'; // phpcs:ignore
		echo '</tbody></table><p><button class="ssa-btn" type="submit">Save questions</button></p>';
		UI::end();
		echo '</div>';
	}

	private static function staff() {
		$reps = get_users( array( 'role__in' => array( 'ss_sales_rep', 'administrator' ) ) );
		?>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Staff users</h2>
				<table class="ssa-table"><thead><tr><th>Name</th><th>Email</th><th>Role</th></tr></thead><tbody>
				<?php foreach ( $reps as $u ) : ?><tr><td><?php echo esc_html( $u->display_name ); ?></td><td><?php echo esc_html( $u->user_email ); ?></td><td><?php echo esc_html( in_array( 'administrator', (array) $u->roles, true ) ? 'WordPress administrator' : 'Sales representative' ); ?></td></tr><?php endforeach; ?>
				</tbody></table>
				<?php if ( current_user_can( 'ssp_manage_staff_users' ) ) : ?>
					<h3>Add a sales representative</h3>
					<?php UI::form( 'staff_user_create', 'class="ssa-row"' ); ?><label>Name <input type="text" name="name" required></label><label>Email <input type="email" name="email" required></label><button class="ssa-btn" type="submit">Create</button><?php UI::end(); ?>
					<p class="ssa-muted ssa-small">Enforce two-factor authentication for staff (e.g. the "Two Factor" plugin). See docs/DEPLOYMENT.md.</p>
				<?php endif; ?>
			</div>
			<div class="ssa-card">
				<h2>Role permissions</h2>
				<?php
				self::settings_form(
					'roles',
					function () {
						self::field( 'reps_can_view_audit_log', 'Sales representatives can view the full audit log (they always see history on each record)', 'checkbox' );
					}
				);
				?>
				<p class="ssa-small">Sales representatives have global operational visibility: all customers and pre-orders, approvals, products and prices, allocations and waitlists, availability, boxes, shipments, invoices, reports and staff resources. Platform configuration, integrations, staff users and settings are limited to administrators.</p>
			</div>
		</div>
		<?php
	}

	private static function decisions() {
		$rows = array(
			array( 'D-1', 'Waitlist promotion', Settings::get( 'waitlist_mode' ) . ', ' . Settings::get( 'waitlist_hold_hours' ) . 'h', 'Settings > Waitlist' ),
			array( 'D-2', 'Open boxes per customer', Settings::get( 'max_open_boxes' ), 'Settings > Box' ),
			array( 'D-3', 'Address change after box creation', Settings::get( 'address_change_until' ), 'Settings > Box' ),
			array( 'D-4', 'Fixed-rate tier values', 'Draft tiers from original T&C', 'Settings > Rate tiers' ),
			array( 'D-5', 'Shipping invoice timing', 'Staff chooses in the invoice wizard', 'Invoices' ),
			array( 'D-6', 'Cancellation policy', Settings::get( 'zero_qty_cancels' ) ? 'Qty 0 before close cancels; staff after close with reason' : 'Staff only', 'Settings > Orders' ),
			array( 'D-7', 'Email sender and wording', Settings::get( 'email_from_name' ), 'Settings > Email' ),
			array( 'D-8', 'Report measures', 'Ordered, Invoiced, Paid side by side', 'Reports' ),
			array( 'D-9', 'In-stock workflow', 'Same as presale; editable until ' . Settings::get( 'instock_editable_until' ), 'Settings > Orders' ),
			array( 'D-10', 'Archive data source', 'CSV importer ready', 'Archive > Import' ),
			array( 'D-11', 'Warehouse platform / authority', Settings::get( 'warehouse_adapter' ), 'Integrations > Warehouse' ),
			array( 'D-12', 'Spot-based pricing at invoice', 'Staff enters final price', 'Products, Invoices' ),
			array( 'D-13', 'Closing time and timezone', Settings::get( 'default_closing_time' ) . ' ' . Settings::get( 'business_timezone' ), 'Settings > General' ),
			array( 'D-14', 'Order numbering', 'Starts at ' . Settings::get( 'order_number_start' ), 'Settings > Orders' ),
			array( 'D-15', 'Confirmation email / Q8 wording', Settings::get( 'order_confirmation_email' ) ? 'Email on' : 'On-screen only', 'Settings > Orders / Questions' ),
			array( 'D-16', 'SMS notifications', 'Consent stored; no SMS sending', 'Future' ),
			array( 'D-19', 'Ship My Box with unavailable items', Settings::get( 'ship_unavailable_mode' ), 'Settings > Box' ),
			array( 'D-23', 'Audit log visibility for reps', Settings::get( 'reps_can_view_audit_log' ) ? 'Reps can view' : 'Admins only', 'Settings > Staff' ),
			array( 'D-27', 'Minimum quantity scope', Settings::get( 'min_qty_scope' ), 'Settings > Orders' ),
			array( 'D-30', 'QuickBooks item mapping', Settings::get( 'qbo_item_strategy' ), 'Integrations > QuickBooks' ),
		);
		echo '<div class="ssa-card"><h2>Open business decisions</h2><p class="ssa-muted">Each item runs on the proposed default today and can be changed without code. See the architecture document Section 14.</p><table class="ssa-table"><thead><tr><th>ID</th><th>Decision</th><th>Current setting</th><th>Where to change</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><td>' . esc_html( $r[0] ) . '</td><td>' . esc_html( $r[1] ) . '</td><td>' . esc_html( (string) $r[2] ) . '</td><td>' . esc_html( $r[3] ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}
}
