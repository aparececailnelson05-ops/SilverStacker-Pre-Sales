<?php
namespace SSP\Admin;

use SSP\Core\Jobs;
use SSP\Domain\Customers;

defined( 'ABSPATH' ) || exit;

class Menu {

	public static function register() {
		$pending = Customers::count_by_status()['pending'] ?? 0;
		$errors  = Jobs::failing_count();
		$bubble  = fn( $n ) => $n ? ' <span class="awaiting-mod">' . (int) $n . '</span>' : '';

		add_menu_page( 'Silver Stacker', 'Silver Stacker' . $bubble( $pending ), 'ssp_staff', 'ssp-dashboard', array( DashboardScreen::class, 'render' ), 'dashicons-database', 2 );
		$pages = array(
			array( 'ssp-dashboard', 'Dashboard', 'ssp_staff', DashboardScreen::class ),
			array( 'ssp-customers', 'Customers' . $bubble( $pending ), 'ssp_view_all_customers', CustomersScreen::class ),
			array( 'ssp-products', 'Products', 'ssp_manage_products', ProductsScreen::class ),
			array( 'ssp-archive', 'Archive', 'ssp_manage_products', ArchiveScreen::class ),
			array( 'ssp-orders', 'Orders / Pre-Orders', 'ssp_view_all_orders', OrdersScreen::class ),
			array( 'ssp-allocation', 'Allocation & Waitlist', 'ssp_manage_allocations', AllocationScreen::class ),
			array( 'ssp-tracker', 'Pre-Sale Tracker', 'ssp_view_all_orders', TrackerScreen::class ),
			array( 'ssp-boxes', 'Boxes & Shipments', 'ssp_manage_boxes', BoxesScreen::class ),
			array( 'ssp-invoices', 'Invoices', 'ssp_create_invoices', InvoicesScreen::class ),
			array( 'ssp-reports', 'Reports', 'ssp_view_reports', ReportsScreen::class ),
			array( 'ssp-integrations', 'Integrations' . $bubble( $errors ), 'ssp_retry_integration_jobs', IntegrationsScreen::class ),
			array( 'ssp-resources', 'Staff Resources', 'ssp_view_staff_resources', ResourcesScreen::class ),
			array( 'ssp-settings', 'Settings', 'ssp_manage_settings', SettingsScreen::class ),
			array( 'ssp-audit', 'Audit Log', 'ssp_view_audit_log', AuditScreen::class ),
		);
		// The portal does not use blog posts or comments; hide them to keep the console focused.
		remove_menu_page( 'edit.php' );
		remove_menu_page( 'edit-comments.php' );
		foreach ( $pages as $p ) {
			add_submenu_page( 'ssp-dashboard', wp_strip_all_tags( $p[1] ), $p[1], $p[2], $p[0], array( $p[3], 'render' ) );
		}
	}
}
