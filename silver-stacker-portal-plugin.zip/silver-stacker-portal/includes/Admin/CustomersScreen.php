<?php
namespace SSP\Admin;

use SSP\Core\Util;
use SSP\Domain\Addresses;
use SSP\Domain\Boxes;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Terms;
use SSP\Domain\Waitlist;

defined( 'ABSPATH' ) || exit;

class CustomersScreen {

	public static function render() {
		if ( UI::get( 'view' ) ) {
			self::detail( (int) UI::get( 'view' ) );
			return;
		}
		$args   = array(
			'q'       => UI::get( 'q' ),
			'status'  => UI::get( 'status' ),
			'orderby' => UI::get( 'orderby', 'created' ),
			'paged'   => (int) UI::get( 'paged', 1 ),
		);
		$res    = Customers::search( $args );
		$counts = Customers::count_by_status();
		$actions = '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::export_url( 'customers' ) ) . '">Export CSV</a> <button class="ssa-btn" type="button" data-toggle="#ssa-invite">+ Invite customer</button>';
		UI::open( 'Customers', 'Individual customer accounts. Every person registers separately; company/store name is profile information only.', $actions );
		?>
		<div id="ssa-invite" class="ssa-card" hidden>
			<h2>Invite a customer</h2>
			<p class="ssa-muted">Sends a registration link. The customer completes their own account, addresses and qualification questions, and then appears here as Pending approval.</p>
			<?php UI::form( 'customer_invite', 'class="ssa-row"' ); ?>
				<label>Name <input type="text" name="name" required></label>
				<label>Email <input type="email" name="email" required></label>
				<button class="ssa-btn" type="submit">Send invitation</button>
			<?php UI::end(); ?>
		</div>
		<div class="ssa-statusbar">
			<?php foreach ( array( '' => 'All' ) + Customers::STATUSES as $k => $l ) : ?>
				<a href="<?php echo esc_url( UI::url( 'ssp-customers', array( 'status' => $k ) ) ); ?>" class="<?php echo $args['status'] === $k ? 'is-active' : ''; ?>"><?php echo esc_html( $l ); ?> <span><?php echo '' === $k ? (int) array_sum( $counts ) : (int) $counts[ $k ]; ?></span></a>
			<?php endforeach; ?>
		</div>
		<form class="ssa-filters" method="get">
			<input type="hidden" name="page" value="ssp-customers"><input type="hidden" name="status" value="<?php echo esc_attr( $args['status'] ); ?>">
			<input type="search" name="q" value="<?php echo esc_attr( $args['q'] ); ?>" placeholder="Search name, company, email, phone">
			<?php echo UI::select( 'orderby', array( 'created' => 'Newest first', 'name' => 'Company A-Z', 'last_order' => 'Last order' ), $args['orderby'] ); // phpcs:ignore ?>
			<button class="ssa-btn ssa-btn--ghost" type="submit">Search</button>
		</form>
		<table class="ssa-table ssa-table--hover">
			<thead><tr><th>Customer name / company</th><th>Primary contact</th><th>Email</th><th>Account created</th><th>Last order date</th><th>Status</th></tr></thead>
			<tbody>
			<?php foreach ( $res['rows'] as $c ) : ?>
				<tr>
					<td><a href="<?php echo esc_url( UI::url( 'ssp-customers', array( 'view' => $c->user_id ) ) ); ?>"><strong><?php echo esc_html( $c->company_name ); ?></strong></a></td>
					<td><?php echo esc_html( $c->contact_name ); ?></td>
					<td><?php echo esc_html( $c->email ); ?></td>
					<td><?php echo esc_html( Util::fmt_date( $c->created_at ) ); ?></td>
					<td><?php echo esc_html( $c->last_order_at ? Util::fmt_date( $c->last_order_at ) : 'None' ); ?></td>
					<td><?php echo ssp_badge( Customers::STATUSES[ $c->status ], ssp_status_kind( $c->status ) ); // phpcs:ignore ?></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( ! $res['rows'] ) : ?><tr><td colspan="6" class="ssa-muted">No customers found.</td></tr><?php endif; ?>
			</tbody>
		</table>
		<?php
		UI::pager( $res['total'], 50, $args['paged'], 'ssp-customers', array_filter( $args ) );
		UI::close();
	}

	private static function detail( $uid ) {
		$p = Customers::profile( $uid );
		if ( ! $p ) {
			UI::open( 'Customer not found' );
			UI::close();
			return;
		}
		$u       = get_userdata( $uid );
		$billing = Addresses::default_for( $uid, 'billing' );
		$ship    = Addresses::list_for( $uid, 'shipping' );
		$orders  = Orders::staff_orders( array( 'user_id' => $uid, 'per_page' => 25 ) )['rows'];
		$box     = Boxes::open_box( $uid );
		$invs    = Invoices::staff_list( array( 'user_id' => $uid ) );
		$wl      = Waitlist::for_user( $uid );
		UI::open( $p->company_name, esc_html( $p->contact_name ) . ' &middot; ' . ssp_badge( Customers::STATUSES[ $p->status ], ssp_status_kind( $p->status ) ), '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::url( 'ssp-customers' ) ) . '">&larr; All customers</a>' );
		?>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Account decision</h2>
				<?php $next = Customers::TRANSITIONS[ $p->status ] ?? array(); ?>
				<?php if ( $next ) : ?>
					<?php UI::form( 'customer_status' ); ?>
						<input type="hidden" name="user_id" value="<?php echo (int) $uid; ?>">
						<div class="ssa-row">
							<?php foreach ( $next as $s ) : ?>
								<label class="ssa-radio"><input type="radio" name="status" value="<?php echo esc_attr( $s ); ?>" required> <?php echo esc_html( array( 'approved' => 'Approve', 'rejected' => 'Reject', 'suspended' => 'Suspend (deactivate)' )[ $s ] ); ?></label>
							<?php endforeach; ?>
						</div>
						<label class="ssa-block">Reason (required to reject or suspend; included in the email)<textarea name="reason" rows="2"></textarea></label>
						<label><input type="checkbox" name="notify" value="1" checked> Email the customer</label>
						<p><button class="ssa-btn" type="submit">Save decision</button></p>
					<?php UI::end(); ?>
				<?php endif; ?>
				<?php if ( $p->status_reason ) : ?><p class="ssa-muted">Last reason: <?php echo esc_html( $p->status_reason ); ?></p><?php endif; ?>
				<?php if ( $p->approved_at ) : ?><p class="ssa-muted">Approved <?php echo esc_html( Util::fmt_dt( $p->approved_at ) ); ?></p><?php endif; ?>
				<p class="ssa-flex">
					<?php UI::button( 'customer_reset_password', array( 'user_id' => $uid ), 'Send password reset', 'ssa-btn ssa-btn--ghost' ); ?>
				</p>
			</div>
			<div class="ssa-card">
				<h2>Contact</h2>
				<?php UI::form( 'customer_update' ); ?>
					<input type="hidden" name="user_id" value="<?php echo (int) $uid; ?>">
					<table class="ssa-kv">
						<tr><th>Customer ID</th><td><code><?php echo esc_html( $p->customer_uid ); ?></code></td></tr>
						<tr><th>Contact</th><td><input type="text" name="contact_name" value="<?php echo esc_attr( $p->contact_name ); ?>"></td></tr>
						<tr><th>Company / store</th><td><input type="text" name="company_name" value="<?php echo esc_attr( $p->company_name ); ?>"></td></tr>
						<tr><th>Email</th><td><?php echo esc_html( $p->email ); ?> (login: <?php echo esc_html( $u ? $u->user_login : '' ); ?>)</td></tr>
						<tr><th>Phone</th><td><input type="text" name="phone" value="<?php echo esc_attr( $p->phone ); ?>"></td></tr>
						<tr><th>Created on</th><td><?php echo esc_html( Util::fmt_dt( $p->created_at ) ); ?></td></tr>
						<tr><th>Last login</th><td><?php echo esc_html( $p->last_login_at ? Util::fmt_dt( $p->last_login_at ) : 'Never' ); ?></td></tr>
						<tr><th>Consent</th><td>Email <?php echo $p->email_consent ? 'yes' : 'no'; ?> &middot; Text <?php echo $p->sms_consent ? 'yes' : 'no'; ?></td></tr>
						<tr><th>Price list</th><td>Default (USD), same for all approved customers</td></tr>
						<tr><th>Payment terms</th><td>Managed in QuickBooks Online<?php echo $p->qbo_customer_id ? ' (QBO customer ' . esc_html( $p->qbo_customer_id ) . ')' : ''; ?></td></tr>
						<tr><th>Staff notes</th><td><textarea name="staff_notes" rows="2"><?php echo esc_textarea( (string) $p->staff_notes ); ?></textarea></td></tr>
					</table>
					<button class="ssa-btn ssa-btn--ghost" type="submit">Save contact</button>
				<?php UI::end(); ?>
			</div>
		</div>

		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Addresses</h2>
				<h3>Billing</h3><p><?php echo nl2br( esc_html( Addresses::format( $billing ) ) ); ?></p>
				<h3>Shipping</h3>
				<?php foreach ( $ship as $a ) : ?><p><?php echo $a->is_default ? ssp_badge( 'Default', 'brand' ) . '<br>' : ''; // phpcs:ignore ?><?php echo nl2br( esc_html( Addresses::format( $a ) ) ); ?></p><?php endforeach; ?>
			</div>
			<div class="ssa-card">
				<h2>Sign-up answers</h2>
				<?php foreach ( Customers::answers( $uid ) as $a ) : ?>
					<div class="ssa-answer">
						<p class="ssa-q"><?php echo esc_html( $a->question_text ); ?></p>
						<?php UI::form( 'customer_answer', 'class="ssa-flex"' ); ?>
							<input type="hidden" name="answer_id" value="<?php echo (int) $a->id; ?>">
							<input type="text" name="answer_text" value="<?php echo esc_attr( $a->answer_text ); ?>" class="<?php echo Customers::is_yes( $a->answer_text ) ? 'is-yes' : ( preg_match( '/^\s*no\b/i', $a->answer_text ) ? 'is-no' : '' ); ?>">
							<button class="ssa-btn ssa-btn--ghost ssa-btn--sm" type="submit">Edit</button>
						<?php UI::end(); ?>
					</div>
				<?php endforeach; ?>
				<h3>Terms acceptance</h3>
				<ul><?php foreach ( Terms::acceptances( $uid ) as $ta ) : ?><li>v<?php echo esc_html( $ta->version_label ); ?> &middot; <?php echo esc_html( Util::fmt_dt( $ta->accepted_at ) ); ?> &middot; IP <?php echo esc_html( $ta->ip ); ?></li><?php endforeach; ?></ul>
			</div>
		</div>

		<div class="ssa-card">
			<h2>Orders</h2>
			<table class="ssa-table"><thead><tr><th>Order #</th><th>Date</th><th class="num">Total</th><th>Status</th></tr></thead><tbody>
			<?php foreach ( $orders as $o ) : ?>
				<tr><td><a href="<?php echo esc_url( UI::url( 'ssp-orders', array( 'order' => $o->order_number ) ) ); ?>">#<?php echo (int) $o->order_number; ?></a></td><td><?php echo esc_html( Util::fmt_dt( $o->submitted_at ) ); ?></td><td class="num"><?php echo esc_html( Util::money( $o->subtotal_usd ) ); ?></td><td><?php echo ssp_badge( Orders::ORDER_STATUSES[ $o->status ] ?? $o->status, ssp_status_kind( $o->status ) ); // phpcs:ignore ?></td></tr>
			<?php endforeach; ?>
			<?php if ( ! $orders ) : ?><tr><td colspan="4" class="ssa-muted">No orders.</td></tr><?php endif; ?>
			</tbody></table>
		</div>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Open box</h2>
				<?php if ( $box ) : ?><?php $tt = Boxes::totals( $box->id ); ?><p><a href="<?php echo esc_url( UI::url( 'ssp-boxes', array( 'box' => $box->id ) ) ); ?>">Box #<?php echo (int) $box->box_number; ?></a>: <?php echo (int) $tt['units']; ?> units (<?php echo (int) $tt['available']; ?> available)</p><?php else : ?><p class="ssa-muted">No open box.</p><?php endif; ?>
				<h2>Waitlist</h2>
				<?php foreach ( $wl as $w ) : ?><p><?php $v = \SSP\Domain\Catalog::variant( $w->variant_id ); echo esc_html( ( $v ? $v->sku : '' ) . ' x' . $w->qty_requested . ' ' ); echo ssp_badge( Waitlist::STATUSES[ $w->status ], ssp_status_kind( $w->status ) ); // phpcs:ignore ?></p><?php endforeach; ?>
				<?php if ( ! $wl ) : ?><p class="ssa-muted">None.</p><?php endif; ?>
			</div>
			<div class="ssa-card">
				<h2>Invoices</h2>
				<?php foreach ( $invs as $i ) : ?><p><a href="<?php echo esc_url( UI::url( 'ssp-invoices', array( 'invoice' => $i->id ) ) ); ?>"><?php echo esc_html( $i->doc_number ? $i->doc_number : 'Invoice ' . $i->id ); ?></a> <?php echo esc_html( Util::money( $i->total_usd ) ); ?> <?php echo ssp_badge( Invoices::payment_label( $i ), ssp_status_kind( $i->sync_status ) ); // phpcs:ignore ?></p><?php endforeach; ?>
				<?php if ( ! $invs ) : ?><p class="ssa-muted">None.</p><?php endif; ?>
				<p><a class="ssa-btn ssa-btn--ghost" href="<?php echo esc_url( UI::url( 'ssp-invoices', array( 'new' => $uid ) ) ); ?>">Create invoice from available lines</a></p>
			</div>
		</div>
		<?php
		UI::history( 'customer', $uid );
		UI::close();
	}
}
