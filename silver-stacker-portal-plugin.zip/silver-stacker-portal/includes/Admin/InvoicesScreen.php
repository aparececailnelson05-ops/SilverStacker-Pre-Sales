<?php
namespace SSP\Admin;

use SSP\Core\Util;
use SSP\Domain\Boxes;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Shipments;
use SSP\Integrations\Qbo;

defined( 'ABSPATH' ) || exit;

class InvoicesScreen {

	public static function render() {
		if ( UI::get( 'new' ) ) {
			self::wizard( (int) UI::get( 'new' ) );
			return;
		}
		if ( UI::get( 'invoice' ) ) {
			self::detail( (int) UI::get( 'invoice' ) );
			return;
		}
		$ready = Invoices::customers_ready();
		$list  = Invoices::staff_list( array( 'status' => UI::get( 'status' ), 'q' => UI::get( 'q' ) ) );
		UI::open( 'Invoices', 'Staff-selected invoicing. QuickBooks Online creates the invoice, calculates tax, emails it and collects payment. ' . ( Qbo::is_connected() ? ssp_badge( 'QuickBooks connected', 'ok' ) : ssp_badge( 'QuickBooks not connected', 'danger' ) . ' <a href="' . esc_url( UI::url( 'ssp-integrations' ) ) . '">Connect</a>' ), '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::export_url( 'invoices' ) ) . '">Export CSV</a>' );
		?>
		<div class="ssa-card">
			<h2>Ready to invoice</h2>
			<table class="ssa-table"><thead><tr><th>Customer</th><th class="num">Lines</th><th class="num">Units</th><th class="num">Amount (order prices)</th><th></th></tr></thead><tbody>
			<?php foreach ( $ready as $r ) : ?>
				<tr><td><?php echo UI::customer_link( $r->user_id, $r->company_name . ' (' . $r->contact_name . ')' ); // phpcs:ignore ?></td><td class="num"><?php echo (int) $r->line_count; ?></td><td class="num"><?php echo (int) $r->units; ?></td><td class="num"><?php echo esc_html( Util::money( $r->amount ) ); ?></td><td><a class="ssa-btn ssa-btn--sm" href="<?php echo esc_url( UI::url( 'ssp-invoices', array( 'new' => $r->user_id ) ) ); ?>">Select lines &amp; invoice</a></td></tr>
			<?php endforeach; ?>
			<?php if ( ! $ready ) : ?><tr><td colspan="5" class="ssa-muted">No available, uninvoiced lines. Mark items available in the Pre-Sale Tracker first.</td></tr><?php endif; ?>
			</tbody></table>
		</div>
		<form class="ssa-filters" method="get"><input type="hidden" name="page" value="ssp-invoices"><?php echo UI::select( 'status', array( '' => 'Any status' ) + Invoices::SYNC_STATUSES, UI::get( 'status' ) ); // phpcs:ignore ?><input type="search" name="q" value="<?php echo esc_attr( UI::get( 'q' ) ); ?>" placeholder="Invoice # or customer"><button class="ssa-btn ssa-btn--ghost">Filter</button></form>
		<table class="ssa-table ssa-table--hover"><thead><tr><th>Invoice #</th><th>Customer</th><th>Date</th><th>Due</th><th class="num">Total</th><th class="num">Amount due</th><th>Status</th><th>Source</th></tr></thead><tbody>
		<?php foreach ( $list as $i ) : ?>
			<tr><td><a href="<?php echo esc_url( UI::url( 'ssp-invoices', array( 'invoice' => $i->id ) ) ); ?>"><strong><?php echo esc_html( $i->doc_number ? $i->doc_number : '(#' . $i->id . ')' ); ?></strong></a></td><td><?php echo esc_html( $i->company_name ); ?></td><td><?php echo esc_html( Util::fmt_date( $i->txn_date ? $i->txn_date : $i->created_at ) ); ?></td><td><?php echo esc_html( Util::fmt_date( $i->due_date ) ); ?></td><td class="num"><?php echo esc_html( Util::money( $i->total_usd ) ); ?></td><td class="num"><?php echo esc_html( Util::money( $i->balance_usd ) ); ?></td><td><?php echo ssp_badge( Invoices::payment_label( $i ), ssp_status_kind( $i->sync_status ) ); // phpcs:ignore ?></td><td><?php echo esc_html( 'manual' === $i->source ? 'Recorded manually' : 'QuickBooks' ); ?></td></tr>
		<?php endforeach; ?>
		<?php if ( ! $list ) : ?><tr><td colspan="8" class="ssa-muted">No invoices yet.</td></tr><?php endif; ?>
		</tbody></table>
		<?php
		UI::close();
	}

	private static function wizard( $uid ) {
		$c     = Customers::profile( $uid );
		$lines = Invoices::eligible_lines( $uid );
		$ships = array_filter( Shipments::for_user( $uid ), fn( $s ) => ! $s->shipping_invoice_id && 'cancelled' !== $s->status );
		UI::open( 'New invoice: ' . Customers::display_name( $c ), 'Select available, uninvoiced lines. Confirm quantities and prices, then create the invoice in QuickBooks. Lines are marked invoiced only after QuickBooks confirms.', '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::url( 'ssp-invoices' ) ) . '">&larr; Invoices</a>' );
		if ( ! $lines && ! $ships ) {
			echo '<div class="ssa-card ssa-muted">No available, uninvoiced lines for this customer.</div>';
			UI::close();
			return;
		}
		UI::form( 'invoice_create', 'data-invoice-form' );
		?>
		<input type="hidden" name="user_id" value="<?php echo (int) $uid; ?>">
		<input type="hidden" name="action_nonce" value="<?php echo esc_attr( wp_generate_password( 20, false ) ); ?>">
		<div class="ssa-card">
			<table class="ssa-table">
				<thead><tr><th><input type="checkbox" data-check-all checked aria-label="Select all"></th><th>Order</th><th>Item</th><th>Box</th><th class="num">Ordered</th><th class="num">Available</th><th class="num">Invoiced</th><th class="num">Qty to invoice</th><th class="num">Unit price</th><th class="num">Amount</th></tr></thead>
				<tbody>
				<?php foreach ( $lines as $l ) : ?>
					<?php $max = Invoices::invoiceable_qty( $l ); $box = Boxes::line_box( $l->id ); ?>
					<tr data-line>
						<td><input type="checkbox" name="sel[<?php echo (int) $l->id; ?>][on]" value="1" checked></td>
						<td>#<?php echo (int) $l->order_number; ?><br><span class="ssa-small ssa-muted"><?php echo esc_html( Util::fmt_date( $l->submitted_at ) ); ?></span></td>
						<td><?php echo esc_html( $l->name_snapshot ); ?><br><span class="ssa-small ssa-muted"><?php echo esc_html( $l->sku_snapshot ); ?></span> <?php echo 'spot_based' === $l->price_type ? ssp_badge( 'Spot-based: enter final price', 'warn' ) : ''; // phpcs:ignore ?></td>
						<td><?php echo $box ? 'Box #' . (int) Boxes::get( $box )->box_number : esc_html( Orders::FULFILLMENT_BADGE[ $l->fulfillment_choice ] ); ?></td>
						<td class="num"><?php echo (int) Orders::net( $l ); ?></td>
						<td class="num"><?php echo (int) $l->qty_available; ?></td>
						<td class="num"><?php echo (int) $l->qty_invoiced; ?></td>
						<td class="num"><input type="number" name="sel[<?php echo (int) $l->id; ?>][qty]" value="<?php echo (int) $max; ?>" min="1" max="<?php echo (int) $max; ?>" style="width:64px" data-qty></td>
						<td class="num"><input type="text" name="sel[<?php echo (int) $l->id; ?>][unit_price]" value="<?php echo esc_attr( number_format( (float) $l->unit_price_usd, 2, '.', '' ) ); ?>" size="8" data-price <?php echo 'spot_based' === $l->price_type ? 'class="ssa-attn"' : ''; ?>></td>
						<td class="num" data-amount></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr><td colspan="9" class="num">Subtotal (before tax; QuickBooks calculates tax)</td><td class="num" data-subtotal></td></tr></tfoot>
			</table>
		</div>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<h2>Shipping (optional)</h2>
				<p class="ssa-muted">Add shipping to this invoice (decision D-5: confirm whether shipping goes on the item invoice, a new invoice at shipment, or separately).</p>
				<div class="ssa-row">
					<label>Amount <input type="text" name="shipping_amount" placeholder="0.00" size="8" data-ship></label>
					<label>Description <input type="text" name="shipping_description" value="Shipping"></label>
					<?php if ( $ships ) : ?>
						<label>For shipment <?php
						$o = array( '' => 'Not linked' );
						foreach ( $ships as $s ) {
							$o[ $s->id ] = ( $s->box_id ? 'Box shipment ' : 'Shipment ' ) . $s->tracking_number . ( null !== $s->shipping_charge_usd ? ' (' . Util::money( $s->shipping_charge_usd ) . ')' : '' );
						}
						echo UI::select( 'shipment_id', $o, '' ); // phpcs:ignore
						?></label>
					<?php endif; ?>
				</div>
			</div>
			<div class="ssa-card">
				<h2>Create</h2>
				<label class="ssa-radio"><input type="radio" name="mode" value="qbo" checked <?php disabled( ! Qbo::is_connected() ); ?>> Create in QuickBooks Online (recommended)</label>
				<?php if ( ! Qbo::is_connected() ) : ?><p class="ssa-warn">QuickBooks is not connected. <a href="<?php echo esc_url( UI::url( 'ssp-integrations' ) ); ?>">Connect QuickBooks</a> or record an invoice you created manually in QuickBooks.</p><?php endif; ?>
				<label class="ssa-radio"><input type="radio" name="mode" value="manual" <?php checked( ! Qbo::is_connected() ); ?>> Record an invoice already created manually in QuickBooks</label>
				<div class="ssa-row" data-manual>
					<label>QBO invoice # <input type="text" name="manual[doc_number]"></label>
					<label>Invoice date <input type="date" name="manual[txn_date]" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></label>
					<label>Due date <input type="date" name="manual[due_date]"></label>
					<label>Total incl. tax <input type="text" name="manual[total]" size="8"></label>
					<label>Pay link <input type="url" name="manual[pay_link]"></label>
				</div>
				<p class="ssa-muted ssa-small">Manually recorded invoices never show as paid in the portal (only QuickBooks can confirm payment).</p>
				<p><button class="ssa-btn" type="submit">Create invoice</button></p>
			</div>
		</div>
		<?php
		UI::end();
		UI::close();
	}

	private static function detail( $id ) {
		$i = Invoices::get( $id );
		if ( ! $i ) {
			UI::open( 'Invoice not found' );
			UI::close();
			return;
		}
		$c = Customers::profile( $i->user_id );
		UI::open( 'Invoice ' . ( $i->doc_number ? $i->doc_number : '#' . $i->id ), UI::customer_link( $i->user_id, Customers::display_name( $c ) ) . ' &middot; ' . ssp_badge( Invoices::payment_label( $i ), ssp_status_kind( $i->sync_status ) ), '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( UI::url( 'ssp-invoices' ) ) . '">&larr; Invoices</a>' );
		if ( 'error' === $i->sync_status ) {
			echo '<div class="notice notice-error"><p><strong>QuickBooks error:</strong> ' . esc_html( $i->error_message ) . '</p><p>The lines are held as "pending invoice" and were NOT marked invoiced. Fix the cause (e.g. connect QuickBooks or set the income account) and click Retry. Retrying reuses the same request ID, so QuickBooks will not create a duplicate.</p></div>';
		}
		?>
		<div class="ssa-grid2">
			<div class="ssa-card">
				<table class="ssa-kv">
					<tr><th>Portal invoice ID</th><td><code><?php echo esc_html( $i->invoice_uid ); ?></code></td></tr>
					<tr><th>QuickBooks ID / number</th><td><?php echo esc_html( (string) $i->qbo_invoice_id ); ?> / <?php echo esc_html( $i->doc_number ); ?></td></tr>
					<tr><th>Request ID (idempotency)</th><td><code><?php echo esc_html( $i->qbo_request_id ); ?></code></td></tr>
					<tr><th>Invoice date</th><td><?php echo esc_html( Util::fmt_date( $i->txn_date ) ); ?></td></tr>
					<tr><th>Due date</th><td><?php echo esc_html( Util::fmt_date( $i->due_date ) ); ?></td></tr>
					<tr><th>Total</th><td><?php echo esc_html( Util::money( $i->total_usd ) ); ?></td></tr>
					<tr><th>Amount due</th><td><?php echo esc_html( Util::money( $i->balance_usd ) ); ?></td></tr>
					<tr><th>Pay link</th><td><?php echo $i->pay_link ? '<a href="' . esc_url( $i->pay_link ) . '" target="_blank" rel="noopener">Open</a>' : ''; // phpcs:ignore ?></td></tr>
					<tr><th>Last synced</th><td><?php echo esc_html( Util::fmt_dt( $i->last_synced_at ) ); ?></td></tr>
					<tr><th>Created by</th><td><?php $u = get_userdata( (int) $i->created_by ); echo esc_html( $u ? $u->display_name : '' ); ?> on <?php echo esc_html( Util::fmt_dt( $i->created_at ) ); ?></td></tr>
				</table>
			</div>
			<div class="ssa-card">
				<h2>Actions</h2>
				<div class="ssa-flex">
					<?php if ( 'qbo' === $i->source ) : ?><?php UI::button( 'invoice_refresh', array( 'invoice_id' => $id ), in_array( $i->sync_status, array( 'error', 'queued', 'creating' ), true ) ? 'Retry creating in QuickBooks' : 'Refresh status from QuickBooks', 'ssa-btn' ); ?><?php endif; ?>
					<?php if ( $i->qbo_invoice_id && Invoices::is_final( $i ) ) : ?><a class="ssa-btn ssa-btn--ghost" href="<?php echo esc_url( home_url( '/portal/invoices/' . strtolower( $i->invoice_uid ) . '/pdf/' ) ); ?>" target="_blank">PDF</a><?php endif; ?>
				</div>
				<?php if ( in_array( $i->sync_status, array( 'queued', 'error' ), true ) ) : ?>
					<?php UI::form( 'invoice_cancel', 'class="ssa-mt"' ); ?>
						<input type="hidden" name="invoice_id" value="<?php echo (int) $id; ?>">
						<label class="ssa-block">Cancel this unsynced invoice (releases the lines). Reason <input type="text" name="reason" required></label>
						<button class="ssa-btn ssa-btn--danger" type="submit">Cancel invoice</button>
					<?php UI::end(); ?>
				<?php endif; ?>
				<p class="ssa-muted ssa-small">To void a synced invoice, void it in QuickBooks; the portal updates automatically and the lines become invoiceable again.</p>
			</div>
		</div>
		<div class="ssa-card">
			<h2>Lines</h2>
			<table class="ssa-table"><thead><tr><th>Type</th><th>Order</th><th>Item / description</th><th class="num">Qty</th><th class="num">Unit price</th><th class="num">Amount</th></tr></thead><tbody>
			<?php foreach ( Invoices::lines( $id ) as $il ) : ?>
				<tr><td><?php echo esc_html( $il->type ); ?></td><td><?php echo $il->order_number ? '<a href="' . esc_url( UI::url( 'ssp-orders', array( 'order' => $il->order_number ) ) ) . '">#' . (int) $il->order_number . '</a>' : ''; // phpcs:ignore ?></td><td><?php echo esc_html( $il->description ); ?></td><td class="num"><?php echo (int) $il->qty; ?></td><td class="num"><?php echo esc_html( Util::money( $il->unit_price_usd ) ); ?></td><td class="num"><?php echo esc_html( Util::money( $il->amount_usd ) ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
		</div>
		<?php
		UI::history( 'invoice', $id );
		UI::close();
	}
}
