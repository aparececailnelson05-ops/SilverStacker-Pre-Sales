<?php
namespace SSP\Admin;

use SSP\Portal\Flash;

defined( 'ABSPATH' ) || exit;

/** Small helpers for staff console markup. */
class UI {

	public static function url( $page, array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => $page ), $args ), admin_url( 'admin.php' ) );
	}

	public static function form( $do, $attrs = '', $multipart = false ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $multipart ? ' enctype="multipart/form-data"' : '' ) . ' ' . $attrs . '>'; // phpcs:ignore
		echo '<input type="hidden" name="action" value="ssp_admin"><input type="hidden" name="do" value="' . esc_attr( $do ) . '">';
		wp_nonce_field( 'ssp_admin_' . $do );
	}

	public static function end() {
		echo '</form>';
	}

	/** One-button POST form. */
	public static function button( $do, array $fields, $label, $class = 'ssa-btn', $confirm_note = '' ) {
		self::form( $do, 'class="ssa-inline"' );
		foreach ( $fields as $k => $v ) {
			echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
		}
		echo '<button type="submit" class="' . esc_attr( $class ) . '"' . ( $confirm_note ? ' data-confirm="' . esc_attr( $confirm_note ) . '"' : '' ) . '>' . esc_html( $label ) . '</button>';
		self::end();
	}

	public static function export_url( $what, array $args = array() ) {
		return wp_nonce_url( add_query_arg( array_merge( array( 'ssp_export' => $what ), $args ), admin_url( 'admin.php' ) ), 'ssp_export_' . $what );
	}

	public static function open( $title, $subtitle = '', $actions = '' ) {
		echo '<div class="wrap ssa"><div class="ssa-head"><div><h1>' . esc_html( $title ) . '</h1>';
		if ( $subtitle ) {
			echo '<p class="ssa-sub">' . wp_kses_post( $subtitle ) . '</p>';
		}
		echo '</div><div class="ssa-actions">' . $actions . '</div></div>'; // phpcs:ignore
		foreach ( Flash::take() as $f ) {
			$type = 'success' === $f['type'] ? 'success' : ( 'error' === $f['type'] ? 'error' : 'info' );
			echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible ssa-notice"><p>' . esc_html( $f['message'] ) . '</p></div>';
		}
	}

	public static function close() {
		echo '</div>';
	}

	public static function tabs( $page, array $tabs, $current, array $keep = array(), $param = 'tab' ) {
		echo '<nav class="ssa-tabs" aria-label="Sections">';
		foreach ( $tabs as $k => $label ) {
			echo '<a href="' . esc_url( self::url( $page, array_merge( $keep, array( $param => $k ) ) ) ) . '"' . ( $k === $current ? ' class="is-active" aria-current="page"' : '' ) . '>' . wp_kses_post( $label ) . '</a>';
		}
		echo '</nav>';
	}

	public static function pager( $total, $per, $page, $page_slug, array $args ) {
		$pages = (int) ceil( $total / max( 1, $per ) );
		if ( $pages <= 1 ) {
			echo '<p class="ssa-muted">' . (int) $total . ' item(s)</p>';
			return;
		}
		echo '<div class="ssa-pager"><span>' . (int) $total . ' item(s) &middot; page ' . (int) $page . ' of ' . (int) $pages . '</span>';
		if ( $page > 1 ) {
			echo '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( self::url( $page_slug, array_merge( $args, array( 'paged' => $page - 1 ) ) ) ) . '">&laquo; Prev</a>';
		}
		if ( $page < $pages ) {
			echo '<a class="ssa-btn ssa-btn--ghost" href="' . esc_url( self::url( $page_slug, array_merge( $args, array( 'paged' => $page + 1 ) ) ) ) . '">Next &raquo;</a>';
		}
		echo '</div>';
	}

	public static function get( $k, $d = '' ) {
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : $d;
	}

	public static function select( $name, array $options, $selected, $attrs = '' ) {
		$h = '<select name="' . esc_attr( $name ) . '" ' . $attrs . '>';
		foreach ( $options as $v => $l ) {
			$h .= '<option value="' . esc_attr( $v ) . '"' . selected( (string) $selected, (string) $v, false ) . '>' . esc_html( $l ) . '</option>';
		}
		return $h . '</select>';
	}

	public static function customer_link( $user_id, $label ) {
		return '<a href="' . esc_url( self::url( 'ssp-customers', array( 'view' => (int) $user_id ) ) ) . '">' . esc_html( $label ) . '</a>';
	}

	public static function history( $object_type, $object_id ) {
		if ( ! current_user_can( 'ssp_view_record_history' ) ) {
			return;
		}
		$rows = \SSP\Core\Audit::for_object( $object_type, $object_id, 50 );
		echo '<details class="ssa-card"><summary><strong>Record history</strong> (' . count( $rows ) . ')</summary><table class="ssa-table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Change</th><th>Reason</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$u = $r->actor_user_id ? get_userdata( $r->actor_user_id ) : null;
			echo '<tr><td>' . esc_html( \SSP\Core\Util::fmt_dt( $r->created_at ) ) . '</td><td>' . esc_html( $u ? $u->display_name : 'System' ) . '</td><td><code>' . esc_html( $r->action ) . '</code></td><td class="ssa-small">' . esc_html( self::diff_text( $r ) ) . '</td><td>' . esc_html( (string) $r->reason ) . '</td></tr>';
		}
		echo '</tbody></table></details>';
	}

	public static function diff_text( $r ) {
		$b = json_decode( (string) $r->before_json, true );
		$a = json_decode( (string) $r->after_json, true );
		$parts = array();
		if ( is_array( $a ) ) {
			foreach ( $a as $k => $v ) {
				$old     = is_array( $b ) && array_key_exists( $k, $b ) ? $b[ $k ] : null;
				$parts[] = $k . ': ' . ( null === $old ? '' : ( is_scalar( $old ) ? $old : wp_json_encode( $old ) ) . ' → ' ) . ( is_scalar( $v ) || null === $v ? (string) $v : wp_json_encode( $v ) );
			}
		} elseif ( is_array( $b ) ) {
			$parts[] = 'removed: ' . wp_json_encode( $b );
		}
		return substr( implode( '; ', $parts ), 0, 400 );
	}
}
