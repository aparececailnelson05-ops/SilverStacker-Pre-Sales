<?php
namespace SSP\Admin;

use SSP\Core\Installer;
use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Allocation;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Waitlist;

defined( 'ABSPATH' ) || exit;

class AllocationScreen {

	public static function render() {
		$tab = UI::get( 'tab', 'allocation' );
		UI::open( 'Allocation & Waitlist', 'Total and per-customer allocation, overrides (always logged with reason) and waitlist releases. Waitlist mode: <strong>' . esc_html( Settings::get( 'waitlist_mode' ) ) . '</strong> (hold window ' . (int) Settings::get( 'waitlist_hold_hours' ) . 'h; decision D-1, configurable in Settings).' );
		UI::tabs( 'ssp-allocation', array( 'allocation' => 'Allocations', 'waitlist' => 'Waitlists', 'overrides' => 'Override log' ), $tab );
		if ( 'waitlist' === $tab ) {
			self::waitlist();
		} elseif ( 'overrides' === $tab ) {
			self::overrides();
		} else {
			self::allocation();
		}
		UI::close();
	}

	private static function allocation() {
		global $wpdb;
		$t   = Installer::tables();
		$q   = UI::get( 'q' );
		$sql = "SELECT v.*, p.name AS product_name, p.lifecycle, p.closing_at FROM {$t['variants']} v JOIN {$t['products']} p ON p.id=v.product_id WHERE p.lifecycle IN ('presale','presale_ended','in_stock')";
		if ( $q ) {
			$like = '%' . $wpdb->esc_like( $q ) . '%';
			$sql .= $wpdb->prepare( ' AND (p.name LIKE %s OR v.sku LIKE %s)', $like, $like );
		}
		$rows      = $wpdb->get_results( $sql . ' ORDER BY p.closing_at IS NULL, p.closing_at ASC, p.id, v.sort LIMIT 500' );
		$customers = Customers::all_approved();
		$opts      = array( '' => 'Choose customer' );
		foreach ( $customers as $c ) {
			$opts[ $c->user_id ] = Customers::display_name( $c );
		}
		?>
		<form class="ssa-filters" method="get"><input type="hidden" name="page" value="ssp-allocation"><input type="search" name="q" value="<?php echo esc_attr( $q ); ?>" placeholder="Product or SKU"><button class="ssa-btn ssa-btn--ghost">Search</button></form>
		<table class="ssa-table ssa-table--hover">
			<thead><tr><th>Product / SKU</th><th>Status</th><th class="num">Total</th><th class="num">Overrides</th><th class="num">Per customer</th><th class="num">Reserved</th><th class="num">Held</th><th class="num">Remaining</th><th class="num">Waitlist</th><th>Override</th></tr></thead>
			<tbody>
			<?php foreach ( $rows as $v ) : ?>
				<?php
				$s  = Allocation::summary( $v );
				$wl = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['waitlist']} WHERE variant_id=%d AND status IN ('waiting','offered')", $v->id ) );
				?>
				<tr>
					<td><a href="<?php echo esc_url( UI::url( 'ssp-products', array( 'edit' => $v->product_id, 'tab' => 'variants' ) ) ); ?>"><?php echo esc_html( $v->product_name ); ?></a><br><span class="ssa-muted ssa-small"><?php echo esc_html( $v->sku . ( $v->label ? ' / ' . $v->label : '' ) ); ?></span></td>
					<td><?php echo ssp_badge( Catalog::lifecycle_label( (object) array( 'lifecycle' => $v->lifecycle, 'closing_at' => $v->closing_at ) ), ssp_status_kind( $v->lifecycle ) ); // phpcs:ignore ?></td>
					<td class="num"><?php echo null === $v->total_allocation ? '&infin;' : (int) $v->total_allocation; ?></td>
					<td class="num"><?php echo (int) $s['overrides']; ?></td>
					<td class="num"><?php echo null === $v->per_customer_allocation ? '&infin;' : (int) $v->per_customer_allocation; ?></td>
					<td class="num"><?php echo (int) $s['reserved']; ?></td>
					<td class="num"><?php echo (int) $s['held']; ?></td>
					<td class="num"><strong><?php echo null === $s['remaining'] ? '&infin;' : (int) $s['remaining']; ?></strong></td>
					<td class="num"><?php echo $wl ? '<a href="' . esc_url( UI::url( 'ssp-allocation', array( 'tab' => 'waitlist', 'variant_id' => $v->id ) ) ) . '">' . (int) $wl . '</a>' : '0'; // phpcs:ignore ?></td>
					<td>
						<details><summary class="ssa-link">Override&hellip;</summary>
						<?php UI::form( 'override_add', 'class="ssa-mini"' ); ?>
							<input type="hidden" name="variant_id" value="<?php echo (int) $v->id; ?>">
							<?php echo UI::select( 'override_type', array( 'total' => 'Add to total allocation', 'per_customer' => 'Raise one customer\'s limit', 'minimum' => 'Waive minimum for a customer' ), 'total' ); // phpcs:ignore ?>
							<?php echo UI::select( 'user_id', $opts, '' ); // phpcs:ignore ?>
							<label>Extra qty <input type="number" name="qty" value="1" style="width:70px"></label>
							<label class="ssa-block">Reason (required) <input type="text" name="reason" required></label>
							<button class="ssa-btn ssa-btn--sm" type="submit">Record override</button>
						<?php UI::end(); ?>
						</details>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	private static function waitlist() {
		$rows = Waitlist::staff_list( array( 'variant_id' => (int) UI::get( 'variant_id' ), 'status' => UI::get( 'status' ) ) );
		$by   = array();
		foreach ( $rows as $r ) {
			$by[ $r->variant_id ][] = $r;
		}
		?>
		<form class="ssa-filters" method="get"><input type="hidden" name="page" value="ssp-allocation"><input type="hidden" name="tab" value="waitlist">
			<?php echo UI::select( 'status', array( '' => 'Active (waiting + offered)' ) + Waitlist::STATUSES, UI::get( 'status' ) ); // phpcs:ignore ?>
			<button class="ssa-btn ssa-btn--ghost">Filter</button></form>
		<?php if ( ! $by ) : ?><div class="ssa-card ssa-muted">No waitlist entries.</div><?php endif; ?>
		<?php foreach ( $by as $vid => $list ) : ?>
			<?php $v = Catalog::variant( $vid ); ?>
			<div class="ssa-card">
				<div class="ssa-between"><h2 class="ssa-mb0"><?php echo esc_html( $list[0]->product_name . ' / ' . $list[0]->sku ); ?></h2>
				<span>Remaining allocation: <strong><?php echo $v ? ( null === Allocation::remaining_total( $v ) ? 'unlimited' : (int) Allocation::remaining_total( $v ) ) : ''; ?></strong> <?php UI::button( 'waitlist_process', array( 'variant_id' => $vid ), 'Release to waitlist now', 'ssa-btn ssa-btn--sm' ); ?></span></div>
				<table class="ssa-table ssa-mt"><thead><tr><th>#</th><th>Customer</th><th class="num">Qty wanted</th><th>Status</th><th class="num">Held</th><th>Offer expires</th><th>Joined</th><th></th></tr></thead><tbody>
				<?php foreach ( $list as $i => $w ) : ?>
					<tr><td><?php echo (int) ( $i + 1 ); ?></td><td><?php echo UI::customer_link( $w->user_id, $w->company_name . ' (' . $w->contact_name . ')' ); // phpcs:ignore ?></td><td class="num"><?php echo (int) $w->qty_requested; ?></td><td><?php echo ssp_badge( Waitlist::STATUSES[ $w->status ], ssp_status_kind( $w->status ) ); // phpcs:ignore ?></td><td class="num"><?php echo (int) $w->offered_qty; ?></td><td><?php echo esc_html( Util::fmt_dt( $w->offer_expires_at ) ); ?></td><td><?php echo esc_html( Util::fmt_dt( $w->created_at ) ); ?></td>
					<td><?php if ( in_array( $w->status, array( 'waiting', 'offered' ), true ) ) : ?><?php UI::form( 'waitlist_cancel', 'class="ssa-inline"' ); ?><input type="hidden" name="waitlist_id" value="<?php echo (int) $w->id; ?>"><input type="text" name="reason" placeholder="Reason" required style="width:120px"> <button class="ssa-btn ssa-btn--sm ssa-btn--danger">Cancel</button><?php UI::end(); ?><?php endif; ?></td></tr>
				<?php endforeach; ?>
				</tbody></table>
			</div>
		<?php endforeach; ?>
		<?php
	}

	private static function overrides() {
		global $wpdb;
		$t    = Installer::tables();
		$rows = $wpdb->get_results( "SELECT o.*, v.sku, p.name FROM {$t['overrides']} o JOIN {$t['variants']} v ON v.id=o.variant_id JOIN {$t['products']} p ON p.id=v.product_id ORDER BY o.id DESC LIMIT 300" );
		?>
		<table class="ssa-table"><thead><tr><th>When</th><th>Staff</th><th>Product / SKU</th><th>Type</th><th>Customer</th><th class="num">Qty</th><th>Reason</th></tr></thead><tbody>
		<?php foreach ( $rows as $r ) : ?>
			<?php $staff = get_userdata( $r->staff_id ); $c = $r->user_id ? Customers::profile( $r->user_id ) : null; ?>
			<tr><td><?php echo esc_html( Util::fmt_dt( $r->created_at ) ); ?></td><td><?php echo esc_html( $staff ? $staff->display_name : '' ); ?></td><td><?php echo esc_html( $r->name . ' / ' . $r->sku ); ?></td><td><?php echo esc_html( $r->override_type ); ?></td><td><?php echo esc_html( Customers::display_name( $c ) ); ?></td><td class="num"><?php echo (int) $r->qty; ?></td><td><?php echo esc_html( $r->reason ); ?></td></tr>
		<?php endforeach; ?>
		<?php if ( ! $rows ) : ?><tr><td colspan="7" class="ssa-muted">No overrides recorded.</td></tr><?php endif; ?>
		</tbody></table>
		<?php
	}
}
