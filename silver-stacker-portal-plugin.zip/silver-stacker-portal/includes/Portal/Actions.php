<?php
namespace SSP\Portal;

use SSP\Core\Roles;
use SSP\Core\Security;
use SSP\Domain\Addresses;
use SSP\Domain\Boxes;
use SSP\Domain\Cart;
use SSP\Domain\Customers;
use SSP\Domain\Orders;
use SSP\Domain\Terms;
use SSP\Domain\Waitlist;

defined( 'ABSPATH' ) || exit;

/**
 * POST handlers (Post/Redirect/Get). Every handler verifies a nonce (CSRF), the user's role
 * and status (via the Router gate) and ownership of every object it touches.
 */
class Actions {

	private static function verify( $action ) {
		$nonce = isset( $_POST['_ssp_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_ssp_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'ssp_' . $action ) ) {
			Flash::add( 'error', 'Your session expired. Please try again.' );
			self::back();
		}
	}

	private static function back( $fallback = '' ) {
		$ref = wp_get_referer();
		wp_safe_redirect( $ref ? $ref : ( $fallback ? $fallback : home_url( '/portal/' ) ) );
		exit;
	}

	private static function go( $url ) {
		wp_safe_redirect( $url );
		exit;
	}

	private static function result( $r, $success, $to = '' ) {
		if ( is_wp_error( $r ) ) {
			Flash::from_error( $r );
		} elseif ( $success ) {
			Flash::add( 'success', $success );
		}
		$to ? self::go( $to ) : self::back();
	}

	private static function p( $key, $default = '' ) {
		return isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : $default; // phpcs:ignore
	}

	/* ---------------- Public forms ---------------- */

	public static function handle_public( array $seg ) {
		$action = sanitize_key( self::p( 'ssp_action' ) );
		switch ( $action ) {
			case 'login':
				self::verify( 'login' );
				$creds = array(
					'user_login'    => sanitize_text_field( self::p( 'log' ) ),
					'user_password' => (string) self::p( 'pwd' ),
					'remember'      => ! empty( $_POST['rememberme'] ),
				);
				// Allow logging in with email.
				if ( is_email( $creds['user_login'] ) ) {
					$u = get_user_by( 'email', $creds['user_login'] );
					if ( $u ) {
						$creds['user_login'] = $u->user_login;
					}
				}
				$user = wp_signon( $creds, is_ssl() );
				if ( is_wp_error( $user ) ) {
					$msg = 'too_many' === $user->get_error_code() ? $user->get_error_message() : 'The email/username or password is incorrect.';
					Flash::add( 'error', $msg );
					self::go( home_url( '/login/' ) );
				}
				wp_set_current_user( $user->ID );
				$redirect = self::p( 'redirect_to' );
				$redirect = $redirect && 0 === strpos( rawurldecode( $redirect ), '/portal' ) ? home_url( rawurldecode( $redirect ) ) : '';
				if ( Roles::is_staff( $user->ID ) ) {
					self::go( $redirect ? $redirect : admin_url( 'admin.php?page=ssp-dashboard' ) );
				}
				if ( ! Customers::is_approved( $user->ID ) ) {
					self::go( home_url( '/account-status/' ) );
				}
				self::go( $redirect ? $redirect : home_url( '/portal/' ) );
				break;

			case 'register':
				self::verify( 'register' );
				if ( ! empty( $_POST['website'] ) ) { // Honeypot.
					self::go( home_url( '/register/submitted/' ) );
				}
				if ( Security::rate_limited( 'register', 5, HOUR_IN_SECONDS ) ) {
					Flash::add( 'error', 'Too many registration attempts from your network. Please try again later.' );
					self::go( home_url( '/register/' ) );
				}
				$in = array(
					'contact_name'     => self::p( 'contact_name' ),
					'email'            => self::p( 'email' ),
					'phone'            => self::p( 'phone' ),
					'company_name'     => self::p( 'company_name' ),
					'password'         => self::p( 'password' ),
					'password_confirm' => self::p( 'password_confirm' ),
					'billing'          => (array) self::p( 'billing', array() ),
					'shipping'         => (array) self::p( 'shipping', array() ),
					'shipping_same'    => self::p( 'shipping_same' ),
					'answers'          => (array) self::p( 'answers', array() ),
					'agree_individual' => self::p( 'agree_individual' ),
					'invite_token'     => sanitize_text_field( self::p( 'invite_token' ) ),
				);
				$r = Customers::register( $in );
				if ( is_wp_error( $r ) ) {
					Flash::from_error( $r );
					$old = $in;
					unset( $old['password'], $old['password_confirm'] );
					Flash::set_data( 'register_old', $old );
					self::go( home_url( '/register/' . ( $in['invite_token'] ? '?invite=' . rawurlencode( $in['invite_token'] ) : '' ) ) );
				}
				self::go( home_url( '/register/submitted/' ) );
				break;

			case 'forgot':
				self::verify( 'forgot' );
				if ( ! Security::rate_limited( 'forgot', 5, HOUR_IN_SECONDS ) ) {
					$login = sanitize_text_field( self::p( 'user_login' ) );
					$user  = is_email( $login ) ? get_user_by( 'email', $login ) : get_user_by( 'login', $login );
					if ( $user ) {
						$key = get_password_reset_key( $user );
						if ( ! is_wp_error( $key ) ) {
							$url = home_url( '/reset-password/?login=' . rawurlencode( $user->user_login ) . '&key=' . rawurlencode( $key ) );
							wp_mail(
								$user->user_email,
								'Reset your Silver Stacker Pre-Sale password',
								\SSP\Core\Mailer::wrap( '<p>Someone requested a password reset for your account.</p><p><a href="' . esc_url( $url ) . '">Choose a new password</a></p><p>If this was not you, ignore this email.</p>' ),
								array( 'Content-Type: text/html; charset=UTF-8' )
							);
						}
					}
				}
				// Same message whether or not the account exists (no account enumeration).
				Flash::add( 'success', 'If an account exists for that email, a reset link has been sent.' );
				self::go( home_url( '/forgot-password/' ) );
				break;

			case 'reset':
				self::verify( 'reset' );
				$login = sanitize_user( self::p( 'login' ) );
				$key   = sanitize_text_field( self::p( 'key' ) );
				$user  = check_password_reset_key( $key, $login );
				if ( is_wp_error( $user ) ) {
					Flash::add( 'error', 'This reset link is invalid or has expired. Please request a new one.' );
					self::go( home_url( '/forgot-password/' ) );
				}
				$p1 = (string) self::p( 'pass1' );
				if ( strlen( $p1 ) < 10 || $p1 !== (string) self::p( 'pass2' ) ) {
					Flash::add( 'error', 'Passwords must match and be at least 10 characters.' );
					self::go( home_url( '/reset-password/?login=' . rawurlencode( $login ) . '&key=' . rawurlencode( $key ) ) );
				}
				reset_password( $user, $p1 );
				Flash::add( 'success', 'Your password was changed. Please log in.' );
				self::go( home_url( '/login/' ) );
				break;
		}
	}

	/* ---------------- Portal forms ---------------- */

	public static function handle_portal( array $seg ) {
		$uid    = get_current_user_id();
		$action = sanitize_key( self::p( 'ssp_action' ) );
		if ( '' === $action ) {
			return;
		}
		self::verify( $action );
		$is_customer = Roles::is_customer( $uid );

		// Ordering-related actions are only for customers (staff never place orders for customers, D-18).
		$customer_only = array( 'cart_add', 'cart_update', 'cart_remove', 'submit_order', 'line_amend', 'line_fulfillment', 'box_request', 'box_cancel_request', 'box_address', 'box_add_line', 'box_remove_line', 'waitlist_join', 'waitlist_accept', 'waitlist_cancel', 'address_save', 'address_default', 'address_delete', 'account_save', 'accept_terms' );
		if ( in_array( $action, $customer_only, true ) && ! $is_customer ) {
			Flash::add( 'error', 'Staff accounts cannot place or change customer orders from the portal. Use the staff console.' );
			self::back();
		}

		switch ( $action ) {
			case 'accept_terms':
				if ( empty( $_POST['agree'] ) ) {
					Flash::add( 'error', 'Please tick the box to confirm you have read and agree to the Terms & Conditions.' );
					self::back();
				}
				$r = Terms::accept( $uid, (int) self::p( 'terms_version_id' ) );
				self::result( $r, 'Thank you. Welcome to Silver Stacker Pre-Sales!', home_url( '/portal/' ) );
				break;

			case 'cart_add':
				$r = Cart::add( $uid, (int) self::p( 'variant_id' ), (int) self::p( 'qty', 1 ), sanitize_key( self::p( 'fulfillment' ) ) );
				if ( is_wp_error( $r ) ) {
					Flash::from_error( $r );
					self::back();
				}
				Flash::add( 'success', 'Added to your order. Review your cart and click Submit Pre-Order when you are ready.', array( 'link' => ssp_url( 'cart/' ), 'link_text' => 'View cart' ) );
				self::back();
				break;

			case 'cart_update':
				$items = (array) self::p( 'items', array() );
				foreach ( $items as $cid => $row ) {
					$r = Cart::update( $uid, (int) $cid, (int) ( $row['qty'] ?? 0 ), sanitize_key( $row['fulfillment'] ?? '' ) );
					if ( is_wp_error( $r ) ) {
						Flash::from_error( $r );
					}
				}
				Flash::add( 'success', 'Cart updated.' );
				if ( ! empty( $_POST['to_review'] ) ) {
					self::go( ssp_url( 'cart/review/' ) );
				}
				self::go( ssp_url( 'cart/' ) );
				break;

			case 'cart_remove':
				Cart::remove( $uid, (int) self::p( 'cart_id' ) );
				self::result( true, 'Item removed.', ssp_url( 'cart/' ) );
				break;

			case 'submit_order':
				$r = Orders::submit_cart( $uid, sanitize_text_field( self::p( 'submit_key' ) ), sanitize_textarea_field( self::p( 'customer_note' ) ) );
				if ( is_wp_error( $r ) ) {
					Flash::from_error( $r );
					self::go( ssp_url( 'cart/' ) );
				}
				$o = Orders::get( $r );
				self::go( ssp_url( 'orders/' . $o->order_number . '/confirmation/' ) );
				break;

			case 'line_amend':
				$r = Orders::customer_amend( $uid, sanitize_text_field( self::p( 'line_uid' ) ), (int) self::p( 'qty' ) );
				self::result( $r, 0 === (int) self::p( 'qty' ) ? 'The item was cancelled and its allocation released.' : 'Quantity updated.' );
				break;

			case 'line_fulfillment':
				$line = Orders::line_owned( $uid, sanitize_text_field( self::p( 'line_uid' ) ) );
				if ( ! $line ) {
					self::result( new \WP_Error( 'nf', 'Order line not found.' ), '' );
				}
				$r = Orders::set_fulfillment( (int) $line->id, sanitize_key( self::p( 'fulfillment' ) ), $uid );
				self::result( $r, 'Fulfillment choice saved.' );
				break;

			case 'box_add_line':
				$line = Orders::line_owned( $uid, sanitize_text_field( self::p( 'line_uid' ) ) );
				if ( ! $line ) {
					self::result( new \WP_Error( 'nf', 'Order line not found.' ), '' );
				}
				$r = Orders::set_fulfillment( (int) $line->id, 'box', $uid );
				self::result( $r, 'Added to My Box.' );
				break;

			case 'box_remove_line':
				$line = Orders::line_owned( $uid, sanitize_text_field( self::p( 'line_uid' ) ) );
				if ( ! $line ) {
					self::result( new \WP_Error( 'nf', 'Order line not found.' ), '' );
				}
				$r = Orders::set_fulfillment( (int) $line->id, 'decide_later', $uid );
				self::result( $r, 'Removed from My Box. It is now awaiting your fulfillment decision.' );
				break;

			case 'box_request':
				$box = Boxes::get_owned( $uid, sanitize_text_field( self::p( 'box_uid' ) ) );
				if ( ! $box ) {
					self::result( new \WP_Error( 'nf', 'Box not found.' ), '' );
				}
				if ( empty( $_POST['confirm'] ) ) {
					self::result( new \WP_Error( 'confirm', 'Please confirm the shipping address and contents before requesting shipment.' ), '' );
				}
				$r = Boxes::request_shipment( (int) $box->id, $uid, sanitize_key( self::p( 'mode', 'ship_available' ) ) );
				self::result( $r, 'Shipment requested! We will prepare your box and email you tracking details.' );
				break;

			case 'box_cancel_request':
				$box = Boxes::get_owned( $uid, sanitize_text_field( self::p( 'box_uid' ) ) );
				if ( ! $box ) {
					self::result( new \WP_Error( 'nf', 'Box not found.' ), '' );
				}
				self::result( Boxes::cancel_request( (int) $box->id, $uid ), 'Shipment request cancelled. Your box is open again.' );
				break;

			case 'box_address':
				$box = Boxes::get_owned( $uid, sanitize_text_field( self::p( 'box_uid' ) ) );
				if ( ! $box ) {
					self::result( new \WP_Error( 'nf', 'Box not found.' ), '' );
				}
				self::result( Boxes::set_address( (int) $box->id, (int) self::p( 'address_id' ), $uid ), 'Box shipping address updated.' );
				break;

			case 'waitlist_join':
				$r = Waitlist::join( $uid, (int) self::p( 'variant_id' ), (int) self::p( 'qty', 1 ) );
				self::result( $r, 'You are on the waitlist. We will email you if allocation becomes available.' );
				break;

			case 'waitlist_accept':
				$r = Waitlist::accept( $uid, sanitize_text_field( self::p( 'waitlist_uid' ) ), sanitize_key( self::p( 'fulfillment', 'decide_later' ) ) );
				if ( is_wp_error( $r ) ) {
					self::result( $r, '' );
				}
				$o = Orders::get( $r );
				self::go( ssp_url( 'orders/' . $o->order_number . '/confirmation/' ) );
				break;

			case 'waitlist_cancel':
				$e = Waitlist::get_owned( $uid, sanitize_text_field( self::p( 'waitlist_uid' ) ) );
				if ( ! $e ) {
					self::result( new \WP_Error( 'nf', 'Waitlist entry not found.' ), '' );
				}
				self::result( Waitlist::cancel( (int) $e->id, $uid ), 'You left the waitlist.' );
				break;

			case 'address_save':
				$data = (array) self::p( 'address', array() );
				$id   = (int) self::p( 'address_id' );
				if ( $id ) {
					$r = Addresses::update( $uid, $id, $data );
				} else {
					$clean = Addresses::sanitize( $data );
					$v     = Addresses::validate( $clean );
					$r     = is_wp_error( $v ) ? $v : Addresses::create( $uid, 'billing' === self::p( 'type' ) ? 'billing' : 'shipping', $clean, ! empty( $_POST['make_default'] ) );
				}
				self::result( $r, 'Address saved.', ssp_url( 'addresses/' ) );
				break;

			case 'address_default':
				self::result( Addresses::set_default( $uid, (int) self::p( 'address_id' ) ), 'Default address updated. Your open box will ship to this address.', ssp_url( 'addresses/' ) );
				break;

			case 'address_delete':
				self::result( Addresses::archive( $uid, (int) self::p( 'address_id' ) ), 'Address removed.', ssp_url( 'addresses/' ) );
				break;

			case 'account_save':
				$r = Customers::update_profile(
					$uid,
					array(
						'contact_name'     => self::p( 'contact_name' ),
						'company_name'     => self::p( 'company_name' ),
						'phone'            => self::p( 'phone' ),
						'email_consent'    => self::p( 'email_consent' ),
						'sms_consent'      => self::p( 'sms_consent' ),
						'consents_present' => 1,
					)
				);
				self::result( $r, 'Profile saved.' );
				break;

			case 'password_change':
				$user = wp_get_current_user();
				if ( ! wp_check_password( (string) self::p( 'current' ), $user->user_pass, $user->ID ) ) {
					self::result( new \WP_Error( 'pw', 'Your current password is incorrect.' ), '' );
				}
				$p1 = (string) self::p( 'pass1' );
				if ( strlen( $p1 ) < 10 || $p1 !== (string) self::p( 'pass2' ) ) {
					self::result( new \WP_Error( 'pw', 'New passwords must match and be at least 10 characters.' ), '' );
				}
				wp_set_password( $p1, $user->ID );
				wp_set_auth_cookie( $user->ID );
				\SSP\Core\Audit::log( 'customer.password_changed', 'customer', $user->ID );
				self::result( true, 'Password changed.' );
				break;
		}
	}
}
