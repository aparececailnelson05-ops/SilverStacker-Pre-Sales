<?php
namespace SSP\Portal;

use SSP\Core\Roles;
use SSP\Domain\Customers;
use SSP\Domain\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * Front-end router and access gate for the customer portal.
 *
 * Public routes (no catalog data): /login, /register, /register/submitted, /account-status,
 * /forgot-password, /reset-password. Everything under /portal requires login; customers must
 * also be approved and have accepted the current Terms & Conditions. Access is enforced here
 * on the server for every request, not by hiding links.
 */
class Router {

	const PUBLIC_ROUTES = array( 'login', 'register', 'account-status', 'forgot-password', 'reset-password' );

	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_rewrites' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'dispatch' ), 1 );
		add_filter( 'redirect_canonical', array( __CLASS__, 'no_canonical' ), 10, 2 );
	}

	public static function add_rewrites() {
		add_rewrite_rule( '^(login|register|account-status|forgot-password|reset-password)(/(.*))?/?$', 'index.php?ssp_route=$matches[1]/$matches[3]', 'top' );
		add_rewrite_rule( '^portal/?$', 'index.php?ssp_route=portal', 'top' );
		add_rewrite_rule( '^portal/(.+?)/?$', 'index.php?ssp_route=portal/$matches[1]', 'top' );
	}

	public static function query_vars( $v ) {
		$v[] = 'ssp_route';
		return $v;
	}

	public static function no_canonical( $redirect, $requested ) {
		return get_query_var( 'ssp_route' ) ? false : $redirect;
	}

	public static function dispatch() {
		$route = trim( (string) get_query_var( 'ssp_route' ), '/' );
		if ( '' === $route ) {
			// Front page: send to the right place.
			if ( is_front_page() || is_home() ) {
				wp_safe_redirect( is_user_logged_in() ? home_url( '/portal/' ) : home_url( '/login/' ) );
				exit;
			}
			return; // Security::gate_non_portal handles every other WP URL.
		}
		$seg = array_values( array_filter( explode( '/', $route ), 'strlen' ) );
		$seg = array_map( 'sanitize_text_field', $seg );

		nocache_headers();
		header( 'Cache-Control: private, no-store, no-cache, must-revalidate' );
		header( 'X-Robots-Tag: noindex, nofollow' );

		$is_post = 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? 'GET' );

		if ( in_array( $seg[0], self::PUBLIC_ROUTES, true ) ) {
			if ( $is_post ) {
				Actions::handle_public( $seg );
			}
			Pages::public_route( $seg );
			exit;
		}

		if ( 'portal' !== $seg[0] ) {
			status_header( 404 );
			exit;
		}
		array_shift( $seg );
		$page = $seg[0] ?? '';

		if ( 'logout' === $page ) {
			if ( is_user_logged_in() && isset( $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'ssp_logout' ) ) {
				wp_logout();
			}
			wp_safe_redirect( home_url( '/login/?loggedout=1' ) );
			exit;
		}

		if ( ! is_user_logged_in() ) {
			// Media/resource URLs must never reveal anything to visitors.
			if ( in_array( $page, array( 'media', 'resource' ), true ) ) {
				status_header( 404 );
				exit;
			}
			$req = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			wp_safe_redirect( add_query_arg( 'redirect_to', rawurlencode( $req ), home_url( '/login/' ) ) );
			exit;
		}

		$uid      = get_current_user_id();
		$is_staff = Roles::is_staff( $uid );

		if ( ! $is_staff ) {
			if ( ! Roles::is_customer( $uid ) ) {
				wp_safe_redirect( home_url( '/account-status/' ) );
				exit;
			}
			if ( ! Customers::is_approved( $uid ) ) {
				if ( in_array( $page, array( 'media', 'resource' ), true ) ) {
					status_header( 404 );
					exit;
				}
				wp_safe_redirect( home_url( '/account-status/' ) );
				exit;
			}
			if ( ! Terms::has_accepted_current( $uid ) && 'terms' !== $page ) {
				if ( in_array( $page, array( 'media', 'resource' ), true ) ) {
					status_header( 404 );
					exit;
				}
				wp_safe_redirect( home_url( '/portal/terms/' ) );
				exit;
			}
		}

		if ( 'resource' === $page && ! current_user_can( 'ssp_view_staff_resources' ) ) {
			status_header( 404 );
			exit;
		}

		if ( $is_post ) {
			Actions::handle_portal( $seg );
		}
		Pages::portal_route( $seg );
		exit;
	}
}
