<?php
namespace SSP\Portal;

use SSP\Domain\Allocation;

defined( 'ABSPATH' ) || exit;

/** Small presentation helper for allocation numbers on customer pages. */
class Allocation_View {

	public static function max( $variant, $user_id ) {
		return Allocation::max_addable( $variant, $user_id );
	}
}
