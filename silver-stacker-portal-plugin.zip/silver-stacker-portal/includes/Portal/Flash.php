<?php
namespace SSP\Portal;

defined( 'ABSPATH' ) || exit;

/** One-time messages across the POST/redirect/GET cycle. */
class Flash {

	private static function key() {
		if ( is_user_logged_in() ) {
			return 'ssp_flash_u' . get_current_user_id();
		}
		$c = isset( $_COOKIE['ssp_fk'] ) ? preg_replace( '/[^a-zA-Z0-9]/', '', (string) $_COOKIE['ssp_fk'] ) : '';
		if ( strlen( $c ) < 20 ) {
			$c = wp_generate_password( 24, false );
			if ( ! headers_sent() ) {
				setcookie( 'ssp_fk', $c, array( 'expires' => time() + 3600, 'path' => COOKIEPATH ? COOKIEPATH : '/', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
			}
			$_COOKIE['ssp_fk'] = $c;
		}
		return 'ssp_flash_g' . $c;
	}

	public static function add( $type, $message, array $extra = array() ) {
		$k   = self::key();
		$all = get_transient( $k );
		$all = is_array( $all ) ? $all : array();
		$all[] = array( 'type' => $type, 'message' => $message, 'extra' => $extra );
		set_transient( $k, $all, 300 );
	}

	public static function from_error( \WP_Error $e ) {
		foreach ( $e->get_error_messages() as $m ) {
			self::add( 'error', $m );
		}
		$data = $e->get_error_data();
		if ( is_array( $data ) && ! empty( $data['line_errors'] ) ) {
			self::set_data( 'line_errors', $data['line_errors'] );
		}
	}

	public static function set_data( $name, $value ) {
		set_transient( self::key() . '_d_' . $name, $value, 300 );
	}

	public static function data( $name ) {
		$k = self::key() . '_d_' . $name;
		$v = get_transient( $k );
		delete_transient( $k );
		return $v;
	}

	public static function take() {
		$k   = self::key();
		$all = get_transient( $k );
		delete_transient( $k );
		return is_array( $all ) ? $all : array();
	}
}
