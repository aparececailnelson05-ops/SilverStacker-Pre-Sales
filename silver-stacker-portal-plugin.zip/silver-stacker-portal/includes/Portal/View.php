<?php
namespace SSP\Portal;

defined( 'ABSPATH' ) || exit;

/**
 * Renders plugin templates inside a layout. A theme may override any template by placing a
 * file at {theme}/silver-stacker/{template}.php.
 */
class View {

	public static function path( $template ) {
		$template = preg_replace( '/[^a-z0-9\-\/_]/', '', $template );
		$theme    = locate_template( 'silver-stacker/' . $template . '.php' );
		return $theme ? $theme : SSP_DIR . 'templates/' . $template . '.php';
	}

	public static function partial( $template, array $vars = array() ) {
		extract( $vars, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract
		include self::path( 'partials/' . $template );
	}

	public static function enqueue() {
		wp_enqueue_style( 'ssp-fonts', 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap', array(), null );
		wp_enqueue_style( 'ssp-portal', SSP_URL . 'assets/css/portal.css', array(), SSP_VERSION );
		wp_enqueue_script( 'ssp-portal', SSP_URL . 'assets/js/portal.js', array(), SSP_VERSION, true );
		// Keep the portal lean: no emoji/global block styles from the theme.
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		wp_dequeue_style( 'global-styles' );
		wp_dequeue_style( 'wp-block-library' );
	}

	public static function render( $template, array $vars = array(), $layout = 'portal', $title = '' ) {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ), 100 );
		$vars['flash'] = Flash::take();
		ob_start();
		extract( $vars, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract
		include self::path( $template );
		$content = ob_get_clean();
		$page_title = $title;
		include self::path( 'layout-' . $layout );
	}

	public static function not_found( $message = 'We could not find that page.' ) {
		status_header( 404 );
		self::render( 'portal/not-found', array( 'message' => $message ), 'portal', 'Not found' );
	}
}
