<?php
namespace SSP\Portal;

use SSP\Core\Media;
use SSP\Core\Roles;
use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Addresses;
use SSP\Domain\Boxes;
use SSP\Domain\Cart;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Shipments;
use SSP\Domain\Terms;
use SSP\Domain\Waitlist;
use SSP\Integrations\Qbo;

defined( 'ABSPATH' ) || exit;

/** GET page controllers. Every data read for a customer is scoped to the current user. */
class Pages {

	/* ---------------- Public ---------------- */

	public static function public_route( array $seg ) {
		switch ( $seg[0] ) {
			case 'login':
				if ( is_user_logged_in() ) {
					wp_safe_redirect( home_url( '/portal/' ) );
					exit;
				}
				View::render( 'public/login', array(), 'public', 'Log in' );
				return;
			case 'register':
				if ( 'submitted' === ( $seg[1] ?? '' ) ) {
					View::render( 'public/register-submitted', array(), 'public', 'Registration received' );
					return;
				}
				if ( is_user_logged_in() ) {
					wp_safe_redirect( home_url( '/portal/' ) );
					exit;
				}
				$invite = isset( $_GET['invite'] ) ? Customers::get_invite( sanitize_text_field( wp_unslash( $_GET['invite'] ) ) ) : null;
				View::render(
					'public/register',
					array(
						'questions'    => Customers::questions(),
						'old'          => is_array( $ssp_old = Flash::data( 'register_old' ) ) ? $ssp_old : array(),
						'invite'       => $invite,
						'invite_token' => $invite ? sanitize_text_field( wp_unslash( $_GET['invite'] ) ) : '',
					),
					'public',
					'Request access'
				);
				return;
			case 'account-status':
				$status  = null;
				$profile = null;
				if ( is_user_logged_in() ) {
					$profile = Customers::profile( get_current_user_id() );
					$status  = $profile ? $profile->status : 'none';
					if ( 'approved' === $status ) {
						wp_safe_redirect( home_url( '/portal/' ) );
						exit;
					}
				}
				View::render( 'public/account-status', array( 'status' => $status, 'profile' => $profile ), 'public', 'Account status' );
				return;
			case 'forgot-password':
				View::render( 'public/forgot', array(), 'public', 'Reset password' );
				return;
			case 'reset-password':
				$login = isset( $_GET['login'] ) ? sanitize_user( wp_unslash( $_GET['login'] ) ) : '';
				$key   = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
				$user  = $login && $key ? check_password_reset_key( $key, $login ) : new \WP_Error( 'invalid' );
				View::render( 'public/reset', array( 'valid' => ! is_wp_error( $user ), 'login' => $login, 'key' => $key ), 'public', 'Choose a new password' );
				return;
		}
		status_header( 404 );
	}

	/* ---------------- Portal ---------------- */

	public static function portal_route( array $seg ) {
		$uid  = get_current_user_id();
		$page = $seg[0] ?? '';
		switch ( $page ) {
			case '':
				return self::dashboard( $uid );
			case 'terms':
				$cur = Terms::current();
				return View::render( 'portal/terms', array( 'terms' => $cur, 'accepted' => Terms::has_accepted_current( $uid ) ), 'portal', 'Terms & Conditions' );
			case 'shop':
				return self::catalog( 'active', 'presale', 'Shop Pre-Sales' );
			case 'in-stock':
				return self::catalog( 'active', 'in_stock', 'In-Stock Products' );
			case 'archive':
				return self::catalog( 'archive', '', 'The Archive' );
			case 'search':
				$tab = ( isset( $_GET['tab'] ) && 'archive' === $_GET['tab'] ) ? 'archive' : 'active';
				return self::catalog( $tab, '', 'Search', true );
			case 'p':
				return self::product( $seg[1] ?? '' );
			case 'cart':
				return self::cart( $uid, 'review' === ( $seg[1] ?? '' ) );
			case 'orders':
				if ( ! empty( $seg[1] ) ) {
					return self::order( $uid, (int) $seg[1], 'confirmation' === ( $seg[2] ?? '' ) );
				}
				return self::orders( $uid );
			case 'box':
				if ( 'history' === ( $seg[1] ?? '' ) ) {
					return self::box_history( $uid );
				}
				return self::box( $uid );
			case 'invoices':
				if ( ! empty( $seg[1] ) && 'pdf' === ( $seg[2] ?? '' ) ) {
					return self::invoice_pdf( $uid, $seg[1] );
				}
				return self::invoices( $uid );
			case 'waitlist':
				return self::waitlist( $uid );
			case 'addresses':
				return View::render( 'portal/addresses', array( 'addresses' => Addresses::list_for( $uid, 'shipping' ), 'billing' => Addresses::list_for( $uid, 'billing' ), 'edit' => isset( $_GET['edit'] ) ? Addresses::get_owned( $uid, (int) $_GET['edit'] ) : null ), 'portal', 'Shipping Addresses' );
			case 'account':
				return View::render( 'portal/account', array( 'profile' => Customers::profile( $uid ), 'acceptances' => Terms::acceptances( $uid ) ), 'portal', 'My Account' );
			case 'media':
				return self::media( $seg[1] ?? '', $seg[2] ?? 'thumb' );
			case 'resource':
				return self::resource( $seg[1] ?? '' );
		}
		View::not_found();
	}

	private static function dashboard( $uid ) {
		$closing = Catalog::search( array( 'tab' => 'active', 'lifecycle' => 'presale', 'per_page' => 8, 'sort' => 'closing' ) );
		$box     = Roles::is_customer( $uid ) ? Boxes::open_box( $uid ) : null;
		View::render(
			'portal/dashboard',
			array(
				'closing'   => $closing['rows'],
				'counts'    => $closing['counts'],
				'box'       => $box,
				'box_tot'   => $box ? Boxes::totals( $box->id ) : null,
				'recent'    => Orders::customer_orders( $uid, array() )['rows'],
				'invoices'  => array_slice( array_filter( Invoices::for_user( $uid ), fn( $i ) => in_array( $i->sync_status, array( 'synced', 'partially_paid', 'overdue' ), true ) ), 0, 5 ),
				'offers'    => array_filter( Waitlist::for_user( $uid ), fn( $w ) => 'offered' === $w->status ),
				'profile'   => Customers::profile( $uid ),
			),
			'portal',
			'Dashboard'
		);
	}

	private static function catalog( $tab, $lifecycle, $title, $is_search = false ) {
		$args = array(
			'q'         => isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '',
			'tab'       => $tab,
			'metal'     => isset( $_GET['metal'] ) ? sanitize_text_field( wp_unslash( $_GET['metal'] ) ) : '',
			'brand'     => isset( $_GET['brand'] ) ? sanitize_text_field( wp_unslash( $_GET['brand'] ) ) : '',
			'category'  => isset( $_GET['category'] ) ? sanitize_text_field( wp_unslash( $_GET['category'] ) ) : '',
			'lifecycle' => $lifecycle ? $lifecycle : ( isset( $_GET['lifecycle'] ) ? sanitize_key( $_GET['lifecycle'] ) : '' ),
			'sort'      => isset( $_GET['sort'] ) ? sanitize_key( $_GET['sort'] ) : '',
			'paged'     => isset( $_GET['pg'] ) ? max( 1, (int) $_GET['pg'] ) : 1,
			'per_page'  => 24,
		);
		$res = Catalog::search( $args );
		View::render(
			'portal/catalog',
			array(
				'res'       => $res,
				'args'      => $args,
				'is_search' => $is_search,
				'base'      => $is_search ? ssp_url( 'search/' ) : ( 'archive' === $tab ? ssp_url( 'archive/' ) : ( 'in_stock' === $lifecycle ? ssp_url( 'in-stock/' ) : ssp_url( 'shop/' ) ) ),
				'title'     => $title,
				'lifecycle_fixed' => $lifecycle,
				'announcement' => Settings::get( 'announcement' ),
			),
			'portal',
			$title
		);
	}

	private static function product( $uid_slug ) {
		$p = Catalog::by_uid( strtoupper( (string) $uid_slug ) );
		if ( ! $p || 'draft' === $p->lifecycle && ! Roles::is_staff() ) {
			return View::not_found( 'This product is not available.' );
		}
		$user     = get_current_user_id();
		$variants = Catalog::variants( $p->id, true );
		$info     = array();
		foreach ( $variants as $v ) {
			$info[ $v->id ] = array(
				'max'      => Allocation_View::max( $v, $user ),
				'mine'     => \SSP\Domain\Allocation::customer_reserved( $v->id, $user ),
				'label'    => \SSP\Domain\Allocation::availability_label( $v ),
				'waitlist' => Waitlist::active_entry( $user, $v->id ),
			);
		}
		View::render(
			'portal/product',
			array(
				'p'        => $p,
				'variants' => $variants,
				'images'   => Catalog::images( $p->id ),
				'info'     => $info,
				'orderable'=> Catalog::is_orderable( $p ),
				'is_customer' => Roles::is_customer( $user ),
			),
			'portal',
			Catalog::display_name( $p )
		);
	}

	private static function cart( $uid, $review ) {
		$items = Cart::items( $uid );
		$rows  = array();
		$total = 0;
		foreach ( $items as $it ) {
			$v = Catalog::variant( $it->variant_id );
			$p = $v ? Catalog::get( $v->product_id ) : null;
			if ( ! $v || ! $p ) {
				continue;
			}
			$rows[] = array( 'item' => $it, 'v' => $v, 'p' => $p, 'img' => Catalog::primary_image( $p->id ) );
			$total += (int) $it->qty * (float) $v->price_usd;
		}
		$errors = Cart::validate( $uid );
		if ( $review && ( ! $rows || $errors ) ) {
			if ( $errors ) {
				Flash::add( 'error', 'Please fix the items marked below before submitting.' );
			}
			wp_safe_redirect( ssp_url( 'cart/' ) );
			exit;
		}
		$line_errors = Flash::data( 'line_errors' );
		View::render(
			$review ? 'portal/review' : 'portal/cart',
			array(
				'rows'        => $rows,
				'total'       => $total,
				'errors'      => $errors,
				'line_errors' => is_array( $line_errors ) ? $line_errors : array(),
				'submit_key'  => wp_generate_password( 32, false ),
				'is_customer' => Roles::is_customer( $uid ),
			),
			'portal',
			$review ? 'Review & Submit' : 'Cart'
		);
	}

	private static function orders( $uid ) {
		$args = array(
			'q'      => isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '',
			'status' => isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : '',
			'from'   => isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '',
			'to'     => isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '',
			'paged'  => isset( $_GET['pg'] ) ? (int) $_GET['pg'] : 1,
		);
		$res = Orders::customer_orders( $uid, $args );
		$lines = array();
		foreach ( $res['rows'] as $o ) {
			$lines[ $o->id ] = Orders::lines( $o->id );
		}
		View::render( 'portal/orders', array( 'res' => $res, 'args' => $args, 'lines' => $lines ), 'portal', 'My Orders' );
	}

	private static function order( $uid, $number, $confirmation ) {
		$o = Orders::get_owned( $uid, $number );
		if ( ! $o ) {
			return View::not_found( 'Order not found.' );
		}
		$lines = Orders::lines( $o->id );
		$extra = array();
		foreach ( $lines as $l ) {
			$p   = Catalog::get( $l->product_id );
			$box = Boxes::line_box( $l->id );
			$extra[ $l->id ] = array(
				'product'  => $p,
				'img'      => $p ? Catalog::primary_image( $p->id ) : null,
				'can_edit' => Orders::customer_can_amend( $l, $p ),
				'can_ful'  => Orders::can_change_fulfillment( $l ),
				'box'      => $box ? Boxes::get( $box ) : null,
				'invoices' => Invoices::for_line( $l->id ),
				'shipments'=> Shipments::for_line( $l->id ),
				'variant'  => Catalog::variant( $l->variant_id ),
			);
		}
		View::render( 'portal/order', array( 'o' => $o, 'lines' => $lines, 'extra' => $extra, 'confirmation' => $confirmation ), 'portal', 'Order #' . $o->order_number );
	}

	private static function box( $uid ) {
		$boxes = Boxes::active_boxes( $uid );
		$data  = array();
		foreach ( $boxes as $b ) {
			$items = Boxes::items( $b->id );
			$ext   = array();
			foreach ( $items as $it ) {
				$p = Catalog::get( $it->product_id );
				$ext[ $it->id ] = array(
					'p'        => $p,
					'img'      => $p ? Catalog::primary_image( $p->id ) : null,
					'invoices' => Invoices::for_line( $it->id ),
				);
			}
			$data[] = array(
				'box'   => $b,
				'items' => $items,
				'ext'   => $ext,
				'tot'   => Boxes::totals( $b->id ),
				'tier'  => $b->rate_tier_id ? Shipments::tier( $b->rate_tier_id ) : null,
			);
		}
		// Eligible lines that could be added to the box (decide later / separate, not shipped).
		global $wpdb;
		$lt = \SSP\Core\Installer::tables()['lines'];
		$ot = \SSP\Core\Installer::tables()['orders'];
		$eligible = $wpdb->get_results( $wpdb->prepare( "SELECT l.*, o.order_number FROM {$lt} l JOIN {$ot} o ON o.id=l.order_id WHERE l.user_id=%d AND l.fulfillment_choice IN ('decide_later','separate') AND (l.qty_ordered-l.qty_cancelled) > l.qty_shipped ORDER BY o.submitted_at DESC LIMIT 100", $uid ) );
		$eligible = array_filter( $eligible, fn( $l ) => true === Orders::can_change_fulfillment( $l ) );
		View::render(
			'portal/box',
			array(
				'boxes'     => $data,
				'eligible'  => $eligible,
				'addresses' => Addresses::list_for( $uid, 'shipping' ),
				'mode'      => Settings::get( 'ship_unavailable_mode' ),
			),
			'portal',
			'My Box'
		);
	}

	private static function box_history( $uid ) {
		$rows = array();
		foreach ( Boxes::history( $uid ) as $b ) {
			$s      = $b->shipment_id ? Shipments::get( $b->shipment_id ) : null;
			$rows[] = array( 'box' => $b, 'shipment' => $s, 'lines' => $s ? Shipments::lines( $s->id ) : Boxes::items( $b->id, true ) );
		}
		$separate = array_filter( Shipments::for_user( $uid ), fn( $s ) => ! $s->box_id );
		$sep = array();
		foreach ( $separate as $s ) {
			$sep[] = array( 'shipment' => $s, 'lines' => Shipments::lines( $s->id ) );
		}
		View::render( 'portal/box-history', array( 'rows' => $rows, 'separate' => $sep ), 'portal', 'Shipment History' );
	}

	private static function invoices( $uid ) {
		$list = Invoices::for_user( $uid );
		$lines = array();
		foreach ( $list as $i ) {
			$lines[ $i->id ] = Invoices::lines( $i->id );
		}
		View::render( 'portal/invoices', array( 'invoices' => $list, 'lines' => $lines ), 'portal', 'Invoices' );
	}

	private static function invoice_pdf( $uid, $inv_uid ) {
		$inv = Invoices::get_owned( $uid, strtoupper( $inv_uid ) );
		if ( ! $inv && Roles::is_staff( $uid ) ) {
			global $wpdb;
			$inv = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . \SSP\Core\Installer::tables()['invoices'] . ' WHERE invoice_uid=%s', strtoupper( $inv_uid ) ) );
		}
		if ( ! $inv || ! $inv->qbo_invoice_id || ! Invoices::is_final( $inv ) ) {
			return View::not_found( 'Invoice PDF not available.' );
		}
		try {
			$pdf = Qbo::invoice_pdf( $inv );
		} catch ( \Throwable $e ) {
			Flash::add( 'error', 'The invoice PDF could not be retrieved from QuickBooks right now. Please try again later.' );
			wp_safe_redirect( ssp_url( 'invoices/' ) );
			exit;
		}
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: inline; filename="invoice-' . sanitize_file_name( $inv->doc_number ) . '.pdf"' );
		header( 'Cache-Control: private, no-store' );
		echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	private static function waitlist( $uid ) {
		$rows = array();
		foreach ( Waitlist::for_user( $uid ) as $w ) {
			$v = Catalog::variant( $w->variant_id );
			$p = $v ? Catalog::get( $v->product_id ) : null;
			$rows[] = array( 'w' => $w, 'v' => $v, 'p' => $p, 'pos' => 'waiting' === $w->status ? Waitlist::position( $w ) : null );
		}
		View::render( 'portal/waitlist', array( 'rows' => $rows ), 'portal', 'Waitlist' );
	}

	private static function media( $image_uid, $size ) {
		if ( ! Customers::can_view_catalog() ) {
			status_header( 404 );
			exit;
		}
		$img = Catalog::image_by_uid( strtoupper( $image_uid ) );
		if ( ! $img ) {
			status_header( 404 );
			exit;
		}
		$p = Catalog::get( $img->product_id );
		if ( ! $p || ( 'draft' === $p->lifecycle && ! Roles::is_staff() ) ) {
			status_header( 404 );
			exit;
		}
		$sizes = (array) json_decode( (string) $img->sizes, true );
		$rel   = 'full' === $size ? $img->file_path : ( $sizes[ $size ] ?? $img->file_path );
		Media::stream( $rel, $img->mime );
	}

	private static function resource( $uid ) {
		global $wpdb;
		$t = \SSP\Core\Installer::tables()['resources'];
		$r = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE resource_uid=%s", strtoupper( $uid ) ) );
		if ( ! $r ) {
			status_header( 404 );
			exit;
		}
		Media::stream( $r->file_path, $r->mime, $r->file_name, 0 );
	}
}
