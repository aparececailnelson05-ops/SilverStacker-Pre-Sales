<?php
namespace SSP\Integrations;

use SSP\Core\Audit;
use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\PermanentJobError;
use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Boxes;
use SSP\Domain\Customers;
use SSP\Domain\Orders;
use SSP\Domain\Shipments;

defined( 'ABSPATH' ) || exit;

/**
 * Warehouse / inventory integration (platform still to be confirmed, decision D-11).
 *
 * Adapters:
 *  - manual (default): staff record availability and shipments in the portal; nothing is sent.
 *  - webhook: every accepted order line, quantity change, fulfillment choice, box request and
 *    shipment is POSTed as signed JSON (HMAC-SHA256, header X-SSP-Signature) to a configured URL,
 *    with stable portal IDs and an idempotency key. This works directly with platforms that accept
 *    webhooks or through middleware, and is replaced by a native adapter once the platform is chosen.
 *
 * Inbound: POST /wp-json/ssp/v1/hooks/warehouse (signed) with events
 *   {"event_id":"...","type":"line.availability","line_id":"<line_uid>","qty_available":5}
 *   {"event_id":"...","type":"shipment.shipped","line_ids":{"<line_uid>":2},"carrier":"UPS","tracking":"1Z..."}
 * Events are de-duplicated by event_id so repeats cannot double-count.
 */
class Warehouse {

	public static function adapter() {
		return Settings::get( 'warehouse_adapter' ) === 'webhook' ? 'webhook' : 'manual';
	}

	public static function push( $type, $object_uid, array $payload ) {
		if ( 'webhook' !== self::adapter() || ! Settings::get( 'warehouse_url' ) ) {
			return;
		}
		$payload['type']       = $type;
		$payload['sent_at']    = gmdate( 'c' );
		$payload['event_key']  = $type . ':' . $object_uid . ':' . md5( wp_json_encode( $payload ) );
		Jobs::enqueue( 'warehouse', 'warehouse.push', $type, $object_uid, $payload, 'wh:' . $payload['event_key'] );
	}

	public static function line_payload( $line_id ) {
		$l = Orders::line( $line_id );
		if ( ! $l ) {
			return null;
		}
		$o = Orders::get( $l->order_id );
		$p = Customers::profile( $l->user_id );
		$box = Boxes::line_box( $l->id );
		return array(
			'line_id'            => $l->line_uid,
			'order_id'           => $o->order_uid,
			'order_number'       => (int) $o->order_number,
			'customer_id'        => $p ? $p->customer_uid : '',
			'customer'           => Customers::display_name( $p ),
			'sku'                => $l->sku_snapshot,
			'name'               => $l->name_snapshot,
			'qty_reserved'       => Orders::net( $l ),
			'qty_available'      => (int) $l->qty_available,
			'qty_held_in_box'    => $box ? max( 0, Orders::net( $l ) - (int) $l->qty_shipped ) : 0,
			'qty_separate'       => 'separate' === $l->fulfillment_choice ? max( 0, Orders::net( $l ) - (int) $l->qty_shipped ) : 0,
			'qty_shipped'        => (int) $l->qty_shipped,
			'qty_cancelled'      => (int) $l->qty_cancelled,
			'fulfillment_choice' => $l->fulfillment_choice,
			'box_id'             => $box ? Boxes::get( $box )->box_uid : null,
		);
	}

	public static function job_push( array $p ) {
		$url    = Settings::get( 'warehouse_url' );
		$secret = Settings::get( 'warehouse_webhook_secret' );
		if ( ! $url ) {
			throw new PermanentJobError( 'Warehouse webhook URL is not configured.' );
		}
		$body = wp_json_encode( $p );
		$resp = wp_remote_post(
			$url,
			array(
				'headers' => array(
					'Content-Type'      => 'application/json',
					'X-SSP-Signature'   => hash_hmac( 'sha256', $body, (string) $secret ),
					'Idempotency-Key'   => $p['event_key'] ?? '',
				),
				'body'    => $body,
				'timeout' => 20,
			)
		);
		if ( is_wp_error( $resp ) ) {
			throw new \RuntimeException( 'Warehouse connection error: ' . $resp->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		if ( $code >= 300 ) {
			throw new \RuntimeException( 'Warehouse responded HTTP ' . $code );
		}
		return true;
	}

	public static function handle_webhook( \WP_REST_Request $req ) {
		global $wpdb;
		$body   = $req->get_body();
		$secret = (string) Settings::get( 'warehouse_webhook_secret' );
		$sig    = (string) $req->get_header( 'x-ssp-signature' );
		if ( '' === $secret || ! hash_equals( hash_hmac( 'sha256', $body, $secret ), $sig ) ) {
			return new \WP_REST_Response( array( 'error' => 'invalid signature' ), 401 );
		}
		$data = json_decode( $body, true );
		$eid  = sanitize_text_field( (string) ( $data['event_id'] ?? '' ) );
		if ( '' === $eid ) {
			return new \WP_REST_Response( array( 'error' => 'event_id required' ), 400 );
		}
		$t   = Installer::tables()['inbound'];
		$ins = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$t} (source, external_event_id, payload, received_at) VALUES ('warehouse', %s, %s, %s)", $eid, $body, Util::now() ) );
		if ( ! $ins ) {
			return new \WP_REST_Response( array( 'ok' => true, 'duplicate' => true ), 200 );
		}
		$result = self::apply_event( $data );
		$wpdb->update( $t, array( 'processed_at' => Util::now(), 'result' => is_wp_error( $result ) ? 'error: ' . $result->get_error_message() : 'ok' ), array( 'source' => 'warehouse', 'external_event_id' => $eid ) );
		if ( is_wp_error( $result ) ) {
			return new \WP_REST_Response( array( 'error' => $result->get_error_message() ), 422 );
		}
		return new \WP_REST_Response( array( 'ok' => true ), 200 );
	}

	public static function apply_event( array $data ) {
		global $wpdb;
		$lt = Installer::tables()['lines'];
		switch ( $data['type'] ?? '' ) {
			case 'line.availability':
				$line = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$lt} WHERE line_uid=%s", (string) ( $data['line_id'] ?? '' ) ) );
				if ( ! $line ) {
					return new \WP_Error( 'line', 'Unknown line_id' );
				}
				return Orders::set_availability( (int) $line->id, (int) $data['qty_available'], 'warehouse', 'Warehouse event ' . ( $data['event_id'] ?? '' ) );
			case 'shipment.shipped':
				$map  = array();
				$user = 0;
				foreach ( (array) ( $data['line_ids'] ?? array() ) as $uid => $qty ) {
					$line = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$lt} WHERE line_uid=%s", (string) $uid ) );
					if ( ! $line ) {
						return new \WP_Error( 'line', 'Unknown line ' . $uid );
					}
					if ( $user && $user !== (int) $line->user_id ) {
						return new \WP_Error( 'mixed', 'A shipment cannot mix customers.' );
					}
					$user               = (int) $line->user_id;
					$map[ (int) $line->id ] = (int) $qty;
				}
				$r = Shipments::create(
					$user,
					$map,
					array(
						'carrier'         => sanitize_text_field( $data['carrier'] ?? '' ),
						'tracking_number' => sanitize_text_field( $data['tracking'] ?? '' ),
						'status'          => 'shipped',
						'allow_no_tracking' => true,
						'notes'           => 'Recorded from warehouse event ' . ( $data['event_id'] ?? '' ),
					)
				);
				return is_wp_error( $r ) ? $r : true;
		}
		Audit::log( 'warehouse.unknown_event', 'integration', 'warehouse', null, $data, null, 0 );
		return true;
	}
}
