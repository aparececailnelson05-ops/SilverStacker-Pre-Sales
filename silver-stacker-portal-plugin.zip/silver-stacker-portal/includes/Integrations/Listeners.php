<?php
namespace SSP\Integrations;

use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Domain\Boxes;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Shipments;

defined( 'ABSPATH' ) || exit;

/** Turns domain events into queued (non-blocking) Google Sheets and warehouse jobs. */
class Listeners {

	public static function init() {
		add_action( 'ssp_event', array( __CLASS__, 'on_event' ), 10, 2 );
		Jobs::register( 'sheets.upsert', array( Sheets::class, 'job_upsert' ) );
		Jobs::register( 'warehouse.push', array( Warehouse::class, 'job_push' ) );
		Jobs::register( 'qbo.create_invoice', array( Qbo::class, 'job_create_invoice' ) );
		Jobs::register( 'qbo.refresh_invoice', array( Qbo::class, 'job_refresh_invoice' ) );
		Jobs::register( 'qbo.payment_changed', array( Qbo::class, 'job_payment_changed' ) );
		Jobs::register( 'email.send', array( \SSP\Core\Mailer::class, 'send_job' ) );
		Jobs::register( 'box.digest', array( Boxes::class, 'digest_job' ) );
	}

	private static function line_rows( $line_id ) {
		$l = Orders::line( $line_id );
		if ( ! $l ) {
			return;
		}
		Sheets::queue( 'Pre-order Lines', $l->line_uid );
		$v = Catalog::variant( $l->variant_id );
		if ( $v ) {
			Sheets::queue( 'Allocations & Waitlists', $v->variant_uid );
		}
		$box = Boxes::line_box( $line_id );
		if ( $box ) {
			Sheets::queue( 'Open Boxes', Boxes::get( $box )->box_uid );
		}
	}

	public static function on_event( $name, array $d ) {
		global $wpdb;
		switch ( $name ) {
			case 'customer.created':
			case 'customer.status_changed':
				$p = Customers::profile( (int) $d['user_id'] );
				if ( $p ) {
					Sheets::queue( 'Customers', $p->customer_uid );
				}
				break;
			case 'order.submitted':
				foreach ( Orders::lines( (int) $d['order_id'] ) as $l ) {
					self::line_rows( (int) $l->id );
					Warehouse::push( 'order_line.accepted', $l->line_uid, (array) Warehouse::line_payload( (int) $l->id ) );
				}
				$o = Orders::get( (int) $d['order_id'] );
				if ( $o ) {
					$p = Customers::profile( (int) $o->user_id );
					if ( $p ) {
						Sheets::queue( 'Customers', $p->customer_uid );
					}
				}
				break;
			case 'line.changed':
			case 'line.availability_changed':
				self::line_rows( (int) $d['line_id'] );
				$l = Orders::line( (int) $d['line_id'] );
				if ( $l ) {
					Warehouse::push( 'order_line.changed', $l->line_uid, (array) Warehouse::line_payload( (int) $l->id ) );
				}
				break;
			case 'box.changed':
			case 'box.status_changed':
				$b = Boxes::get( (int) $d['box_id'] );
				if ( $b ) {
					Sheets::queue( 'Open Boxes', $b->box_uid );
					foreach ( Boxes::items( $b->id ) as $it ) {
						Sheets::queue( 'Pre-order Lines', $it->line_uid );
					}
					if ( 'box.status_changed' === $name ) {
						$lines = array();
						foreach ( Boxes::items( $b->id ) as $it ) {
							$lines[] = Warehouse::line_payload( (int) $it->id );
						}
						Warehouse::push( 'box.' . $b->status, $b->box_uid, array( 'box_id' => $b->box_uid, 'box_number' => (int) $b->box_number, 'status' => $b->status, 'address' => Boxes::address( $b ), 'lines' => $lines ) );
					}
				}
				break;
			case 'shipment.changed':
				$s = Shipments::get( (int) $d['shipment_id'] );
				if ( $s ) {
					Sheets::queue( 'Shipments', $s->shipment_uid );
					foreach ( Shipments::lines( $s->id ) as $l ) {
						Sheets::queue( 'Pre-order Lines', $l->line_uid );
					}
					if ( $s->box_id ) {
						$b = Boxes::get( (int) $s->box_id );
						if ( $b ) {
							Sheets::queue( 'Open Boxes', $b->box_uid );
						}
					}
				}
				break;
			case 'invoice.changed':
				foreach ( Invoices::lines( (int) $d['invoice_id'] ) as $il ) {
					if ( $il->line_uid ) {
						Sheets::queue( 'Pre-order Lines', $il->line_uid );
					}
				}
				break;
			case 'waitlist.changed':
			case 'variant.allocation_changed':
				$v = Catalog::variant( (int) $d['variant_id'] );
				if ( $v ) {
					Sheets::queue( 'Allocations & Waitlists', $v->variant_uid );
					$wt = Installer::tables()['waitlist'];
					foreach ( $wpdb->get_col( $wpdb->prepare( "SELECT waitlist_uid FROM {$wt} WHERE variant_id=%d", $v->id ) ) as $wuid ) {
						Sheets::queue( 'Allocations & Waitlists', $wuid );
					}
				}
				break;
			case 'product.eta_changed':
			case 'product.changed':
				if ( Sheets::enabled() ) {
					$lt = Installer::tables()['lines'];
					foreach ( $wpdb->get_col( $wpdb->prepare( "SELECT line_uid FROM {$lt} WHERE product_id=%d", (int) $d['product_id'] ) ) as $uid ) {
						Sheets::queue( 'Pre-order Lines', $uid );
					}
				}
				break;
		}
	}
}
