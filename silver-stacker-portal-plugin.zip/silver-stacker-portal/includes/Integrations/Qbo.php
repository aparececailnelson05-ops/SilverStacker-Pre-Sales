<?php
namespace SSP\Integrations;

use SSP\Core\Audit;
use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\PermanentJobError;
use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Addresses;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;

defined( 'ABSPATH' ) || exit;

/**
 * QuickBooks Online integration (Intuit OAuth 2.0, Accounting API v3).
 * QBO is the authority for invoices, tax, payment links, payment collection and payment status.
 */
class Qbo {

	const AUTH_URL   = 'https://appcenter.intuit.com/connect/oauth2';
	const TOKEN_URL  = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';
	const REVOKE_URL = 'https://developer.api.intuit.com/v2/oauth2/tokens/revoke';
	const SCOPE      = 'com.intuit.quickbooks.accounting';
	const MINOR      = '75';

	public static function api_base() {
		return 'production' === Settings::get( 'qbo_environment' ) ? 'https://quickbooks.api.intuit.com' : 'https://sandbox-quickbooks.api.intuit.com';
	}

	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=ssp_qbo_callback' );
	}

	public static function tokens() {
		$raw = Settings::secret_get( 'qbo_tokens' );
		$t   = $raw ? json_decode( $raw, true ) : null;
		return is_array( $t ) ? $t : null;
	}

	public static function save_tokens( array $t ) {
		Settings::secret_set( 'qbo_tokens', wp_json_encode( $t ) );
	}

	public static function is_connected() {
		$t = self::tokens();
		return $t && ! empty( $t['refresh_token'] ) && ! empty( $t['realm_id'] );
	}

	public static function authorize_url() {
		$state = wp_generate_password( 32, false );
		set_transient( 'ssp_qbo_state_' . get_current_user_id(), $state, 15 * MINUTE_IN_SECONDS );
		return add_query_arg(
			array(
				'client_id'     => Settings::get( 'qbo_client_id' ),
				'response_type' => 'code',
				'scope'         => self::SCOPE,
				'redirect_uri'  => self::redirect_uri(),
				'state'         => $state,
			),
			self::AUTH_URL
		);
	}

	public static function handle_callback( $code, $realm_id, $state ) {
		$expected = get_transient( 'ssp_qbo_state_' . get_current_user_id() );
		delete_transient( 'ssp_qbo_state_' . get_current_user_id() );
		if ( ! $expected || ! hash_equals( $expected, (string) $state ) ) {
			return new \WP_Error( 'state', 'Invalid OAuth state. Please try connecting again.' );
		}
		$r = self::token_request(
			array(
				'grant_type'   => 'authorization_code',
				'code'         => $code,
				'redirect_uri' => self::redirect_uri(),
			)
		);
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$r['realm_id'] = sanitize_text_field( $realm_id );
		self::save_tokens( $r );
		Audit::log( 'qbo.connected', 'integration', 'qbo', null, array( 'realm_id' => $r['realm_id'], 'env' => Settings::get( 'qbo_environment' ) ) );
		return true;
	}

	public static function disconnect() {
		$t = self::tokens();
		if ( $t && ! empty( $t['refresh_token'] ) ) {
			wp_remote_post(
				self::REVOKE_URL,
				array(
					'headers' => array(
						'Authorization' => 'Basic ' . base64_encode( Settings::get( 'qbo_client_id' ) . ':' . Settings::get( 'qbo_client_secret' ) ),
						'Accept'        => 'application/json',
						'Content-Type'  => 'application/json',
					),
					'body'    => wp_json_encode( array( 'token' => $t['refresh_token'] ) ),
					'timeout' => 15,
				)
			);
		}
		delete_option( 'ssp_secret_qbo_tokens' );
		Audit::log( 'qbo.disconnected', 'integration', 'qbo' );
	}

	private static function token_request( array $body ) {
		$resp = wp_remote_post(
			self::TOKEN_URL,
			array(
				'headers' => array(
					'Authorization' => 'Basic ' . base64_encode( Settings::get( 'qbo_client_id' ) . ':' . Settings::get( 'qbo_client_secret' ) ),
					'Accept'        => 'application/json',
					'Content-Type'  => 'application/x-www-form-urlencoded',
				),
				'body'    => $body,
				'timeout' => 20,
			)
		);
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		$code = wp_remote_retrieve_response_code( $resp );
		$data = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( 200 !== $code || empty( $data['access_token'] ) ) {
			return new \WP_Error( 'token', 'QuickBooks token error: ' . ( $data['error'] ?? $code ) );
		}
		return array(
			'access_token'       => $data['access_token'],
			'refresh_token'      => $data['refresh_token'],
			'expires_at'         => time() + (int) $data['expires_in'] - 60,
			'refresh_expires_at' => time() + (int) ( $data['x_refresh_token_expires_in'] ?? 8640000 ),
		);
	}

	private static function access_token() {
		$t = self::tokens();
		if ( ! $t ) {
			throw new PermanentJobError( 'QuickBooks is not connected. An administrator must connect QuickBooks in Integrations.' );
		}
		if ( time() >= (int) $t['expires_at'] ) {
			$lock = get_transient( 'ssp_qbo_refreshing' );
			if ( $lock ) {
				sleep( 2 );
				$t = self::tokens();
				if ( time() < (int) $t['expires_at'] ) {
					return $t;
				}
			}
			set_transient( 'ssp_qbo_refreshing', 1, 30 );
			$r = self::token_request( array( 'grant_type' => 'refresh_token', 'refresh_token' => $t['refresh_token'] ) );
			delete_transient( 'ssp_qbo_refreshing' );
			if ( is_wp_error( $r ) ) {
				throw new \RuntimeException( 'QuickBooks token refresh failed: ' . $r->get_error_message() . '. Reconnect QuickBooks if this persists.' );
			}
			$r['realm_id'] = $t['realm_id'];
			self::save_tokens( $r );
			$t = $r;
		}
		return $t;
	}

	/**
	 * @return array decoded JSON (or ['_raw'=>bytes] for PDFs)
	 */
	public static function request( $method, $path, $body = null, array $query = array(), $accept = 'application/json' ) {
		$t   = self::access_token();
		$url = self::api_base() . '/v3/company/' . rawurlencode( $t['realm_id'] ) . '/' . ltrim( $path, '/' );
		$query['minorversion'] = self::MINOR;
		$url = add_query_arg( array_map( 'rawurlencode', $query ), $url );
		$args = array(
			'method'  => $method,
			'headers' => array(
				'Authorization' => 'Bearer ' . $t['access_token'],
				'Accept'        => $accept,
				'Content-Type'  => 'application/json',
			),
			'timeout' => 30,
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}
		$resp = wp_remote_request( $url, $args );
		if ( is_wp_error( $resp ) ) {
			throw new \RuntimeException( 'QuickBooks connection error: ' . $resp->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		$raw  = wp_remote_retrieve_body( $resp );
		if ( 'application/pdf' === $accept && 200 === $code ) {
			return array( '_raw' => $raw );
		}
		$data = json_decode( $raw, true );
		if ( $code >= 400 || isset( $data['Fault'] ) ) {
			$msg = 'HTTP ' . $code;
			if ( isset( $data['Fault']['Error'][0] ) ) {
				$e   = $data['Fault']['Error'][0];
				$msg = trim( ( $e['Message'] ?? '' ) . ': ' . ( $e['Detail'] ?? '' ) . ' (code ' . ( $e['code'] ?? '?' ) . ')' );
			}
			if ( 401 === $code ) {
				// Force refresh next time.
				$tk = self::tokens();
				if ( $tk ) {
					$tk['expires_at'] = 0;
					self::save_tokens( $tk );
				}
			}
			if ( in_array( $code, array( 400, 403 ), true ) && isset( $data['Fault'] ) && 'ValidationFault' === ( $data['Fault']['type'] ?? '' ) ) {
				throw new PermanentJobError( 'QuickBooks rejected the request: ' . $msg );
			}
			throw new \RuntimeException( 'QuickBooks error: ' . $msg );
		}
		return is_array( $data ) ? $data : array();
	}

	public static function query( $sql ) {
		$r = self::request( 'GET', 'query', null, array( 'query' => $sql ) );
		return $r['QueryResponse'] ?? array();
	}

	private static function q( $s ) {
		return str_replace( array( '\\', "'" ), array( '\\\\', "\\'" ), (string) $s );
	}

	/* ---------------------------------------------------------------- */
	/* Mapping                                                          */
	/* ---------------------------------------------------------------- */

	public static function map_get( $type, $portal_uid ) {
		global $wpdb;
		$t = Installer::tables()['map'];
		return $wpdb->get_var( $wpdb->prepare( "SELECT external_id FROM {$t} WHERE integration='qbo' AND object_type=%s AND portal_uid=%s", $type, $portal_uid ) );
	}

	public static function map_set( $type, $portal_uid, $external_id ) {
		global $wpdb;
		$t = Installer::tables()['map'];
		$wpdb->query( $wpdb->prepare( "INSERT INTO {$t} (integration, object_type, portal_uid, external_id, updated_at) VALUES ('qbo', %s, %s, %s, %s) ON DUPLICATE KEY UPDATE external_id=VALUES(external_id), updated_at=VALUES(updated_at)", $type, $portal_uid, $external_id, Util::now() ) );
	}

	private static function qbo_address( $a ) {
		if ( ! $a ) {
			return null;
		}
		$a = (array) $a;
		return array(
			'Line1'                  => $a['line1'] ?? '',
			'Line2'                  => $a['line2'] ?? '',
			'City'                   => $a['city'] ?? '',
			'CountrySubDivisionCode' => $a['state'] ?? '',
			'PostalCode'             => $a['postal_code'] ?? '',
			'Country'                => $a['country'] ?? 'US',
		);
	}

	public static function ensure_customer( $user_id ) {
		global $wpdb;
		$p = Customers::profile( $user_id );
		if ( ! $p ) {
			throw new PermanentJobError( 'Customer profile missing.' );
		}
		$id = self::map_get( 'customer', $p->customer_uid );
		if ( $id ) {
			return $id;
		}
		// Display names must be unique in QBO; include a short stable suffix to avoid collisions.
		$display = substr( trim( ( $p->company_name ? $p->company_name : $p->contact_name ) . ' - ' . $p->contact_name ), 0, 80 ) . ' [' . substr( $p->customer_uid, -6 ) . ']';
		$found   = self::query( "select Id from Customer where DisplayName = '" . self::q( $display ) . "'" );
		if ( ! empty( $found['Customer'][0]['Id'] ) ) {
			$id = $found['Customer'][0]['Id'];
		} else {
			$body = array(
				'DisplayName'      => $display,
				'CompanyName'      => $p->company_name,
				'GivenName'        => $p->contact_name,
				'PrimaryEmailAddr' => array( 'Address' => $p->email ),
				'PrimaryPhone'     => array( 'FreeFormNumber' => $p->phone ),
			);
			$bill = Addresses::default_for( $user_id, 'billing' );
			$ship = Addresses::default_for( $user_id, 'shipping' );
			if ( $bill ) {
				$body['BillAddr'] = self::qbo_address( $bill );
			}
			if ( $ship ) {
				$body['ShipAddr'] = self::qbo_address( $ship );
			}
			$r  = self::request( 'POST', 'customer', $body, array( 'requestid' => 'cust' . strtolower( $p->customer_uid ) ) );
			$id = $r['Customer']['Id'] ?? null;
			if ( ! $id ) {
				throw new \RuntimeException( 'QuickBooks did not return a customer ID.' );
			}
		}
		self::map_set( 'customer', $p->customer_uid, $id );
		$wpdb->update( Installer::tables()['profiles'], array( 'qbo_customer_id' => $id ), array( 'user_id' => $user_id ) );
		return $id;
	}

	public static function ensure_item( $variant ) {
		global $wpdb;
		if ( 'generic' === Settings::get( 'qbo_item_strategy' ) ) {
			$g = Settings::get( 'qbo_generic_item_id' );
			if ( ! $g ) {
				throw new PermanentJobError( 'Set the generic QuickBooks item ID in Settings > QuickBooks.' );
			}
			return $g;
		}
		$id = self::map_get( 'item', $variant->variant_uid );
		if ( $id ) {
			return $id;
		}
		$name  = substr( $variant->sku, 0, 100 );
		$found = self::query( "select Id from Item where Name = '" . self::q( $name ) . "'" );
		if ( ! empty( $found['Item'][0]['Id'] ) ) {
			$id = $found['Item'][0]['Id'];
		} else {
			$income = Settings::get( 'qbo_income_account_id' );
			if ( ! $income ) {
				throw new PermanentJobError( 'Set the QuickBooks income account ID in Settings > QuickBooks before invoicing.' );
			}
			$product = Catalog::get( $variant->product_id );
			$r = self::request(
				'POST',
				'item',
				array(
					'Name'             => $name,
					'Sku'              => $variant->sku,
					'Description'      => substr( ( $product ? $product->name : '' ) . ( $variant->label ? ' - ' . $variant->label : '' ), 0, 4000 ),
					'Type'             => 'NonInventory',
					'IncomeAccountRef' => array( 'value' => $income ),
					'UnitPrice'        => (float) $variant->price_usd,
				),
				array( 'requestid' => 'item' . strtolower( $variant->variant_uid ) )
			);
			$id = $r['Item']['Id'] ?? null;
			if ( ! $id ) {
				throw new \RuntimeException( 'QuickBooks did not return an item ID.' );
			}
		}
		self::map_set( 'item', $variant->variant_uid, $id );
		$wpdb->update( Installer::tables()['variants'], array( 'qbo_item_id' => $id ), array( 'id' => $variant->id ) );
		return $id;
	}

	/* ---------------------------------------------------------------- */
	/* Jobs                                                             */
	/* ---------------------------------------------------------------- */

	/** Job: create the invoice in QBO (idempotent via requestid). */
	public static function job_create_invoice( array $p ) {
		global $wpdb;
		$inv = Invoices::get( (int) $p['invoice_id'] );
		if ( ! $inv ) {
			throw new PermanentJobError( 'Invoice record missing.' );
		}
		if ( Invoices::is_final( $inv ) || in_array( $inv->sync_status, array( 'cancelled', 'voided' ), true ) ) {
			return true;
		}
		$wpdb->update( Installer::tables()['invoices'], array( 'sync_status' => 'creating', 'updated_at' => Util::now() ), array( 'id' => $inv->id ) );
		try {
			$customer_id = self::ensure_customer( (int) $inv->user_id );
			$lines       = array();
			$memo        = array();
			foreach ( Invoices::lines( $inv->id ) as $il ) {
				if ( 'shipping' === $il->type ) {
					$ship_item = Settings::get( 'qbo_shipping_item_id' );
					if ( ! $ship_item ) {
						throw new PermanentJobError( 'Set the QuickBooks shipping item ID in Settings > QuickBooks to invoice shipping.' );
					}
					$lines[] = array(
						'DetailType'          => 'SalesItemLineDetail',
						'Amount'              => (float) $il->amount_usd,
						'Description'         => $il->description,
						'SalesItemLineDetail' => array(
							'ItemRef'   => array( 'value' => $ship_item ),
							'Qty'       => 1,
							'UnitPrice' => (float) $il->unit_price_usd,
						),
					);
					continue;
				}
				$line    = Orders::line( (int) $il->order_line_id );
				$variant = Catalog::variant( (int) $line->variant_id );
				$lines[] = array(
					'DetailType'          => 'SalesItemLineDetail',
					'Amount'              => (float) $il->amount_usd,
					'Description'         => $il->description . ' [' . $line->line_uid . ']',
					'SalesItemLineDetail' => array(
						'ItemRef'   => array( 'value' => self::ensure_item( $variant ) ),
						'Qty'       => (int) $il->qty,
						'UnitPrice' => (float) $il->unit_price_usd,
					),
				);
				$memo[] = '#' . $il->order_number;
			}
			$prof = Customers::profile( (int) $inv->user_id );
			$body = array(
				'CustomerRef'                  => array( 'value' => $customer_id ),
				'Line'                         => $lines,
				'BillEmail'                    => array( 'Address' => $prof->email ),
				'AllowOnlineCreditCardPayment' => true,
				'AllowOnlineACHPayment'        => true,
				'PrivateNote'                  => 'Portal invoice ' . $inv->invoice_uid . ' | Orders ' . implode( ', ', array_unique( $memo ) ),
				'CustomerMemo'                 => array( 'value' => 'Silver Stacker Pre-Sale orders ' . implode( ', ', array_unique( $memo ) ) ),
			);
			if ( Settings::get( 'qbo_term_id' ) ) {
				$body['SalesTermRef'] = array( 'value' => Settings::get( 'qbo_term_id' ) );
			}
			$ship = Addresses::default_for( (int) $inv->user_id, 'shipping' );
			if ( $ship ) {
				$body['ShipAddr'] = self::qbo_address( $ship );
			}
			$r  = self::request( 'POST', 'invoice', $body, array( 'requestid' => $inv->qbo_request_id ) );
			$qi = $r['Invoice'] ?? null;
			if ( empty( $qi['Id'] ) ) {
				throw new \RuntimeException( 'QuickBooks did not return an invoice.' );
			}
			if ( Settings::get( 'qbo_send_invoice_email' ) ) {
				try {
					self::request( 'POST', 'invoice/' . rawurlencode( $qi['Id'] ) . '/send', null, array( 'sendTo' => $prof->email ) );
				} catch ( \Throwable $e ) {
					Audit::log( 'qbo.send_failed', 'invoice', $inv->id, null, null, $e->getMessage(), 0 );
				}
			}
			$link = '';
			try {
				$full = self::request( 'GET', 'invoice/' . rawurlencode( $qi['Id'] ), null, array( 'include' => 'invoiceLink' ) );
				$qi   = $full['Invoice'] ?? $qi;
				$link = $qi['InvoiceLink'] ?? '';
			} catch ( \Throwable $e ) {
				$link = '';
			}
			self::map_set( 'invoice', $inv->invoice_uid, $qi['Id'] );
			Invoices::finalize_success( $inv->id, self::parse_invoice( $qi, $link ) );
			return true;
		} catch ( \Throwable $e ) {
			Invoices::mark_error( $inv->id, $e->getMessage() );
			throw $e;
		}
	}

	public static function parse_invoice( array $qi, $link = '' ) {
		return array(
			'qbo_invoice_id' => (string) $qi['Id'],
			'doc_number'     => (string) ( $qi['DocNumber'] ?? $qi['Id'] ),
			'txn_date'       => $qi['TxnDate'] ?? null,
			'due_date'       => $qi['DueDate'] ?? null,
			'total_usd'      => isset( $qi['TotalAmt'] ) ? (float) $qi['TotalAmt'] : null,
			'balance_usd'    => isset( $qi['Balance'] ) ? (float) $qi['Balance'] : null,
			'pay_link'       => $link ? $link : ( $qi['InvoiceLink'] ?? null ),
		);
	}

	/** Job: refresh one invoice's payment status/balance from QBO. */
	public static function job_refresh_invoice( array $p ) {
		$inv = ! empty( $p['invoice_id'] ) ? Invoices::get( (int) $p['invoice_id'] ) : Invoices::by_qbo_id( (string) ( $p['qbo_invoice_id'] ?? '' ) );
		if ( ! $inv || ! $inv->qbo_invoice_id ) {
			return true;
		}
		if ( ! empty( $p['operation'] ) && in_array( $p['operation'], array( 'Void', 'Delete' ), true ) ) {
			Invoices::mark_voided( $inv->id );
			return true;
		}
		$r  = self::request( 'GET', 'invoice/' . rawurlencode( $inv->qbo_invoice_id ), null, array( 'include' => 'invoiceLink' ) );
		$qi = $r['Invoice'] ?? null;
		if ( ! $qi ) {
			return true;
		}
		if ( isset( $qi['PrivateNote'] ) && stripos( $qi['PrivateNote'], 'Voided' ) !== false && 0.0 === (float) ( $qi['TotalAmt'] ?? 0 ) ) {
			Invoices::mark_voided( $inv->id );
			return true;
		}
		Invoices::update_from_qbo( $inv->id, self::parse_invoice( $qi ) );
		return true;
	}

	/** Job: a QBO Payment changed; refresh every portal invoice it applies to. */
	public static function job_payment_changed( array $p ) {
		$r   = self::request( 'GET', 'payment/' . rawurlencode( (string) $p['payment_id'] ) );
		$pay = $r['Payment'] ?? array();
		foreach ( (array) ( $pay['Line'] ?? array() ) as $line ) {
			foreach ( (array) ( $line['LinkedTxn'] ?? array() ) as $lt ) {
				if ( 'Invoice' === ( $lt['TxnType'] ?? '' ) ) {
					$inv = Invoices::by_qbo_id( (string) $lt['TxnId'] );
					if ( $inv ) {
						self::job_refresh_invoice( array( 'invoice_id' => $inv->id ) );
					}
				}
			}
		}
		return true;
	}

	/** Cron: Change Data Capture poll as a safety net for missed webhooks. */
	public static function cdc_poll() {
		if ( ! self::is_connected() ) {
			return;
		}
		$since = get_option( 'ssp_qbo_cdc_since', gmdate( 'c', time() - DAY_IN_SECONDS ) );
		$now   = gmdate( 'c' );
		try {
			$r = self::request( 'GET', 'cdc', null, array( 'entities' => 'Invoice,Payment', 'changedSince' => $since ) );
		} catch ( \Throwable $e ) {
			return;
		}
		foreach ( (array) ( $r['CDCResponse'][0]['QueryResponse'] ?? array() ) as $qr ) {
			foreach ( (array) ( $qr['Invoice'] ?? array() ) as $qi ) {
				$inv = Invoices::by_qbo_id( (string) $qi['Id'] );
				if ( $inv ) {
					if ( ( $qi['status'] ?? '' ) === 'Deleted' ) {
						Invoices::mark_voided( $inv->id );
					} else {
						Invoices::update_from_qbo( $inv->id, self::parse_invoice( $qi ) );
					}
				}
			}
			foreach ( (array) ( $qr['Payment'] ?? array() ) as $pay ) {
				Jobs::enqueue( 'qbo', 'qbo.payment_changed', 'payment', $pay['Id'], array( 'payment_id' => $pay['Id'] ), null, 0, true );
			}
		}
		update_option( 'ssp_qbo_cdc_since', $now, false );
	}

	/** Webhook: verify Intuit signature then enqueue refresh jobs. */
	public static function handle_webhook( \WP_REST_Request $req ) {
		global $wpdb;
		$body     = $req->get_body();
		$sig      = $req->get_header( 'intuit-signature' );
		$verifier = Settings::get( 'qbo_webhook_verifier' );
		if ( ! $verifier || ! $sig || ! hash_equals( base64_encode( hash_hmac( 'sha256', $body, $verifier, true ) ), $sig ) ) {
			return new \WP_REST_Response( array( 'error' => 'invalid signature' ), 401 );
		}
		$event_id = hash( 'sha256', $body );
		$t        = Installer::tables()['inbound'];
		$ins      = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$t} (source, external_event_id, payload, received_at) VALUES ('qbo', %s, %s, %s)", $event_id, $body, Util::now() ) );
		if ( ! $ins ) {
			return new \WP_REST_Response( array( 'ok' => true, 'duplicate' => true ), 200 );
		}
		$data = json_decode( $body, true );
		foreach ( (array) ( $data['eventNotifications'] ?? array() ) as $n ) {
			foreach ( (array) ( $n['dataChangeEvent']['entities'] ?? array() ) as $e ) {
				$name = $e['name'] ?? '';
				$id   = (string) ( $e['id'] ?? '' );
				$op   = (string) ( $e['operation'] ?? '' );
				if ( 'Invoice' === $name ) {
					$inv = Invoices::by_qbo_id( $id );
					if ( $inv ) {
						Jobs::enqueue( 'qbo', 'qbo.refresh_invoice', 'invoice', $inv->id, array( 'invoice_id' => $inv->id, 'operation' => $op ), null, 0, true );
					}
				} elseif ( 'Payment' === $name ) {
					Jobs::enqueue( 'qbo', 'qbo.payment_changed', 'payment', $id, array( 'payment_id' => $id ), null, 0, true );
				}
			}
		}
		$wpdb->update( $t, array( 'processed_at' => Util::now(), 'result' => 'queued' ), array( 'source' => 'qbo', 'external_event_id' => $event_id ) );
		return new \WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/** Fetch invoice PDF bytes from QBO (streamed to the owner through an ownership-checked route). */
	public static function invoice_pdf( $inv ) {
		$r = self::request( 'GET', 'invoice/' . rawurlencode( $inv->qbo_invoice_id ) . '/pdf', null, array(), 'application/pdf' );
		return $r['_raw'] ?? '';
	}
}
