<?php
namespace SSP\Integrations;

use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\PermanentJobError;
use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Addresses;
use SSP\Domain\Allocation;
use SSP\Domain\Boxes;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Shipments;
use SSP\Domain\Waitlist;

defined( 'ABSPATH' ) || exit;

/**
 * One-way reporting copy to one master Google Sheet. WordPress is the source of truth;
 * nothing is ever read back from the Sheet into portal records (column A is read only to
 * locate the row for a stable ID so rows are updated in place, never duplicated).
 */
class Sheets {

	const TABS = array(
		'Customers'              => array( 'Customer ID', 'Company / Store', 'Contact', 'Email', 'Phone', 'Account Status', 'Billing Address', 'Default Shipping Address', 'Created (UTC)', 'Approved (UTC)' ),
		'Pre-order Lines'        => array( 'Line ID', 'Order #', 'Order ID', 'Customer ID', 'Customer', 'Product', 'SKU', 'Barcode', 'Qty Ordered', 'Qty Available', 'Qty Invoiced', 'Qty Shipped', 'Qty Cancelled', 'Unit Price USD', 'Line Total USD', 'Submitted (UTC)', 'Closing (UTC)', 'ETA', 'Fulfillment Choice', 'Box ID', 'Line Status', 'Invoice #s', 'Customer Note' ),
		'Allocations & Waitlists'=> array( 'ID', 'Type', 'Product', 'SKU', 'Total Allocation', 'Per-Customer Limit', 'Reserved', 'Held for Waitlist', 'Remaining', 'Override Applied', 'Waitlist Customer', 'Waitlist Qty', 'Waitlist State', 'Updated (UTC)' ),
		'Open Boxes'             => array( 'Box ID', 'Box #', 'Customer ID', 'Customer', 'Box Status', 'Shipping Address', 'Included Lines', 'Units', 'Invoice References', 'Rate Tier', 'Shipping Charge USD', 'Shipment Requested (UTC)', 'Updated (UTC)' ),
		'Shipments'              => array( 'Shipment ID', 'Box #', 'Customer ID', 'Customer', 'Status', 'Lines', 'Carrier', 'Tracking', 'Rate Tier', 'Shipping Charge USD', 'Shipped (UTC)', 'Delivered (UTC)' ),
	);

	public static function enabled() {
		return (bool) Settings::get( 'sheets_enabled' ) && Settings::get( 'sheets_spreadsheet_id' ) && Settings::get( 'sheets_service_account' );
	}

	/** Queue an upsert of one logical row (coalesced: only the latest snapshot is written). */
	public static function queue( $tab, $uid ) {
		if ( ! self::enabled() || ! $uid ) {
			return;
		}
		Jobs::enqueue( 'sheets', 'sheets.upsert', $tab, $uid, array( 'tab' => $tab, 'uid' => $uid ), 'sheets:' . $tab . ':' . $uid, 5, true );
	}

	/* ---------------------------------------------------------------- */
	/* Row builders (latest snapshot from the database)                 */
	/* ---------------------------------------------------------------- */

	public static function build_row( $tab, $uid ) {
		global $wpdb;
		$t = Installer::tables();
		switch ( $tab ) {
			case 'Customers':
				$p = Customers::by_uid( $uid );
				if ( ! $p ) {
					return null;
				}
				return array(
					$p->customer_uid, $p->company_name, $p->contact_name, $p->email, $p->phone,
					Customers::STATUSES[ $p->status ] ?? $p->status,
					Addresses::format( Addresses::default_for( $p->user_id, 'billing' ), ', ' ),
					Addresses::format( Addresses::default_for( $p->user_id, 'shipping' ), ', ' ),
					$p->created_at, (string) $p->approved_at,
				);
			case 'Pre-order Lines':
				$l = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['lines']} WHERE line_uid=%s", $uid ) );
				if ( ! $l ) {
					return null;
				}
				$o    = Orders::get( $l->order_id );
				$p    = Customers::profile( $l->user_id );
				$v    = Catalog::variant( $l->variant_id );
				$prod = Catalog::get( $l->product_id );
				$box  = Boxes::line_box( $l->id );
				$boxr = $box ? Boxes::get( $box ) : null;
				$invs = array_map( fn( $i ) => $i->doc_number ? $i->doc_number : 'pending', Invoices::for_line( $l->id ) );
				return array(
					$l->line_uid, $o->order_number, $o->order_uid, $p ? $p->customer_uid : '', Customers::display_name( $p ),
					$l->name_snapshot, $l->sku_snapshot, $v ? $v->barcode : '',
					(int) $l->qty_ordered, (int) $l->qty_available, (int) $l->qty_invoiced, (int) $l->qty_shipped, (int) $l->qty_cancelled,
					(float) $l->unit_price_usd, Orders::line_total( $l ), $o->submitted_at, $prod ? (string) $prod->closing_at : '',
					$prod ? Catalog::eta_label( $prod ) : $l->eta_at_order,
					Orders::FULFILLMENT[ $l->fulfillment_choice ] ?? $l->fulfillment_choice,
					$boxr ? $boxr->box_uid : '', Orders::LINE_STATUSES[ $l->display_status ] ?? $l->display_status,
					implode( ', ', $invs ), (string) $o->customer_note,
				);
			case 'Allocations & Waitlists':
				$v = Catalog::variant_by_uid( $uid );
				if ( $v ) {
					$prod = Catalog::get( $v->product_id );
					$s    = Allocation::summary( $v );
					return array( $v->variant_uid, 'Allocation', $prod ? $prod->name : '', $v->sku, null === $s['total'] ? 'Unlimited' : $s['total'], null === $v->per_customer_allocation ? 'Unlimited' : (int) $v->per_customer_allocation, $s['reserved'], $s['held'], null === $s['remaining'] ? 'Unlimited' : $s['remaining'], $s['overrides'] ? 'Yes (' . $s['overrides'] . ')' : 'No', '', '', '', Util::now() );
				}
				$w = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['waitlist']} WHERE waitlist_uid=%s", $uid ) );
				if ( ! $w ) {
					return null;
				}
				$v    = Catalog::variant( $w->variant_id );
				$prod = $v ? Catalog::get( $v->product_id ) : null;
				$p    = Customers::profile( $w->user_id );
				return array( $w->waitlist_uid, 'Waitlist', $prod ? $prod->name : '', $v ? $v->sku : '', '', '', '', (int) $w->offered_qty, '', '', Customers::display_name( $p ), (int) $w->qty_requested, Waitlist::STATUSES[ $w->status ] ?? $w->status, $w->updated_at );
			case 'Open Boxes':
				$b = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['boxes']} WHERE box_uid=%s", $uid ) );
				if ( ! $b ) {
					return null;
				}
				$p     = Customers::profile( $b->user_id );
				$items = Boxes::items( $b->id );
				$desc  = array();
				$invs  = array();
				$units = 0;
				foreach ( $items as $it ) {
					$q      = Orders::net( $it ) - (int) $it->qty_shipped;
					$units += $q;
					$desc[] = '#' . $it->order_number . ' ' . $it->sku_snapshot . ' x' . $q;
					foreach ( Invoices::for_line( $it->id ) as $i ) {
						$invs[ $i->doc_number ? $i->doc_number : 'pending' ] = true;
					}
				}
				$tier = $b->rate_tier_id ? Shipments::tier( $b->rate_tier_id ) : null;
				return array( $b->box_uid, $b->box_number, $p ? $p->customer_uid : '', Customers::display_name( $p ), Boxes::STATUSES[ $b->status ] ?? $b->status, Addresses::format( Boxes::address( $b ), ', ' ), implode( '; ', $desc ), $units, implode( ', ', array_keys( $invs ) ), $tier ? $tier->name : '', null === $b->shipping_charge_usd ? '' : (float) $b->shipping_charge_usd, (string) $b->shipment_requested_at, $b->updated_at );
			case 'Shipments':
				$s = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['shipments']} WHERE shipment_uid=%s", $uid ) );
				if ( ! $s ) {
					return null;
				}
				$p    = Customers::profile( $s->user_id );
				$box  = $s->box_id ? Boxes::get( $s->box_id ) : null;
				$tier = $s->rate_tier_id ? Shipments::tier( $s->rate_tier_id ) : null;
				$desc = array();
				foreach ( Shipments::lines( $s->id ) as $l ) {
					$desc[] = '#' . $l->order_number . ' ' . $l->sku_snapshot . ' x' . (int) $l->ship_qty;
				}
				return array( $s->shipment_uid, $box ? $box->box_number : 'Separate', $p ? $p->customer_uid : '', Customers::display_name( $p ), Shipments::STATUSES[ $s->status ] ?? $s->status, implode( '; ', $desc ), $s->carrier, $s->tracking_number, $tier ? $tier->name : '', null === $s->shipping_charge_usd ? '' : (float) $s->shipping_charge_usd, (string) $s->shipped_at, (string) $s->delivered_at );
		}
		return null;
	}

	/* ---------------------------------------------------------------- */
	/* Google API                                                       */
	/* ---------------------------------------------------------------- */

	private static function access_token() {
		$cached = get_transient( 'ssp_gs_token' );
		if ( $cached ) {
			return $cached;
		}
		$sa = json_decode( (string) Settings::get( 'sheets_service_account' ), true );
		if ( empty( $sa['client_email'] ) || empty( $sa['private_key'] ) ) {
			throw new PermanentJobError( 'Google service account JSON is missing or invalid (Settings > Google Sheets).' );
		}
		$now    = time();
		$header = self::b64( wp_json_encode( array( 'alg' => 'RS256', 'typ' => 'JWT' ) ) );
		$claim  = self::b64(
			wp_json_encode(
				array(
					'iss'   => $sa['client_email'],
					'scope' => 'https://www.googleapis.com/auth/spreadsheets',
					'aud'   => 'https://oauth2.googleapis.com/token',
					'iat'   => $now,
					'exp'   => $now + 3600,
				)
			)
		);
		$sig = '';
		if ( ! openssl_sign( $header . '.' . $claim, $sig, $sa['private_key'], 'sha256WithRSAEncryption' ) ) {
			throw new PermanentJobError( 'Could not sign Google service account token.' );
		}
		$jwt  = $header . '.' . $claim . '.' . self::b64( $sig );
		$resp = wp_remote_post(
			'https://oauth2.googleapis.com/token',
			array(
				'body'    => array(
					'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
					'assertion'  => $jwt,
				),
				'timeout' => 20,
			)
		);
		if ( is_wp_error( $resp ) ) {
			throw new \RuntimeException( 'Google auth error: ' . $resp->get_error_message() );
		}
		$data = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( empty( $data['access_token'] ) ) {
			throw new \RuntimeException( 'Google auth error: ' . ( $data['error_description'] ?? $data['error'] ?? 'unknown' ) );
		}
		set_transient( 'ssp_gs_token', $data['access_token'], (int) $data['expires_in'] - 120 );
		return $data['access_token'];
	}

	private static function b64( $s ) {
		return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' );
	}

	private static function api( $method, $path, $body = null, array $query = array() ) {
		$url  = 'https://sheets.googleapis.com/v4/spreadsheets/' . rawurlencode( Settings::get( 'sheets_spreadsheet_id' ) ) . $path;
		$url  = $query ? add_query_arg( $query, $url ) : $url;
		$args = array(
			'method'  => $method,
			'headers' => array(
				'Authorization' => 'Bearer ' . self::access_token(),
				'Content-Type'  => 'application/json',
			),
			'timeout' => 30,
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}
		$resp = wp_remote_request( $url, $args );
		if ( is_wp_error( $resp ) ) {
			throw new \RuntimeException( 'Google Sheets connection error: ' . $resp->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		$data = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( $code >= 400 ) {
			if ( 401 === $code ) {
				delete_transient( 'ssp_gs_token' );
			}
			$msg = $data['error']['message'] ?? ( 'HTTP ' . $code );
			if ( 403 === $code || 404 === $code ) {
				throw new PermanentJobError( 'Google Sheets: ' . $msg . ' (check the spreadsheet ID and that it is shared with the service account).' );
			}
			throw new \RuntimeException( 'Google Sheets: ' . $msg );
		}
		return is_array( $data ) ? $data : array();
	}

	private static function col_letter( $n ) {
		$s = '';
		while ( $n > 0 ) {
			$m = ( $n - 1 ) % 26;
			$s = chr( 65 + $m ) . $s;
			$n = intdiv( $n - $m, 26 );
		}
		return $s;
	}

	private static function range( $tab, $a1 ) {
		return "'" . str_replace( "'", "''", $tab ) . "'!" . $a1;
	}

	public static function ensure_tabs() {
		if ( get_transient( 'ssp_gs_tabs_ok' ) ) {
			return;
		}
		$meta     = self::api( 'GET', '', null, array( 'fields' => 'sheets.properties' ) );
		$existing = array();
		foreach ( (array) ( $meta['sheets'] ?? array() ) as $s ) {
			$existing[ $s['properties']['title'] ] = $s['properties']['sheetId'];
		}
		$requests = array();
		foreach ( array_keys( self::TABS ) as $tab ) {
			if ( ! isset( $existing[ $tab ] ) ) {
				$requests[] = array( 'addSheet' => array( 'properties' => array( 'title' => $tab, 'gridProperties' => array( 'frozenRowCount' => 1 ) ) ) );
			}
		}
		if ( $requests ) {
			self::api( 'POST', ':batchUpdate', array( 'requests' => $requests ) );
		}
		$data = array();
		foreach ( self::TABS as $tab => $headers ) {
			$data[] = array(
				'range'  => self::range( $tab, 'A1:' . self::col_letter( count( $headers ) ) . '1' ),
				'values' => array( $headers ),
			);
		}
		self::api( 'POST', '/values:batchUpdate', array( 'valueInputOption' => 'RAW', 'data' => $data ) );
		set_transient( 'ssp_gs_tabs_ok', 1, HOUR_IN_SECONDS );
	}

	/** Job: upsert one logical row in place, keyed by the stable portal ID in column A. */
	public static function job_upsert( array $p ) {
		global $wpdb;
		if ( ! self::enabled() ) {
			return true;
		}
		$tab = $p['tab'];
		$uid = $p['uid'];
		if ( ! isset( self::TABS[ $tab ] ) ) {
			throw new PermanentJobError( 'Unknown sheet tab ' . $tab );
		}
		$row = self::build_row( $tab, $uid );
		if ( null === $row ) {
			return true;
		}
		$hash = md5( wp_json_encode( $row ) );
		$mt   = Installer::tables()['sheet_rows'];
		$map  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$mt} WHERE tab=%s AND portal_uid=%s", $tab, $uid ) );
		if ( $map && $map->last_hash === $hash ) {
			return true;
		}
		self::ensure_tabs();
		$last  = self::col_letter( count( self::TABS[ $tab ] ) );
		$index = $map ? (int) $map->row_index : 0;
		if ( $index ) {
			// Verify the mapped row still holds this ID (rows may have been sorted/deleted by people).
			$check = self::api( 'GET', '/values/' . rawurlencode( self::range( $tab, 'A' . $index ) ) );
			if ( ( $check['values'][0][0] ?? '' ) !== $uid ) {
				$index = 0;
			}
		}
		if ( ! $index ) {
			$col = self::api( 'GET', '/values/' . rawurlencode( self::range( $tab, 'A:A' ) ) );
			foreach ( (array) ( $col['values'] ?? array() ) as $i => $v ) {
				if ( ( $v[0] ?? '' ) === $uid ) {
					$index = $i + 1;
					break;
				}
			}
		}
		if ( $index ) {
			self::api( 'PUT', '/values/' . rawurlencode( self::range( $tab, 'A' . $index . ':' . $last . $index ) ), array( 'values' => array( $row ) ), array( 'valueInputOption' => 'RAW' ) );
		} else {
			$r = self::api( 'POST', '/values/' . rawurlencode( self::range( $tab, 'A1' ) ) . ':append', array( 'values' => array( $row ) ), array( 'valueInputOption' => 'RAW', 'insertDataOption' => 'INSERT_ROWS' ) );
			if ( preg_match( '/![A-Z]+(\d+)/', (string) ( $r['updates']['updatedRange'] ?? '' ), $m ) ) {
				$index = (int) $m[1];
			}
		}
		$wpdb->query( $wpdb->prepare( "INSERT INTO {$mt} (tab, portal_uid, row_index, last_hash, updated_at) VALUES (%s,%s,%d,%s,%s) ON DUPLICATE KEY UPDATE row_index=VALUES(row_index), last_hash=VALUES(last_hash), updated_at=VALUES(updated_at)", $tab, $uid, $index, $hash, Util::now() ) );
		return true;
	}

	/** Staff action: rebuild every tab from the database (clears tabs, rewrites all rows). */
	public static function rebuild() {
		global $wpdb;
		$t = Installer::tables();
		delete_transient( 'ssp_gs_tabs_ok' );
		self::ensure_tabs();
		$sets = array(
			'Customers'               => $wpdb->get_col( "SELECT customer_uid FROM {$t['profiles']} ORDER BY created_at" ),
			'Pre-order Lines'         => $wpdb->get_col( "SELECT line_uid FROM {$t['lines']} ORDER BY id" ),
			'Allocations & Waitlists' => array_merge( $wpdb->get_col( "SELECT variant_uid FROM {$t['variants']} ORDER BY id" ), $wpdb->get_col( "SELECT waitlist_uid FROM {$t['waitlist']} ORDER BY id" ) ),
			'Open Boxes'              => $wpdb->get_col( "SELECT box_uid FROM {$t['boxes']} ORDER BY id" ),
			'Shipments'               => $wpdb->get_col( "SELECT shipment_uid FROM {$t['shipments']} ORDER BY id" ),
		);
		$wpdb->query( "DELETE FROM {$t['sheet_rows']}" );
		$data = array();
		foreach ( $sets as $tab => $uids ) {
			self::api( 'POST', '/values/' . rawurlencode( self::range( $tab, 'A2:ZZ' ) ) . ':clear', new \stdClass() );
			$rows = array();
			foreach ( $uids as $uid ) {
				$r = self::build_row( $tab, $uid );
				if ( $r ) {
					$rows[] = $r;
				}
			}
			if ( $rows ) {
				$data[] = array( 'range' => self::range( $tab, 'A2' ), 'values' => $rows );
			}
			foreach ( $rows as $i => $r ) {
				$wpdb->query( $wpdb->prepare( "INSERT INTO {$t['sheet_rows']} (tab, portal_uid, row_index, last_hash, updated_at) VALUES (%s,%s,%d,%s,%s)", $tab, $r[0], $i + 2, md5( wp_json_encode( $r ) ), Util::now() ) );
			}
		}
		if ( $data ) {
			self::api( 'POST', '/values:batchUpdate', array( 'valueInputOption' => 'RAW', 'data' => $data ) );
		}
		return true;
	}
}
