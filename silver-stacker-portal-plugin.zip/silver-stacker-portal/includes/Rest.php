<?php
namespace SSP;

use SSP\Domain\Cart;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Integrations\Qbo;
use SSP\Integrations\Warehouse;

defined( 'ABSPATH' ) || exit;

/**
 * REST API (namespace ssp/v1). Every customer route checks login + approval + terms, and every
 * object returned is scoped to the current user. Webhooks are verified by signature.
 */
class Rest {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function customer_permission() {
		return Customers::can_view_catalog( get_current_user_id() );
	}

	public static function routes() {
		register_rest_route(
			'ssp/v1',
			'/hooks/qbo',
			array(
				'methods'             => 'POST',
				'callback'            => array( Qbo::class, 'handle_webhook' ),
				'permission_callback' => '__return_true', // Verified by Intuit HMAC signature in the handler.
			)
		);
		register_rest_route(
			'ssp/v1',
			'/hooks/warehouse',
			array(
				'methods'             => 'POST',
				'callback'            => array( Warehouse::class, 'handle_webhook' ),
				'permission_callback' => '__return_true', // Verified by HMAC signature in the handler.
			)
		);
		register_rest_route(
			'ssp/v1',
			'/me/cart',
			array(
				'methods'             => 'GET',
				'callback'            => fn() => array( 'count' => Cart::count( get_current_user_id() ) ),
				'permission_callback' => array( __CLASS__, 'customer_permission' ),
			)
		);
		register_rest_route(
			'ssp/v1',
			'/catalog/suggest',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'suggest' ),
				'permission_callback' => array( __CLASS__, 'customer_permission' ),
				'args'                => array( 'q' => array( 'sanitize_callback' => 'sanitize_text_field' ) ),
			)
		);
	}

	public static function suggest( \WP_REST_Request $r ) {
		$out = array();
		foreach ( array( 'active', 'archive' ) as $tab ) {
			$res = Catalog::search( array( 'q' => $r->get_param( 'q' ), 'tab' => $tab, 'per_page' => 5 ) );
			foreach ( $res['rows'] as $p ) {
				$out[] = array(
					'name' => Catalog::display_name( $p ),
					'url'  => Catalog::url( $p ),
					'tab'  => $tab,
					'status' => Catalog::lifecycle_label( $p ),
				);
			}
		}
		return $out;
	}
}
