<?php
namespace SSP\Domain;

use SSP\Core\Installer;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Pre-Sale Tracker (replaces the shared spreadsheet): Active Product Master List, Active Orders,
 * Closed Orders and Ready to Invoice. All views are live queries over line-level data.
 */
class Tracker {

	public static function t() {
		return Installer::tables();
	}

	/** Active Product Master List: one row per variant of products not archived/draft. */
	public static function master_list( array $f = array() ) {
		global $wpdb;
		$t     = self::t();
		$where = "p.lifecycle IN ('presale','presale_ended','in_stock')";
		$params = array();
		if ( ! empty( $f['q'] ) ) {
			$like    = '%' . $wpdb->esc_like( $f['q'] ) . '%';
			$where  .= ' AND (p.name LIKE %s OR v.sku LIKE %s)';
			$params  = array( $like, $like );
		}
		if ( ! empty( $f['supplier_id'] ) ) {
			$where   .= ' AND p.supplier_id=%d';
			$params[] = (int) $f['supplier_id'];
		}
		$sql = "SELECT p.*, v.id AS variant_id, v.sku, v.label, v.price_usd, v.supplier_qty_ordered, v.total_allocation, v.reserved_qty, v.held_qty,
			(SELECT COALESCE(SUM(l.qty_available),0) FROM {$t['lines']} l WHERE l.variant_id=v.id) AS qty_available_lines,
			(SELECT COUNT(*) FROM {$t['lines']} l WHERE l.variant_id=v.id AND (l.qty_ordered-l.qty_cancelled)>0) AS line_count
			FROM {$t['products']} p JOIN {$t['variants']} v ON v.product_id=p.id
			WHERE {$where} ORDER BY p.date_posted DESC, p.id DESC, v.sort ASC";
		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );
		foreach ( $rows as $r ) {
			$life = Catalog::effective_lifecycle( $r );
			$r->tracker_status = 'presale' === $life ? 'Active' : ( 'in_stock' === $life ? 'In Stock' : 'Ordered' );
		}
		return $rows;
	}

	/**
	 * Lines grouped by product.
	 *
	 * @param string $mode active | closed | ready
	 */
	public static function grouped_lines( $mode, array $f = array() ) {
		global $wpdb;
		$t   = self::t();
		$now = Util::now();
		switch ( $mode ) {
			case 'active':
				$cond = "((p.lifecycle='presale' AND p.closing_at > '{$now}') OR p.lifecycle='in_stock') AND (l.qty_ordered-l.qty_cancelled) > 0 AND l.qty_available < (l.qty_ordered-l.qty_cancelled)";
				break;
			case 'closed':
				$cond = "(p.lifecycle IN ('presale_ended','archived') OR (p.lifecycle='presale' AND p.closing_at <= '{$now}')) AND (l.qty_ordered-l.qty_cancelled) > 0 AND l.qty_available < (l.qty_ordered-l.qty_cancelled)";
				break;
			case 'ready':
			default:
				$cond = 'l.qty_available > (l.qty_invoiced + l.qty_pending_invoice)';
				if ( ! empty( $f['include_invoiced'] ) ) {
					$cond = 'l.qty_available > 0 AND (l.qty_ordered-l.qty_cancelled) > 0';
				}
		}
		$params = array();
		if ( ! empty( $f['q'] ) ) {
			$like    = '%' . $wpdb->esc_like( $f['q'] ) . '%';
			$cond   .= ' AND (p.name LIKE %s OR l.sku_snapshot LIKE %s OR c.company_name LIKE %s OR c.contact_name LIKE %s)';
			$params  = array( $like, $like, $like, $like );
		}
		$sql = "SELECT l.*, o.order_number, o.submitted_at, o.customer_note, c.company_name, c.contact_name, p.name AS product_name, p.closing_at, p.lifecycle, p.eta_type, p.eta_start, p.eta_end, p.eta_text, p.id AS pid
			FROM {$t['lines']} l JOIN {$t['orders']} o ON o.id=l.order_id JOIN {$t['products']} p ON p.id=l.product_id LEFT JOIN {$t['profiles']} c ON c.user_id=l.user_id
			WHERE {$cond} ORDER BY p.closing_at ASC, p.id ASC, l.variant_id ASC, o.submitted_at ASC LIMIT 3000";
		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );
		$groups = array();
		foreach ( $rows as $r ) {
			$k = (int) $r->variant_id;
			if ( ! isset( $groups[ $k ] ) ) {
				$groups[ $k ] = array(
					'name'    => $r->name_snapshot,
					'product' => (object) array( 'eta_type' => $r->eta_type, 'eta_start' => $r->eta_start, 'eta_end' => $r->eta_end, 'eta_text' => $r->eta_text ),
					'closing' => $r->closing_at,
					'pid'     => (int) $r->pid,
					'variant_id' => $k,
					'lines'   => array(),
					'qty'     => 0,
					'total'   => 0,
				);
			}
			$groups[ $k ]['lines'][] = $r;
			$groups[ $k ]['qty']    += Orders::net( $r );
			$groups[ $k ]['total']  += Orders::line_total( $r );
		}
		return $groups;
	}
}
