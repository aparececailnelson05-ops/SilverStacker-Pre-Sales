<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Events;
use SSP\Core\Installer;
use SSP\Core\Mailer;
use SSP\Core\Settings;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Waitlists when allocation is unavailable. Promotion mode is configurable (decision D-1):
 *  hold (default): freed allocation is held for the next customer for N hours (FIFO); they accept to convert.
 *  fcfs: waiting customers are notified; first to order normally gets it.
 *  auto: freed allocation is automatically reserved as a new pre-order for the next customer.
 */
class Waitlist {

	const STATUSES = array(
		'waiting'   => 'Waiting',
		'offered'   => 'Available for you',
		'accepted'  => 'Accepted',
		'converted' => 'Ordered',
		'expired'   => 'Offer expired',
		'cancelled' => 'Cancelled',
	);

	public static function t() {
		return Installer::tables();
	}

	public static function get( $id ) {
		global $wpdb;
		$t = self::t()['waitlist'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
	}

	public static function get_owned( $user_id, $uid ) {
		global $wpdb;
		$t = self::t()['waitlist'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE waitlist_uid=%s AND user_id=%d", $uid, $user_id ) );
	}

	public static function for_user( $user_id ) {
		global $wpdb;
		$t = self::t()['waitlist'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d ORDER BY FIELD(status,'offered','waiting','converted','expired','cancelled'), created_at DESC", $user_id ) );
	}

	public static function for_variant( $variant_id, $active_only = true ) {
		global $wpdb;
		$t = self::t()['waitlist'];
		$s = $active_only ? " AND status IN ('waiting','offered')" : '';
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE variant_id=%d{$s} ORDER BY created_at ASC, id ASC", $variant_id ) );
	}

	public static function active_entry( $user_id, $variant_id ) {
		global $wpdb;
		$t = self::t()['waitlist'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND variant_id=%d AND status IN ('waiting','offered') LIMIT 1", $user_id, $variant_id ) );
	}

	public static function position( $entry ) {
		global $wpdb;
		$t = self::t()['waitlist'];
		return 1 + (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE variant_id=%d AND status='waiting' AND (created_at < %s OR (created_at=%s AND id<%d))", $entry->variant_id, $entry->created_at, $entry->created_at, $entry->id ) );
	}

	/** @return int|\WP_Error */
	public static function join( $user_id, $variant_id, $qty ) {
		global $wpdb;
		$v = Catalog::variant( $variant_id );
		if ( ! $v || ! $v->active ) {
			return new \WP_Error( 'variant', 'Item not found.' );
		}
		$p = Catalog::get( $v->product_id );
		if ( ! $p || ! Catalog::is_orderable( $p ) ) {
			return new \WP_Error( 'closed', 'This pre-sale has ended, so the waitlist is closed.' );
		}
		$qty = max( 1, (int) $qty );
		$max = Allocation::max_addable( $v, $user_id );
		if ( null === $max || $max >= $qty ) {
			return new \WP_Error( 'available', 'This quantity is currently available. Add it to your order instead.' );
		}
		$t        = self::t()['waitlist'];
		$existing = self::active_entry( $user_id, $variant_id );
		$now      = Util::now();
		if ( $existing ) {
			$wpdb->update( $t, array( 'qty_requested' => $qty, 'updated_at' => $now ), array( 'id' => $existing->id ) );
			Audit::log( 'waitlist.updated', 'waitlist', $existing->id, array( 'qty' => (int) $existing->qty_requested ), array( 'qty' => $qty ), null, $user_id );
			return (int) $existing->id;
		}
		$wpdb->insert(
			$t,
			array(
				'waitlist_uid'  => Util::ulid(),
				'variant_id'    => $variant_id,
				'user_id'       => $user_id,
				'qty_requested' => $qty,
				'status'        => 'waiting',
				'created_at'    => $now,
				'updated_at'    => $now,
			)
		);
		$id = (int) $wpdb->insert_id;
		Audit::log( 'waitlist.joined', 'waitlist', $id, null, array( 'variant_id' => $variant_id, 'qty' => $qty ), null, $user_id );
		Events::emit( 'waitlist.changed', array( 'variant_id' => $variant_id ) );
		return $id;
	}

	public static function cancel( $entry_id, $actor_id = null, $reason = '' ) {
		global $wpdb;
		$e = self::get( $entry_id );
		if ( ! $e || ! in_array( $e->status, array( 'waiting', 'offered' ), true ) ) {
			return new \WP_Error( 'state', 'This waitlist entry is no longer active.' );
		}
		$wpdb->query( 'START TRANSACTION' );
		Allocation::lock_variants( array( $e->variant_id ) );
		if ( 'offered' === $e->status && $e->offered_qty > 0 ) {
			self::release_hold( $e );
		}
		$wpdb->update( self::t()['waitlist'], array( 'status' => 'cancelled', 'updated_at' => Util::now() ), array( 'id' => $entry_id ) );
		$wpdb->query( 'COMMIT' );
		Audit::log( 'waitlist.cancelled', 'waitlist', $entry_id, array( 'status' => $e->status ), array( 'status' => 'cancelled' ), $reason ? $reason : null, $actor_id );
		Events::emit( 'waitlist.changed', array( 'variant_id' => (int) $e->variant_id ) );
		if ( 'offered' === $e->status ) {
			self::process_variant( (int) $e->variant_id );
		}
		return true;
	}

	private static function release_hold( $e ) {
		global $wpdb;
		$vt = self::t()['variants'];
		$wpdb->query( $wpdb->prepare( "UPDATE {$vt} SET held_qty = GREATEST(0, CAST(held_qty AS SIGNED) - %d) WHERE id=%d", (int) $e->offered_qty, $e->variant_id ) );
	}

	/** Customer accepts a held offer: converts to a pre-order line through normal validation. */
	public static function accept( $user_id, $uid, $fulfillment = 'decide_later' ) {
		global $wpdb;
		$e = self::get_owned( $user_id, $uid );
		if ( ! $e || 'offered' !== $e->status ) {
			return new \WP_Error( 'state', 'This offer is no longer available.' );
		}
		if ( $e->offer_expires_at && Util::ts( $e->offer_expires_at ) < time() ) {
			self::expire( $e );
			return new \WP_Error( 'expired', 'Sorry, this offer has expired.' );
		}
		$qty = (int) ( $e->offered_qty ? $e->offered_qty : $e->qty_requested );
		$order_id = Orders::place(
			$user_id,
			array( array( 'variant_id' => (int) $e->variant_id, 'qty' => $qty, 'fulfillment' => $fulfillment ) ),
			'wl' . strtolower( $e->waitlist_uid ),
			'Waitlist offer accepted',
			array( 'held_credit' => array( (int) $e->variant_id => (int) $e->offered_qty ), 'source' => 'waitlist' )
		);
		if ( is_wp_error( $order_id ) ) {
			return $order_id;
		}
		$line = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . self::t()['lines'] . ' WHERE order_id=%d LIMIT 1', $order_id ) );
		$remaining = max( 0, (int) $e->qty_requested - $qty );
		$wpdb->update(
			self::t()['waitlist'],
			array(
				'status'            => 'converted',
				'converted_line_id' => $line ? $line->id : null,
				'updated_at'        => Util::now(),
			),
			array( 'id' => $e->id )
		);
		Audit::log( 'waitlist.converted', 'waitlist', $e->id, null, array( 'order_id' => $order_id, 'qty' => $qty ), null, $user_id );
		if ( $remaining > 0 ) {
			// Keep waiting for the rest.
			$wpdb->insert(
				self::t()['waitlist'],
				array(
					'waitlist_uid'  => Util::ulid(),
					'variant_id'    => $e->variant_id,
					'user_id'       => $user_id,
					'qty_requested' => $remaining,
					'status'        => 'waiting',
					'created_at'    => $e->created_at, // keeps original queue position
					'updated_at'    => Util::now(),
				)
			);
		}
		Events::emit( 'waitlist.changed', array( 'variant_id' => (int) $e->variant_id ) );
		return $order_id;
	}

	public static function expire( $e ) {
		global $wpdb;
		$wpdb->query( 'START TRANSACTION' );
		Allocation::lock_variants( array( $e->variant_id ) );
		$fresh = self::get( $e->id );
		if ( $fresh && 'offered' === $fresh->status ) {
			self::release_hold( $fresh );
			$wpdb->update( self::t()['waitlist'], array( 'status' => 'expired', 'updated_at' => Util::now() ), array( 'id' => $e->id ) );
		}
		$wpdb->query( 'COMMIT' );
		Audit::log( 'waitlist.expired', 'waitlist', $e->id, null, null, 'Offer window passed', 0 );
		self::process_variant( (int) $e->variant_id );
	}

	public static function expire_due() {
		global $wpdb;
		$t    = self::t()['waitlist'];
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE status='offered' AND offer_expires_at IS NOT NULL AND offer_expires_at < %s", Util::now() ) );
		foreach ( $rows as $r ) {
			self::expire( $r );
		}
		return count( $rows );
	}

	/** Promote waiting customers when allocation becomes available. */
	public static function process_variant( $variant_id ) {
		global $wpdb;
		$mode = Settings::get( 'waitlist_mode' );
		$v    = Catalog::variant( $variant_id );
		if ( ! $v ) {
			return;
		}
		$p = Catalog::get( $v->product_id );
		if ( ! $p || ! Catalog::is_orderable( $p ) ) {
			return;
		}
		$waiting = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t()['waitlist'] . " WHERE variant_id=%d AND status='waiting' ORDER BY created_at ASC, id ASC", $variant_id ) );
		if ( ! $waiting ) {
			return;
		}

		if ( 'fcfs' === $mode ) {
			$remaining = Allocation::remaining_total( $v );
			if ( null !== $remaining && $remaining <= 0 ) {
				return;
			}
			foreach ( $waiting as $e ) {
				$wpdb->update( self::t()['waitlist'], array( 'status' => 'offered', 'offered_qty' => 0, 'offered_at' => Util::now(), 'updated_at' => Util::now() ), array( 'id' => $e->id ) );
				self::notify( $e, $p, 'Allocation is available now on a first-come, first-served basis. Order soon to secure it.' );
			}
			return;
		}

		$offers = array();
		$wpdb->query( 'START TRANSACTION' );
		$locked    = Allocation::lock_variants( array( $variant_id ) );
		$v         = $locked[ $variant_id ];
		$remaining = Allocation::remaining_total( $v );
		foreach ( $waiting as $e ) {
			if ( null !== $remaining && $remaining <= 0 ) {
				break;
			}
			$rc    = Allocation::remaining_customer( $v, $e->user_id );
			$offer = (int) $e->qty_requested;
			if ( null !== $remaining ) {
				$offer = min( $offer, $remaining );
			}
			if ( null !== $rc ) {
				$offer = min( $offer, $rc );
			}
			if ( $offer <= 0 ) {
				continue;
			}
			if ( 'auto' === $mode ) {
				$offers[] = array( $e, $offer );
				if ( null !== $remaining ) {
					$remaining -= $offer;
				}
				continue;
			}
			$hours = max( 1, (int) Settings::get( 'waitlist_hold_hours' ) );
			$wpdb->update(
				self::t()['waitlist'],
				array(
					'status'           => 'offered',
					'offered_qty'      => $offer,
					'offered_at'       => Util::now(),
					'offer_expires_at' => Util::now( $hours * 3600 ),
					'updated_at'       => Util::now(),
				),
				array( 'id' => $e->id )
			);
			$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t()['variants'] . ' SET held_qty = held_qty + %d WHERE id=%d', $offer, $variant_id ) );
			$v->held_qty = (int) $v->held_qty + $offer;
			if ( null !== $remaining ) {
				$remaining -= $offer;
			}
			$offers[] = array( $e, $offer );
		}
		$wpdb->query( 'COMMIT' );

		foreach ( $offers as list( $e, $offer ) ) {
			if ( 'auto' === $mode ) {
				$oid = Orders::place( (int) $e->user_id, array( array( 'variant_id' => $variant_id, 'qty' => $offer, 'fulfillment' => Settings::get( 'default_fulfillment_choice' ) ) ), 'wla' . strtolower( $e->waitlist_uid ), 'Automatically reserved from waitlist', array( 'source' => 'waitlist' ) );
				if ( ! is_wp_error( $oid ) ) {
					$wpdb->update( self::t()['waitlist'], array( 'status' => 'converted', 'updated_at' => Util::now() ), array( 'id' => $e->id ) );
					self::notify( $e, $p, sprintf( 'We automatically reserved %d for you on a new pre-order. You can change the quantity in My Orders before the closing date.', $offer ) );
				}
			} else {
				$hours = max( 1, (int) Settings::get( 'waitlist_hold_hours' ) );
				self::notify( $e, $p, sprintf( 'We are holding %d for you until %s. Accept the offer from your waitlist page to reserve it.', $offer, Util::fmt_dt( Util::now( $hours * 3600 ) ) ) );
			}
			Audit::log( 'waitlist.offered', 'waitlist', $e->id, null, array( 'qty' => $offer, 'mode' => $mode ), null, 0 );
		}
		if ( $offers ) {
			Events::emit( 'waitlist.changed', array( 'variant_id' => $variant_id ) );
		}
	}

	private static function notify( $e, $product, $action_text ) {
		$prof = Customers::profile( $e->user_id );
		if ( ! $prof ) {
			return;
		}
		$v = Catalog::variant( $e->variant_id );
		Mailer::queue(
			'waitlist_available',
			$prof->email,
			array(
				'name'        => $prof->contact_name,
				'product'     => $product->name . ( $v && $v->label ? ' - ' . $v->label : '' ),
				'action_text' => $action_text,
			),
			(int) $e->user_id,
			'waitlist',
			$e->id
		);
	}

	public static function staff_list( array $args = array() ) {
		global $wpdb;
		$t  = self::t()['waitlist'];
		$pt = self::t()['profiles'];
		$vt = self::t()['variants'];
		$prt = self::t()['products'];
		$where = array( '1=1' );
		$params = array();
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'w.status=%s';
			$params[] = $args['status'];
		} else {
			$where[] = "w.status IN ('waiting','offered')";
		}
		if ( ! empty( $args['variant_id'] ) ) {
			$where[]  = 'w.variant_id=%d';
			$params[] = (int) $args['variant_id'];
		}
		$w   = implode( ' AND ', $where );
		$sql = "SELECT w.*, c.company_name, c.contact_name, v.sku, v.label AS variant_label, p.name AS product_name, p.id AS product_id FROM {$t} w LEFT JOIN {$pt} c ON c.user_id=w.user_id LEFT JOIN {$vt} v ON v.id=w.variant_id LEFT JOIN {$prt} p ON p.id=v.product_id WHERE {$w} ORDER BY w.variant_id, w.created_at ASC LIMIT 500";
		return $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );
	}
}
