<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Installer;
use SSP\Core\Settings;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/** Versioned Terms & Conditions with recorded acceptance (customer ID, timestamp, version). */
class Terms {

	public static function current() {
		global $wpdb;
		$t = Installer::tables()['terms'];
		return $wpdb->get_row( "SELECT * FROM {$t} WHERE is_current=1 ORDER BY id DESC LIMIT 1" );
	}

	public static function all() {
		global $wpdb;
		$t = Installer::tables()['terms'];
		return $wpdb->get_results( "SELECT * FROM {$t} ORDER BY id DESC" );
	}

	public static function has_accepted_current( $user_id ) {
		global $wpdb;
		$cur = self::current();
		if ( ! $cur ) {
			return true;
		}
		$t = Installer::tables()['acceptances'];
		if ( Settings::get( 'require_terms_reaccept' ) ) {
			return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE user_id=%d AND terms_version_id=%d", $user_id, $cur->id ) );
		}
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE user_id=%d", $user_id ) );
	}

	public static function accept( $user_id, $version_id ) {
		global $wpdb;
		$cur = self::current();
		if ( ! $cur || (int) $cur->id !== (int) $version_id ) {
			return new \WP_Error( 'version', 'The terms were updated. Please review the latest version.' );
		}
		$t = Installer::tables()['acceptances'];
		$wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$t} (user_id, terms_version_id, accepted_at, ip, user_agent) VALUES (%d,%d,%s,%s,%s)",
				$user_id,
				$cur->id,
				Util::now(),
				Util::ip(),
				Util::ua()
			)
		);
		Audit::log( 'terms.accepted', 'customer', $user_id, null, array( 'terms_version' => $cur->version_label, 'terms_version_id' => (int) $cur->id ), null, $user_id );
		return true;
	}

	public static function acceptances( $user_id ) {
		global $wpdb;
		$a = Installer::tables()['acceptances'];
		$v = Installer::tables()['terms'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT a.*, v.version_label FROM {$a} a JOIN {$v} v ON v.id=a.terms_version_id WHERE a.user_id=%d ORDER BY a.id DESC", $user_id ) );
	}

	public static function publish( $label, $content ) {
		global $wpdb;
		$t = Installer::tables()['terms'];
		$label = sanitize_text_field( $label );
		if ( '' === $label || '' === trim( wp_strip_all_tags( $content ) ) ) {
			return new \WP_Error( 'required', 'Version label and content are required.' );
		}
		$wpdb->query( "UPDATE {$t} SET is_current=0" );
		$wpdb->insert(
			$t,
			array(
				'version_label' => $label,
				'content'       => wp_kses_post( $content ),
				'is_current'    => 1,
				'published_by'  => get_current_user_id(),
				'published_at'  => Util::now(),
			)
		);
		$id = (int) $wpdb->insert_id;
		Audit::log( 'terms.published', 'terms', $id, null, array( 'version' => $label ) );
		return $id;
	}
}
