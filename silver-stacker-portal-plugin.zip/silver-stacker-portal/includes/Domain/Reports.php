<?php
namespace SSP\Domain;

use SSP\Core\Installer;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Staff reports. Ordered, Invoiced and Paid are always reported as separate measures.
 * "Paid" only counts invoices QuickBooks reports as paid (balance 0); partial payments are
 * shown in their own column as amounts received.
 */
class Reports {

	public static function t() {
		return Installer::tables();
	}

	/** Normalizes a local date range to UTC bounds. */
	public static function range( $from, $to ) {
		$from = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $from ) ? $from : gmdate( 'Y-01-01' );
		$to   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $to ) ? $to : current_time( 'Y-m-d' );
		return array( $from, $to, Util::local_to_utc( $from . ' 00:00:00' ), Util::local_to_utc( $to . ' 23:59:59' ) );
	}

	private static function tz_offset_sql() {
		$d = new \DateTime( 'now', Util::business_tz() );
		$o = $d->getOffset();
		return sprintf( '%s%02d:%02d', $o < 0 ? '-' : '+', abs( $o ) / 3600, ( abs( $o ) % 3600 ) / 60 );
	}

	private static function period_sql( $col, $granularity ) {
		$off   = self::tz_offset_sql();
		$local = "CONVERT_TZ({$col}, '+00:00', '{$off}')";
		switch ( $granularity ) {
			case 'day':
				return "DATE_FORMAT({$local}, '%Y-%m-%d')";
			case 'week':
				return "DATE_FORMAT({$local}, '%x-W%v')";
			case 'year':
				return "DATE_FORMAT({$local}, '%Y')";
		}
		return "DATE_FORMAT({$local}, '%Y-%m')";
	}

	public static function sales_summary( $from, $to ) {
		global $wpdb;
		list( , , $f, $tt ) = self::range( $from, $to );
		$t   = self::t();
		$per = self::period_sql( 'o.submitted_at', 'month' );
		$ordered = $wpdb->get_results( $wpdb->prepare( "SELECT {$per} AS period, COUNT(DISTINCT o.id) AS orders, SUM((l.qty_ordered - l.qty_cancelled) * l.unit_price_usd) AS ordered FROM {$t['orders']} o JOIN {$t['lines']} l ON l.order_id=o.id WHERE o.submitted_at BETWEEN %s AND %s GROUP BY period ORDER BY period", $f, $tt ), OBJECT_K );
		$iper = "DATE_FORMAT(i.txn_date, '%Y-%m')";
		$inv  = $wpdb->get_results( $wpdb->prepare( "SELECT {$iper} AS period, SUM(i.total_usd) AS invoiced, SUM(CASE WHEN i.sync_status='paid' THEN i.total_usd ELSE 0 END) AS paid, SUM(CASE WHEN i.source='qbo' AND i.sync_status IN ('partially_paid','paid','overdue','synced') THEN GREATEST(0, i.total_usd - COALESCE(i.balance_usd, i.total_usd)) ELSE 0 END) AS received FROM {$t['invoices']} i WHERE i.sync_status IN ('synced','partially_paid','paid','overdue') AND i.txn_date BETWEEN %s AND %s GROUP BY period", substr( $f, 0, 10 ), substr( $tt, 0, 10 ) ), OBJECT_K );
		$periods = array_unique( array_merge( array_keys( $ordered ), array_keys( $inv ) ) );
		sort( $periods );
		$rows = array();
		foreach ( $periods as $p ) {
			$rows[] = array(
				'period'   => $p,
				'orders'   => (int) ( $ordered[ $p ]->orders ?? 0 ),
				'ordered'  => (float) ( $ordered[ $p ]->ordered ?? 0 ),
				'invoiced' => (float) ( $inv[ $p ]->invoiced ?? 0 ),
				'received' => (float) ( $inv[ $p ]->received ?? 0 ),
				'paid'     => (float) ( $inv[ $p ]->paid ?? 0 ),
			);
		}
		return $rows;
	}

	public static function sales_by_product( $from, $to, array $f = array() ) {
		global $wpdb;
		list( , , $uf, $ut ) = self::range( $from, $to );
		$t      = self::t();
		$where  = array( 'o.submitted_at BETWEEN %s AND %s' );
		$params = array( $uf, $ut );
		if ( ! empty( $f['metal'] ) ) {
			$where[]  = 'p.metal=%s';
			$params[] = $f['metal'];
		}
		if ( ! empty( $f['lifecycle'] ) ) {
			$where[]  = 'p.lifecycle=%s';
			$params[] = $f['lifecycle'];
		}
		if ( ! empty( $f['product_id'] ) ) {
			$where[]  = 'p.id=%d';
			$params[] = (int) $f['product_id'];
		}
		if ( ! empty( $f['user_id'] ) ) {
			$where[]  = 'l.user_id=%d';
			$params[] = (int) $f['user_id'];
		}
		$sorts = array(
			'name'     => 'p.name ASC',
			'name_desc'=> 'p.name DESC',
			'code'     => 'codes ASC',
			'qty'      => 'qty_ordered DESC',
			'value'    => 'ordered DESC',
			'posted'   => 'p.date_posted DESC',
		);
		$order = $sorts[ $f['sort'] ?? 'name' ] ?? 'p.name ASC';
		$w     = implode( ' AND ', $where );
		$sql   = "SELECT p.id, p.name, p.metal, p.date_posted, p.lifecycle, GROUP_CONCAT(DISTINCT l.sku_snapshot ORDER BY l.sku_snapshot SEPARATOR ', ') AS codes,
			COUNT(DISTINCT o.id) AS orders,
			SUM(l.qty_ordered - l.qty_cancelled) AS qty_ordered,
			SUM((l.qty_ordered - l.qty_cancelled) * l.unit_price_usd) AS ordered,
			SUM(l.qty_available) AS qty_available,
			SUM(l.qty_invoiced) AS qty_invoiced
			FROM {$t['lines']} l JOIN {$t['orders']} o ON o.id=l.order_id JOIN {$t['products']} p ON p.id=l.product_id
			WHERE {$w} GROUP BY p.id, p.name, p.metal, p.date_posted, p.lifecycle ORDER BY {$order}";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
		$money = self::invoiced_paid_by( 'l.product_id', $uf, $ut );
		foreach ( $rows as $r ) {
			$r->invoiced = (float) ( $money[ $r->id ]->invoiced ?? 0 );
			$r->paid     = (float) ( $money[ $r->id ]->paid ?? 0 );
		}
		return $rows;
	}

	/** Invoiced and paid amounts per product or customer for lines ordered in range. */
	private static function invoiced_paid_by( $group_col, $uf, $ut ) {
		global $wpdb;
		$t = self::t();
		$sql = "SELECT {$group_col} AS gid, SUM(il.amount_usd) AS invoiced, SUM(CASE WHEN i.sync_status='paid' THEN il.amount_usd ELSE 0 END) AS paid
			FROM {$t['invoice_lines']} il JOIN {$t['invoices']} i ON i.id=il.invoice_id JOIN {$t['lines']} l ON l.id=il.order_line_id JOIN {$t['orders']} o ON o.id=l.order_id
			WHERE il.type='product' AND i.sync_status IN ('synced','partially_paid','paid','overdue') AND o.submitted_at BETWEEN %s AND %s GROUP BY gid";
		return $wpdb->get_results( $wpdb->prepare( $sql, $uf, $ut ), OBJECT_K );
	}

	public static function sales_by_category( $from, $to, $granularity = 'month' ) {
		global $wpdb;
		list( , , $uf, $ut ) = self::range( $from, $to );
		$t   = self::t();
		$per = self::period_sql( 'o.submitted_at', in_array( $granularity, array( 'week', 'month', 'year' ), true ) ? $granularity : 'month' );
		$sql = "SELECT {$per} AS period, COALESCE(NULLIF(p.metal,''),'Uncategorized') AS metal, SUM(l.qty_ordered - l.qty_cancelled) AS qty, SUM((l.qty_ordered - l.qty_cancelled) * l.unit_price_usd) AS ordered, COUNT(DISTINCT o.id) AS orders
			FROM {$t['lines']} l JOIN {$t['orders']} o ON o.id=l.order_id JOIN {$t['products']} p ON p.id=l.product_id
			WHERE o.submitted_at BETWEEN %s AND %s GROUP BY period, metal ORDER BY period, metal";
		return $wpdb->get_results( $wpdb->prepare( $sql, $uf, $ut ) );
	}

	/** Ranking of customers per period, by quantity or by value. */
	public static function sales_by_customer( $from, $to, $granularity = 'total', $rank_by = 'value' ) {
		global $wpdb;
		list( , , $uf, $ut ) = self::range( $from, $to );
		$t      = self::t();
		$per    = 'total' === $granularity ? "'All'" : self::period_sql( 'o.submitted_at', $granularity );
		$sql    = "SELECT {$per} AS period, l.user_id, c.company_name, c.contact_name, COUNT(DISTINCT o.id) AS orders, SUM(l.qty_ordered - l.qty_cancelled) AS qty, SUM((l.qty_ordered - l.qty_cancelled) * l.unit_price_usd) AS ordered
			FROM {$t['lines']} l JOIN {$t['orders']} o ON o.id=l.order_id LEFT JOIN {$t['profiles']} c ON c.user_id=l.user_id
			WHERE o.submitted_at BETWEEN %s AND %s GROUP BY period, l.user_id, c.company_name, c.contact_name";
		$rows   = $wpdb->get_results( $wpdb->prepare( $sql, $uf, $ut ) );
		$money  = self::invoiced_paid_by( 'l.user_id', $uf, $ut );
		$key    = 'qty' === $rank_by ? 'qty' : 'ordered';
		$grouped = array();
		foreach ( $rows as $r ) {
			$r->invoiced = 'total' === $granularity ? (float) ( $money[ $r->user_id ]->invoiced ?? 0 ) : null;
			$r->paid     = 'total' === $granularity ? (float) ( $money[ $r->user_id ]->paid ?? 0 ) : null;
			$grouped[ $r->period ][] = $r;
		}
		krsort( $grouped );
		foreach ( $grouped as &$list ) {
			usort( $list, fn( $a, $b ) => (float) $b->$key <=> (float) $a->$key );
			foreach ( $list as $i => $r ) {
				$r->rank = $i + 1;
			}
		}
		return $grouped;
	}

	public static function preorders_by_customer( $from, $to, $user_id = 0 ) {
		global $wpdb;
		list( , , $uf, $ut ) = self::range( $from, $to );
		$t      = self::t();
		$extra  = $user_id ? $wpdb->prepare( ' AND l.user_id=%d', $user_id ) : '';
		$sql    = "SELECT l.user_id, c.company_name, c.contact_name, COUNT(DISTINCT o.id) AS orders, COUNT(l.id) AS lines_count,
			SUM(l.qty_ordered - l.qty_cancelled) AS qty_ordered, SUM(l.qty_available) AS qty_available, SUM(l.qty_invoiced) AS qty_invoiced, SUM(l.qty_shipped) AS qty_shipped,
			SUM((l.qty_ordered - l.qty_cancelled) * l.unit_price_usd) AS ordered, SUM(l.qty_invoiced * l.unit_price_usd) AS invoiced_at_order_price
			FROM {$t['lines']} l JOIN {$t['orders']} o ON o.id=l.order_id LEFT JOIN {$t['profiles']} c ON c.user_id=l.user_id
			WHERE o.submitted_at BETWEEN %s AND %s{$extra} GROUP BY l.user_id, c.company_name, c.contact_name ORDER BY c.company_name";
		return $wpdb->get_results( $wpdb->prepare( $sql, $uf, $ut ) );
	}

	public static function preorders_by_product( $from, $to, $metal = '' ) {
		global $wpdb;
		list( , , $uf, $ut ) = self::range( $from, $to );
		$t     = self::t();
		$extra = $metal ? $wpdb->prepare( ' AND p.metal=%s', $metal ) : '';
		$sql   = "SELECT v.id AS variant_id, v.sku, v.label, v.total_allocation, v.per_customer_allocation, v.reserved_qty, v.held_qty, p.name, p.lifecycle, p.closing_at,
			SUM(l.qty_ordered - l.qty_cancelled) AS qty_ordered, SUM(l.qty_available) AS qty_available, SUM(l.qty_invoiced) AS qty_invoiced, COUNT(DISTINCT l.user_id) AS customers
			FROM {$t['lines']} l JOIN {$t['orders']} o ON o.id=l.order_id JOIN {$t['variants']} v ON v.id=l.variant_id JOIN {$t['products']} p ON p.id=v.product_id
			WHERE o.submitted_at BETWEEN %s AND %s{$extra} GROUP BY v.id, v.sku, v.label, v.total_allocation, v.per_customer_allocation, v.reserved_qty, v.held_qty, p.name, p.lifecycle, p.closing_at ORDER BY p.name";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $uf, $ut ) );
		foreach ( $rows as $r ) {
			$v           = Catalog::variant( $r->variant_id );
			$r->remaining = $v ? Allocation::remaining_total( $v ) : null;
			$r->waitlist  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['waitlist']} WHERE variant_id=%d AND status IN ('waiting','offered')", $r->variant_id ) );
		}
		return $rows;
	}

	public static function boxes_report( $status = 'active' ) {
		$rows = Boxes::staff_list( array( 'status' => $status ) );
		foreach ( $rows as $b ) {
			$tot          = Boxes::totals( $b->id );
			$b->units     = $tot['units'];
			$b->available = $tot['available'];
			$b->lines     = $tot['lines'];
			$b->value     = $tot['value'];
			$b->age_days  = (int) floor( ( time() - Util::ts( $b->created_at ) ) / DAY_IN_SECONDS );
			$b->address   = Addresses::format( Boxes::address( $b ), ', ' );
			$tier         = $b->rate_tier_id ? Shipments::tier( $b->rate_tier_id ) : null;
			$b->tier      = $tier ? $tier->name : '';
			$s            = $b->shipment_id ? Shipments::get( $b->shipment_id ) : null;
			$b->tracking  = $s ? $s->tracking_number : '';
			$b->carrier   = $s ? $s->carrier : '';
		}
		return $rows;
	}

	/** Raw data exports (Orders, Invoices, Customers, Products). */
	public static function export( $what ) {
		global $wpdb;
		$t = self::t();
		switch ( $what ) {
			case 'orders':
				$rows = $wpdb->get_results( "SELECT o.order_number, o.submitted_at, c.company_name, c.contact_name, c.email, l.line_uid, l.name_snapshot, l.sku_snapshot, l.unit_price_usd, l.qty_ordered, l.qty_cancelled, l.qty_available, l.qty_invoiced, l.qty_shipped, l.fulfillment_choice, l.display_status, o.status, o.customer_note FROM {$t['lines']} l JOIN {$t['orders']} o ON o.id=l.order_id LEFT JOIN {$t['profiles']} c ON c.user_id=l.user_id ORDER BY o.order_number, l.id", ARRAY_A );
				return array( array( 'Order #', 'Submitted (UTC)', 'Company', 'Contact', 'Email', 'Line ID', 'Item', 'SKU', 'Unit Price', 'Qty Ordered', 'Qty Cancelled', 'Qty Available', 'Qty Invoiced', 'Qty Shipped', 'Fulfillment', 'Line Status', 'Order Status', 'Customer Note' ), $rows );
			case 'invoices':
				$rows = $wpdb->get_results( "SELECT i.invoice_uid, i.doc_number, i.qbo_invoice_id, c.company_name, c.contact_name, i.txn_date, i.due_date, i.total_usd, i.balance_usd, i.sync_status, i.source, i.created_at FROM {$t['invoices']} i LEFT JOIN {$t['profiles']} c ON c.user_id=i.user_id ORDER BY i.id", ARRAY_A );
				return array( array( 'Invoice ID', 'QBO Invoice #', 'QBO ID', 'Company', 'Contact', 'Invoice Date', 'Due Date', 'Total', 'Amount Due', 'Status', 'Source', 'Created (UTC)' ), $rows );
			case 'customers':
				$rows = $wpdb->get_results( "SELECT customer_uid, company_name, contact_name, email, phone, status, created_at, approved_at, last_order_at FROM {$t['profiles']} ORDER BY created_at", ARRAY_A );
				return array( array( 'Customer ID', 'Company', 'Contact', 'Email', 'Phone', 'Status', 'Created (UTC)', 'Approved (UTC)', 'Last Order (UTC)' ), $rows );
			case 'products':
				$rows = $wpdb->get_results( "SELECT p.product_uid, p.name, v.sku, v.barcode, v.label, p.brand, p.metal, p.category, p.mintage, p.lifecycle, v.price_usd, p.price_type, p.closing_at, p.eta_type, p.eta_start, p.eta_end, p.eta_text, v.min_order_qty, v.total_allocation, v.per_customer_allocation, v.reserved_qty, v.supplier_qty_ordered, s.name AS supplier, p.date_posted FROM {$t['products']} p LEFT JOIN {$t['variants']} v ON v.product_id=p.id LEFT JOIN {$t['suppliers']} s ON s.id=p.supplier_id ORDER BY p.id, v.sort", ARRAY_A );
				return array( array( 'Product ID', 'Name', 'SKU', 'Barcode', 'Variant', 'Brand', 'Metal', 'Category', 'Mintage', 'Lifecycle', 'Price USD', 'Price Type', 'Closing (UTC)', 'ETA Type', 'ETA Start', 'ETA End', 'ETA Text', 'Min Qty', 'Total Allocation', 'Per-Customer', 'Reserved', 'Supplier Qty Ordered', 'Supplier', 'Date Posted' ), $rows );
		}
		return array( array(), array() );
	}
}
