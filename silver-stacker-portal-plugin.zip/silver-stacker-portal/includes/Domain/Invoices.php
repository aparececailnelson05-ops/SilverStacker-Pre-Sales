<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Events;
use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\Mailer;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Staff-selected invoicing. QuickBooks Online is the financial authority.
 *
 * Two-phase, idempotent flow:
 *  1. Staff selects available, uninvoiced lines. In one transaction an invoice record is created
 *     (sync_status=queued) and the quantities move to qty_pending_invoice so they cannot be selected twice.
 *  2. A job creates the invoice in QBO using a fixed requestid (QBO de-duplicates retries).
 *     Success: pending -> invoiced, QBO fields stored, customer notified.
 *     Failure: status=error, lines are NOT marked invoiced; staff can retry (same requestid) or cancel
 *     (releases the pending quantities).
 * Nothing is ever shown as paid unless QBO reports the balance as paid.
 */
class Invoices {

	const SYNC_STATUSES = array(
		'queued'         => 'Queued',
		'creating'       => 'Creating',
		'synced'         => 'Invoiced (unpaid)',
		'partially_paid' => 'Partially paid',
		'paid'           => 'Paid',
		'overdue'        => 'Overdue',
		'error'          => 'Error',
		'voided'         => 'Voided',
		'cancelled'      => 'Cancelled before sync',
	);

	public static function t() {
		return Installer::tables();
	}

	public static function get( $id ) {
		global $wpdb;
		$t = self::t()['invoices'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
	}

	public static function get_owned( $user_id, $uid ) {
		global $wpdb;
		$t = self::t()['invoices'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE invoice_uid=%s AND user_id=%d", $uid, $user_id ) );
	}

	public static function by_qbo_id( $qbo_id ) {
		global $wpdb;
		$t = self::t()['invoices'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE qbo_invoice_id=%s", $qbo_id ) );
	}

	public static function lines( $invoice_id ) {
		global $wpdb;
		$il = self::t()['invoice_lines'];
		$lt = self::t()['lines'];
		$ot = self::t()['orders'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT il.*, l.name_snapshot, l.sku_snapshot, l.line_uid, l.product_id, o.order_number FROM {$il} il LEFT JOIN {$lt} l ON l.id=il.order_line_id LEFT JOIN {$ot} o ON o.id=l.order_id WHERE il.invoice_id=%d ORDER BY il.id", $invoice_id ) );
	}

	public static function for_user( $user_id ) {
		global $wpdb;
		$t = self::t()['invoices'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND sync_status NOT IN ('cancelled') ORDER BY id DESC", $user_id ) );
	}

	/** Invoices linked to a line (line-level relationship). */
	public static function for_line( $line_id ) {
		global $wpdb;
		$t  = self::t()['invoices'];
		$il = self::t()['invoice_lines'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT i.*, il.qty AS inv_qty FROM {$t} i JOIN {$il} il ON il.invoice_id=i.id WHERE il.order_line_id=%d AND i.sync_status NOT IN ('cancelled','voided') ORDER BY i.id", $line_id ) );
	}

	public static function payment_label( $inv ) {
		return self::SYNC_STATUSES[ $inv->sync_status ] ?? $inv->sync_status;
	}

	public static function is_final( $inv ) {
		return in_array( $inv->sync_status, array( 'synced', 'partially_paid', 'paid', 'overdue' ), true );
	}

	/* ---------------------------------------------------------------- */
	/* Selection                                                        */
	/* ---------------------------------------------------------------- */

	public static function invoiceable_qty( $line ) {
		return max( 0, (int) $line->qty_available - (int) $line->qty_invoiced - (int) $line->qty_pending_invoice );
	}

	public static function eligible_lines( $user_id ) {
		global $wpdb;
		$lt = self::t()['lines'];
		$ot = self::t()['orders'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT l.*, o.order_number, o.submitted_at FROM {$lt} l JOIN {$ot} o ON o.id=l.order_id WHERE l.user_id=%d AND l.qty_available > (l.qty_invoiced + l.qty_pending_invoice) ORDER BY o.submitted_at ASC, l.id ASC", $user_id ) );
	}

	public static function customers_ready() {
		global $wpdb;
		$lt = self::t()['lines'];
		$pt = self::t()['profiles'];
		return $wpdb->get_results( "SELECT l.user_id, c.company_name, c.contact_name, COUNT(*) AS line_count, SUM(l.qty_available - l.qty_invoiced - l.qty_pending_invoice) AS units, SUM((l.qty_available - l.qty_invoiced - l.qty_pending_invoice) * l.unit_price_usd) AS amount FROM {$lt} l LEFT JOIN {$pt} c ON c.user_id=l.user_id WHERE l.qty_available > (l.qty_invoiced + l.qty_pending_invoice) GROUP BY l.user_id, c.company_name, c.contact_name ORDER BY c.company_name" );
	}

	/**
	 * Create an invoice from selected lines.
	 *
	 * @param array  $selection [line_id => ['qty'=>int, 'unit_price'=>float|null]]
	 * @param array  $shipping  ['amount'=>float, 'description'=>string, 'shipment_id'=>int|null] or empty
	 * @param string $action_nonce Unique per staff confirmation screen; repeated posts reuse it (idempotent).
	 * @param string $mode qbo | manual (record an invoice already created in QBO by hand)
	 * @param array  $manual doc_number, qbo_invoice_id, total, due_date, txn_date, pay_link
	 * @return int|\WP_Error invoice id
	 */
	public static function create( $user_id, array $selection, array $shipping, $action_nonce, $mode = 'qbo', array $manual = array() ) {
		global $wpdb;
		$selection = array_filter(
			$selection,
			fn( $s ) => (int) ( $s['qty'] ?? 0 ) > 0
		);
		if ( ! $selection && empty( $shipping['amount'] ) ) {
			return new \WP_Error( 'empty', 'Select at least one line to invoice.' );
		}
		ksort( $selection );
		$key_src = $user_id . '|' . $action_nonce . '|' . wp_json_encode( $selection ) . '|' . wp_json_encode( $shipping );
		$key     = hash( 'sha256', $key_src );
		$it      = self::t()['invoices'];
		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$it} WHERE idempotency_key=%s", $key ) );
		if ( $existing ) {
			return (int) $existing;
		}
		if ( 'manual' === $mode && '' === trim( (string) ( $manual['doc_number'] ?? '' ) ) ) {
			return new \WP_Error( 'doc', 'Enter the QuickBooks invoice number you are recording.' );
		}
		$lt  = self::t()['lines'];
		$now = Util::now();
		$wpdb->query( 'START TRANSACTION' );
		try {
			$rows = array();
			foreach ( $selection as $lid => $s ) {
				$l = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$lt} WHERE id=%d FOR UPDATE", $lid ) );
				if ( ! $l || (int) $l->user_id !== (int) $user_id ) {
					throw new \RuntimeException( 'A selected line does not belong to this customer.' );
				}
				$q   = (int) $s['qty'];
				$max = self::invoiceable_qty( $l );
				if ( $q > $max ) {
					throw new \RuntimeException( sprintf( '%s: only %d available and not yet invoiced.', $l->name_snapshot, $max ) );
				}
				$price = ( isset( $s['unit_price'] ) && '' !== $s['unit_price'] && null !== $s['unit_price'] ) ? round( (float) $s['unit_price'], 2 ) : (float) $l->unit_price_usd;
				if ( $price < 0 ) {
					throw new \RuntimeException( 'Unit price cannot be negative.' );
				}
				$rows[] = array( $l, $q, $price );
			}
			$uid = Util::ulid();
			$wpdb->insert(
				$it,
				array(
					'invoice_uid'     => $uid,
					'user_id'         => $user_id,
					'source'          => 'manual' === $mode ? 'manual' : 'qbo',
					'sync_status'     => 'queued',
					'idempotency_key' => $key,
					'qbo_request_id'  => strtolower( $uid ),
					'created_by'      => get_current_user_id(),
					'created_at'      => $now,
					'updated_at'      => $now,
				)
			);
			$inv_id = (int) $wpdb->insert_id;
			$total  = 0;
			foreach ( $rows as list( $l, $q, $price ) ) {
				$amount = round( $q * $price, 2 );
				$total += $amount;
				$wpdb->insert(
					self::t()['invoice_lines'],
					array(
						'invoice_id'     => $inv_id,
						'order_line_id'  => $l->id,
						'type'           => 'product',
						'description'    => substr( $l->name_snapshot . ' (Order #' . Orders::get( $l->order_id )->order_number . ')', 0, 255 ),
						'qty'            => $q,
						'unit_price_usd' => $price,
						'amount_usd'     => $amount,
					)
				);
				$wpdb->query( $wpdb->prepare( "UPDATE {$lt} SET qty_pending_invoice = qty_pending_invoice + %d, updated_at=%s WHERE id=%d", $q, $now, $l->id ) );
				if ( abs( $price - (float) $l->unit_price_usd ) > 0.001 ) {
					Audit::log( 'invoice.price_override', 'order_line', $l->id, array( 'unit_price' => (float) $l->unit_price_usd ), array( 'unit_price' => $price ), 'spot_based' === $l->price_type ? 'Spot-based final price' : 'Staff price adjustment at invoicing' );
				}
			}
			if ( ! empty( $shipping['amount'] ) && (float) $shipping['amount'] > 0 ) {
				$amt    = round( (float) $shipping['amount'], 2 );
				$total += $amt;
				$wpdb->insert(
					self::t()['invoice_lines'],
					array(
						'invoice_id'     => $inv_id,
						'order_line_id'  => null,
						'type'           => 'shipping',
						'description'    => sanitize_text_field( $shipping['description'] ?? 'Shipping' ),
						'qty'            => 1,
						'unit_price_usd' => $amt,
						'amount_usd'     => $amt,
						'shipment_id'    => ! empty( $shipping['shipment_id'] ) ? (int) $shipping['shipment_id'] : null,
					)
				);
				if ( ! empty( $shipping['shipment_id'] ) ) {
					$wpdb->update( self::t()['shipments'], array( 'shipping_invoice_id' => $inv_id ), array( 'id' => (int) $shipping['shipment_id'] ) );
				}
			}
			$wpdb->update( $it, array( 'total_usd' => $total ), array( 'id' => $inv_id ) );
			$wpdb->query( 'COMMIT' );
		} catch ( \Throwable $e ) {
			$wpdb->query( 'ROLLBACK' );
			$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$it} WHERE idempotency_key=%s", $key ) );
			if ( $existing ) {
				return (int) $existing;
			}
			return new \WP_Error( 'invoice', $e->getMessage() );
		}
		foreach ( $selection as $lid => $s ) {
			Events::emit( 'line.changed', array( 'line_id' => (int) $lid ) );
		}
		Audit::log( 'invoice.created', 'invoice', $inv_id, null, array( 'mode' => $mode, 'lines' => $selection, 'shipping' => $shipping ) );

		if ( 'manual' === $mode ) {
			self::finalize_success(
				$inv_id,
				array(
					'qbo_invoice_id' => sanitize_text_field( $manual['qbo_invoice_id'] ?? '' ),
					'doc_number'     => sanitize_text_field( $manual['doc_number'] ),
					'txn_date'       => ! empty( $manual['txn_date'] ) ? sanitize_text_field( $manual['txn_date'] ) : current_time( 'Y-m-d' ),
					'due_date'       => ! empty( $manual['due_date'] ) ? sanitize_text_field( $manual['due_date'] ) : null,
					'total_usd'      => isset( $manual['total'] ) && '' !== $manual['total'] ? (float) $manual['total'] : null,
					'balance_usd'    => isset( $manual['total'] ) && '' !== $manual['total'] ? (float) $manual['total'] : null,
					'pay_link'       => esc_url_raw( $manual['pay_link'] ?? '' ),
				)
			);
		} else {
			Jobs::enqueue( 'qbo', 'qbo.create_invoice', 'invoice', $inv_id, array( 'invoice_id' => $inv_id ), 'qbo_create_invoice:' . $inv_id );
			Jobs::run( 3, 'qbo' );
		}
		return $inv_id;
	}

	/** Called by the QBO job after QBO confirms the invoice. */
	public static function finalize_success( $inv_id, array $qbo ) {
		global $wpdb;
		$inv = self::get( $inv_id );
		if ( ! $inv ) {
			return;
		}
		if ( self::is_final( $inv ) ) {
			return; // Already finalized (idempotent).
		}
		$lt  = self::t()['lines'];
		$now = Util::now();
		$wpdb->query( 'START TRANSACTION' );
		foreach ( self::lines( $inv_id ) as $il ) {
			if ( 'product' !== $il->type || ! $il->order_line_id ) {
				continue;
			}
			$wpdb->query( $wpdb->prepare( "UPDATE {$lt} SET qty_pending_invoice = GREATEST(0, CAST(qty_pending_invoice AS SIGNED) - %d), qty_invoiced = qty_invoiced + %d, updated_at=%s WHERE id=%d", (int) $il->qty, (int) $il->qty, $now, $il->order_line_id ) );
		}
		$data = array(
			'qbo_invoice_id' => $qbo['qbo_invoice_id'] ?? null,
			'doc_number'     => $qbo['doc_number'] ?? '',
			'txn_date'       => $qbo['txn_date'] ?? null,
			'due_date'       => $qbo['due_date'] ?? null,
			'total_usd'      => $qbo['total_usd'] ?? $inv->total_usd,
			'balance_usd'    => $qbo['balance_usd'] ?? ( $qbo['total_usd'] ?? $inv->total_usd ),
			'pay_link'       => $qbo['pay_link'] ?? null,
			'sync_status'    => 'synced',
			'error_message'  => null,
			'last_synced_at' => $now,
			'updated_at'     => $now,
		);
		$wpdb->update( self::t()['invoices'], $data, array( 'id' => $inv_id ) );
		$wpdb->query( 'COMMIT' );
		self::apply_payment_state( $inv_id );

		$rows = array();
		foreach ( self::lines( $inv_id ) as $il ) {
			if ( $il->order_line_id ) {
				Orders::refresh_line( (int) $il->order_line_id );
				Events::emit( 'line.changed', array( 'line_id' => (int) $il->order_line_id ) );
				$box = Boxes::line_box( (int) $il->order_line_id );
				if ( $box ) {
					Events::emit( 'box.changed', array( 'box_id' => $box ) );
				}
			}
			$rows[] = array( 'name' => $il->description, 'qty' => $il->qty, 'price' => $il->unit_price_usd );
		}
		Audit::log( 'invoice.synced', 'invoice', $inv_id, null, array( 'qbo_invoice_id' => $data['qbo_invoice_id'], 'doc_number' => $data['doc_number'] ), null, 0 );
		Events::emit( 'invoice.changed', array( 'invoice_id' => $inv_id ) );

		$prof = Customers::profile( (int) $inv->user_id );
		if ( $prof ) {
			Mailer::queue(
				'line_invoiced',
				$prof->email,
				array(
					'name'           => $prof->contact_name,
					'invoice_number' => $data['doc_number'],
					'invoice_total'  => Util::money( $data['total_usd'] ),
					'lines_table'    => Mailer::lines_table( $rows ),
				),
				(int) $inv->user_id,
				'invoice',
				$inv_id
			);
		}
	}

	public static function mark_error( $inv_id, $message ) {
		global $wpdb;
		$wpdb->update( self::t()['invoices'], array( 'sync_status' => 'error', 'error_message' => substr( $message, 0, 2000 ), 'updated_at' => Util::now() ), array( 'id' => $inv_id ) );
		Audit::log( 'invoice.error', 'invoice', $inv_id, null, null, $message, 0 );
		Events::emit( 'invoice.changed', array( 'invoice_id' => $inv_id ) );
	}

	/** Staff cancels an invoice that never synced: releases pending quantities. */
	public static function cancel_unsynced( $inv_id, $reason ) {
		global $wpdb;
		$inv = self::get( $inv_id );
		if ( ! $inv || ! in_array( $inv->sync_status, array( 'queued', 'error' ), true ) ) {
			return new \WP_Error( 'state', 'Only unsynced (queued or error) invoices can be cancelled here. Void synced invoices in QuickBooks.' );
		}
		if ( '' === trim( (string) $reason ) ) {
			return new \WP_Error( 'reason', 'A reason is required.' );
		}
		$lt = self::t()['lines'];
		$wpdb->query( 'START TRANSACTION' );
		foreach ( self::lines( $inv_id ) as $il ) {
			if ( $il->order_line_id ) {
				$wpdb->query( $wpdb->prepare( "UPDATE {$lt} SET qty_pending_invoice = GREATEST(0, CAST(qty_pending_invoice AS SIGNED) - %d) WHERE id=%d", (int) $il->qty, $il->order_line_id ) );
			}
		}
		$wpdb->update( self::t()['invoices'], array( 'sync_status' => 'cancelled', 'updated_at' => Util::now() ), array( 'id' => $inv_id ) );
		$wpdb->query( 'COMMIT' );
		$jt = self::t()['jobs'];
		$wpdb->query( $wpdb->prepare( "UPDATE {$jt} SET status='dead', last_error='Invoice cancelled by staff' WHERE idempotency_key=%s AND status IN ('queued','failed')", 'qbo_create_invoice:' . $inv_id ) );
		Audit::log( 'invoice.cancelled', 'invoice', $inv_id, array( 'status' => $inv->sync_status ), array( 'status' => 'cancelled' ), sanitize_textarea_field( $reason ) );
		foreach ( self::lines( $inv_id ) as $il ) {
			if ( $il->order_line_id ) {
				Orders::refresh_line( (int) $il->order_line_id );
				Events::emit( 'line.changed', array( 'line_id' => (int) $il->order_line_id ) );
			}
		}
		return true;
	}

	/** Invoice voided/deleted in QBO: invoiced quantities become invoiceable again. */
	public static function mark_voided( $inv_id ) {
		global $wpdb;
		$inv = self::get( $inv_id );
		if ( ! $inv || 'voided' === $inv->sync_status ) {
			return;
		}
		$lt = self::t()['lines'];
		$wpdb->query( 'START TRANSACTION' );
		foreach ( self::lines( $inv_id ) as $il ) {
			if ( $il->order_line_id ) {
				$col = self::is_final( $inv ) ? 'qty_invoiced' : 'qty_pending_invoice';
				$wpdb->query( $wpdb->prepare( "UPDATE {$lt} SET {$col} = GREATEST(0, CAST({$col} AS SIGNED) - %d) WHERE id=%d", (int) $il->qty, $il->order_line_id ) );
			}
		}
		$wpdb->update( self::t()['invoices'], array( 'sync_status' => 'voided', 'balance_usd' => 0, 'updated_at' => Util::now() ), array( 'id' => $inv_id ) );
		$wpdb->query( 'COMMIT' );
		Audit::log( 'invoice.voided', 'invoice', $inv_id, array( 'status' => $inv->sync_status ), array( 'status' => 'voided' ), 'Voided in QuickBooks', 0 );
		foreach ( self::lines( $inv_id ) as $il ) {
			if ( $il->order_line_id ) {
				Orders::refresh_line( (int) $il->order_line_id );
			}
		}
		Events::emit( 'invoice.changed', array( 'invoice_id' => $inv_id ) );
	}

	/** Update totals/balance from QBO data and derive payment status. */
	public static function update_from_qbo( $inv_id, array $q ) {
		global $wpdb;
		$data = array(
			'doc_number'     => $q['doc_number'] ?? null,
			'txn_date'       => $q['txn_date'] ?? null,
			'due_date'       => $q['due_date'] ?? null,
			'total_usd'      => $q['total_usd'] ?? null,
			'balance_usd'    => $q['balance_usd'] ?? null,
			'pay_link'       => $q['pay_link'] ?? null,
			'last_synced_at' => Util::now(),
			'updated_at'     => Util::now(),
		);
		$data = array_filter( $data, fn( $v ) => null !== $v );
		$wpdb->update( self::t()['invoices'], $data, array( 'id' => $inv_id ) );
		self::apply_payment_state( $inv_id );
		Events::emit( 'invoice.changed', array( 'invoice_id' => $inv_id ) );
	}

	public static function apply_payment_state( $inv_id ) {
		global $wpdb;
		$inv = self::get( $inv_id );
		if ( ! $inv || ! self::is_final( $inv ) ) {
			return;
		}
		$status = 'synced';
		if ( null !== $inv->balance_usd && null !== $inv->total_usd ) {
			if ( (float) $inv->balance_usd <= 0.004 && (float) $inv->total_usd > 0 && 'qbo' === $inv->source && $inv->last_synced_at ) {
				$status = 'paid';
			} elseif ( (float) $inv->balance_usd < (float) $inv->total_usd - 0.004 ) {
				$status = 'partially_paid';
			}
		}
		// Manual records never claim "paid" until QBO confirms (they have no QBO sync).
		if ( 'manual' === $inv->source && 'paid' === $status ) {
			$status = 'synced';
		}
		if ( 'synced' === $status && $inv->due_date && $inv->due_date < current_time( 'Y-m-d' ) && (float) $inv->balance_usd > 0 ) {
			$status = 'overdue';
		}
		if ( $status !== $inv->sync_status ) {
			$wpdb->update( self::t()['invoices'], array( 'sync_status' => $status ), array( 'id' => $inv_id ) );
			Audit::log( 'invoice.payment_status', 'invoice', $inv_id, array( 'status' => $inv->sync_status ), array( 'status' => $status ), null, 0 );
		}
	}

	public static function staff_list( array $args ) {
		global $wpdb;
		$t      = self::t()['invoices'];
		$pt     = self::t()['profiles'];
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['status'] ) && isset( self::SYNC_STATUSES[ $args['status'] ] ) ) {
			$where[]  = 'i.sync_status=%s';
			$params[] = $args['status'];
		}
		if ( ! empty( $args['q'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['q'] ) . '%';
			$where[]  = '(i.doc_number LIKE %s OR c.company_name LIKE %s OR c.contact_name LIKE %s)';
			$params   = array_merge( $params, array( $like, $like, $like ) );
		}
		if ( ! empty( $args['user_id'] ) ) {
			$where[]  = 'i.user_id=%d';
			$params[] = (int) $args['user_id'];
		}
		$w   = implode( ' AND ', $where );
		$sql = "SELECT i.*, c.company_name, c.contact_name FROM {$t} i LEFT JOIN {$pt} c ON c.user_id=i.user_id WHERE {$w} ORDER BY i.id DESC LIMIT 300";
		return $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );
	}
}
