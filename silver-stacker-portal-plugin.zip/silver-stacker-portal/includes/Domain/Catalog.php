<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Events;
use SSP\Core\Installer;
use SSP\Core\Media;
use SSP\Core\Settings;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/** Products, variants, images, lifecycle, ETA, countdown and indexed search (Active / Archive). */
class Catalog {

	const LIFECYCLES = array(
		'draft'         => 'Draft',
		'presale'       => 'Presale',
		'presale_ended' => 'Pre-Sale Ended',
		'in_stock'      => 'In Stock',
		'archived'      => 'Archived',
	);

	/** Allowed lifecycle transitions (Architecture §9.2). */
	const TRANSITIONS = array(
		'draft'         => array( 'presale', 'in_stock', 'archived' ),
		'presale'       => array( 'presale_ended', 'archived', 'draft' ),
		'presale_ended' => array( 'presale', 'in_stock', 'archived' ),
		'in_stock'      => array( 'archived', 'presale_ended' ),
		'archived'      => array( 'presale', 'in_stock' ),
	);

	const ETA_TYPES = array(
		'none'  => 'Not set',
		'month' => 'Month (e.g. November 2026)',
		'date'  => 'Exact date',
		'range' => 'Date range (e.g. Nov. 15-30, 2026)',
		'text'  => 'Free text (e.g. Late October)',
	);

	public static function t() {
		return Installer::tables();
	}

	/* ---------------------------------------------------------------- */
	/* Reads                                                            */
	/* ---------------------------------------------------------------- */

	public static function get( $id ) {
		global $wpdb;
		$t = self::t()['products'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
	}

	public static function by_uid( $uid ) {
		global $wpdb;
		$t = self::t()['products'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE product_uid=%s", $uid ) );
	}

	public static function variants( $product_id, $active_only = false ) {
		global $wpdb;
		$t = self::t()['variants'];
		$sql = "SELECT * FROM {$t} WHERE product_id=%d" . ( $active_only ? ' AND active=1' : '' ) . ' ORDER BY sort ASC, id ASC';
		return $wpdb->get_results( $wpdb->prepare( $sql, $product_id ) );
	}

	public static function variant( $id ) {
		global $wpdb;
		$t = self::t()['variants'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
	}

	public static function variant_by_uid( $uid ) {
		global $wpdb;
		$t = self::t()['variants'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE variant_uid=%s", $uid ) );
	}

	public static function images( $product_id ) {
		global $wpdb;
		$t = self::t()['images'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE product_id=%d ORDER BY is_primary DESC, sort ASC, id ASC", $product_id ) );
	}

	public static function primary_image( $product_id ) {
		global $wpdb;
		$t = self::t()['images'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE product_id=%d ORDER BY is_primary DESC, sort ASC, id ASC LIMIT 1", $product_id ) );
	}

	public static function image_url( $image, $size = 'thumb' ) {
		if ( ! $image ) {
			return SSP_URL . 'assets/img/placeholder.svg';
		}
		return home_url( '/portal/media/' . $image->image_uid . '/' . $size . '/' );
	}

	public static function url( $product ) {
		return home_url( '/portal/p/' . $product->product_uid . '/' . $product->slug . '/' );
	}

	/* ---------------------------------------------------------------- */
	/* Lifecycle, countdown, ETA, display                               */
	/* ---------------------------------------------------------------- */

	/** Lifecycle evaluated against the server clock so a delayed cron can never allow a late order. */
	public static function effective_lifecycle( $p ) {
		if ( 'presale' === $p->lifecycle && $p->closing_at && Util::ts( $p->closing_at ) <= time() ) {
			return 'presale_ended';
		}
		return $p->lifecycle;
	}

	public static function is_orderable( $p ) {
		return in_array( self::effective_lifecycle( $p ), array( 'presale', 'in_stock' ), true );
	}

	public static function lifecycle_label( $p ) {
		return self::LIFECYCLES[ self::effective_lifecycle( $p ) ] ?? ucfirst( $p->lifecycle );
	}

	public static function sale_type_label( $p ) {
		$l = self::effective_lifecycle( $p );
		if ( 'presale' === $l || 'presale_ended' === $l ) {
			return 'Presale';
		}
		if ( 'in_stock' === $l ) {
			return 'In Stock';
		}
		return self::LIFECYCLES[ $l ] ?? '';
	}

	public static function display_name( $p ) {
		$name = $p->name;
		if ( Settings::get( 'append_closing_date_to_name' ) && $p->closing_at && in_array( $p->lifecycle, array( 'presale', 'presale_ended' ), true ) ) {
			$name .= ' (' . Util::fmt_dt( $p->closing_at, 'm/d' ) . ')';
		}
		return $name;
	}

	/** Customer-facing ETA text; an estimate, never a guarantee. */
	public static function eta_label( $p ) {
		switch ( $p->eta_type ) {
			case 'date':
				return $p->eta_start ? Util::fmt_date( $p->eta_start, 'M j, Y' ) : '';
			case 'month':
				return $p->eta_start ? Util::fmt_date( $p->eta_start, 'F Y' ) : '';
			case 'range':
				if ( ! $p->eta_start ) {
					return '';
				}
				$s = new \DateTime( $p->eta_start );
				$e = $p->eta_end ? new \DateTime( $p->eta_end ) : null;
				if ( ! $e ) {
					return $s->format( 'M. j, Y' );
				}
				if ( $s->format( 'Y-m' ) === $e->format( 'Y-m' ) ) {
					return $s->format( 'M. j' ) . '-' . $e->format( 'j, Y' );
				}
				if ( $s->format( 'Y' ) === $e->format( 'Y' ) ) {
					return $s->format( 'M. j' ) . ' - ' . $e->format( 'M. j, Y' );
				}
				return $s->format( 'M. j, Y' ) . ' - ' . $e->format( 'M. j, Y' );
			case 'text':
				return $p->eta_text;
		}
		return '';
	}

	public static function price_label( $variant, $product ) {
		if ( 'spot_based' === $product->price_type ) {
			if ( null !== $product->spot_premium_usd && '' !== $product->spot_premium_usd ) {
				return 'Spot + ' . Util::money( $product->spot_premium_usd );
			}
			return 'Spot based (see details)';
		}
		return Util::money( $variant->price_usd );
	}

	public static function price_range_label( $product ) {
		if ( 'spot_based' === $product->price_type ) {
			return self::price_label( null, $product );
		}
		$prices = array();
		foreach ( self::variants( $product->id, true ) as $v ) {
			$prices[] = (float) $v->price_usd;
		}
		if ( ! $prices ) {
			return '';
		}
		$min = min( $prices );
		$max = max( $prices );
		return $min === $max ? Util::money( $min ) : Util::money( $min ) . ' - ' . Util::money( $max );
	}

	/* ---------------------------------------------------------------- */
	/* Writes                                                           */
	/* ---------------------------------------------------------------- */

	public static function sanitize_product( array $in ) {
		$metals = (array) Settings::get( 'metals' );
		$metal  = sanitize_text_field( $in['metal'] ?? '' );
		$d      = array(
			'name'             => sanitize_text_field( $in['name'] ?? '' ),
			'description'      => wp_kses_post( $in['description'] ?? '' ),
			'brand'            => sanitize_text_field( $in['brand'] ?? '' ),
			'metal'            => in_array( $metal, $metals, true ) ? $metal : '',
			'category'         => sanitize_text_field( $in['category'] ?? '' ),
			'mintage'          => sanitize_text_field( $in['mintage'] ?? '' ),
			'eta_type'         => array_key_exists( $in['eta_type'] ?? '', self::ETA_TYPES ) ? $in['eta_type'] : 'none',
			'eta_text'         => sanitize_text_field( $in['eta_text'] ?? '' ),
			'supplier_id'      => Util::int_or_null( $in['supplier_id'] ?? null ),
			'date_posted'      => self::date_or_null( $in['date_posted'] ?? '' ),
			'price_type'       => ( $in['price_type'] ?? '' ) === 'spot_based' ? 'spot_based' : 'fixed',
			'spot_premium_usd' => Util::dec_or_null( $in['spot_premium_usd'] ?? null ),
		);
		// ETA dates: month input gives Y-m.
		$eta_start = $in['eta_start'] ?? '';
		if ( 'month' === $d['eta_type'] && preg_match( '/^\d{4}-\d{2}$/', $eta_start ) ) {
			$eta_start .= '-01';
		}
		$d['eta_start'] = self::date_or_null( $eta_start );
		$d['eta_end']   = self::date_or_null( $in['eta_end'] ?? '' );
		if ( isset( $in['closing_at'] ) ) {
			$d['closing_at'] = $in['closing_at'] ? Util::local_to_utc( str_replace( 'T', ' ', $in['closing_at'] ) ) : null;
		}
		return $d;
	}

	private static function date_or_null( $v ) {
		$v = sanitize_text_field( (string) $v );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : null;
	}

	/**
	 * Create or update a product. Lifecycle changes go through set_lifecycle().
	 *
	 * @return int|\WP_Error product id
	 */
	public static function save_product( array $in, $id = null ) {
		global $wpdb;
		$t   = self::t()['products'];
		$d   = self::sanitize_product( $in );
		if ( '' === $d['name'] ) {
			return new \WP_Error( 'name', 'Product name is required.' );
		}
		if ( 'range' === $d['eta_type'] && $d['eta_start'] && $d['eta_end'] && $d['eta_end'] < $d['eta_start'] ) {
			return new \WP_Error( 'eta', 'ETA range end must be after the start.' );
		}
		$now = Util::now();
		if ( $id ) {
			$before = self::get( $id );
			if ( ! $before ) {
				return new \WP_Error( 'not_found', 'Product not found.' );
			}
			$d['updated_at'] = $now;
			$wpdb->update( $t, $d, array( 'id' => $id ) );
			$after = self::get( $id );
			list( $b, $a ) = Audit::diff( (array) $before, (array) $after );
			unset( $b['updated_at'], $a['updated_at'], $b['search_text'], $a['search_text'] );
			if ( $a ) {
				if ( isset( $a['description'] ) ) {
					$b['description'] = '(changed)';
					$a['description'] = '(changed)';
				}
				Audit::log( 'product.updated', 'product', $id, $b, $a );
			}
			if ( self::eta_label( $before ) !== self::eta_label( $after ) ) {
				$wpdb->insert(
					self::t()['eta_history'],
					array(
						'product_id' => $id,
						'old_value'  => self::eta_label( $before ),
						'new_value'  => self::eta_label( $after ),
						'changed_by' => get_current_user_id(),
						'changed_at' => $now,
					)
				);
				Audit::log( 'product.eta_changed', 'product', $id, array( 'eta' => self::eta_label( $before ) ), array( 'eta' => self::eta_label( $after ) ) );
				Events::emit( 'product.eta_changed', array( 'product_id' => $id ) );
			}
			// Re-opening a closed presale by extending the closing date.
			if ( 'presale_ended' === $after->lifecycle && $after->closing_at && Util::ts( $after->closing_at ) > time() && ! empty( $in['reopen_if_extended'] ) ) {
				self::set_lifecycle( $id, 'presale', 'Closing date extended' );
			}
		} else {
			$d['product_uid'] = Util::ulid();
			$d['slug']        = sanitize_title( $d['name'] ) ? substr( sanitize_title( $d['name'] ), 0, 180 ) : 'product';
			$d['lifecycle']   = 'draft';
			$d['created_by']  = get_current_user_id();
			$d['created_at']  = $now;
			$d['updated_at']  = $now;
			if ( ! $d['date_posted'] ) {
				$d['date_posted'] = current_time( 'Y-m-d' );
			}
			$wpdb->insert( $t, $d );
			$id = (int) $wpdb->insert_id;
			Audit::log( 'product.created', 'product', $id, null, array( 'name' => $d['name'] ) );
		}
		self::reindex( $id );
		Events::emit( 'product.changed', array( 'product_id' => $id ) );
		return $id;
	}

	/**
	 * @return true|\WP_Error
	 */
	public static function set_lifecycle( $id, $new, $reason = '' ) {
		global $wpdb;
		$p = self::get( $id );
		if ( ! $p ) {
			return new \WP_Error( 'not_found', 'Product not found.' );
		}
		$current = self::effective_lifecycle( $p );
		if ( $current === $new ) {
			if ( $p->lifecycle !== $new ) {
				$wpdb->update( self::t()['products'], array( 'lifecycle' => $new, 'updated_at' => Util::now() ), array( 'id' => $id ) );
			}
			return true;
		}
		if ( ! in_array( $new, self::TRANSITIONS[ $current ] ?? array(), true ) ) {
			return new \WP_Error( 'transition', sprintf( 'Cannot change lifecycle from %s to %s.', self::LIFECYCLES[ $current ] ?? $current, self::LIFECYCLES[ $new ] ?? $new ) );
		}
		$variants = self::variants( $id, true );
		if ( in_array( $new, array( 'presale', 'in_stock' ), true ) ) {
			if ( ! $variants ) {
				return new \WP_Error( 'variants', 'Add at least one active variant (SKU and price) before publishing.' );
			}
			if ( 'presale' === $new && ( ! $p->closing_at || Util::ts( $p->closing_at ) <= time() ) ) {
				return new \WP_Error( 'closing', 'A presale needs a pre-order closing date in the future.' );
			}
		}
		$data = array(
			'lifecycle'  => $new,
			'updated_at' => Util::now(),
		);
		if ( 'archived' === $new ) {
			$data['archived_at'] = Util::now();
		}
		$wpdb->update( self::t()['products'], $data, array( 'id' => $id ) );
		if ( 'presale_ended' === $new ) {
			self::lock_lines( $id );
		}
		if ( in_array( $new, array( 'presale', 'in_stock' ), true ) ) {
			// Reopened: unlock lines so customers can amend again.
			$lt = self::t()['lines'];
			$wpdb->query( $wpdb->prepare( "UPDATE {$lt} SET locked_at=NULL WHERE product_id=%d AND qty_available=0 AND qty_invoiced=0", $id ) );
			Orders::refresh_lines_for_product( $id );
		}
		Audit::log( 'product.lifecycle_changed', 'product', $id, array( 'lifecycle' => $current ), array( 'lifecycle' => $new ), $reason );
		self::reindex( $id );
		Events::emit( 'product.changed', array( 'product_id' => $id ) );
		return true;
	}

	public static function lock_lines( $product_id ) {
		global $wpdb;
		$lt = self::t()['lines'];
		$wpdb->query( $wpdb->prepare( "UPDATE {$lt} SET locked_at=%s WHERE product_id=%d AND locked_at IS NULL", Util::now(), $product_id ) );
		Orders::refresh_lines_for_product( $product_id );
	}

	/** Cron: finalize presales whose countdown reached zero. */
	public static function close_due_presales() {
		global $wpdb;
		$t   = self::t()['products'];
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t} WHERE lifecycle='presale' AND closing_at IS NOT NULL AND closing_at <= %s", Util::now() ) );
		foreach ( $ids as $id ) {
			$wpdb->update( $t, array( 'lifecycle' => 'presale_ended', 'updated_at' => Util::now() ), array( 'id' => $id ) );
			self::lock_lines( (int) $id );
			Audit::log( 'product.presale_closed', 'product', $id, array( 'lifecycle' => 'presale' ), array( 'lifecycle' => 'presale_ended' ), 'Countdown reached zero', 0 );
			self::reindex( (int) $id );
			Events::emit( 'product.changed', array( 'product_id' => (int) $id ) );
		}
		return count( $ids );
	}

	/**
	 * Products with order history are never deleted (archive instead). Drafts without history may be removed.
	 */
	public static function delete_product( $id ) {
		global $wpdb;
		$lt  = self::t()['lines'];
		$has = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$lt} WHERE product_id=%d", $id ) );
		$p   = self::get( $id );
		if ( ! $p ) {
			return new \WP_Error( 'not_found', 'Product not found.' );
		}
		if ( $has || 'draft' !== $p->lifecycle ) {
			return new \WP_Error( 'history', 'Products that were offered or ordered cannot be deleted. Archive them instead.' );
		}
		foreach ( self::images( $id ) as $img ) {
			self::delete_image( $img->id );
		}
		$wpdb->delete( self::t()['variants'], array( 'product_id' => $id ) );
		$wpdb->delete( self::t()['products'], array( 'id' => $id ) );
		Audit::log( 'product.deleted', 'product', $id, array( 'name' => $p->name ), null );
		return true;
	}

	/* ---------------------------------------------------------------- */
	/* Variants                                                         */
	/* ---------------------------------------------------------------- */

	public static function save_variant( $product_id, array $in, $variant_id = null ) {
		global $wpdb;
		$t = self::t()['variants'];
		$d = array(
			'label'                   => sanitize_text_field( $in['label'] ?? '' ),
			'sku'                     => strtoupper( preg_replace( '/[^A-Za-z0-9\-_.]/', '', (string) ( $in['sku'] ?? '' ) ) ),
			'barcode'                 => preg_replace( '/[^A-Za-z0-9\-]/', '', (string) ( $in['barcode'] ?? '' ) ),
			'price_usd'               => (float) Util::dec_or_null( $in['price_usd'] ?? 0 ),
			'msrp_usd'                => Util::dec_or_null( $in['msrp_usd'] ?? null ),
			'min_order_qty'           => max( 1, (int) ( $in['min_order_qty'] ?? 1 ) ),
			'total_allocation'        => Util::int_or_null( $in['total_allocation'] ?? null ),
			'per_customer_allocation' => Util::int_or_null( $in['per_customer_allocation'] ?? null ),
			'supplier_qty_ordered'    => Util::int_or_null( $in['supplier_qty_ordered'] ?? null ),
			'weight_oz'               => Util::dec_or_null( $in['weight_oz'] ?? null ),
			'sort'                    => (int) ( $in['sort'] ?? 0 ),
			'active'                  => empty( $in['active'] ) && isset( $in['active_present'] ) ? 0 : 1,
		);
		if ( '' === $d['sku'] ) {
			return new \WP_Error( 'sku', 'SKU is required.' );
		}
		if ( $d['price_usd'] < 0 ) {
			return new \WP_Error( 'price', 'Price cannot be negative.' );
		}
		$dupe = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE sku=%s AND id<>%d", $d['sku'], (int) $variant_id ) );
		if ( $dupe ) {
			return new \WP_Error( 'sku', 'SKU ' . $d['sku'] . ' is already used by another product.' );
		}
		$now = Util::now();
		if ( $variant_id ) {
			$before = self::variant( $variant_id );
			if ( ! $before || (int) $before->product_id !== (int) $product_id ) {
				return new \WP_Error( 'not_found', 'Variant not found.' );
			}
			if ( null !== $d['total_allocation'] && $d['total_allocation'] + Allocation::override_total( $variant_id ) < (int) $before->reserved_qty + (int) $before->held_qty ) {
				return new \WP_Error( 'allocation', sprintf( 'Total allocation cannot be lower than the %d units already reserved or held. Reduce customer quantities first or use an override.', (int) $before->reserved_qty + (int) $before->held_qty ) );
			}
			$d['updated_at'] = $now;
			$wpdb->update( $t, $d, array( 'id' => $variant_id ) );
			list( $b, $a ) = Audit::diff( (array) $before, $d );
			unset( $b['updated_at'], $a['updated_at'] );
			if ( $a ) {
				$action = ( isset( $a['price_usd'] ) ) ? 'variant.price_changed' : 'variant.updated';
				if ( isset( $a['total_allocation'] ) || isset( $a['per_customer_allocation'] ) ) {
					$action = 'variant.allocation_changed';
				}
				Audit::log( $action, 'variant', $variant_id, $b, $a );
			}
			if ( isset( $a['total_allocation'] ) || isset( $a['per_customer_allocation'] ) ) {
				Waitlist::process_variant( $variant_id );
				Events::emit( 'variant.allocation_changed', array( 'variant_id' => $variant_id ) );
			}
		} else {
			$d['variant_uid'] = Util::ulid();
			$d['product_id']  = $product_id;
			$d['created_at']  = $now;
			$d['updated_at']  = $now;
			$wpdb->insert( $t, $d );
			$variant_id = (int) $wpdb->insert_id;
			Audit::log( 'variant.created', 'variant', $variant_id, null, $d );
			Events::emit( 'variant.allocation_changed', array( 'variant_id' => $variant_id ) );
		}
		self::reindex( $product_id );
		return $variant_id;
	}

	public static function delete_variant( $variant_id ) {
		global $wpdb;
		$v = self::variant( $variant_id );
		if ( ! $v ) {
			return new \WP_Error( 'not_found', 'Variant not found.' );
		}
		$lt  = self::t()['lines'];
		$has = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$lt} WHERE variant_id=%d", $variant_id ) );
		if ( $has ) {
			$wpdb->update( self::t()['variants'], array( 'active' => 0, 'updated_at' => Util::now() ), array( 'id' => $variant_id ) );
			Audit::log( 'variant.deactivated', 'variant', $variant_id );
		} else {
			$wpdb->delete( self::t()['variants'], array( 'id' => $variant_id ) );
			Audit::log( 'variant.deleted', 'variant', $variant_id, (array) $v, null );
		}
		self::reindex( (int) $v->product_id );
		return true;
	}

	/* ---------------------------------------------------------------- */
	/* Images                                                           */
	/* ---------------------------------------------------------------- */

	public static function add_image( $product_id, array $file, $alt = '' ) {
		global $wpdb;
		$stored = Media::store_image( $file );
		if ( is_wp_error( $stored ) ) {
			return $stored;
		}
		$t     = self::t()['images'];
		$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE product_id=%d", $product_id ) );
		$wpdb->insert(
			$t,
			array(
				'image_uid'  => Util::ulid(),
				'product_id' => $product_id,
				'file_path'  => $stored['file_path'],
				'sizes'      => wp_json_encode( $stored['sizes'] ),
				'mime'       => $stored['mime'],
				'alt'        => sanitize_text_field( $alt ),
				'sort'       => $count + 1,
				'is_primary' => $count ? 0 : 1,
				'created_at' => Util::now(),
			)
		);
		Audit::log( 'product.image_added', 'product', $product_id );
		return (int) $wpdb->insert_id;
	}

	public static function delete_image( $image_id ) {
		global $wpdb;
		$t   = self::t()['images'];
		$img = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $image_id ) );
		if ( ! $img ) {
			return false;
		}
		Media::delete_relative( $img->file_path );
		foreach ( (array) json_decode( (string) $img->sizes, true ) as $rel ) {
			Media::delete_relative( $rel );
		}
		$wpdb->delete( $t, array( 'id' => $image_id ) );
		if ( $img->is_primary ) {
			$next = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE product_id=%d ORDER BY sort ASC LIMIT 1", $img->product_id ) );
			if ( $next ) {
				$wpdb->update( $t, array( 'is_primary' => 1 ), array( 'id' => $next ) );
			}
		}
		Audit::log( 'product.image_deleted', 'product', $img->product_id );
		return true;
	}

	public static function set_primary_image( $product_id, $image_id ) {
		global $wpdb;
		$t = self::t()['images'];
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET is_primary=0 WHERE product_id=%d", $product_id ) );
		$wpdb->update( $t, array( 'is_primary' => 1 ), array( 'id' => $image_id, 'product_id' => $product_id ) );
	}

	public static function reorder_images( $product_id, array $ordered_ids ) {
		global $wpdb;
		$t = self::t()['images'];
		foreach ( array_values( $ordered_ids ) as $i => $id ) {
			$wpdb->update( $t, array( 'sort' => $i + 1 ), array( 'id' => (int) $id, 'product_id' => $product_id ) );
		}
	}

	public static function image_by_uid( $uid ) {
		global $wpdb;
		$t = self::t()['images'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE image_uid=%s", $uid ) );
	}

	/* ---------------------------------------------------------------- */
	/* Search                                                           */
	/* ---------------------------------------------------------------- */

	public static function reindex( $product_id ) {
		global $wpdb;
		$p = self::get( $product_id );
		if ( ! $p ) {
			return;
		}
		$bits = array( $p->mintage, self::LIFECYCLES[ $p->lifecycle ] ?? '', $p->metal );
		foreach ( self::variants( $product_id ) as $v ) {
			$bits[] = $v->label;
			$bits[] = $v->sku;
			$bits[] = $v->barcode;
		}
		$wpdb->update( self::t()['products'], array( 'search_text' => trim( implode( ' ', array_filter( $bits ) ) ) ), array( 'id' => $product_id ) );
	}

	/**
	 * Indexed, paginated search. Tabs: 'active' (Presale + In Stock, plus recently ended presales
	 * so customers can still find them) and 'archive' (reference-only).
	 *
	 * @return array { rows, total, counts: { active, archive } }
	 */
	public static function search( array $args ) {
		global $wpdb;
		$t   = self::t()['products'];
		$vt  = self::t()['variants'];
		$q   = trim( sanitize_text_field( $args['q'] ?? '' ) );
		$tab = ( $args['tab'] ?? 'active' ) === 'archive' ? 'archive' : 'active';

		$where  = array();
		$params = array();

		if ( '' !== $q ) {
			// Codes (SKU / barcode, no spaces, contain a digit) are matched exactly/prefix, not by full text.
			$is_code = ! preg_match( '/\s/', $q ) && preg_match( '/\d/', $q ) && preg_match( '/^[A-Za-z0-9\-_.]+$/', $q );
			$words   = preg_split( '/\s+/', trim( preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $q ) ) );
			$ft      = array();
			foreach ( $is_code ? array() : $words as $w ) {
				if ( mb_strlen( $w ) >= 3 ) {
					$ft[] = '+' . $w . '*';
				}
			}
			$conds = array();
			if ( $is_code ) {
				$conds[]  = 'p.name LIKE %s';
				$params[] = '%' . $wpdb->esc_like( $q ) . '%';
			} elseif ( $ft ) {
				$conds[]  = 'MATCH(p.name,p.brand,p.category,p.search_text) AGAINST (%s IN BOOLEAN MODE)';
				$params[] = implode( ' ', $ft );
			} else {
				$conds[]  = 'p.name LIKE %s';
				$params[] = '%' . $wpdb->esc_like( $q ) . '%';
			}
			$conds[]  = "p.id IN (SELECT product_id FROM {$vt} WHERE sku LIKE %s OR barcode = %s)";
			$params[] = $wpdb->esc_like( strtoupper( $q ) ) . '%';
			$params[] = $q;
			$where[]  = '(' . implode( ' OR ', $conds ) . ')';
		}
		if ( ! empty( $args['metal'] ) ) {
			$where[]  = 'p.metal = %s';
			$params[] = sanitize_text_field( $args['metal'] );
		}
		if ( ! empty( $args['brand'] ) ) {
			$where[]  = 'p.brand = %s';
			$params[] = sanitize_text_field( $args['brand'] );
		}
		if ( ! empty( $args['category'] ) ) {
			$where[]  = 'p.category = %s';
			$params[] = sanitize_text_field( $args['category'] );
		}
		$now = Util::now();
		$lifecycle_filter = sanitize_key( $args['lifecycle'] ?? '' );

		$tab_sql = array(
			'active'  => "( (p.lifecycle='presale' AND p.closing_at > '{$now}') OR p.lifecycle='in_stock' OR (p.lifecycle IN ('presale','presale_ended') AND (p.closing_at IS NULL OR p.closing_at <= '{$now}')) )",
			'archive' => "p.lifecycle='archived'",
		);
		if ( 'presale' === $lifecycle_filter ) {
			$tab_sql['active'] = "(p.lifecycle='presale' AND p.closing_at > '{$now}')";
		} elseif ( 'in_stock' === $lifecycle_filter ) {
			$tab_sql['active'] = "p.lifecycle='in_stock'";
		} elseif ( 'presale_ended' === $lifecycle_filter ) {
			$tab_sql['active'] = "(p.lifecycle='presale_ended' OR (p.lifecycle='presale' AND p.closing_at <= '{$now}'))";
		}

		$base_where = $where ? implode( ' AND ', $where ) . ' AND ' : '';
		$counts     = array();
		foreach ( $tab_sql as $k => $cond ) {
			$sql          = "SELECT COUNT(*) FROM {$t} p WHERE {$base_where}{$cond}";
			$counts[ $k ] = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_var( $sql ) );
		}

		$per  = min( 96, max( 1, (int) ( $args['per_page'] ?? 24 ) ) );
		$page = max( 1, (int) ( $args['paged'] ?? 1 ) );
		$sort = $args['sort'] ?? '';
		if ( 'archive' === $tab ) {
			$order = 'name' === $sort ? 'p.name ASC' : 'p.archived_at DESC, p.id DESC';
		} else {
			$order_map = array(
				'closing' => "CASE WHEN p.lifecycle='presale' AND p.closing_at > '{$now}' THEN 0 WHEN p.lifecycle='in_stock' THEN 1 ELSE 2 END, p.closing_at ASC",
				'newest'  => 'p.date_posted DESC, p.id DESC',
				'name'    => 'p.name ASC',
			);
			$order = $order_map[ $sort ] ?? $order_map['closing'];
		}
		$sql  = "SELECT p.* FROM {$t} p WHERE {$base_where}{$tab_sql[ $tab ]} ORDER BY {$order} LIMIT %d OFFSET %d";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $params, array( $per, ( $page - 1 ) * $per ) ) ) );

		return array(
			'rows'     => $rows,
			'total'    => $counts[ $tab ],
			'counts'   => $counts,
			'tab'      => $tab,
			'page'     => $page,
			'per_page' => $per,
		);
	}

	public static function distinct( $column, $tab = null ) {
		global $wpdb;
		$t = self::t()['products'];
		if ( ! in_array( $column, array( 'brand', 'category', 'metal' ), true ) ) {
			return array();
		}
		$cache = wp_cache_get( 'ssp_distinct_' . $column, 'ssp' );
		if ( false !== $cache ) {
			return $cache;
		}
		$vals = $wpdb->get_col( "SELECT DISTINCT {$column} FROM {$t} WHERE {$column}<>'' AND lifecycle<>'draft' ORDER BY {$column} ASC LIMIT 500" );
		wp_cache_set( 'ssp_distinct_' . $column, $vals, 'ssp', 300 );
		return $vals;
	}

	/** Staff list. */
	public static function admin_list( array $args ) {
		global $wpdb;
		$t      = self::t()['products'];
		$vt     = self::t()['variants'];
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['q'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['q'] ) . '%';
			$where[]  = "(p.name LIKE %s OR p.brand LIKE %s OR p.id IN (SELECT product_id FROM {$vt} WHERE sku LIKE %s OR barcode LIKE %s))";
			$params   = array_merge( $params, array( $like, $like, $like, $like ) );
		}
		if ( ! empty( $args['lifecycle'] ) && isset( self::LIFECYCLES[ $args['lifecycle'] ] ) ) {
			if ( 'presale' === $args['lifecycle'] ) {
				$where[] = "p.lifecycle='presale' AND (p.closing_at IS NULL OR p.closing_at > '" . Util::now() . "')";
			} elseif ( 'presale_ended' === $args['lifecycle'] ) {
				$where[] = "(p.lifecycle='presale_ended' OR (p.lifecycle='presale' AND p.closing_at <= '" . Util::now() . "'))";
			} else {
				$where[]  = 'p.lifecycle=%s';
				$params[] = $args['lifecycle'];
			}
		} elseif ( empty( $args['include_archived'] ) ) {
			$where[] = "p.lifecycle<>'archived'";
		}
		if ( ! empty( $args['metal'] ) ) {
			$where[]  = 'p.metal=%s';
			$params[] = $args['metal'];
		}
		$per   = max( 1, (int) ( $args['per_page'] ?? 50 ) );
		$page  = max( 1, (int) ( $args['paged'] ?? 1 ) );
		$w     = implode( ' AND ', $where );
		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} p WHERE {$w}", $params ) ) : $wpdb->get_var( "SELECT COUNT(*) FROM {$t} p WHERE {$w}" ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT p.* FROM {$t} p WHERE {$w} ORDER BY p.updated_at DESC LIMIT %d OFFSET %d", array_merge( $params, array( $per, ( $page - 1 ) * $per ) ) ) );
		return array( 'rows' => $rows, 'total' => $total );
	}

	/* ---------------------------------------------------------------- */
	/* Suppliers                                                        */
	/* ---------------------------------------------------------------- */

	public static function suppliers() {
		global $wpdb;
		$t = self::t()['suppliers'];
		return $wpdb->get_results( "SELECT * FROM {$t} WHERE active=1 ORDER BY name ASC" );
	}

	public static function supplier_name( $id ) {
		global $wpdb;
		if ( ! $id ) {
			return '';
		}
		$t = self::t()['suppliers'];
		return (string) $wpdb->get_var( $wpdb->prepare( "SELECT name FROM {$t} WHERE id=%d", $id ) );
	}

	public static function save_supplier( $name, $contact = '', $notes = '' ) {
		global $wpdb;
		$t    = self::t()['suppliers'];
		$name = sanitize_text_field( $name );
		if ( '' === $name ) {
			return new \WP_Error( 'name', 'Supplier name is required.' );
		}
		$id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE name=%s", $name ) );
		if ( $id ) {
			return (int) $id;
		}
		$wpdb->insert( $t, array( 'name' => $name, 'contact' => sanitize_text_field( $contact ), 'notes' => sanitize_textarea_field( $notes ), 'created_at' => Util::now() ) );
		Audit::log( 'supplier.created', 'supplier', $wpdb->insert_id, null, array( 'name' => $name ) );
		return (int) $wpdb->insert_id;
	}
}
