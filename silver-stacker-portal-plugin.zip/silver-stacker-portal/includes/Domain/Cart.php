<?php
namespace SSP\Domain;

use SSP\Core\Installer;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Cart = the customer's order draft. It never reserves allocation and is never the box.
 * Everything is re-validated under lock when the pre-order is submitted.
 */
class Cart {

	public static function t() {
		return Installer::tables()['cart'];
	}

	public static function items( $user_id ) {
		global $wpdb;
		$t = self::t();
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d ORDER BY added_at ASC, id ASC", $user_id ) );
	}

	public static function count( $user_id ) {
		global $wpdb;
		$t = self::t();
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(qty),0) FROM {$t} WHERE user_id=%d", $user_id ) );
	}

	/** @return true|\WP_Error */
	public static function add( $user_id, $variant_id, $qty, $fulfillment = null ) {
		global $wpdb;
		$v = Catalog::variant( $variant_id );
		if ( ! $v || ! $v->active ) {
			return new \WP_Error( 'variant', 'That item is not available.' );
		}
		$p = Catalog::get( $v->product_id );
		if ( ! $p || ! Catalog::is_orderable( $p ) ) {
			return new \WP_Error( 'closed', 'Pre-Sale Ended: this item can no longer be ordered.' );
		}
		$qty = (int) $qty;
		if ( $qty < 1 ) {
			return new \WP_Error( 'qty', 'Quantity must be at least 1.' );
		}
		$fulfillment = isset( Orders::FULFILLMENT[ $fulfillment ] ) ? $fulfillment : \SSP\Core\Settings::get( 'default_fulfillment_choice' );
		$t        = self::t();
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND variant_id=%d", $user_id, $variant_id ) );
		$new_qty  = $qty + ( $existing ? (int) $existing->qty : 0 );
		$max      = Allocation::max_addable( $v, $user_id );
		if ( null !== $max && $new_qty > $max ) {
			return new \WP_Error(
				'allocation',
				0 === $max ? 'This item is fully allocated for you. You can join the waitlist.' : sprintf( 'You can reserve up to %d of this item right now.', $max ),
				array( 'waitlist' => true, 'max' => $max )
			);
		}
		if ( $existing ) {
			$wpdb->update( $t, array( 'qty' => $new_qty, 'fulfillment_choice' => $fulfillment ), array( 'id' => $existing->id ) );
		} else {
			$wpdb->insert(
				$t,
				array(
					'user_id'            => $user_id,
					'variant_id'         => $variant_id,
					'qty'                => $qty,
					'fulfillment_choice' => $fulfillment,
					'added_at'           => Util::now(),
				)
			);
		}
		return true;
	}

	public static function update( $user_id, $cart_id, $qty, $fulfillment ) {
		global $wpdb;
		$t   = self::t();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d AND user_id=%d", $cart_id, $user_id ) );
		if ( ! $row ) {
			return new \WP_Error( 'not_found', 'Cart item not found.' );
		}
		$qty = (int) $qty;
		if ( $qty <= 0 ) {
			$wpdb->delete( $t, array( 'id' => $cart_id ) );
			return true;
		}
		$fulfillment = isset( Orders::FULFILLMENT[ $fulfillment ] ) ? $fulfillment : $row->fulfillment_choice;
		$wpdb->update( $t, array( 'qty' => $qty, 'fulfillment_choice' => $fulfillment ), array( 'id' => $cart_id ) );
		return true;
	}

	public static function remove( $user_id, $cart_id ) {
		global $wpdb;
		$wpdb->delete( self::t(), array( 'id' => (int) $cart_id, 'user_id' => $user_id ) );
	}

	public static function clear( $user_id ) {
		global $wpdb;
		$wpdb->delete( self::t(), array( 'user_id' => $user_id ) );
	}

	/** Non-binding pre-check for display; binding validation happens at submit under row locks. */
	public static function validate( $user_id ) {
		$out = array();
		foreach ( self::items( $user_id ) as $it ) {
			$v = Catalog::variant( $it->variant_id );
			$p = $v ? Catalog::get( $v->product_id ) : null;
			if ( ! $v || ! $p || ! $v->active ) {
				$out[ $it->id ] = 'This item is no longer available. Please remove it.';
				continue;
			}
			if ( ! Catalog::is_orderable( $p ) ) {
				$out[ $it->id ] = 'Pre-Sale Ended. Please remove this item.';
				continue;
			}
			$current = Allocation::customer_reserved( $v->id, $user_id );
			$chk     = Allocation::check( $v, $user_id, (int) $it->qty, $current + (int) $it->qty );
			if ( is_wp_error( $chk ) ) {
				$out[ $it->id ] = $chk->get_error_message();
			}
		}
		return $out;
	}
}
