<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Events;
use SSP\Core\Installer;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/** Billing and multiple saved shipping addresses, one default per type. Always owner-scoped. */
class Addresses {

	const FIELDS = array( 'label', 'name', 'company', 'line1', 'line2', 'city', 'state', 'postal_code', 'country', 'phone' );

	public static function sanitize( $in ) {
		$in  = is_array( $in ) ? $in : array();
		$out = array();
		foreach ( self::FIELDS as $f ) {
			$out[ $f ] = sanitize_text_field( $in[ $f ] ?? '' );
		}
		$out['country'] = strtoupper( substr( $out['country'] ? $out['country'] : 'US', 0, 2 ) );
		return $out;
	}

	public static function validate( array $a ) {
		$e = new \WP_Error();
		foreach ( array( 'name' => 'Name', 'line1' => 'Street address', 'city' => 'City', 'state' => 'State', 'postal_code' => 'ZIP / postal code' ) as $f => $label ) {
			if ( '' === trim( $a[ $f ] ?? '' ) ) {
				$e->add( $f, $label . ' is required.' );
			}
		}
		return $e->has_errors() ? $e : true;
	}

	public static function create( $user_id, $type, array $a, $make_default = false ) {
		global $wpdb;
		$t   = Installer::tables()['addresses'];
		$now = Util::now();
		$row = array_merge(
			self::sanitize( $a ),
			array(
				'address_uid' => Util::ulid(),
				'user_id'     => $user_id,
				'type'        => 'billing' === $type ? 'billing' : 'shipping',
				'is_default'  => 0,
				'created_at'  => $now,
				'updated_at'  => $now,
			)
		);
		$wpdb->insert( $t, $row );
		$id = (int) $wpdb->insert_id;
		if ( $make_default || ! self::default_for( $user_id, $row['type'] ) ) {
			self::set_default( $user_id, $id );
		}
		return $id;
	}

	public static function list_for( $user_id, $type = null ) {
		global $wpdb;
		$t = Installer::tables()['addresses'];
		if ( $type ) {
			return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND type=%s AND archived_at IS NULL ORDER BY is_default DESC, id ASC", $user_id, $type ) );
		}
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND archived_at IS NULL ORDER BY type ASC, is_default DESC, id ASC", $user_id ) );
	}

	/** Ownership-checked fetch. */
	public static function get_owned( $user_id, $id ) {
		global $wpdb;
		$t = Installer::tables()['addresses'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d AND user_id=%d AND archived_at IS NULL", $id, $user_id ) );
	}

	public static function get( $id ) {
		global $wpdb;
		$t = Installer::tables()['addresses'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
	}

	public static function default_for( $user_id, $type = 'shipping' ) {
		global $wpdb;
		$t = Installer::tables()['addresses'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND type=%s AND is_default=1 AND archived_at IS NULL LIMIT 1", $user_id, $type ) );
	}

	public static function update( $user_id, $id, array $a ) {
		global $wpdb;
		$addr = self::get_owned( $user_id, $id );
		if ( ! $addr ) {
			return new \WP_Error( 'not_found', 'Address not found.' );
		}
		$clean = self::sanitize( $a );
		$v     = self::validate( $clean );
		if ( is_wp_error( $v ) ) {
			return $v;
		}
		$clean['updated_at'] = Util::now();
		$wpdb->update( Installer::tables()['addresses'], $clean, array( 'id' => $id ) );
		Audit::log( 'address.updated', 'customer', $user_id, null, array( 'address_id' => $id ) );
		if ( 'shipping' === $addr->type && $addr->is_default ) {
			Boxes::sync_default_address( $user_id );
		}
		Events::emit( 'customer.status_changed', array( 'user_id' => $user_id ) );
		return true;
	}

	public static function set_default( $user_id, $id ) {
		global $wpdb;
		$addr = self::get_owned( $user_id, $id );
		if ( ! $addr ) {
			return new \WP_Error( 'not_found', 'Address not found.' );
		}
		$t = Installer::tables()['addresses'];
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET is_default=0 WHERE user_id=%d AND type=%s", $user_id, $addr->type ) );
		$wpdb->update( $t, array( 'is_default' => 1 ), array( 'id' => $id ) );
		if ( 'shipping' === $addr->type ) {
			Boxes::sync_default_address( $user_id );
		}
		Events::emit( 'customer.status_changed', array( 'user_id' => $user_id ) );
		return true;
	}

	public static function archive( $user_id, $id ) {
		global $wpdb;
		$addr = self::get_owned( $user_id, $id );
		if ( ! $addr ) {
			return new \WP_Error( 'not_found', 'Address not found.' );
		}
		if ( $addr->is_default ) {
			return new \WP_Error( 'default', 'Set another address as default before removing this one.' );
		}
		$wpdb->update( Installer::tables()['addresses'], array( 'archived_at' => Util::now() ), array( 'id' => $id ) );
		return true;
	}

	public static function snapshot( $addr ) {
		if ( ! $addr ) {
			return null;
		}
		$s = array();
		foreach ( self::FIELDS as $f ) {
			$s[ $f ] = $addr->$f ?? '';
		}
		$s['address_id'] = (int) $addr->id;
		return $s;
	}

	public static function format( $a, $sep = "\n" ) {
		if ( ! $a ) {
			return '';
		}
		$a     = (array) $a;
		$parts = array_filter(
			array(
				$a['name'] ?? '',
				$a['company'] ?? '',
				$a['line1'] ?? '',
				$a['line2'] ?? '',
				trim( ( $a['city'] ?? '' ) . ', ' . ( $a['state'] ?? '' ) . ' ' . ( $a['postal_code'] ?? '' ), ' ,' ),
				( $a['country'] ?? 'US' ) !== 'US' ? ( $a['country'] ?? '' ) : '',
			)
		);
		return implode( $sep, $parts );
	}
}
