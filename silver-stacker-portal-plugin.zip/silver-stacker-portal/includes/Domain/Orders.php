<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Events;
use SSP\Core\Installer;
use SSP\Core\Mailer;
use SSP\Core\Roles;
use SSP\Core\Settings;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Pre-orders and order lines. Line-level quantities drive everything:
 *   net = qty_ordered - qty_cancelled (reserved against allocation)
 *   qty_available <= net, qty_invoiced + qty_pending_invoice <= qty_available, qty_shipped <= qty_available
 * Order and line statuses are derived from these numbers, never typed in.
 */
class Orders {

	const FULFILLMENT = array(
		'box'          => 'Add to My Box',
		'separate'     => 'Ship separately when available',
		'decide_later' => 'Decide later',
	);

	const FULFILLMENT_BADGE = array(
		'box'          => 'Assigned to box',
		'separate'     => 'Separate shipment',
		'decide_later' => 'Awaiting decision',
	);

	const LINE_STATUSES = array(
		'reserved'            => 'Reserved',
		'waitlisted'          => 'Waitlisted',
		'locked'              => 'Locked',
		'partially_available' => 'Partially available',
		'available'           => 'Available',
		'partially_invoiced'  => 'Partially invoiced',
		'invoiced'            => 'Invoiced',
		'fulfilled'           => 'Fulfilled',
		'cancelled'           => 'Cancelled',
	);

	const ORDER_STATUSES = array(
		'submitted'           => 'Submitted',
		'open'                => 'Open',
		'partially_available' => 'Partially available',
		'fully_available'     => 'Fully available',
		'partially_invoiced'  => 'Partially invoiced',
		'fully_invoiced'      => 'Fully invoiced',
		'completed'           => 'Completed',
		'cancelled'           => 'Cancelled',
	);

	public static function t() {
		return Installer::tables();
	}

	public static function net( $line ) {
		return max( 0, (int) $line->qty_ordered - (int) $line->qty_cancelled );
	}

	public static function line_total( $line ) {
		return round( self::net( $line ) * (float) $line->unit_price_usd, 2 );
	}

	/* ---------------------------------------------------------------- */
	/* Status derivation                                                */
	/* ---------------------------------------------------------------- */

	public static function derive_line_status( $line, $product = null ) {
		$net = self::net( $line );
		if ( 0 === $net ) {
			return 'cancelled';
		}
		if ( (int) $line->qty_shipped >= $net ) {
			return 'fulfilled';
		}
		if ( (int) $line->qty_invoiced >= $net ) {
			return 'invoiced';
		}
		if ( (int) $line->qty_invoiced > 0 ) {
			return 'partially_invoiced';
		}
		if ( (int) $line->qty_available >= $net ) {
			return 'available';
		}
		if ( (int) $line->qty_available > 0 ) {
			return 'partially_available';
		}
		$product = $product ? $product : Catalog::get( $line->product_id );
		if ( $line->locked_at || ( $product && in_array( Catalog::effective_lifecycle( $product ), array( 'presale_ended', 'archived' ), true ) ) ) {
			return 'locked';
		}
		return 'reserved';
	}

	public static function derive_order_status( array $lines ) {
		$active = array_filter( $lines, fn( $l ) => self::net( $l ) > 0 );
		if ( ! $active ) {
			return 'cancelled';
		}
		$all = fn( $cb ) => count( array_filter( $active, $cb ) ) === count( $active );
		$any = fn( $cb ) => count( array_filter( $active, $cb ) ) > 0;
		if ( $all( fn( $l ) => (int) $l->qty_shipped >= self::net( $l ) ) ) {
			return 'completed';
		}
		if ( $all( fn( $l ) => (int) $l->qty_invoiced >= self::net( $l ) ) ) {
			return 'fully_invoiced';
		}
		if ( $any( fn( $l ) => (int) $l->qty_invoiced > 0 ) ) {
			return 'partially_invoiced';
		}
		if ( $all( fn( $l ) => (int) $l->qty_available >= self::net( $l ) ) ) {
			return 'fully_available';
		}
		if ( $any( fn( $l ) => (int) $l->qty_available > 0 ) ) {
			return 'partially_available';
		}
		if ( $any( fn( $l ) => 'locked' === self::derive_line_status( $l ) ) ) {
			return 'open';
		}
		return 'submitted';
	}

	public static function refresh_line( $line_id ) {
		global $wpdb;
		$line = self::line( $line_id );
		if ( ! $line ) {
			return;
		}
		$status = self::derive_line_status( $line );
		if ( $status !== $line->display_status ) {
			$wpdb->update( self::t()['lines'], array( 'display_status' => $status ), array( 'id' => $line_id ) );
		}
		self::refresh_order( (int) $line->order_id );
	}

	public static function refresh_order( $order_id ) {
		global $wpdb;
		$lines = self::lines( $order_id );
		$sub   = 0;
		foreach ( $lines as $l ) {
			$sub += self::line_total( $l );
		}
		$wpdb->update(
			self::t()['orders'],
			array(
				'status'       => self::derive_order_status( $lines ),
				'subtotal_usd' => $sub,
				'updated_at'   => Util::now(),
			),
			array( 'id' => $order_id )
		);
	}

	public static function refresh_lines_for_product( $product_id ) {
		global $wpdb;
		$lt  = self::t()['lines'];
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$lt} WHERE product_id=%d", $product_id ) );
		$product = Catalog::get( $product_id );
		$orders  = array();
		foreach ( $ids as $id ) {
			$line   = self::line( $id );
			$status = self::derive_line_status( $line, $product );
			if ( $status !== $line->display_status ) {
				$wpdb->update( $lt, array( 'display_status' => $status ), array( 'id' => $id ) );
			}
			$orders[ (int) $line->order_id ] = true;
		}
		foreach ( array_keys( $orders ) as $oid ) {
			self::refresh_order( $oid );
		}
	}

	/* ---------------------------------------------------------------- */
	/* Reads                                                            */
	/* ---------------------------------------------------------------- */

	public static function get( $order_id ) {
		global $wpdb;
		$t = self::t()['orders'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $order_id ) );
	}

	public static function by_number( $number ) {
		global $wpdb;
		$t = self::t()['orders'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE order_number=%d", $number ) );
	}

	/** Ownership-checked: returns null if the order is not the user's. */
	public static function get_owned( $user_id, $order_number ) {
		global $wpdb;
		$t = self::t()['orders'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE order_number=%d AND user_id=%d", $order_number, $user_id ) );
	}

	public static function lines( $order_id ) {
		global $wpdb;
		$t = self::t()['lines'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE order_id=%d ORDER BY id ASC", $order_id ) );
	}

	public static function line( $id ) {
		global $wpdb;
		$t = self::t()['lines'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
	}

	/** Ownership-checked line fetch by public UID. */
	public static function line_owned( $user_id, $line_uid ) {
		global $wpdb;
		$t = self::t()['lines'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE line_uid=%s AND user_id=%d", $line_uid, $user_id ) );
	}

	public static function customer_orders( $user_id, array $args = array() ) {
		global $wpdb;
		$ot     = self::t()['orders'];
		$lt     = self::t()['lines'];
		$where  = array( 'o.user_id=%d' );
		$params = array( $user_id );
		if ( ! empty( $args['q'] ) ) {
			$where[]  = "o.id IN (SELECT order_id FROM {$lt} WHERE user_id=%d AND (name_snapshot LIKE %s OR sku_snapshot LIKE %s))";
			$like     = '%' . $wpdb->esc_like( $args['q'] ) . '%';
			$params[] = $user_id;
			$params[] = $like;
			$params[] = $like;
		}
		if ( ! empty( $args['status'] ) && isset( self::ORDER_STATUSES[ $args['status'] ] ) ) {
			$where[]  = 'o.status=%s';
			$params[] = $args['status'];
		}
		if ( ! empty( $args['from'] ) ) {
			$where[]  = 'o.submitted_at >= %s';
			$params[] = Util::local_to_utc( $args['from'] . ' 00:00:00' );
		}
		if ( ! empty( $args['to'] ) ) {
			$where[]  = 'o.submitted_at <= %s';
			$params[] = Util::local_to_utc( $args['to'] . ' 23:59:59' );
		}
		$per   = 20;
		$page  = max( 1, (int) ( $args['paged'] ?? 1 ) );
		$w     = implode( ' AND ', $where );
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$ot} o WHERE {$w}", $params ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT o.* FROM {$ot} o WHERE {$w} ORDER BY o.submitted_at DESC, o.id DESC LIMIT %d OFFSET %d", array_merge( $params, array( $per, ( $page - 1 ) * $per ) ) ) );
		return array( 'rows' => $rows, 'total' => $total, 'per_page' => $per, 'page' => $page );
	}

	/* ---------------------------------------------------------------- */
	/* Placement                                                        */
	/* ---------------------------------------------------------------- */

	/**
	 * Submit the customer's cart as a pre-order (no payment).
	 *
	 * @return int|\WP_Error order id. On validation failure the error data contains 'line_errors' keyed by variant id.
	 */
	public static function submit_cart( $user_id, $submit_key, $note = '' ) {
		$items = Cart::items( $user_id );
		if ( ! $items ) {
			return new \WP_Error( 'empty', 'Your cart is empty.' );
		}
		$payload = array();
		foreach ( $items as $it ) {
			$payload[] = array(
				'variant_id'  => (int) $it->variant_id,
				'qty'         => (int) $it->qty,
				'fulfillment' => $it->fulfillment_choice,
			);
		}
		$result = self::place( $user_id, $payload, $submit_key, $note );
		if ( ! is_wp_error( $result ) ) {
			Cart::clear( $user_id );
		}
		return $result;
	}

	/**
	 * Core placement: validates closing date, product status, minimum quantity, total and
	 * per-customer allocation under row locks, then reserves allocation atomically.
	 *
	 * @param array $items [ [variant_id, qty, fulfillment] ]
	 * @param array $opts  'held_credit' => [variant_id => qty] for waitlist offer conversion, 'source'
	 */
	public static function place( $user_id, array $items, $submit_key, $note = '', array $opts = array() ) {
		global $wpdb;
		if ( ! Roles::is_customer( $user_id ) || ! Customers::is_approved( $user_id ) ) {
			return new \WP_Error( 'forbidden', 'Your account is not approved for ordering.' );
		}
		$submit_key = substr( preg_replace( '/[^A-Za-z0-9\-_]/', '', (string) $submit_key ), 0, 64 );
		if ( strlen( $submit_key ) < 16 ) {
			return new \WP_Error( 'key', 'Invalid submission. Please refresh and try again.' );
		}
		$ot = self::t()['orders'];
		$lt = self::t()['lines'];

		// Idempotency: the same submission (double click, network retry) returns the original order.
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT id,user_id FROM {$ot} WHERE submit_key=%s", $submit_key ) );
		if ( $existing ) {
			return (int) $existing->user_id === (int) $user_id ? (int) $existing->id : new \WP_Error( 'key', 'Invalid submission.' );
		}

		// Merge duplicates and sanitize.
		$merged = array();
		foreach ( $items as $it ) {
			$vid = (int) $it['variant_id'];
			$qty = (int) $it['qty'];
			$f   = isset( self::FULFILLMENT[ $it['fulfillment'] ?? '' ] ) ? $it['fulfillment'] : 'decide_later';
			if ( $vid <= 0 ) {
				continue;
			}
			if ( ! isset( $merged[ $vid ] ) ) {
				$merged[ $vid ] = array( 'qty' => 0, 'fulfillment' => $f );
			}
			$merged[ $vid ]['qty'] += $qty;
		}
		if ( ! $merged ) {
			return new \WP_Error( 'empty', 'Nothing to order.' );
		}

		$held_credit = (array) ( $opts['held_credit'] ?? array() );
		$wpdb->query( 'START TRANSACTION' );
		try {
			$variants    = Allocation::lock_variants( array_keys( $merged ) );
			$line_errors = array();
			$products    = array();
			foreach ( $merged as $vid => $m ) {
				$v = $variants[ $vid ] ?? null;
				if ( ! $v || ! $v->active ) {
					$line_errors[ $vid ] = 'This item is no longer available.';
					continue;
				}
				$p = Catalog::get( $v->product_id );
				$products[ $vid ] = $p;
				if ( ! $p || ! Catalog::is_orderable( $p ) ) {
					$line_errors[ $vid ] = ( $p && 'presale_ended' === Catalog::effective_lifecycle( $p ) ) ? 'The pre-sale for ' . $p->name . ' has ended.' : 'This item cannot be ordered right now.';
					continue;
				}
				if ( $m['qty'] < 1 ) {
					$line_errors[ $vid ] = 'Quantity must be at least 1.';
					continue;
				}
				$current   = Allocation::customer_reserved( $vid, $user_id );
				$new_total = 'per_line' === Settings::get( 'min_qty_scope' ) ? $m['qty'] : $current + $m['qty'];
				if ( 'per_line' === Settings::get( 'min_qty_scope' ) && $m['qty'] < (int) $v->min_order_qty && ! Allocation::has_minimum_override( $vid, $user_id ) ) {
					$line_errors[ $vid ] = sprintf( '%s: the minimum order quantity is %d.', $p->name, (int) $v->min_order_qty );
					continue;
				}
				$chk = Allocation::check( $v, $user_id, $m['qty'], 'per_line' === Settings::get( 'min_qty_scope' ) ? $current + $m['qty'] : $new_total, 0, (int) ( $held_credit[ $vid ] ?? 0 ) );
				if ( is_wp_error( $chk ) ) {
					$line_errors[ $vid ] = $chk->get_error_message();
				}
			}
			if ( $line_errors ) {
				$wpdb->query( 'ROLLBACK' );
				return new \WP_Error( 'validation', 'Some items could not be reserved. Please review the messages below.', array( 'line_errors' => $line_errors ) );
			}

			$now      = Util::now();
			$number   = Util::next_sequence( 'order_number' );
			$terms    = Terms::current();
			$order_id = 0;
			$wpdb->insert(
				$ot,
				array(
					'order_uid'        => Util::ulid(),
					'order_number'     => $number,
					'user_id'          => $user_id,
					'status'           => 'submitted',
					'customer_note'    => sanitize_textarea_field( $note ),
					'terms_version_id' => $terms ? $terms->id : null,
					'subtotal_usd'     => 0,
					'submit_key'       => $submit_key,
					'source'           => $opts['source'] ?? 'portal',
					'submitted_at'     => $now,
					'updated_at'       => $now,
				)
			);
			$order_id = (int) $wpdb->insert_id;
			if ( ! $order_id ) {
				throw new \RuntimeException( 'Could not create order: ' . $wpdb->last_error );
			}
			$box_lines = array();
			foreach ( $merged as $vid => $m ) {
				$v = $variants[ $vid ];
				$p = $products[ $vid ];
				$wpdb->insert(
					$lt,
					array(
						'line_uid'           => Util::ulid(),
						'order_id'           => $order_id,
						'user_id'            => $user_id,
						'product_id'         => $p->id,
						'variant_id'         => $vid,
						'name_snapshot'      => $p->name . ( $v->label ? ' - ' . $v->label : '' ),
						'sku_snapshot'       => $v->sku,
						'unit_price_usd'     => $v->price_usd,
						'price_type'         => $p->price_type,
						'qty_ordered'        => $m['qty'],
						'fulfillment_choice' => $m['fulfillment'],
						'eta_at_order'       => Catalog::eta_label( $p ),
						'display_status'     => 'reserved',
						'created_at'         => $now,
						'updated_at'         => $now,
					)
				);
				$line_id = (int) $wpdb->insert_id;
				$credit  = min( (int) ( $held_credit[ $vid ] ?? 0 ), $m['qty'] );
				if ( $credit > 0 ) {
					$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t()['variants'] . ' SET held_qty = GREATEST(0, CAST(held_qty AS SIGNED) - %d) WHERE id=%d', $credit, $vid ) );
				}
				Allocation::apply( $vid, $user_id, $line_id, $m['qty'], 'reserve', 'Order #' . $number );
				if ( 'box' === $m['fulfillment'] ) {
					$box_lines[] = $line_id;
				}
			}
			$wpdb->update( self::t()['profiles'], array( 'last_order_at' => $now ), array( 'user_id' => $user_id ) );
			$wpdb->query( 'COMMIT' );
		} catch ( \Throwable $e ) {
			$wpdb->query( 'ROLLBACK' );
			// A concurrent duplicate submit raced us: return the winner.
			$existing = $wpdb->get_row( $wpdb->prepare( "SELECT id,user_id FROM {$ot} WHERE submit_key=%s", $submit_key ) );
			if ( $existing && (int) $existing->user_id === (int) $user_id ) {
				return (int) $existing->id;
			}
			return new \WP_Error( 'server', 'We could not submit your order. Please try again. (' . $e->getMessage() . ')' );
		}

		foreach ( self::lines( $order_id ) as $l ) {
			self::refresh_line( $l->id );
		}
		foreach ( $box_lines as $lid ) {
			Boxes::add_line( $user_id, $lid, $user_id );
		}
		Audit::log( 'order.submitted', 'order', $order_id, null, array( 'order_number' => $number, 'items' => $merged ), null, $user_id );
		Events::emit( 'order.submitted', array( 'order_id' => $order_id ) );

		if ( Settings::get( 'order_confirmation_email' ) ) {
			$p    = Customers::profile( $user_id );
			$rows = array();
			foreach ( self::lines( $order_id ) as $l ) {
				$rows[] = array( 'name' => $l->name_snapshot, 'qty' => self::net( $l ), 'price' => $l->unit_price_usd );
			}
			Mailer::queue( 'order_confirmation', $p->email, array( 'name' => $p->contact_name, 'order_number' => $number, 'lines_table' => Mailer::lines_table( $rows ), 'order_url' => home_url( '/portal/orders/' . $number . '/' ) ), $user_id, 'order', $order_id );
		}
		return $order_id;
	}

	/* ---------------------------------------------------------------- */
	/* Amendments                                                       */
	/* ---------------------------------------------------------------- */

	/** @return true|string reason not editable */
	public static function customer_can_amend( $line, $product = null ) {
		$product = $product ? $product : Catalog::get( $line->product_id );
		if ( 0 === self::net( $line ) ) {
			return 'This line was cancelled.';
		}
		if ( $line->locked_at ) {
			return 'Locked: the pre-order closing date has passed.';
		}
		$life = $product ? Catalog::effective_lifecycle( $product ) : 'archived';
		if ( 'presale' === $life ) {
			return true;
		}
		if ( 'in_stock' === $life ) {
			$rule = Settings::get( 'instock_editable_until' );
			if ( 'never' === $rule ) {
				return 'In-stock orders cannot be changed online. Please contact us.';
			}
			if ( 'available' === $rule && (int) $line->qty_available > 0 ) {
				return 'Locked: this item is already being prepared.';
			}
			if ( (int) $line->qty_invoiced > 0 || (int) $line->qty_pending_invoice > 0 ) {
				return 'Locked: this item has been invoiced.';
			}
			return true;
		}
		return 'Locked: the pre-order closing date has passed.';
	}

	/**
	 * Customer quantity change before closing. Decrease releases allocation; increase is
	 * re-validated against minimum, total and per-customer limits. Zero cancels (D-6).
	 */
	public static function customer_amend( $user_id, $line_uid, $new_qty ) {
		$line = self::line_owned( $user_id, $line_uid );
		if ( ! $line ) {
			return new \WP_Error( 'not_found', 'Order line not found.' );
		}
		$can = self::customer_can_amend( $line );
		if ( true !== $can ) {
			return new \WP_Error( 'locked', $can );
		}
		$new_qty = (int) $new_qty;
		if ( $new_qty < 0 ) {
			return new \WP_Error( 'qty', 'Quantity cannot be negative.' );
		}
		if ( 0 === $new_qty && ! Settings::get( 'zero_qty_cancels' ) ) {
			return new \WP_Error( 'qty', 'To cancel this item please contact us.' );
		}
		return self::change_qty( $line, $new_qty, 'customer', '', false );
	}

	/** Staff operational correction (any time) with audit reason. */
	public static function staff_set_qty( $line_id, $new_qty, $reason, $allow_over_allocation = false ) {
		$line = self::line( $line_id );
		if ( ! $line ) {
			return new \WP_Error( 'not_found', 'Order line not found.' );
		}
		if ( '' === trim( (string) $reason ) ) {
			return new \WP_Error( 'reason', 'A reason is required for staff corrections.' );
		}
		return self::change_qty( $line, (int) $new_qty, 'staff', sanitize_textarea_field( $reason ), $allow_over_allocation );
	}

	private static function change_qty( $line, $new_qty, $actor_type, $reason, $allow_over ) {
		global $wpdb;
		$lt  = self::t()['lines'];
		$old = self::net( $line );
		if ( $new_qty === $old ) {
			return true;
		}
		$floor = max( (int) $line->qty_invoiced + (int) $line->qty_pending_invoice, (int) $line->qty_shipped );
		if ( $new_qty < $floor ) {
			return new \WP_Error( 'floor', sprintf( 'Quantity cannot go below %d because those units are already invoiced or shipped.', $floor ) );
		}
		$delta = $new_qty - $old;
		$wpdb->query( 'START TRANSACTION' );
		try {
			$vs = Allocation::lock_variants( array( $line->variant_id ) );
			$v  = $vs[ (int) $line->variant_id ] ?? null;
			if ( ! $v ) {
				throw new \RuntimeException( 'Variant missing' );
			}
			$fresh = self::line( $line->id ); // re-read under lock
			if ( self::net( $fresh ) !== $old ) {
				$wpdb->query( 'ROLLBACK' );
				return new \WP_Error( 'conflict', 'This line changed while you were editing. Please review and try again.' );
			}
			if ( $delta > 0 ) {
				$others    = Allocation::customer_reserved( $v->id, $line->user_id, $line->id );
				$new_total = 'per_line' === Settings::get( 'min_qty_scope' ) ? $new_qty : $others + $new_qty;
				if ( ! $allow_over ) {
					$chk = Allocation::check( $v, $line->user_id, $delta, $others + $new_qty, $line->id );
					if ( is_wp_error( $chk ) ) {
						$wpdb->query( 'ROLLBACK' );
						return $chk;
					}
				}
				if ( 'per_line' === Settings::get( 'min_qty_scope' ) && $new_total < (int) $v->min_order_qty && ! $allow_over ) {
					$wpdb->query( 'ROLLBACK' );
					return new \WP_Error( 'minimum', 'The minimum order quantity is ' . (int) $v->min_order_qty . '.' );
				}
			} elseif ( $new_qty > 0 && 'customer' === $actor_type ) {
				$others = Allocation::customer_reserved( $v->id, $line->user_id, $line->id );
				$total  = 'per_line' === Settings::get( 'min_qty_scope' ) ? $new_qty : $others + $new_qty;
				if ( $total < (int) $v->min_order_qty && ! Allocation::has_minimum_override( $v->id, $line->user_id ) ) {
					$wpdb->query( 'ROLLBACK' );
					return new \WP_Error( 'minimum', 'The minimum order quantity is ' . (int) $v->min_order_qty . '. Set the quantity to 0 to cancel instead.' );
				}
			}
			if ( 0 === $new_qty ) {
				$data = array( 'qty_cancelled' => (int) $fresh->qty_ordered );
			} else {
				$data = array( 'qty_ordered' => $new_qty + (int) $fresh->qty_cancelled );
			}
			$data['qty_available'] = min( (int) $fresh->qty_available, $new_qty );
			$data['updated_at']    = Util::now();
			$data['row_version']   = (int) $fresh->row_version + 1;
			$wpdb->update( $lt, $data, array( 'id' => $line->id ) );
			Allocation::apply( $v->id, $line->user_id, $line->id, $delta, $delta > 0 ? 'reserve' : 'release', $reason ? $reason : ucfirst( $actor_type ) . ' amendment' );
			if ( $allow_over && $delta > 0 ) {
				Allocation::add_override( $v->id, $line->user_id, 'per_customer', $delta, 'Staff correction: ' . $reason, $line->id );
			}
			$wpdb->insert(
				self::t()['amendments'],
				array(
					'line_id'    => $line->id,
					'old_qty'    => $old,
					'new_qty'    => $new_qty,
					'actor_id'   => get_current_user_id(),
					'actor_type' => $actor_type,
					'reason'     => $reason,
					'created_at' => Util::now(),
				)
			);
			$wpdb->query( 'COMMIT' );
		} catch ( \Throwable $e ) {
			$wpdb->query( 'ROLLBACK' );
			return new \WP_Error( 'server', 'Could not update the quantity: ' . $e->getMessage() );
		}
		self::refresh_line( $line->id );
		Audit::log( 0 === $new_qty ? 'line.cancelled' : 'line.qty_changed', 'order_line', $line->id, array( 'qty' => $old ), array( 'qty' => $new_qty ), $reason ? $reason : null );
		if ( 0 === $new_qty ) {
			Boxes::remove_line_everywhere( $line->id, get_current_user_id(), 'Line cancelled' );
		} elseif ( Boxes::line_box( $line->id ) ) {
			Boxes::queue_digest( Boxes::line_box( $line->id ) );
		}
		Events::emit( 'line.changed', array( 'line_id' => $line->id ) );
		if ( $delta < 0 ) {
			Waitlist::process_variant( (int) $line->variant_id );
		}
		return true;
	}

	/* ---------------------------------------------------------------- */
	/* Availability (staff / warehouse)                                 */
	/* ---------------------------------------------------------------- */

	public static function set_availability( $line_id, $qty, $source = 'staff', $note = '' ) {
		global $wpdb;
		$line = self::line( $line_id );
		if ( ! $line ) {
			return new \WP_Error( 'not_found', 'Line not found.' );
		}
		$qty = (int) $qty;
		$net = self::net( $line );
		if ( $qty < 0 || $qty > $net ) {
			return new \WP_Error( 'range', sprintf( 'Available quantity must be between 0 and %d (the ordered quantity).', $net ) );
		}
		$floor = max( (int) $line->qty_invoiced + (int) $line->qty_pending_invoice, (int) $line->qty_shipped );
		if ( $qty < $floor ) {
			return new \WP_Error( 'floor', sprintf( 'Available quantity cannot be below %d (already invoiced or shipped).', $floor ) );
		}
		if ( $qty === (int) $line->qty_available ) {
			return true;
		}
		$wpdb->update(
			self::t()['lines'],
			array(
				'qty_available' => $qty,
				'updated_at'    => Util::now(),
				'row_version'   => (int) $line->row_version + 1,
			),
			array( 'id' => $line_id )
		);
		self::refresh_line( $line_id );
		Audit::log( 'line.availability_changed', 'order_line', $line_id, array( 'qty_available' => (int) $line->qty_available ), array( 'qty_available' => $qty, 'source' => $source ), $note ? $note : null );
		$box = Boxes::line_box( $line_id );
		if ( $box ) {
			Boxes::queue_digest( $box );
		}
		Events::emit( 'line.availability_changed', array( 'line_id' => $line_id ) );
		return true;
	}

	/**
	 * Proposal helper: distribute an arrived quantity across a variant's open lines, oldest order first.
	 * Returns a preview; staff must confirm (apply_distribution) before anything is saved.
	 */
	public static function propose_distribution( $variant_id, $arrived_qty ) {
		global $wpdb;
		$lt    = self::t()['lines'];
		$ot    = self::t()['orders'];
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT l.*, o.order_number, o.submitted_at FROM {$lt} l JOIN {$ot} o ON o.id=l.order_id WHERE l.variant_id=%d AND (l.qty_ordered - l.qty_cancelled) > l.qty_available ORDER BY o.submitted_at ASC, l.id ASC", $variant_id ) );
		$left  = max( 0, (int) $arrived_qty );
		$plan  = array();
		foreach ( $rows as $r ) {
			$need = self::net( $r ) - (int) $r->qty_available;
			$give = min( $need, $left );
			$plan[] = array(
				'line'        => $r,
				'current'     => (int) $r->qty_available,
				'proposed'    => (int) $r->qty_available + $give,
			);
			$left  -= $give;
		}
		return array( 'plan' => $plan, 'unassigned' => $left );
	}

	/* ---------------------------------------------------------------- */
	/* Fulfillment choice                                               */
	/* ---------------------------------------------------------------- */

	public static function can_change_fulfillment( $line ) {
		if ( 0 === self::net( $line ) || (int) $line->qty_shipped >= self::net( $line ) ) {
			return 'This item has already shipped or was cancelled.';
		}
		$box_id = Boxes::line_box( $line->id );
		if ( $box_id ) {
			$box  = Boxes::get( $box_id );
			$rule = Settings::get( 'fulfillment_change_until' );
			$locked_statuses = 'preparing' === $rule ? array( 'preparing', 'shipped', 'delivered', 'closed' ) : array( 'shipment_requested', 'preparing', 'shipped', 'delivered', 'closed' );
			if ( $box && in_array( $box->status, $locked_statuses, true ) ) {
				return 'Your box is already being prepared for shipment.';
			}
		}
		if ( Shipments::line_in_open_shipment( $line->id ) ) {
			return 'This item is already being prepared for a separate shipment.';
		}
		return true;
	}

	/**
	 * @param int|null $owner_user_id When set (customer action), ownership is enforced.
	 */
	public static function set_fulfillment( $line_id, $choice, $owner_user_id = null ) {
		global $wpdb;
		$line = self::line( $line_id );
		if ( ! $line || ( $owner_user_id && (int) $line->user_id !== (int) $owner_user_id ) ) {
			return new \WP_Error( 'not_found', 'Order line not found.' );
		}
		if ( ! isset( self::FULFILLMENT[ $choice ] ) ) {
			return new \WP_Error( 'choice', 'Invalid fulfillment choice.' );
		}
		if ( $choice === $line->fulfillment_choice ) {
			if ( 'box' === $choice && ! Boxes::line_box( $line_id ) ) {
				return Boxes::add_line( (int) $line->user_id, $line_id, get_current_user_id() );
			}
			return true;
		}
		$can = self::can_change_fulfillment( $line );
		if ( true !== $can ) {
			return new \WP_Error( 'locked', $can );
		}
		if ( 'box' === $choice ) {
			$r = Boxes::add_line( (int) $line->user_id, $line_id, get_current_user_id() );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		} elseif ( Boxes::line_box( $line_id ) ) {
			Boxes::remove_line( Boxes::line_box( $line_id ), $line_id, get_current_user_id() );
		}
		$wpdb->update( self::t()['lines'], array( 'fulfillment_choice' => $choice, 'updated_at' => Util::now() ), array( 'id' => $line_id ) );
		Audit::log( 'line.fulfillment_changed', 'order_line', $line_id, array( 'fulfillment' => $line->fulfillment_choice ), array( 'fulfillment' => $choice ) );
		Events::emit( 'line.changed', array( 'line_id' => $line_id ) );
		return true;
	}

	/* ---------------------------------------------------------------- */
	/* Staff queries                                                    */
	/* ---------------------------------------------------------------- */

	public static function staff_orders( array $args ) {
		global $wpdb;
		$ot     = self::t()['orders'];
		$pt     = self::t()['profiles'];
		$lt     = self::t()['lines'];
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['q'] ) ) {
			$q = trim( $args['q'] );
			$like = '%' . $wpdb->esc_like( $q ) . '%';
			$where[] = "(o.order_number = %d OR c.company_name LIKE %s OR c.contact_name LIKE %s OR c.email LIKE %s OR o.id IN (SELECT order_id FROM {$lt} WHERE name_snapshot LIKE %s OR sku_snapshot LIKE %s))";
			$params  = array_merge( $params, array( (int) $q, $like, $like, $like, $like, $like ) );
		}
		if ( ! empty( $args['status'] ) ) {
			if ( 'not_cancelled' === $args['status'] ) {
				$where[] = "o.status<>'cancelled'";
			} elseif ( isset( self::ORDER_STATUSES[ $args['status'] ] ) ) {
				$where[]  = 'o.status=%s';
				$params[] = $args['status'];
			}
		}
		if ( ! empty( $args['user_id'] ) ) {
			$where[]  = 'o.user_id=%d';
			$params[] = (int) $args['user_id'];
		}
		if ( ! empty( $args['from'] ) ) {
			$where[]  = 'o.submitted_at >= %s';
			$params[] = Util::local_to_utc( $args['from'] . ' 00:00:00' );
		}
		if ( ! empty( $args['to'] ) ) {
			$where[]  = 'o.submitted_at <= %s';
			$params[] = Util::local_to_utc( $args['to'] . ' 23:59:59' );
		}
		$per   = max( 1, (int) ( $args['per_page'] ?? 50 ) );
		$page  = max( 1, (int) ( $args['paged'] ?? 1 ) );
		$w     = implode( ' AND ', $where );
		$from  = "FROM {$ot} o LEFT JOIN {$pt} c ON c.user_id=o.user_id WHERE {$w}";
		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) {$from}", $params ) ) : $wpdb->get_var( "SELECT COUNT(*) {$from}" ) );
		$sql   = "SELECT o.*, c.company_name, c.contact_name, c.email {$from} ORDER BY o.submitted_at DESC, o.id DESC LIMIT %d OFFSET %d";
		$rows  = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $params, array( $per, ( $page - 1 ) * $per ) ) ) );
		return array( 'rows' => $rows, 'total' => $total );
	}

	public static function staff_lines( array $args ) {
		global $wpdb;
		$lt     = self::t()['lines'];
		$ot     = self::t()['orders'];
		$pt     = self::t()['profiles'];
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['q'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['q'] ) . '%';
			$where[]  = '(l.name_snapshot LIKE %s OR l.sku_snapshot LIKE %s OR c.company_name LIKE %s OR c.contact_name LIKE %s OR o.order_number=%d)';
			$params   = array_merge( $params, array( $like, $like, $like, $like, (int) $args['q'] ) );
		}
		foreach ( array( 'product_id', 'variant_id', 'user_id' ) as $k ) {
			if ( ! empty( $args[ $k ] ) ) {
				$where[]  = "l.{$k}=%d";
				$params[] = (int) $args[ $k ];
			}
		}
		if ( ! empty( $args['status'] ) && isset( self::LINE_STATUSES[ $args['status'] ] ) ) {
			$where[]  = 'l.display_status=%s';
			$params[] = $args['status'];
		}
		if ( ! empty( $args['fulfillment'] ) && isset( self::FULFILLMENT[ $args['fulfillment'] ] ) ) {
			$where[]  = 'l.fulfillment_choice=%s';
			$params[] = $args['fulfillment'];
		}
		if ( ! empty( $args['invoice_state'] ) ) {
			if ( 'uninvoiced_available' === $args['invoice_state'] ) {
				$where[] = 'l.qty_available > (l.qty_invoiced + l.qty_pending_invoice)';
			} elseif ( 'invoiced' === $args['invoice_state'] ) {
				$where[] = 'l.qty_invoiced > 0';
			} elseif ( 'not_invoiced' === $args['invoice_state'] ) {
				$where[] = 'l.qty_invoiced = 0';
			}
		}
		if ( ! empty( $args['exclude_cancelled'] ) ) {
			$where[] = '(l.qty_ordered - l.qty_cancelled) > 0';
		}
		$per   = max( 1, (int) ( $args['per_page'] ?? 100 ) );
		$page  = max( 1, (int) ( $args['paged'] ?? 1 ) );
		$w     = implode( ' AND ', $where );
		$from  = "FROM {$lt} l JOIN {$ot} o ON o.id=l.order_id LEFT JOIN {$pt} c ON c.user_id=l.user_id WHERE {$w}";
		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) {$from}", $params ) ) : $wpdb->get_var( "SELECT COUNT(*) {$from}" ) );
		$order = $args['order'] ?? 'o.submitted_at DESC, l.id ASC';
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT l.*, o.order_number, o.submitted_at, o.customer_note, c.company_name, c.contact_name {$from} ORDER BY {$order} LIMIT %d OFFSET %d", array_merge( $params, array( $per, ( $page - 1 ) * $per ) ) ) );
		return array( 'rows' => $rows, 'total' => $total );
	}

	public static function amendments( $line_id ) {
		global $wpdb;
		$t = self::t()['amendments'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE line_id=%d ORDER BY id DESC", $line_id ) );
	}
}
