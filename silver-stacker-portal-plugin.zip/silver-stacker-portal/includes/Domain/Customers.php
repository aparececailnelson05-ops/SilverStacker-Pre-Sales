<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Events;
use SSP\Core\Installer;
use SSP\Core\Mailer;
use SSP\Core\Roles;
use SSP\Core\Settings;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/** Customer accounts: registration, approval workflow, profile, access checks. */
class Customers {

	const STATUSES = array(
		'pending'   => 'Pending approval',
		'approved'  => 'Approved',
		'rejected'  => 'Rejected',
		'suspended' => 'Suspended',
	);

	/** Allowed status transitions (Architecture §9.1). */
	const TRANSITIONS = array(
		'pending'   => array( 'approved', 'rejected' ),
		'approved'  => array( 'suspended' ),
		'suspended' => array( 'approved' ),
		'rejected'  => array( 'approved' ),
	);

	public static function t() {
		return Installer::tables();
	}

	public static function profile( $user_id ) {
		global $wpdb;
		$t = self::t()['profiles'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d", $user_id ) );
	}

	public static function by_uid( $uid ) {
		global $wpdb;
		$t = self::t()['profiles'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE customer_uid=%s", $uid ) );
	}

	public static function status( $user_id ) {
		$p = self::profile( $user_id );
		return $p ? $p->status : null;
	}

	public static function is_approved( $user_id ) {
		return 'approved' === self::status( $user_id );
	}

	/** Can this user see private catalog data (prices, products, images)? */
	public static function can_view_catalog( $user_id = null ) {
		$user_id = $user_id ? $user_id : get_current_user_id();
		if ( ! $user_id ) {
			return false;
		}
		if ( Roles::is_staff( $user_id ) ) {
			return true;
		}
		return Roles::is_customer( $user_id ) && self::is_approved( $user_id ) && Terms::has_accepted_current( $user_id );
	}

	public static function display_name( $p ) {
		if ( ! $p ) {
			return '';
		}
		return $p->company_name ? $p->company_name . ' (' . $p->contact_name . ')' : $p->contact_name;
	}

	/**
	 * Register a new individual customer account (pending approval).
	 *
	 * @return int|\WP_Error user id
	 */
	public static function register( array $in ) {
		global $wpdb;
		$errors = new \WP_Error();

		$contact = sanitize_text_field( $in['contact_name'] ?? '' );
		$email   = sanitize_email( $in['email'] ?? '' );
		$phone   = sanitize_text_field( $in['phone'] ?? '' );
		$company = sanitize_text_field( $in['company_name'] ?? '' );
		$pass    = (string) ( $in['password'] ?? '' );
		$pass2   = (string) ( $in['password_confirm'] ?? '' );

		if ( '' === $contact ) {
			$errors->add( 'contact_name', 'Contact name is required.' );
		}
		if ( ! is_email( $email ) ) {
			$errors->add( 'email', 'A valid email address is required.' );
		} elseif ( email_exists( $email ) ) {
			$errors->add( 'email', 'An account with this email already exists. Please log in or reset your password.' );
		}
		if ( strlen( preg_replace( '/\D/', '', $phone ) ) < 7 ) {
			$errors->add( 'phone', 'A valid phone number is required.' );
		}
		if ( '' === $company ) {
			$errors->add( 'company_name', 'Company or store name is required.' );
		}
		if ( strlen( $pass ) < 10 ) {
			$errors->add( 'password', 'Password must be at least 10 characters.' );
		} elseif ( $pass !== $pass2 ) {
			$errors->add( 'password_confirm', 'Passwords do not match.' );
		}

		$billing  = Addresses::sanitize( $in['billing'] ?? array() );
		$same     = ! empty( $in['shipping_same'] );
		$shipping = $same ? $billing : Addresses::sanitize( $in['shipping'] ?? array() );
		foreach ( array( 'billing' => $billing, 'shipping' => $shipping ) as $type => $addr ) {
			$v = Addresses::validate( $addr );
			if ( is_wp_error( $v ) ) {
				foreach ( $v->get_error_messages() as $m ) {
					$errors->add( $type, ucfirst( $type ) . ' address: ' . $m );
				}
			}
		}

		$questions = self::questions();
		$answers   = (array) ( $in['answers'] ?? array() );
		foreach ( $questions as $q ) {
			$a = trim( sanitize_textarea_field( $answers[ $q->id ] ?? '' ) );
			if ( '' === $a ) {
				$errors->add( 'answers', 'Please answer every qualification question.' );
				break;
			}
		}
		if ( empty( $in['agree_individual'] ) ) {
			$errors->add( 'agree_individual', 'Please confirm this account is for you individually and will not be shared.' );
		}

		if ( $errors->has_errors() ) {
			return $errors;
		}

		$username = self::unique_username( $email );
		$user_id  = wp_insert_user(
			array(
				'user_login'   => $username,
				'user_email'   => $email,
				'user_pass'    => $pass,
				'display_name' => $contact,
				'first_name'   => $contact,
				'role'         => 'ss_customer',
			)
		);
		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		$now        = Util::now();
		$contact_ok = 0;
		foreach ( $questions as $q ) {
			if ( 'contact_permission' === $q->question_key ) {
				$contact_ok = self::is_yes( $answers[ $q->id ] ?? '' ) ? 1 : 0;
			}
		}
		$invited_by = null;
		if ( ! empty( $in['invite_token'] ) ) {
			$inv = self::get_invite( $in['invite_token'] );
			if ( $inv && strtolower( $inv['email'] ) === strtolower( $email ) ) {
				$invited_by = (int) $inv['by'];
				delete_transient( 'ssp_invite_' . hash( 'sha256', $in['invite_token'] ) );
			}
		}

		$wpdb->insert(
			self::t()['profiles'],
			array(
				'user_id'       => $user_id,
				'customer_uid'  => Util::ulid(),
				'contact_name'  => $contact,
				'company_name'  => $company,
				'phone'         => $phone,
				'email'         => $email,
				'status'        => 'pending',
				'email_consent' => $contact_ok,
				'sms_consent'   => $contact_ok,
				'invited_by'    => $invited_by,
				'created_at'    => $now,
				'updated_at'    => $now,
			)
		);

		Addresses::create( $user_id, 'billing', $billing, true );
		Addresses::create( $user_id, 'shipping', $shipping, true );

		foreach ( $questions as $q ) {
			$wpdb->insert(
				self::t()['answers'],
				array(
					'user_id'       => $user_id,
					'question_id'   => $q->id,
					'question_text' => self::question_text( $q ),
					'answer_text'   => sanitize_textarea_field( $answers[ $q->id ] ?? '' ),
					'created_at'    => $now,
					'updated_at'    => $now,
				)
			);
		}

		Audit::log( 'customer.registered', 'customer', $user_id, null, array( 'email' => $email, 'company' => $company ), null, $user_id );
		Events::emit( 'customer.created', array( 'user_id' => $user_id ) );

		$alert = Settings::get( 'staff_alert_email' );
		if ( $alert ) {
			Mailer::queue(
				'staff_new_registration',
				$alert,
				array(
					'name'      => $contact,
					'company'   => $company,
					'admin_url' => admin_url( 'admin.php?page=ssp-customers&view=' . $user_id ),
				),
				null,
				'customer',
				$user_id
			);
		}
		return $user_id;
	}

	public static function is_yes( $answer ) {
		return (bool) preg_match( '/^\s*(y|yes|i do|i agree|agree|true)\b/i', (string) $answer );
	}

	private static function unique_username( $email ) {
		$base = sanitize_user( strtolower( strstr( $email, '@', true ) ), true );
		$base = $base ? $base : 'customer';
		$name = $base;
		$i    = 1;
		while ( username_exists( $name ) ) {
			$name = $base . ( ++$i );
		}
		return $name;
	}

	public static function questions( $active_only = true ) {
		global $wpdb;
		$t = self::t()['questions'];
		return $wpdb->get_results( "SELECT * FROM {$t}" . ( $active_only ? ' WHERE active=1' : '' ) . ' ORDER BY sort ASC, id ASC' );
	}

	public static function question_text( $q ) {
		return str_replace( '{fb_group_link}', (string) Settings::get( 'fb_group_link' ), $q->text );
	}

	public static function answers( $user_id ) {
		global $wpdb;
		$t = self::t()['answers'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d ORDER BY id ASC", $user_id ) );
	}

	public static function update_answer( $answer_id, $text ) {
		global $wpdb;
		$t   = self::t()['answers'];
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $answer_id ) );
		if ( ! $row ) {
			return false;
		}
		$text = sanitize_textarea_field( $text );
		$wpdb->update( $t, array( 'answer_text' => $text, 'edited_by' => get_current_user_id(), 'updated_at' => Util::now() ), array( 'id' => $answer_id ) );
		Audit::log( 'customer.answer_edited', 'customer', $row->user_id, array( 'answer' => $row->answer_text ), array( 'answer' => $text ) );
		return true;
	}

	/**
	 * Change account status following the allowed transitions.
	 *
	 * @return true|\WP_Error
	 */
	public static function set_status( $user_id, $new_status, $reason = '', $notify = true ) {
		global $wpdb;
		$p = self::profile( $user_id );
		if ( ! $p ) {
			return new \WP_Error( 'not_found', 'Customer not found.' );
		}
		if ( ! isset( self::STATUSES[ $new_status ] ) ) {
			return new \WP_Error( 'status', 'Unknown status.' );
		}
		if ( ! in_array( $new_status, self::TRANSITIONS[ $p->status ] ?? array(), true ) ) {
			return new \WP_Error( 'transition', sprintf( 'Cannot change status from %s to %s.', self::STATUSES[ $p->status ], self::STATUSES[ $new_status ] ) );
		}
		$reason = sanitize_textarea_field( $reason );
		if ( in_array( $new_status, array( 'rejected', 'suspended' ), true ) && '' === trim( $reason ) ) {
			return new \WP_Error( 'reason', 'A reason is required to reject or suspend an account.' );
		}
		$now  = Util::now();
		$data = array(
			'status'        => $new_status,
			'status_reason' => $reason,
			'updated_at'    => $now,
		);
		if ( 'approved' === $new_status ) {
			$data['approved_by'] = get_current_user_id();
			$data['approved_at'] = $now;
		} elseif ( 'rejected' === $new_status ) {
			$data['rejected_at'] = $now;
		} elseif ( 'suspended' === $new_status ) {
			$data['suspended_at'] = $now;
		}
		$wpdb->update( self::t()['profiles'], $data, array( 'user_id' => $user_id ) );

		if ( 'suspended' === $new_status || 'rejected' === $new_status ) {
			\WP_Session_Tokens::get_instance( $user_id )->destroy_all();
		}

		Audit::log( 'customer.status_changed', 'customer', $user_id, array( 'status' => $p->status ), array( 'status' => $new_status ), $reason );
		Events::emit( 'customer.status_changed', array( 'user_id' => $user_id, 'status' => $new_status ) );

		if ( $notify ) {
			$tpl = array(
				'approved'  => 'account_approved',
				'rejected'  => 'account_rejected',
				'suspended' => 'account_suspended',
			)[ $new_status ] ?? null;
			if ( $tpl ) {
				Mailer::queue( $tpl, $p->email, array( 'name' => $p->contact_name, 'reason' => $reason ), $user_id, 'customer', $user_id );
			}
		}
		return true;
	}

	public static function update_profile( $user_id, array $in, $by_staff = false ) {
		global $wpdb;
		$p = self::profile( $user_id );
		if ( ! $p ) {
			return new \WP_Error( 'not_found', 'Customer not found.' );
		}
		$data = array(
			'contact_name' => sanitize_text_field( $in['contact_name'] ?? $p->contact_name ),
			'company_name' => sanitize_text_field( $in['company_name'] ?? $p->company_name ),
			'phone'        => sanitize_text_field( $in['phone'] ?? $p->phone ),
		);
		if ( isset( $in['email_consent'] ) || isset( $in['sms_consent'] ) || isset( $in['consents_present'] ) ) {
			$data['email_consent'] = empty( $in['email_consent'] ) ? 0 : 1;
			$data['sms_consent']   = empty( $in['sms_consent'] ) ? 0 : 1;
		}
		if ( $by_staff && isset( $in['staff_notes'] ) ) {
			$data['staff_notes'] = sanitize_textarea_field( $in['staff_notes'] );
		}
		if ( '' === $data['contact_name'] || '' === $data['company_name'] ) {
			return new \WP_Error( 'required', 'Contact name and company/store name are required.' );
		}
		$data['updated_at'] = Util::now();
		list( $b, $a ) = Audit::diff( (array) $p, $data );
		unset( $b['updated_at'], $a['updated_at'] );
		$wpdb->update( self::t()['profiles'], $data, array( 'user_id' => $user_id ) );
		wp_update_user( array( 'ID' => $user_id, 'display_name' => $data['contact_name'] ) );
		if ( $a ) {
			Audit::log( 'customer.profile_updated', 'customer', $user_id, $b, $a );
			Events::emit( 'customer.status_changed', array( 'user_id' => $user_id ) );
		}
		return true;
	}

	public static function touch_login( $user_login, $user ) {
		global $wpdb;
		$wpdb->update( self::t()['profiles'], array( 'last_login_at' => Util::now() ), array( 'user_id' => $user->ID ) );
	}

	/* ---------- Staff invitations (decision D-18) ---------- */

	public static function create_invite( $email, $name ) {
		$email = sanitize_email( $email );
		if ( ! is_email( $email ) ) {
			return new \WP_Error( 'email', 'Valid email required.' );
		}
		if ( email_exists( $email ) ) {
			return new \WP_Error( 'email', 'An account with this email already exists.' );
		}
		$token = wp_generate_password( 40, false );
		set_transient(
			'ssp_invite_' . hash( 'sha256', $token ),
			array(
				'email' => $email,
				'name'  => sanitize_text_field( $name ),
				'by'    => get_current_user_id(),
			),
			7 * DAY_IN_SECONDS
		);
		Mailer::queue( 'customer_invite', $email, array( 'name' => $name ? $name : 'there', 'invite_url' => home_url( '/register/?invite=' . rawurlencode( $token ) ) ) );
		Audit::log( 'customer.invited', 'invite', $email );
		return $token;
	}

	public static function get_invite( $token ) {
		$v = get_transient( 'ssp_invite_' . hash( 'sha256', (string) $token ) );
		return is_array( $v ) ? $v : null;
	}

	/* ---------- Staff listing ---------- */

	public static function search( array $args ) {
		global $wpdb;
		$t      = self::t()['profiles'];
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['status'] ) && isset( self::STATUSES[ $args['status'] ] ) ) {
			$where[]  = 'status=%s';
			$params[] = $args['status'];
		}
		if ( ! empty( $args['q'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['q'] ) . '%';
			$where[]  = '(company_name LIKE %s OR contact_name LIKE %s OR email LIKE %s OR phone LIKE %s)';
			$params   = array_merge( $params, array( $like, $like, $like, $like ) );
		}
		$order_map = array(
			'created'    => 'created_at DESC',
			'name'       => 'company_name ASC',
			'last_order' => 'last_order_at DESC',
		);
		$order    = $order_map[ $args['orderby'] ?? 'created' ] ?? 'created_at DESC';
		$per      = max( 1, (int) ( $args['per_page'] ?? 50 ) );
		$page     = max( 1, (int) ( $args['paged'] ?? 1 ) );
		$sql_w    = implode( ' AND ', $where );
		$count_q  = "SELECT COUNT(*) FROM {$t} WHERE {$sql_w}";
		$total    = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_q, $params ) ) : $wpdb->get_var( $count_q ) );
		$list_q   = "SELECT * FROM {$t} WHERE {$sql_w} ORDER BY {$order} LIMIT %d OFFSET %d";
		$rows     = $wpdb->get_results( $wpdb->prepare( $list_q, array_merge( $params, array( $per, ( $page - 1 ) * $per ) ) ) );
		return array( 'rows' => $rows, 'total' => $total );
	}

	public static function count_by_status() {
		global $wpdb;
		$t   = self::t()['profiles'];
		$out = array_fill_keys( array_keys( self::STATUSES ), 0 );
		foreach ( $wpdb->get_results( "SELECT status, COUNT(*) c FROM {$t} GROUP BY status" ) as $r ) {
			$out[ $r->status ] = (int) $r->c;
		}
		return $out;
	}

	public static function all_approved() {
		global $wpdb;
		$t = self::t()['profiles'];
		return $wpdb->get_results( "SELECT * FROM {$t} WHERE status='approved' ORDER BY company_name ASC" );
	}
}
