<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Events;
use SSP\Core\Installer;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Total and per-customer allocation enforcement.
 *
 * reserved_qty on a variant = sum of net quantities (ordered - cancelled) of all lines.
 * held_qty = quantity held for waitlist offers awaiting customer response.
 * Remaining total = total_allocation + total overrides - reserved - held (NULL total = unlimited).
 * Every change is written to the append-only allocation ledger.
 */
class Allocation {

	public static function t() {
		return Installer::tables();
	}

	public static function override_total( $variant_id ) {
		global $wpdb;
		$t = self::t()['overrides'];
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(qty),0) FROM {$t} WHERE variant_id=%d AND override_type='total'", $variant_id ) );
	}

	public static function override_customer( $variant_id, $user_id ) {
		global $wpdb;
		$t = self::t()['overrides'];
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(qty),0) FROM {$t} WHERE variant_id=%d AND user_id=%d AND override_type='per_customer'", $variant_id, $user_id ) );
	}

	public static function has_minimum_override( $variant_id, $user_id ) {
		global $wpdb;
		$t = self::t()['overrides'];
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE variant_id=%d AND user_id=%d AND override_type='minimum'", $variant_id, $user_id ) );
	}

	public static function customer_reserved( $variant_id, $user_id, $exclude_line_id = 0 ) {
		global $wpdb;
		$t = self::t()['lines'];
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COALESCE(SUM(qty_ordered - qty_cancelled),0) FROM {$t} WHERE variant_id=%d AND user_id=%d AND id<>%d",
				$variant_id,
				$user_id,
				(int) $exclude_line_id
			)
		);
	}

	/** Remaining total allocation, or null when unlimited. */
	public static function remaining_total( $variant ) {
		if ( null === $variant->total_allocation ) {
			return null;
		}
		return max( 0, (int) $variant->total_allocation + self::override_total( $variant->id ) - (int) $variant->reserved_qty - (int) $variant->held_qty );
	}

	/** Remaining per-customer allocation, or null when unlimited. */
	public static function remaining_customer( $variant, $user_id, $exclude_line_id = 0 ) {
		if ( null === $variant->per_customer_allocation ) {
			return null;
		}
		return max( 0, (int) $variant->per_customer_allocation + self::override_customer( $variant->id, $user_id ) - self::customer_reserved( $variant->id, $user_id, $exclude_line_id ) );
	}

	/** Max a customer may add right now (null = unlimited). */
	public static function max_addable( $variant, $user_id ) {
		$a = self::remaining_total( $variant );
		$b = self::remaining_customer( $variant, $user_id );
		if ( null === $a ) {
			return $b;
		}
		if ( null === $b ) {
			return $a;
		}
		return min( $a, $b );
	}

	public static function availability_label( $variant ) {
		$r = self::remaining_total( $variant );
		if ( null === $r ) {
			return array( 'ok', 'Available' );
		}
		if ( 0 === $r ) {
			return array( 'full', 'Fully allocated' );
		}
		$total = (int) $variant->total_allocation + self::override_total( $variant->id );
		if ( $total > 0 && $r / $total <= 0.15 ) {
			return array( 'low', 'Limited allocation' );
		}
		return array( 'ok', 'Available' );
	}

	/**
	 * Validate adding $delta units for a customer. Must be called after the variant row is locked
	 * (SELECT ... FOR UPDATE) when used in a write path.
	 *
	 * @param int $held_credit Units of held (waitlist-offer) quantity this customer may consume.
	 * @return true|\WP_Error
	 */
	public static function check( $variant, $user_id, $delta, $new_customer_total, $exclude_line_id = 0, $held_credit = 0 ) {
		if ( $delta <= 0 ) {
			return true;
		}
		$product = Catalog::get( $variant->product_id );
		$label   = $product ? $product->name . ( $variant->label ? ' - ' . $variant->label : '' ) : $variant->sku;
		$min     = (int) $variant->min_order_qty;
		if ( $new_customer_total > 0 && $new_customer_total < $min && ! self::has_minimum_override( $variant->id, $user_id ) ) {
			return new \WP_Error( 'minimum', sprintf( '%s: the minimum order quantity is %d.', $label, $min ), array( 'code' => 'minimum', 'min' => $min ) );
		}
		$rt = self::remaining_total( $variant );
		if ( null !== $rt && $delta > $rt + $held_credit ) {
			return new \WP_Error(
				'allocation_total',
				$rt + $held_credit > 0 ? sprintf( '%s: only %d more can be reserved. You can reduce your quantity or join the waitlist for the rest.', $label, $rt + $held_credit ) : sprintf( '%s is fully allocated. You can join the waitlist.', $label ),
				array( 'code' => 'allocation_total', 'remaining' => $rt + $held_credit, 'waitlist' => true )
			);
		}
		if ( null !== $variant->per_customer_allocation ) {
			$cap = (int) $variant->per_customer_allocation + self::override_customer( $variant->id, $user_id );
			if ( $new_customer_total > $cap ) {
				$can = max( 0, $cap - ( $new_customer_total - $delta ) );
				return new \WP_Error(
					'allocation_customer',
					sprintf( '%s: the limit is %d per customer. You can reserve %d more.', $label, $cap, $can ),
					array( 'code' => 'allocation_customer', 'remaining' => $can )
				);
			}
		}
		return true;
	}

	public static function lock_variants( array $variant_ids ) {
		global $wpdb;
		$ids = array_values( array_unique( array_map( 'intval', $variant_ids ) ) );
		sort( $ids );
		if ( ! $ids ) {
			return array();
		}
		$t    = self::t()['variants'];
		$in   = implode( ',', $ids );
		$rows = $wpdb->get_results( "SELECT * FROM {$t} WHERE id IN ({$in}) ORDER BY id ASC FOR UPDATE" );
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ (int) $r->id ] = $r;
		}
		return $out;
	}

	/** Adjust reserved_qty and write a ledger row. Call inside the caller's transaction. */
	public static function apply( $variant_id, $user_id, $line_id, $delta, $type, $reason = null ) {
		global $wpdb;
		if ( 0 === (int) $delta ) {
			return;
		}
		$t = self::t()['variants'];
		if ( $delta > 0 ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET reserved_qty = reserved_qty + %d WHERE id=%d", $delta, $variant_id ) );
		} else {
			$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET reserved_qty = GREATEST(0, CAST(reserved_qty AS SIGNED) - %d) WHERE id=%d", abs( $delta ), $variant_id ) );
		}
		$wpdb->insert(
			self::t()['ledger'],
			array(
				'variant_id'    => $variant_id,
				'user_id'       => $user_id,
				'order_line_id' => $line_id,
				'type'          => $type,
				'qty_delta'     => (int) $delta,
				'actor_id'      => get_current_user_id(),
				'reason'        => $reason,
				'created_at'    => Util::now(),
			)
		);
	}

	/**
	 * Staff override of allocation limits. Logged with staff user, time, quantity and reason.
	 *
	 * @param string $type total | per_customer | minimum
	 */
	public static function add_override( $variant_id, $user_id, $type, $qty, $reason, $line_id = null ) {
		global $wpdb;
		if ( ! current_user_can( 'ssp_override_allocation' ) ) {
			return new \WP_Error( 'forbidden', 'You are not allowed to override allocations.' );
		}
		$reason = sanitize_textarea_field( $reason );
		if ( '' === trim( $reason ) ) {
			return new \WP_Error( 'reason', 'A reason is required for every allocation override.' );
		}
		if ( ! in_array( $type, array( 'total', 'per_customer', 'minimum' ), true ) ) {
			return new \WP_Error( 'type', 'Invalid override type.' );
		}
		if ( in_array( $type, array( 'per_customer', 'minimum' ), true ) && ! $user_id ) {
			return new \WP_Error( 'customer', 'Choose the customer for this override.' );
		}
		$qty = (int) $qty;
		if ( 'minimum' !== $type && 0 === $qty ) {
			return new \WP_Error( 'qty', 'Enter the extra quantity to allow.' );
		}
		$wpdb->insert(
			self::t()['overrides'],
			array(
				'variant_id'    => $variant_id,
				'user_id'       => $user_id ? $user_id : null,
				'order_line_id' => $line_id,
				'override_type' => $type,
				'qty'           => $qty,
				'reason'        => $reason,
				'staff_id'      => get_current_user_id(),
				'created_at'    => Util::now(),
			)
		);
		$id = (int) $wpdb->insert_id;
		Audit::log( 'allocation.override', 'variant', $variant_id, null, array( 'type' => $type, 'qty' => $qty, 'customer' => $user_id ), $reason );
		Events::emit( 'variant.allocation_changed', array( 'variant_id' => $variant_id ) );
		if ( 'total' === $type && $qty > 0 ) {
			Waitlist::process_variant( $variant_id );
		}
		return $id;
	}

	public static function overrides( $variant_id ) {
		global $wpdb;
		$t = self::t()['overrides'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE variant_id=%d ORDER BY id DESC", $variant_id ) );
	}

	/** Recompute reserved_qty from lines (repair tool; also used by tests). */
	public static function reconcile( $variant_id ) {
		global $wpdb;
		$lt  = self::t()['lines'];
		$vt  = self::t()['variants'];
		$sum = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(qty_ordered - qty_cancelled),0) FROM {$lt} WHERE variant_id=%d", $variant_id ) );
		$wt  = self::t()['waitlist'];
		$held = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(offered_qty),0) FROM {$wt} WHERE variant_id=%d AND status='offered'", $variant_id ) );
		$wpdb->update( $vt, array( 'reserved_qty' => $sum, 'held_qty' => $held ), array( 'id' => $variant_id ) );
		return array( 'reserved' => $sum, 'held' => $held );
	}

	public static function summary( $variant ) {
		$rt = self::remaining_total( $variant );
		return array(
			'total'      => null === $variant->total_allocation ? null : (int) $variant->total_allocation + self::override_total( $variant->id ),
			'base_total' => $variant->total_allocation,
			'overrides'  => self::override_total( $variant->id ),
			'reserved'   => (int) $variant->reserved_qty,
			'held'       => (int) $variant->held_qty,
			'remaining'  => $rt,
		);
	}
}
