<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Events;
use SSP\Core\Installer;
use SSP\Core\Mailer;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Shipments (box or separate). A shipment permanently records exactly which order lines
 * and quantities were included, plus rate tier, charge, carrier, tracking and dates.
 */
class Shipments {

	const STATUSES = array(
		'preparing' => 'Preparing',
		'shipped'   => 'Shipped',
		'delivered' => 'Delivered',
		'cancelled' => 'Cancelled',
	);

	public static function t() {
		return Installer::tables();
	}

	public static function get( $id ) {
		global $wpdb;
		$t = self::t()['shipments'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
	}

	public static function lines( $shipment_id ) {
		global $wpdb;
		$sl = self::t()['shipment_lines'];
		$lt = self::t()['lines'];
		$ot = self::t()['orders'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT sl.qty AS ship_qty, l.*, o.order_number FROM {$sl} sl JOIN {$lt} l ON l.id=sl.order_line_id JOIN {$ot} o ON o.id=l.order_id WHERE sl.shipment_id=%d ORDER BY o.order_number, l.id", $shipment_id ) );
	}

	public static function for_user( $user_id ) {
		global $wpdb;
		$t = self::t()['shipments'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d ORDER BY id DESC", $user_id ) );
	}

	public static function for_line( $line_id ) {
		global $wpdb;
		$t  = self::t()['shipments'];
		$sl = self::t()['shipment_lines'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT s.*, sl.qty AS ship_qty FROM {$t} s JOIN {$sl} sl ON sl.shipment_id=s.id WHERE sl.order_line_id=%d AND s.status<>'cancelled' ORDER BY s.id DESC", $line_id ) );
	}

	public static function line_in_open_shipment( $line_id ) {
		global $wpdb;
		$t  = self::t()['shipments'];
		$sl = self::t()['shipment_lines'];
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} s JOIN {$sl} sl ON sl.shipment_id=s.id WHERE sl.order_line_id=%d AND s.status='preparing'", $line_id ) );
	}

	public static function tiers( $active_only = true ) {
		global $wpdb;
		$t = self::t()['rate_tiers'];
		return $wpdb->get_results( "SELECT * FROM {$t}" . ( $active_only ? ' WHERE active=1' : '' ) . ' ORDER BY priority ASC, id ASC' );
	}

	public static function tier( $id ) {
		global $wpdb;
		$t = self::t()['rate_tiers'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
	}

	public static function save_tier( array $in, $id = null ) {
		global $wpdb;
		$t = self::t()['rate_tiers'];
		$d = array(
			'name'       => sanitize_text_field( $in['name'] ?? '' ),
			'basis'      => ( $in['basis'] ?? '' ) === 'weight' ? 'weight' : 'size',
			'min_value'  => Util::dec_or_null( $in['min_value'] ?? null ),
			'max_value'  => Util::dec_or_null( $in['max_value'] ?? null ),
			'unit'       => sanitize_text_field( $in['unit'] ?? '' ),
			'charge_usd' => (float) Util::dec_or_null( $in['charge_usd'] ?? 0 ),
			'priority'   => (int) ( $in['priority'] ?? 0 ),
			'active'     => empty( $in['active'] ) ? 0 : 1,
			'confirmed'  => empty( $in['confirmed'] ) ? 0 : 1,
		);
		if ( '' === $d['name'] ) {
			return new \WP_Error( 'name', 'Tier name is required.' );
		}
		if ( $id ) {
			$before = self::tier( $id );
			$wpdb->update( $t, $d, array( 'id' => $id ) );
			Audit::log( 'rate_tier.updated', 'rate_tier', $id, (array) $before, $d );
			return (int) $id;
		}
		$d['created_at'] = Util::now();
		$wpdb->insert( $t, $d );
		Audit::log( 'rate_tier.created', 'rate_tier', $wpdb->insert_id, null, $d );
		return (int) $wpdb->insert_id;
	}

	/**
	 * Create a shipment for one customer.
	 *
	 * @param array $line_qty [line_id => qty]
	 * @param array $in       box_id, rate_tier_id, shipping_charge_usd, carrier, tracking_number, shipped_at (local), status, address, notes
	 */
	public static function create( $user_id, array $line_qty, array $in ) {
		global $wpdb;
		if ( ! $line_qty ) {
			return new \WP_Error( 'empty', 'Select at least one item to ship.' );
		}
		$status = ( $in['status'] ?? 'shipped' ) === 'preparing' ? 'preparing' : 'shipped';
		if ( 'shipped' === $status && '' === trim( (string) ( $in['tracking_number'] ?? '' ) ) && empty( $in['allow_no_tracking'] ) ) {
			return new \WP_Error( 'tracking', 'Enter a tracking number (or save as Preparing first).' );
		}
		$wpdb->query( 'START TRANSACTION' );
		try {
			$lt = self::t()['lines'];
			foreach ( $line_qty as $lid => $q ) {
				$l = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$lt} WHERE id=%d FOR UPDATE", $lid ) );
				if ( ! $l || (int) $l->user_id !== (int) $user_id ) {
					throw new \RuntimeException( 'Line does not belong to this customer.' );
				}
				$max = (int) $l->qty_available - (int) $l->qty_shipped;
				if ( $q < 1 || $q > $max ) {
					throw new \RuntimeException( sprintf( '%s: can ship at most %d (available and not yet shipped).', $l->name_snapshot, $max ) );
				}
			}
			$address = $in['address'] ?? null;
			if ( ! $address ) {
				$addr    = Addresses::default_for( $user_id, 'shipping' );
				$address = Addresses::snapshot( $addr );
			}
			$shipped_at = ! empty( $in['shipped_at'] ) ? Util::local_to_utc( str_replace( 'T', ' ', $in['shipped_at'] ) ) : Util::now();
			$wpdb->insert(
				self::t()['shipments'],
				array(
					'shipment_uid'        => Util::ulid(),
					'user_id'             => $user_id,
					'box_id'              => $in['box_id'] ?? null,
					'status'              => $status,
					'address_snapshot'    => $address ? wp_json_encode( $address ) : null,
					'rate_tier_id'        => ! empty( $in['rate_tier_id'] ) ? (int) $in['rate_tier_id'] : null,
					'shipping_charge_usd' => isset( $in['shipping_charge_usd'] ) && '' !== $in['shipping_charge_usd'] && null !== $in['shipping_charge_usd'] ? (float) $in['shipping_charge_usd'] : null,
					'carrier'             => sanitize_text_field( $in['carrier'] ?? '' ),
					'tracking_number'     => sanitize_text_field( $in['tracking_number'] ?? '' ),
					'shipped_at'          => 'shipped' === $status ? $shipped_at : null,
					'notes'               => sanitize_textarea_field( $in['notes'] ?? '' ),
					'created_by'          => get_current_user_id(),
					'created_at'          => Util::now(),
					'updated_at'          => Util::now(),
				)
			);
			$sid = (int) $wpdb->insert_id;
			foreach ( $line_qty as $lid => $q ) {
				$wpdb->insert( self::t()['shipment_lines'], array( 'shipment_id' => $sid, 'order_line_id' => $lid, 'qty' => (int) $q ) );
				if ( 'shipped' === $status ) {
					$wpdb->query( $wpdb->prepare( "UPDATE {$lt} SET qty_shipped = qty_shipped + %d, updated_at=%s WHERE id=%d", (int) $q, Util::now(), $lid ) );
				}
			}
			$wpdb->query( 'COMMIT' );
		} catch ( \Throwable $e ) {
			$wpdb->query( 'ROLLBACK' );
			return new \WP_Error( 'ship', $e->getMessage() );
		}
		foreach ( array_keys( $line_qty ) as $lid ) {
			Orders::refresh_line( $lid );
			Events::emit( 'line.changed', array( 'line_id' => $lid ) );
		}
		Audit::log( 'shipment.created', 'shipment', $sid, null, array( 'lines' => $line_qty, 'status' => $status, 'tracking' => $in['tracking_number'] ?? '' ) );
		Events::emit( 'shipment.changed', array( 'shipment_id' => $sid ) );
		if ( 'shipped' === $status ) {
			self::notify_shipped( $sid );
		}
		return $sid;
	}

	public static function notify_shipped( $sid ) {
		$s    = self::get( $sid );
		$prof = $s ? Customers::profile( (int) $s->user_id ) : null;
		if ( $prof ) {
			Mailer::queue( 'box_shipped', $prof->email, array( 'name' => $prof->contact_name, 'carrier' => $s->carrier ? $s->carrier : 'our carrier', 'tracking' => $s->tracking_number ), (int) $s->user_id, 'shipment', $sid );
		}
	}

	/** Staff updates tracking/carrier/status on an existing shipment. */
	public static function update( $sid, array $in ) {
		global $wpdb;
		$s = self::get( $sid );
		if ( ! $s ) {
			return new \WP_Error( 'not_found', 'Shipment not found.' );
		}
		$d = array(
			'carrier'             => sanitize_text_field( $in['carrier'] ?? $s->carrier ),
			'tracking_number'     => sanitize_text_field( $in['tracking_number'] ?? $s->tracking_number ),
			'rate_tier_id'        => isset( $in['rate_tier_id'] ) ? ( (int) $in['rate_tier_id'] ? (int) $in['rate_tier_id'] : null ) : $s->rate_tier_id,
			'shipping_charge_usd' => isset( $in['shipping_charge_usd'] ) ? Util::dec_or_null( $in['shipping_charge_usd'] ) : $s->shipping_charge_usd,
			'notes'               => sanitize_textarea_field( $in['notes'] ?? (string) $s->notes ),
			'updated_at'          => Util::now(),
		);
		$wpdb->update( self::t()['shipments'], $d, array( 'id' => $sid ) );
		list( $b, $a ) = Audit::diff( (array) $s, $d );
		unset( $b['updated_at'], $a['updated_at'] );
		if ( $a ) {
			Audit::log( 'shipment.updated', 'shipment', $sid, $b, $a );
		}
		if ( ! empty( $in['status'] ) && $in['status'] !== $s->status ) {
			$r = self::set_status( $sid, $in['status'] );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		Events::emit( 'shipment.changed', array( 'shipment_id' => $sid ) );
		return true;
	}

	public static function set_status( $sid, $status ) {
		global $wpdb;
		$s = self::get( $sid );
		if ( ! $s || ! isset( self::STATUSES[ $status ] ) ) {
			return new \WP_Error( 'state', 'Invalid shipment status.' );
		}
		$allowed = array(
			'preparing' => array( 'shipped', 'cancelled' ),
			'shipped'   => array( 'delivered' ),
			'delivered' => array(),
			'cancelled' => array(),
		);
		if ( ! in_array( $status, $allowed[ $s->status ], true ) ) {
			return new \WP_Error( 'state', sprintf( 'Cannot change shipment from %s to %s.', self::STATUSES[ $s->status ], self::STATUSES[ $status ] ) );
		}
		$d = array( 'status' => $status, 'updated_at' => Util::now() );
		if ( 'shipped' === $status ) {
			if ( '' === $s->tracking_number ) {
				return new \WP_Error( 'tracking', 'Add a tracking number before marking as shipped.' );
			}
			$d['shipped_at'] = Util::now();
			$lt = self::t()['lines'];
			foreach ( self::lines( $sid ) as $l ) {
				$wpdb->query( $wpdb->prepare( "UPDATE {$lt} SET qty_shipped = LEAST(qty_shipped + %d, qty_available) WHERE id=%d", (int) $l->ship_qty, $l->id ) );
				Orders::refresh_line( $l->id );
			}
		}
		if ( 'delivered' === $status ) {
			$d['delivered_at'] = Util::now();
		}
		$wpdb->update( self::t()['shipments'], $d, array( 'id' => $sid ) );
		Audit::log( 'shipment.status_changed', 'shipment', $sid, array( 'status' => $s->status ), array( 'status' => $status ) );
		Events::emit( 'shipment.changed', array( 'shipment_id' => $sid ) );
		if ( 'shipped' === $status ) {
			self::notify_shipped( $sid );
		}
		if ( 'delivered' === $status && $s->box_id ) {
			$box = Boxes::get( (int) $s->box_id );
			if ( $box && 'shipped' === $box->status ) {
				$wpdb->update( self::t()['boxes'], array( 'status' => 'delivered', 'delivered_at' => Util::now() ), array( 'id' => $box->id ) );
				Events::emit( 'box.status_changed', array( 'box_id' => (int) $box->id ) );
			}
		}
		return true;
	}

	/** Lines chosen "ship separately" that are available and not yet shipped. */
	public static function separate_queue() {
		global $wpdb;
		$lt = self::t()['lines'];
		$ot = self::t()['orders'];
		$pt = self::t()['profiles'];
		return $wpdb->get_results( "SELECT l.*, o.order_number, c.company_name, c.contact_name FROM {$lt} l JOIN {$ot} o ON o.id=l.order_id LEFT JOIN {$pt} c ON c.user_id=l.user_id WHERE l.fulfillment_choice='separate' AND l.qty_available > l.qty_shipped AND (l.qty_ordered - l.qty_cancelled) > 0 ORDER BY c.company_name, o.order_number LIMIT 500" );
	}

	public static function staff_list( array $args = array() ) {
		global $wpdb;
		$t  = self::t()['shipments'];
		$pt = self::t()['profiles'];
		$where = array( '1=1' );
		$params = array();
		if ( ! empty( $args['status'] ) && isset( self::STATUSES[ $args['status'] ] ) ) {
			$where[]  = 's.status=%s';
			$params[] = $args['status'];
		}
		if ( ! empty( $args['q'] ) ) {
			$like = '%' . $wpdb->esc_like( $args['q'] ) . '%';
			$where[] = '(c.company_name LIKE %s OR c.contact_name LIKE %s OR s.tracking_number LIKE %s)';
			$params = array_merge( $params, array( $like, $like, $like ) );
		}
		$w   = implode( ' AND ', $where );
		$sql = "SELECT s.*, c.company_name, c.contact_name FROM {$t} s LEFT JOIN {$pt} c ON c.user_id=s.user_id WHERE {$w} ORDER BY s.id DESC LIMIT 300";
		return $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );
	}
}
