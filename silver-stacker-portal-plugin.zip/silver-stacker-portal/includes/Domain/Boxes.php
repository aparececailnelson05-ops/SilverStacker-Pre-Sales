<?php
namespace SSP\Domain;

use SSP\Core\Audit;
use SSP\Core\Events;
use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\Mailer;
use SSP\Core\Settings;
use SSP\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Build A Box: a true shipping-consolidation box, not a cart.
 * A box holds order LINES (each keeps its original order, invoice and availability), possibly
 * from many pre-orders. Items can be invoiced while physically held. Shipping happens later as
 * one consolidated shipment.
 *
 * Lifecycle: open -> shipment_requested -> preparing -> shipped -> delivered -> closed
 * (shipment_requested -> open when a request is cancelled).
 */
class Boxes {

	const STATUSES = array(
		'open'               => 'Open',
		'shipment_requested' => 'Shipment requested',
		'preparing'          => 'Preparing',
		'shipped'            => 'Shipped',
		'delivered'          => 'Delivered',
		'closed'             => 'Closed',
	);

	const ACTIVE = array( 'open', 'shipment_requested', 'preparing' );

	public static function t() {
		return Installer::tables();
	}

	public static function get( $id ) {
		global $wpdb;
		$t = self::t()['boxes'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) );
	}

	public static function get_owned( $user_id, $box_uid ) {
		global $wpdb;
		$t = self::t()['boxes'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE box_uid=%s AND user_id=%d", $box_uid, $user_id ) );
	}

	public static function open_box( $user_id ) {
		global $wpdb;
		$t = self::t()['boxes'];
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND status='open' ORDER BY id DESC LIMIT 1", $user_id ) );
	}

	public static function active_boxes( $user_id ) {
		global $wpdb;
		$t = self::t()['boxes'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND status IN ('open','shipment_requested','preparing') ORDER BY id DESC", $user_id ) );
	}

	public static function history( $user_id ) {
		global $wpdb;
		$t = self::t()['boxes'];
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id=%d AND status IN ('shipped','delivered','closed') ORDER BY id DESC", $user_id ) );
	}

	public static function get_or_create_open( $user_id ) {
		global $wpdb;
		$box = self::open_box( $user_id );
		if ( $box ) {
			return $box;
		}
		$t     = self::t()['boxes'];
		$open  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE user_id=%d AND status='open'", $user_id ) );
		$max   = max( 1, (int) Settings::get( 'max_open_boxes' ) );
		if ( $open >= $max ) {
			return new \WP_Error( 'max_boxes', 'You already have the maximum number of open boxes.' );
		}
		$addr = Addresses::default_for( $user_id, 'shipping' );
		$now  = Util::now();
		$wpdb->insert(
			$t,
			array(
				'box_uid'          => Util::ulid(),
				'box_number'       => Util::next_sequence( 'box_number' ),
				'user_id'          => $user_id,
				'status'           => 'open',
				'address_id'       => $addr ? $addr->id : null,
				'address_snapshot' => $addr ? wp_json_encode( Addresses::snapshot( $addr ) ) : null,
				'last_digest_at'   => $now,
				'created_at'       => $now,
				'updated_at'       => $now,
			)
		);
		$id = (int) $wpdb->insert_id;
		Audit::log( 'box.created', 'box', $id, null, array( 'user_id' => $user_id ), null, 0 );
		return self::get( $id );
	}

	/** Active box (open / requested / preparing) holding this line, if any. */
	public static function line_box( $line_id ) {
		global $wpdb;
		$bi = self::t()['box_items'];
		$b  = self::t()['boxes'];
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT bi.box_id FROM {$bi} bi JOIN {$b} b ON b.id=bi.box_id WHERE bi.order_line_id=%d AND bi.removed_at IS NULL AND b.status IN ('open','shipment_requested','preparing') ORDER BY bi.id DESC LIMIT 1", $line_id ) );
	}

	/** @return true|\WP_Error */
	public static function add_line( $user_id, $line_id, $actor_id = null ) {
		global $wpdb;
		$line = Orders::line( $line_id );
		if ( ! $line || (int) $line->user_id !== (int) $user_id ) {
			return new \WP_Error( 'not_found', 'Order line not found.' );
		}
		if ( Orders::net( $line ) === 0 ) {
			return new \WP_Error( 'cancelled', 'Cancelled items cannot be added to a box.' );
		}
		if ( (int) $line->qty_shipped >= Orders::net( $line ) ) {
			return new \WP_Error( 'shipped', 'This item has already shipped.' );
		}
		if ( self::line_box( $line_id ) ) {
			$existing = self::get( self::line_box( $line_id ) );
			if ( $existing && 'open' === $existing->status ) {
				return true;
			}
			return new \WP_Error( 'in_box', 'This item is already in a box that is being shipped.' );
		}
		if ( Shipments::line_in_open_shipment( $line_id ) ) {
			return new \WP_Error( 'shipment', 'This item is already being prepared for a separate shipment.' );
		}
		$box = self::get_or_create_open( $user_id );
		if ( is_wp_error( $box ) ) {
			return $box;
		}
		$wpdb->insert(
			self::t()['box_items'],
			array(
				'box_id'        => $box->id,
				'order_line_id' => $line_id,
				'added_at'      => Util::now(),
				'added_by'      => $actor_id,
			)
		);
		if ( 'box' !== $line->fulfillment_choice ) {
			$wpdb->update( self::t()['lines'], array( 'fulfillment_choice' => 'box', 'updated_at' => Util::now() ), array( 'id' => $line_id ) );
		}
		Audit::log( 'box.line_added', 'box', $box->id, null, array( 'line_id' => $line_id, 'order_line' => $line->line_uid ), null, $actor_id );
		self::queue_digest( $box->id );
		return true;
	}

	public static function remove_line( $box_id, $line_id, $actor_id = null, $reason = '' ) {
		global $wpdb;
		$box = self::get( $box_id );
		if ( ! $box ) {
			return new \WP_Error( 'not_found', 'Box not found.' );
		}
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t()['box_items'] . ' SET removed_at=%s, removed_by=%d WHERE box_id=%d AND order_line_id=%d AND removed_at IS NULL', Util::now(), (int) $actor_id, $box_id, $line_id ) );
		$wpdb->update( self::t()['lines'], array( 'fulfillment_choice' => 'decide_later', 'updated_at' => Util::now() ), array( 'id' => $line_id, 'fulfillment_choice' => 'box' ) );
		Audit::log( 'box.line_removed', 'box', $box_id, array( 'line_id' => $line_id ), null, $reason ? $reason : null, $actor_id );
		self::queue_digest( $box_id );
		return true;
	}

	public static function remove_line_everywhere( $line_id, $actor_id = null, $reason = '' ) {
		$box = self::line_box( $line_id );
		if ( $box ) {
			self::remove_line( $box, $line_id, $actor_id, $reason );
		}
	}

	/** Staff: move a line from its current box to another box of the same customer. */
	public static function move_line( $line_id, $to_box_id, $reason = '' ) {
		global $wpdb;
		$line = Orders::line( $line_id );
		$to   = self::get( $to_box_id );
		if ( ! $line || ! $to || (int) $to->user_id !== (int) $line->user_id ) {
			return new \WP_Error( 'mismatch', 'Lines can only move between boxes of the same customer.' );
		}
		if ( ! in_array( $to->status, array( 'open', 'shipment_requested', 'preparing' ), true ) ) {
			return new \WP_Error( 'state', 'Target box is not active.' );
		}
		$from = self::line_box( $line_id );
		if ( $from === (int) $to_box_id ) {
			return true;
		}
		if ( $from ) {
			self::remove_line( $from, $line_id, get_current_user_id(), $reason );
		}
		$wpdb->insert(
			self::t()['box_items'],
			array(
				'box_id'        => $to->id,
				'order_line_id' => $line_id,
				'added_at'      => Util::now(),
				'added_by'      => get_current_user_id(),
			)
		);
		$wpdb->update( self::t()['lines'], array( 'fulfillment_choice' => 'box' ), array( 'id' => $line_id ) );
		Audit::log( 'box.line_moved', 'box', $to->id, array( 'from_box' => $from ), array( 'line_id' => $line_id ), $reason ? $reason : null );
		self::queue_digest( $to->id );
		return true;
	}

	/** Items with joined line/order/product data, original order references preserved. */
	public static function items( $box_id, $include_removed = false ) {
		global $wpdb;
		$bi = self::t()['box_items'];
		$lt = self::t()['lines'];
		$ot = self::t()['orders'];
		$rm = $include_removed ? '' : ' AND bi.removed_at IS NULL';
		return $wpdb->get_results( $wpdb->prepare( "SELECT bi.id AS box_item_id, bi.added_at, bi.removed_at, l.*, o.order_number, o.submitted_at FROM {$bi} bi JOIN {$lt} l ON l.id=bi.order_line_id JOIN {$ot} o ON o.id=l.order_id WHERE bi.box_id=%d{$rm} ORDER BY o.submitted_at ASC, l.id ASC", $box_id ) );
	}

	public static function totals( $box_id ) {
		$items = self::items( $box_id );
		$units = 0;
		$avail = 0;
		$value = 0;
		$weight = 0;
		foreach ( $items as $it ) {
			$remaining = Orders::net( $it ) - (int) $it->qty_shipped;
			$units    += $remaining;
			$avail    += max( 0, (int) $it->qty_available - (int) $it->qty_shipped );
			$value    += $remaining * (float) $it->unit_price_usd;
			$v         = Catalog::variant( $it->variant_id );
			if ( $v && $v->weight_oz ) {
				$weight += $remaining * (float) $v->weight_oz;
			}
		}
		return array(
			'lines'      => count( $items ),
			'units'      => $units,
			'available'  => $avail,
			'unavailable'=> $units - $avail,
			'value'      => $value,
			'weight_oz'  => $weight,
		);
	}

	public static function address( $box ) {
		return $box && $box->address_snapshot ? json_decode( $box->address_snapshot, true ) : null;
	}

	/* ---------------------------------------------------------------- */
	/* Customer actions                                                 */
	/* ---------------------------------------------------------------- */

	/**
	 * Request shipment of the box (customer with confirmation, or staff).
	 *
	 * @param string $mode ship_available | wait_all (only when setting is customer_choice)
	 */
	public static function request_shipment( $box_id, $actor_id, $mode = 'ship_available' ) {
		global $wpdb;
		$box = self::get( $box_id );
		if ( ! $box || 'open' !== $box->status ) {
			return new \WP_Error( 'state', 'Only an open box can be requested for shipment.' );
		}
		$tot = self::totals( $box_id );
		if ( ! $tot['lines'] ) {
			return new \WP_Error( 'empty', 'Your box is empty.' );
		}
		$setting = Settings::get( 'ship_unavailable_mode' );
		if ( 'customer_choice' !== $setting ) {
			$mode = 'wait_all' === $setting ? 'wait_all' : 'ship_available';
		}
		$mode = 'wait_all' === $mode ? 'wait_all' : 'ship_available';
		if ( 0 === $tot['available'] && 'ship_available' === $mode ) {
			return new \WP_Error( 'none_available', 'None of the items in your box have arrived yet. You can request shipment once at least one item is available, or choose to ship when everything has arrived.' );
		}
		if ( ! self::address( $box ) ) {
			return new \WP_Error( 'address', 'Please add a default shipping address first.' );
		}
		$wpdb->update(
			self::t()['boxes'],
			array(
				'status'                => 'shipment_requested',
				'ship_mode'             => $mode,
				'shipment_requested_at' => Util::now(),
				'shipment_requested_by' => $actor_id,
				'updated_at'            => Util::now(),
			),
			array( 'id' => $box_id )
		);
		// Items with nothing available move to a new open box so the customer can keep accumulating.
		if ( 'ship_available' === $mode && $tot['unavailable'] > 0 ) {
			$moving = array();
			foreach ( self::items( $box_id ) as $it ) {
				if ( (int) $it->qty_available <= (int) $it->qty_shipped ) {
					$moving[] = (int) $it->id;
				}
			}
			if ( $moving ) {
				$new = self::get_or_create_open( (int) $box->user_id );
				if ( ! is_wp_error( $new ) ) {
					foreach ( $moving as $lid ) {
						$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t()['box_items'] . ' SET removed_at=%s, removed_by=%d WHERE box_id=%d AND order_line_id=%d AND removed_at IS NULL', Util::now(), (int) $actor_id, $box_id, $lid ) );
						$wpdb->insert( self::t()['box_items'], array( 'box_id' => $new->id, 'order_line_id' => $lid, 'added_at' => Util::now(), 'added_by' => $actor_id ) );
					}
					Audit::log( 'box.items_carried', 'box', $new->id, null, array( 'from_box' => $box_id, 'lines' => $moving ), 'Not yet available at shipment request', $actor_id );
				}
			}
		}
		Audit::log( 'box.shipment_requested', 'box', $box_id, array( 'status' => 'open' ), array( 'status' => 'shipment_requested', 'mode' => $mode ), null, $actor_id );
		Events::emit( 'box.status_changed', array( 'box_id' => $box_id ) );
		return true;
	}

	/** Undo a shipment request before staff starts preparing. Any newer open box is merged back. */
	public static function cancel_request( $box_id, $actor_id ) {
		global $wpdb;
		$box = self::get( $box_id );
		if ( ! $box || 'shipment_requested' !== $box->status ) {
			return new \WP_Error( 'state', 'This shipment request can no longer be cancelled.' );
		}
		$other = self::open_box( (int) $box->user_id );
		if ( $other && (int) $other->id !== (int) $box_id ) {
			foreach ( self::items( $other->id ) as $it ) {
				$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t()['box_items'] . ' SET removed_at=%s, removed_by=%d WHERE box_id=%d AND order_line_id=%d AND removed_at IS NULL', Util::now(), (int) $actor_id, $other->id, $it->id ) );
				$wpdb->insert( self::t()['box_items'], array( 'box_id' => $box_id, 'order_line_id' => $it->id, 'added_at' => Util::now(), 'added_by' => $actor_id ) );
			}
			$wpdb->update( self::t()['boxes'], array( 'status' => 'closed', 'closed_at' => Util::now(), 'updated_at' => Util::now() ), array( 'id' => $other->id ) );
			Audit::log( 'box.merged', 'box', $box_id, null, array( 'merged_box' => (int) $other->id ), null, $actor_id );
		}
		$wpdb->update( self::t()['boxes'], array( 'status' => 'open', 'ship_mode' => null, 'shipment_requested_at' => null, 'updated_at' => Util::now() ), array( 'id' => $box_id ) );
		Audit::log( 'box.request_cancelled', 'box', $box_id, array( 'status' => 'shipment_requested' ), array( 'status' => 'open' ), null, $actor_id );
		Events::emit( 'box.status_changed', array( 'box_id' => $box_id ) );
		return true;
	}

	public static function can_change_address( $box, $is_staff = false ) {
		if ( $is_staff ) {
			return in_array( $box->status, self::ACTIVE, true );
		}
		$rule = Settings::get( 'address_change_until' );
		if ( 'never' === $rule ) {
			return false;
		}
		if ( 'shipment_requested' === $rule ) {
			return 'open' === $box->status;
		}
		return in_array( $box->status, array( 'open', 'shipment_requested' ), true );
	}

	public static function set_address( $box_id, $address_id, $actor_id, $is_staff = false ) {
		global $wpdb;
		$box = self::get( $box_id );
		if ( ! $box ) {
			return new \WP_Error( 'not_found', 'Box not found.' );
		}
		if ( ! self::can_change_address( $box, $is_staff ) ) {
			return new \WP_Error( 'locked', 'The address can no longer be changed for this box.' );
		}
		$addr = Addresses::get_owned( (int) $box->user_id, $address_id );
		if ( ! $addr || 'shipping' !== $addr->type ) {
			return new \WP_Error( 'address', 'Address not found.' );
		}
		$old = self::address( $box );
		$wpdb->update( self::t()['boxes'], array( 'address_id' => $addr->id, 'address_snapshot' => wp_json_encode( Addresses::snapshot( $addr ) ), 'updated_at' => Util::now() ), array( 'id' => $box_id ) );
		Audit::log( 'box.address_changed', 'box', $box_id, $old, Addresses::snapshot( $addr ), null, $actor_id );
		Events::emit( 'box.changed', array( 'box_id' => $box_id ) );
		return true;
	}

	/** Default address changed: update open boxes that still follow the default. */
	public static function sync_default_address( $user_id ) {
		$addr = Addresses::default_for( $user_id, 'shipping' );
		if ( ! $addr ) {
			return;
		}
		foreach ( self::active_boxes( $user_id ) as $b ) {
			if ( self::can_change_address( $b, false ) ) {
				global $wpdb;
				$wpdb->update( self::t()['boxes'], array( 'address_id' => $addr->id, 'address_snapshot' => wp_json_encode( Addresses::snapshot( $addr ) ), 'updated_at' => Util::now() ), array( 'id' => $b->id ) );
				Events::emit( 'box.changed', array( 'box_id' => (int) $b->id ) );
			}
		}
	}

	/* ---------------------------------------------------------------- */
	/* Staff processing                                                 */
	/* ---------------------------------------------------------------- */

	public static function set_preparing( $box_id ) {
		global $wpdb;
		$box = self::get( $box_id );
		if ( ! $box || ! in_array( $box->status, array( 'open', 'shipment_requested' ), true ) ) {
			return new \WP_Error( 'state', 'Box must be open or requested to start preparing.' );
		}
		$wpdb->update( self::t()['boxes'], array( 'status' => 'preparing', 'preparing_at' => Util::now(), 'updated_at' => Util::now() ), array( 'id' => $box_id ) );
		Audit::log( 'box.preparing', 'box', $box_id, array( 'status' => $box->status ), array( 'status' => 'preparing' ) );
		Events::emit( 'box.status_changed', array( 'box_id' => $box_id ) );
		return true;
	}

	public static function set_rate( $box_id, $tier_id, $charge ) {
		global $wpdb;
		$box = self::get( $box_id );
		if ( ! $box ) {
			return new \WP_Error( 'not_found', 'Box not found.' );
		}
		$tier   = $tier_id ? Shipments::tier( $tier_id ) : null;
		$charge = '' === $charge || null === $charge ? ( $tier ? (float) $tier->charge_usd : null ) : (float) $charge;
		$wpdb->update( self::t()['boxes'], array( 'rate_tier_id' => $tier ? $tier->id : null, 'shipping_charge_usd' => $charge, 'updated_at' => Util::now() ), array( 'id' => $box_id ) );
		Audit::log( 'box.rate_set', 'box', $box_id, array( 'tier' => $box->rate_tier_id, 'charge' => $box->shipping_charge_usd ), array( 'tier' => $tier ? $tier->id : null, 'charge' => $charge ) );
		Events::emit( 'box.changed', array( 'box_id' => $box_id ) );
		return true;
	}

	/**
	 * Ship the box: creates a shipment containing every available, unshipped unit in the box.
	 * Remaining (not yet available) quantities are carried into an open box.
	 */
	public static function ship( $box_id, array $in ) {
		global $wpdb;
		$box = self::get( $box_id );
		if ( ! $box || ! in_array( $box->status, array( 'shipment_requested', 'preparing', 'open' ), true ) ) {
			return new \WP_Error( 'state', 'This box cannot be shipped in its current status.' );
		}
		$line_qty = array();
		foreach ( self::items( $box_id ) as $it ) {
			$q = (int) $it->qty_available - (int) $it->qty_shipped;
			if ( $q > 0 ) {
				$line_qty[ (int) $it->id ] = $q;
			}
		}
		if ( ! $line_qty ) {
			return new \WP_Error( 'empty', 'No available items in this box to ship.' );
		}
		$tier_id = ! empty( $in['rate_tier_id'] ) ? (int) $in['rate_tier_id'] : ( $box->rate_tier_id ? (int) $box->rate_tier_id : null );
		$charge  = isset( $in['shipping_charge_usd'] ) && '' !== $in['shipping_charge_usd'] ? (float) $in['shipping_charge_usd'] : $box->shipping_charge_usd;
		$shipment_id = Shipments::create(
			(int) $box->user_id,
			$line_qty,
			array_merge(
				$in,
				array(
					'box_id'              => $box_id,
					'rate_tier_id'        => $tier_id,
					'shipping_charge_usd' => $charge,
					'address'             => self::address( $box ),
				)
			)
		);
		if ( is_wp_error( $shipment_id ) ) {
			return $shipment_id;
		}
		$wpdb->update(
			self::t()['boxes'],
			array(
				'status'              => 'shipped',
				'shipment_id'         => $shipment_id,
				'rate_tier_id'        => $tier_id,
				'shipping_charge_usd' => $charge,
				'shipped_at'          => Util::now(),
				'updated_at'          => Util::now(),
			),
			array( 'id' => $box_id )
		);
		// Carry remainders forward.
		$carry = array();
		foreach ( self::items( $box_id ) as $it ) {
			if ( Orders::net( $it ) > (int) $it->qty_shipped ) {
				$carry[] = (int) $it->id;
			}
		}
		if ( $carry ) {
			$new = self::get_or_create_open( (int) $box->user_id );
			if ( ! is_wp_error( $new ) ) {
				foreach ( $carry as $lid ) {
					$wpdb->insert( self::t()['box_items'], array( 'box_id' => $new->id, 'order_line_id' => $lid, 'added_at' => Util::now(), 'added_by' => get_current_user_id() ) );
				}
				Audit::log( 'box.items_carried', 'box', $new->id, null, array( 'from_box' => $box_id, 'lines' => $carry ), 'Remaining quantity after shipment' );
			}
		}
		Audit::log( 'box.shipped', 'box', $box_id, array( 'status' => $box->status ), array( 'status' => 'shipped', 'shipment_id' => $shipment_id ) );
		Events::emit( 'box.status_changed', array( 'box_id' => $box_id ) );
		return $shipment_id;
	}

	public static function set_delivered( $box_id ) {
		global $wpdb;
		$box = self::get( $box_id );
		if ( ! $box || 'shipped' !== $box->status ) {
			return new \WP_Error( 'state', 'Only shipped boxes can be marked delivered.' );
		}
		$wpdb->update( self::t()['boxes'], array( 'status' => 'delivered', 'delivered_at' => Util::now(), 'updated_at' => Util::now() ), array( 'id' => $box_id ) );
		if ( $box->shipment_id ) {
			Shipments::set_status( (int) $box->shipment_id, 'delivered' );
		}
		Audit::log( 'box.delivered', 'box', $box_id, array( 'status' => 'shipped' ), array( 'status' => 'delivered' ) );
		Events::emit( 'box.status_changed', array( 'box_id' => $box_id ) );
		return true;
	}

	public static function close( $box_id, $reason = '' ) {
		global $wpdb;
		$box = self::get( $box_id );
		if ( ! $box ) {
			return new \WP_Error( 'not_found', 'Box not found.' );
		}
		if ( 'delivered' !== $box->status && ! ( 'open' === $box->status && 0 === self::totals( $box_id )['lines'] ) ) {
			return new \WP_Error( 'state', 'Only delivered boxes (or empty open boxes) can be closed.' );
		}
		$wpdb->update( self::t()['boxes'], array( 'status' => 'closed', 'closed_at' => Util::now(), 'updated_at' => Util::now() ), array( 'id' => $box_id ) );
		Audit::log( 'box.closed', 'box', $box_id, array( 'status' => $box->status ), array( 'status' => 'closed' ), $reason ? $reason : null );
		Events::emit( 'box.status_changed', array( 'box_id' => $box_id ) );
		return true;
	}

	public static function auto_close_delivered() {
		global $wpdb;
		$days = (int) Settings::get( 'box_auto_close_days' );
		if ( $days <= 0 ) {
			return;
		}
		$t   = self::t()['boxes'];
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t} WHERE status='delivered' AND delivered_at < %s", Util::now( -$days * DAY_IN_SECONDS ) ) );
		foreach ( $ids as $id ) {
			$wpdb->update( $t, array( 'status' => 'closed', 'closed_at' => Util::now() ), array( 'id' => $id ) );
			Audit::log( 'box.closed', 'box', $id, array( 'status' => 'delivered' ), array( 'status' => 'closed' ), 'Auto-closed after delivery', 0 );
		}
	}

	/* ---------------------------------------------------------------- */
	/* Change digest email (debounced)                                  */
	/* ---------------------------------------------------------------- */

	public static function queue_digest( $box_id ) {
		$minutes = max( 0, (int) Settings::get( 'box_digest_minutes' ) );
		Jobs::enqueue( 'email', 'box.digest', 'box', $box_id, array( 'box_id' => (int) $box_id ), 'box_digest:' . $box_id . ':' . floor( time() / max( 60, $minutes * 60 ) ), $minutes * 60 );
		Events::emit( 'box.changed', array( 'box_id' => (int) $box_id ) );
	}

	public static function digest_job( array $p ) {
		global $wpdb;
		$box = self::get( (int) $p['box_id'] );
		if ( ! $box ) {
			return true;
		}
		$since = $box->last_digest_at ? $box->last_digest_at : $box->created_at;
		$bi    = self::t()['box_items'];
		$lt    = self::t()['lines'];
		$added = $wpdb->get_results( $wpdb->prepare( "SELECT l.name_snapshot, l.qty_ordered, l.qty_cancelled FROM {$bi} bi JOIN {$lt} l ON l.id=bi.order_line_id WHERE bi.box_id=%d AND bi.added_at > %s", $box->id, $since ) );
		$removed = $wpdb->get_results( $wpdb->prepare( "SELECT l.name_snapshot FROM {$bi} bi JOIN {$lt} l ON l.id=bi.order_line_id WHERE bi.box_id=%d AND bi.removed_at > %s", $box->id, $since ) );
		$wpdb->update( self::t()['boxes'], array( 'last_digest_at' => Util::now() ), array( 'id' => $box->id ) );
		if ( ! $added && ! $removed ) {
			return true;
		}
		$html = '';
		if ( $added ) {
			$html .= '<p><strong>Added:</strong></p><ul>';
			foreach ( $added as $a ) {
				$html .= '<li>' . esc_html( $a->name_snapshot ) . ' &times; ' . (int) ( $a->qty_ordered - $a->qty_cancelled ) . '</li>';
			}
			$html .= '</ul>';
		}
		if ( $removed ) {
			$html .= '<p><strong>Removed:</strong></p><ul>';
			foreach ( $removed as $r ) {
				$html .= '<li>' . esc_html( $r->name_snapshot ) . '</li>';
			}
			$html .= '</ul>';
		}
		$prof = Customers::profile( (int) $box->user_id );
		if ( $prof ) {
			Mailer::queue( 'box_changed', $prof->email, array( 'name' => $prof->contact_name, 'box_number' => $box->box_number, 'changes' => $html ), (int) $box->user_id, 'box', $box->id );
		}
		return true;
	}

	/* ---------------------------------------------------------------- */
	/* Staff list                                                       */
	/* ---------------------------------------------------------------- */

	public static function staff_list( array $args ) {
		global $wpdb;
		$t      = self::t()['boxes'];
		$pt     = self::t()['profiles'];
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['status'] ) ) {
			if ( 'active' === $args['status'] ) {
				$where[] = "b.status IN ('open','shipment_requested','preparing')";
			} elseif ( isset( self::STATUSES[ $args['status'] ] ) ) {
				$where[]  = 'b.status=%s';
				$params[] = $args['status'];
			}
		}
		if ( ! empty( $args['q'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['q'] ) . '%';
			$where[]  = '(c.company_name LIKE %s OR c.contact_name LIKE %s OR b.box_number=%d)';
			$params   = array_merge( $params, array( $like, $like, (int) $args['q'] ) );
		}
		if ( ! empty( $args['user_id'] ) ) {
			$where[]  = 'b.user_id=%d';
			$params[] = (int) $args['user_id'];
		}
		$w   = implode( ' AND ', $where );
		$sql = "SELECT b.*, c.company_name, c.contact_name FROM {$t} b LEFT JOIN {$pt} c ON c.user_id=b.user_id WHERE {$w} ORDER BY FIELD(b.status,'shipment_requested','preparing','open','shipped','delivered','closed'), b.updated_at DESC LIMIT 300";
		return $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );
	}
}
