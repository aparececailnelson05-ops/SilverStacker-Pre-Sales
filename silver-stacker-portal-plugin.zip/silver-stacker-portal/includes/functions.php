<?php
/**
 * Template helper functions (thin wrappers; all business logic lives in SSP\Domain).
 */

defined( 'ABSPATH' ) || exit;

/** Echo escaped text. */
function ssp_e( $text ) {
	echo esc_html( (string) $text );
}

function ssp_money( $amount ) {
	return \SSP\Core\Util::money( $amount );
}

/** Hidden nonce + action fields for portal forms. */
function ssp_form_fields( $action ) {
	echo '<input type="hidden" name="ssp_action" value="' . esc_attr( $action ) . '">';
	wp_nonce_field( 'ssp_' . $action, '_ssp_nonce' );
}

function ssp_url( $path = '' ) {
	return home_url( '/portal/' . ltrim( $path, '/' ) );
}

function ssp_badge( $text, $kind = 'neutral' ) {
	return '<span class="ssp-badge ssp-badge--' . esc_attr( $kind ) . '">' . esc_html( $text ) . '</span>';
}

function ssp_status_kind( $status ) {
	$map = array(
		'reserved'            => 'info',
		'waitlisted'          => 'warn',
		'locked'              => 'neutral',
		'partially_available' => 'warn',
		'available'           => 'ok',
		'partially_invoiced'  => 'info',
		'invoiced'            => 'brand',
		'fulfilled'           => 'ok',
		'cancelled'           => 'muted',
		'submitted'           => 'info',
		'open'                => 'neutral',
		'fully_available'     => 'ok',
		'fully_invoiced'      => 'brand',
		'completed'           => 'ok',
		'shipment_requested'  => 'warn',
		'preparing'           => 'info',
		'shipped'             => 'brand',
		'delivered'           => 'ok',
		'closed'              => 'muted',
		'synced'              => 'info',
		'paid'                => 'ok',
		'partially_paid'      => 'warn',
		'overdue'             => 'danger',
		'error'               => 'danger',
		'queued'              => 'neutral',
		'creating'            => 'neutral',
		'voided'              => 'muted',
		'pending'             => 'warn',
		'approved'            => 'ok',
		'rejected'            => 'danger',
		'suspended'           => 'danger',
		'presale'             => 'brand',
		'in_stock'            => 'ok',
		'presale_ended'       => 'neutral',
		'archived'            => 'muted',
		'draft'               => 'muted',
		'waiting'             => 'warn',
		'offered'             => 'ok',
		'converted'           => 'brand',
		'expired'             => 'muted',
	);
	return $map[ $status ] ?? 'neutral';
}

/** Inline SVG icons (decorative; aria-hidden). */
function ssp_icon( $name ) {
	$paths = array(
		'search'   => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
		'cart'     => '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.5 12h11L21 7H6.2"/>',
		'box'      => '<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/>',
		'orders'   => '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',
		'invoice'  => '<path d="M6 2h9l4 4v16H6z"/><path d="M14 2v5h5M9 13h6M9 17h6M9 9h2"/>',
		'home'     => '<path d="M3 11 12 3l9 8"/><path d="M5 10v10h14V10"/>',
		'user'     => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 5-6 8-6s6.5 2 8 6"/>',
		'list'     => '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
		'clock'    => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		'truck'    => '<path d="M2 6h11v10H2zM13 10h4l4 4v2h-8z"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
		'pin'      => '<path d="M12 22s7-6.5 7-12a7 7 0 0 0-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/>',
		'archive'  => '<rect x="3" y="4" width="18" height="4" rx="1"/><path d="M5 8v12h14V8M10 12h4"/>',
		'logout'   => '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/>',
		'gear'     => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
		'chart'    => '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
		'users'    => '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c1-3.5 4-5 7-5s6 1.5 7 5"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 15c2 .7 3.3 2.4 4 5"/>',
		'heart'    => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
		'check'    => '<path d="M20 6 9 17l-5-5"/>',
		'stack'    => '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v4c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 10v4c0 1.7 3.6 3 8 3s8-1.3 8-3v-4M4 14v4c0 1.7 3.6 3 8 3s8-1.3 8-3v-4"/>',
	);
	$p = $paths[ $name ] ?? '';
	return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $p . '</svg>';
}

/** Countdown markup (server time drives validity; this is display only). */
function ssp_countdown( $closing_utc, $large = false ) {
	if ( ! $closing_utc ) {
		return '';
	}
	$ended = \SSP\Core\Util::ts( $closing_utc ) <= time();
	return '<span class="ssp-countdown' . ( $large ? ' ssp-countdown--lg' : '' ) . ( $ended ? ' is-ended' : '' ) . '" data-countdown="' . esc_attr( \SSP\Core\Util::iso_utc( $closing_utc ) ) . '" title="Closes ' . esc_attr( \SSP\Core\Util::fmt_dt( $closing_utc ) ) . '">'
		. ssp_icon( 'clock' ) . ( $ended ? '' : '<span>Pre-Sale Ends In:</span> ' ) . '<span data-countdown-value>' . ( $ended ? 'Pre-Sale Ended' : '&nbsp;' ) . '</span></span>';
}

function ssp_eta( $product, $large = false ) {
	$label = \SSP\Domain\Catalog::eta_label( $product );
	if ( '' === $label ) {
		return '';
	}
	return '<span class="ssp-eta' . ( $large ? ' ssp-eta--lg' : '' ) . '">' . ssp_icon( 'truck' ) . ' Estimated Arrival: <b>' . esc_html( $label ) . '</b></span>';
}

function ssp_pagination( $total, $per, $page, $base_args, $base_url ) {
	$pages = (int) ceil( $total / max( 1, $per ) );
	if ( $pages <= 1 ) {
		return '';
	}
	$h = '<nav class="ssp-pagination" aria-label="Pagination">';
	$window = array_unique( array_filter( array( 1, $page - 2, $page - 1, $page, $page + 1, $page + 2, $pages ), fn( $p ) => $p >= 1 && $p <= $pages ) );
	sort( $window );
	$prev = 0;
	foreach ( $window as $p ) {
		if ( $prev && $p - $prev > 1 ) {
			$h .= '<span aria-hidden="true">&hellip;</span>';
		}
		$url = add_query_arg( array_merge( $base_args, array( 'pg' => $p ) ), $base_url );
		$h  .= $p === $page ? '<span class="is-current" aria-current="page">' . $p . '</span>' : '<a href="' . esc_url( $url ) . '">' . $p . '</a>';
		$prev = $p;
	}
	return $h . '</nav>';
}
