<?php
namespace SSP;

use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\Roles;
use SSP\Core\Security;
use SSP\Core\Settings;
use SSP\Domain\Boxes;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Waitlist;
use SSP\Integrations\Listeners;
use SSP\Integrations\Qbo;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	public static function boot() {
		Installer::maybe_upgrade();
		Security::init();
		Listeners::init();
		Portal\Router::init();
		Rest::init();
		if ( is_admin() ) {
			Admin\Admin::init();
		}

		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		add_action( 'ssp_cron_minutely', array( __CLASS__, 'minutely' ) );
		add_action( 'ssp_cron_quarter_hour', array( __CLASS__, 'quarter_hour' ) );
		add_action( 'wp_login', array( Customers::class, 'touch_login' ), 10, 2 );
		add_filter( 'user_has_cap', array( Roles::class, 'filter_caps' ), 10, 4 );
		add_filter( 'wp_mail_from_name', array( __CLASS__, 'mail_from_name' ) );
		add_filter( 'wp_mail_from', array( __CLASS__, 'mail_from' ) );

		if ( ! wp_next_scheduled( 'ssp_cron_minutely' ) ) {
			wp_schedule_event( time() + 60, 'ssp_minute', 'ssp_cron_minutely' );
		}
		if ( ! wp_next_scheduled( 'ssp_cron_quarter_hour' ) ) {
			wp_schedule_event( time() + 900, 'ssp_quarter_hour', 'ssp_cron_quarter_hour' );
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'ssp', CLI::class );
		}
	}

	public static function schedules( $s ) {
		$s['ssp_minute']       = array( 'interval' => 60, 'display' => 'Every minute (Silver Stacker)' );
		$s['ssp_quarter_hour'] = array( 'interval' => 900, 'display' => 'Every 15 minutes (Silver Stacker)' );
		return $s;
	}

	public static function minutely() {
		Catalog::close_due_presales();
		Waitlist::expire_due();
		Jobs::run( 50 );
	}

	public static function quarter_hour() {
		Qbo::cdc_poll();
		Boxes::auto_close_delivered();
		global $wpdb;
		$t = Installer::tables()['invoices'];
		foreach ( $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t} WHERE sync_status='synced' AND due_date < %s", current_time( 'Y-m-d' ) ) ) as $id ) {
			Invoices::apply_payment_state( (int) $id );
		}
	}

	public static function mail_from_name( $name ) {
		$n = Settings::get( 'email_from_name' );
		return $n ? $n : $name;
	}

	public static function mail_from( $from ) {
		$f = Settings::get( 'email_from_address' );
		return $f && is_email( $f ) ? $f : $from;
	}
}
