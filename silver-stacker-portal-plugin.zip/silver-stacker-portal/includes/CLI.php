<?php
namespace SSP;

use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\Util;
use SSP\Domain\Allocation;
use SSP\Domain\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * WP-CLI commands: wp ssp <command>
 */
class CLI {

	/**
	 * Process due background jobs.
	 *
	 * ## OPTIONS
	 * [--limit=<n>]
	 */
	public function jobs( $args, $assoc ) {
		$n = Jobs::run( (int) ( $assoc['limit'] ?? 100 ) );
		\WP_CLI::success( "Processed {$n} job(s)." );
	}

	/** Close presales whose countdown reached zero and expire waitlist offers. */
	public function tick() {
		\WP_CLI::log( 'Closed presales: ' . Catalog::close_due_presales() );
		\WP_CLI::log( 'Expired offers: ' . \SSP\Domain\Waitlist::expire_due() );
		\WP_CLI::success( 'Jobs processed: ' . Jobs::run( 100 ) );
	}

	/** Rebuild the product search index. */
	public function reindex() {
		global $wpdb;
		$t   = Installer::tables()['products'];
		$ids = $wpdb->get_col( "SELECT id FROM {$t}" );
		foreach ( $ids as $id ) {
			Catalog::reindex( (int) $id );
		}
		\WP_CLI::success( count( $ids ) . ' product(s) reindexed.' );
	}

	/** Recompute reserved/held allocation counters from order lines and waitlist offers. */
	public function reconcile() {
		global $wpdb;
		$t   = Installer::tables()['variants'];
		$fix = 0;
		foreach ( $wpdb->get_results( "SELECT id, reserved_qty, held_qty FROM {$t}" ) as $v ) {
			$r = Allocation::reconcile( (int) $v->id );
			if ( (int) $v->reserved_qty !== $r['reserved'] || (int) $v->held_qty !== $r['held'] ) {
				++$fix;
				\WP_CLI::log( "Variant {$v->id}: reserved {$v->reserved_qty} -> {$r['reserved']}, held {$v->held_qty} -> {$r['held']}" );
			}
		}
		\WP_CLI::success( "Reconciled. {$fix} variant(s) corrected." );
	}

	/**
	 * Seed archived reference products for performance testing.
	 *
	 * ## OPTIONS
	 * [--count=<n>]
	 */
	public function seed_archive( $args, $assoc ) {
		global $wpdb;
		$count  = (int) ( $assoc['count'] ?? 10000 );
		$t      = Installer::tables();
		$metals = array( 'Silver', 'Gold', 'Copper', 'Platinum' );
		$brands = array( 'Royal Canadian Mint', 'Perth Mint', 'PAMP', 'Royal Mint', 'US Mint', 'Niue Mint', 'Scottsdale', 'Germania Mint', 'Mint of Poland', 'Asahi' );
		$types  = array( 'Maple Leaf', 'Kangaroo', 'Lunar Dragon', 'Brumby Horse', 'Britannia', 'Eagle', 'Samurai Warrior', 'Stars and Stripes', 'Kookaburra', 'Koala', 'Valkyrie', 'Buffalo', 'Philharmonic', 'Krugerrand', 'Panda' );
		$finish = array( '1 oz Silver Coin', '1/10 oz Gold Coin', '2 oz Silver Coin', '1 oz Copper Round', '5 oz Silver Bar', '1 oz Platinum Coin', '10 oz Copper Bar', 'Colorized 1 oz Silver Coin' );
		$now    = Util::now();
		\WP_CLI::log( "Seeding {$count} archived products..." );
		$wpdb->query( 'START TRANSACTION' );
		for ( $i = 1; $i <= $count; $i++ ) {
			$year = 2010 + ( $i % 16 );
			$name = $year . ' ' . $types[ $i % count( $types ) ] . ' ' . $finish[ $i % count( $finish ) ] . ' #' . $i;
			$sku  = 'ARC-' . str_pad( (string) $i, 6, '0', STR_PAD_LEFT );
			$wpdb->insert(
				$t['products'],
				array(
					'product_uid' => Util::ulid(),
					'slug'        => sanitize_title( $name ),
					'name'        => $name,
					'description' => 'Archived reference listing.',
					'brand'       => $brands[ $i % count( $brands ) ],
					'metal'       => $metals[ $i % 4 ],
					'category'    => 'Coins',
					'mintage'     => (string) ( 1000 * ( 1 + $i % 50 ) ),
					'lifecycle'   => 'archived',
					'eta_type'    => 'none',
					'search_text' => $sku . ' ' . ( 700000000000 + $i ),
					'archived_at' => $now,
					'created_at'  => $now,
					'updated_at'  => $now,
				)
			);
			$pid = (int) $wpdb->insert_id;
			$wpdb->insert(
				$t['variants'],
				array(
					'variant_uid' => Util::ulid(),
					'product_id'  => $pid,
					'sku'         => $sku,
					'barcode'     => (string) ( 700000000000 + $i ),
					'price_usd'   => 10 + ( $i % 300 ),
					'created_at'  => $now,
					'updated_at'  => $now,
				)
			);
			if ( 0 === $i % 2000 ) {
				$wpdb->query( 'COMMIT' );
				$wpdb->query( 'START TRANSACTION' );
				\WP_CLI::log( "  {$i}" );
			}
		}
		$wpdb->query( 'COMMIT' );
		\WP_CLI::success( "Seeded {$count} archive products." );
	}

	/** Seed demo data: products with images, customers, sample orders (for local evaluation only). */
	public function seed_demo() {
		require_once SSP_DIR . 'tests/demo-seed.php';
		\SSP_Demo_Seed::run();
		\WP_CLI::success( 'Demo data seeded.' );
	}

	/**
	 * Import archive products from CSV (columns: name,sku,barcode,brand,metal,category,mintage,description,image_url_or_path).
	 *
	 * ## OPTIONS
	 * <file>
	 * [--dry-run]
	 */
	public function import_archive( $args, $assoc ) {
		$res = \SSP\Admin\ArchiveImport::import( $args[0], ! empty( $assoc['dry-run'] ) );
		foreach ( $res['errors'] as $e ) {
			\WP_CLI::warning( $e );
		}
		\WP_CLI::success( sprintf( '%d imported, %d skipped%s.', $res['imported'], $res['skipped'], ! empty( $assoc['dry-run'] ) ? ' (dry run)' : '' ) );
	}
}
