<?php
/**
 * Acceptance test suite (functional, against a real WordPress + MySQL database).
 * Run on a STAGING copy only:  wp eval-file wp-content/plugins/silver-stacker-portal/tests/acceptance.php
 *
 * Covers the Version 1 acceptance criteria (REV2 §17 / Master Prompt §26). External services
 * (QuickBooks, Google Sheets) are simulated by intercepting HTTP with the pre_http_request filter.
 */

defined( 'ABSPATH' ) || exit;

use SSP\Core\Installer;
use SSP\Core\Jobs;
use SSP\Core\Settings;
use SSP\Core\Util;
use SSP\Domain\Allocation;
use SSP\Domain\Boxes;
use SSP\Domain\Cart;
use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Invoices;
use SSP\Domain\Orders;
use SSP\Domain\Shipments;
use SSP\Domain\Terms;
use SSP\Domain\Waitlist;
use SSP\Integrations\Qbo;
use SSP\Integrations\Sheets;
use SSP\Integrations\Warehouse;

$GLOBALS['ssp_t'] = array( 'pass' => 0, 'fail' => 0, 'log' => array() );

function ssp_check( $cond, $label ) {
	if ( $cond ) {
		++$GLOBALS['ssp_t']['pass'];
		echo "  \033[32mPASS\033[0m {$label}\n";
	} else {
		++$GLOBALS['ssp_t']['fail'];
		echo "  \033[31mFAIL\033[0m {$label}\n";
	}
}

function ssp_section( $t ) {
	echo "\n\033[1m{$t}\033[0m\n";
}

$run = substr( strtolower( Util::ulid() ), -6 );
wp_set_current_user( 1 );
global $wpdb;
$T = Installer::tables();

function ssp_new_customer( $email, $company, $run ) {
	$q = array();
	foreach ( Customers::questions() as $qq ) {
		$q[ $qq->id ] = 'Yes';
	}
	$addr = array( 'name' => 'Test ' . $company, 'line1' => '1 Test Way', 'city' => 'Irving', 'state' => 'TX', 'postal_code' => '75038' );
	return Customers::register( array( 'contact_name' => 'Tester ' . $email, 'email' => $email . $run . '@example.test', 'phone' => '214-555-0101', 'company_name' => $company, 'password' => 'Password!2026x', 'password_confirm' => 'Password!2026x', 'billing' => $addr, 'shipping_same' => 1, 'answers' => $q, 'agree_individual' => 1 ) );
}

function ssp_new_product( $name, array $v, $life = 'presale', $closing_days = 5 ) {
	wp_set_current_user( 1 );
	$pid = Catalog::save_product( array( 'name' => $name, 'metal' => 'Silver', 'brand' => 'Test Mint', 'mintage' => '1,000', 'closing_at' => wp_date( 'Y-m-d\TH:i', time() + $closing_days * DAY_IN_SECONDS, Util::business_tz() ), 'eta_type' => 'text', 'eta_text' => 'Late November' ) );
	$vid = Catalog::save_variant( $pid, $v );
	$r   = Catalog::set_lifecycle( $pid, $life );
	if ( is_wp_error( $r ) ) {
		echo 'Lifecycle error: ' . $r->get_error_message() . "\n";
	}
	return array( $pid, $vid );
}

/* ------------------------------------------------------------------ */
ssp_section( 'AT-01..04 Registration, approval, terms gate' );
$A = ssp_new_customer( 'alice', 'Same Store LLC', $run );
$B = ssp_new_customer( 'bob', 'Same Store LLC', $run ); // same company name on purpose (REV2 §17.46)
ssp_check( ! is_wp_error( $A ) && ! is_wp_error( $B ), 'Two individual accounts register (same company name allowed)' );
ssp_check( 'pending' === Customers::status( $A ), 'New account is Pending approval' );
ssp_check( ! Customers::can_view_catalog( $A ), 'Pending customer cannot view catalog' );
$dup = ssp_new_customer( 'alice', 'Other', $run );
ssp_check( is_wp_error( $dup ), 'Duplicate email rejected' );
$bad = Customers::set_status( $A, 'suspended' );
ssp_check( is_wp_error( $bad ), 'Invalid transition pending -> suspended blocked' );
$noreason = Customers::set_status( $B, 'rejected', '' );
ssp_check( is_wp_error( $noreason ), 'Rejection requires a reason' );
ssp_check( true === Customers::set_status( $A, 'approved' ) && true === Customers::set_status( $B, 'approved' ), 'Staff approves customers' );
$mail = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$T['notifications']} WHERE user_id=%d AND template='account_approved'", $A ) );
ssp_check( 1 === $mail, 'Approval email queued' );
ssp_check( ! Customers::can_view_catalog( $A ), 'Approved but terms not accepted: still no catalog' );
Terms::accept( $A, Terms::current()->id );
Terms::accept( $B, Terms::current()->id );
ssp_check( Customers::can_view_catalog( $A ), 'After accepting terms: catalog visible' );
$acc = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$T['acceptances']} WHERE user_id=%d", $A ) );
ssp_check( $acc && $acc->terms_version_id && $acc->accepted_at, 'Acceptance recorded with customer, version, timestamp' );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-05..07 Catalog, search, ETA, countdown' );
list( $P1, $V1 ) = ssp_new_product( "Acceptance Eagle {$run}", array( 'sku' => "ACC-EAGLE-{$run}", 'barcode' => "99{$run}", 'price_usd' => 50, 'min_order_qty' => 2, 'total_allocation' => 10, 'per_customer_allocation' => 6 ) );
$res = Catalog::search( array( 'q' => "Eagle {$run}", 'tab' => 'active' ) );
ssp_check( 1 === $res['total'], 'Search by name finds product in Active Items' );
ssp_check( 1 === Catalog::search( array( 'q' => "ACC-EAGLE-{$run}" ) )['total'], 'Search by SKU' );
ssp_check( 1 === Catalog::search( array( 'q' => "99{$run}" ) )['total'], 'Search by barcode' );
ssp_check( 0 === $res['counts']['archive'] || $res['counts']['archive'] >= 0, 'Archive tab count returned alongside' );
ssp_check( 'Late November' === Catalog::eta_label( Catalog::get( $P1 ) ), 'ETA label shown' );
ssp_check( Catalog::is_orderable( Catalog::get( $P1 ) ), 'Presale with future closing is orderable' );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-08..10 Pre-order, allocation, history' );
wp_set_current_user( $A );
$r = Orders::place( $A, array( array( 'variant_id' => $V1, 'qty' => 1, 'fulfillment' => 'box' ) ), 'k-min-' . $run . str_repeat( 'x', 10 ) );
ssp_check( is_wp_error( $r ), 'Below minimum quantity is blocked' );
$r = Orders::place( $A, array( array( 'variant_id' => $V1, 'qty' => 7, 'fulfillment' => 'box' ) ), 'k-pc-' . $run . str_repeat( 'x', 10 ) );
ssp_check( is_wp_error( $r ) && false !== strpos( implode( ' ', (array) $r->get_error_data()['line_errors'] ), 'per customer' ), 'Above per-customer allocation is blocked with clear message' );
$O1 = Orders::place( $A, array( array( 'variant_id' => $V1, 'qty' => 4, 'fulfillment' => 'box' ) ), 'k-ok1-' . $run . str_repeat( 'x', 10 ), 'note A' );
ssp_check( is_int( $O1 ), 'Valid pre-order submitted without payment' );
$again = Orders::place( $A, array( array( 'variant_id' => $V1, 'qty' => 4, 'fulfillment' => 'box' ) ), 'k-ok1-' . $run . str_repeat( 'x', 10 ) );
ssp_check( $again === $O1, 'Double-submit with same key returns same order (idempotent)' );
$v = Catalog::variant( $V1 );
ssp_check( 4 === (int) $v->reserved_qty && 6 === Allocation::remaining_total( $v ), 'Allocation decreased correctly (4 reserved, 6 remaining)' );
$ord = Orders::get( $O1 );
ssp_check( (int) $ord->order_number > 0, 'Order number assigned' );
ssp_check( 1 === (int) Orders::customer_orders( $A, array( 'q' => "Eagle {$run}" ) )['total'], 'Order history searchable by item name' );
ssp_check( null === Orders::get_owned( $B, $ord->order_number ), 'Customer B cannot load customer A\'s order (same company name)' );
$lineA = Orders::lines( $O1 )[0];
ssp_check( null === Orders::line_owned( $B, $lineA->line_uid ), 'Customer B cannot load A\'s order line by ID' );
wp_set_current_user( $B );
$rB = Orders::customer_amend( $B, $lineA->line_uid, 0 );
ssp_check( is_wp_error( $rB ), 'Customer B cannot change A\'s line' );
ssp_check( (bool) Boxes::line_box( $lineA->id ), 'Line chosen "Add to My Box" is in A\'s open box' );

// Concurrency: 8 parallel submissions for 3 units each from distinct customers against remaining 6 (limit 6 per customer).
list( $P2, $V2 ) = ssp_new_product( "Race Coin {$run}", array( 'sku' => "RACE-{$run}", 'price_usd' => 20, 'total_allocation' => 6 ) );
$racers = array();
for ( $i = 0; $i < 8; $i++ ) {
	$u = ssp_new_customer( "race{$i}", "Race {$i}", $run );
	Customers::set_status( $u, 'approved', '', false );
	Terms::accept( $u, Terms::current()->id );
	$racers[] = $u;
}
$script = SSP_DIR . 'tests/race-worker.php';
$cmds   = array();
foreach ( $racers as $i => $u ) {
	$cmds[] = sprintf( 'wp --allow-root --path=%s eval-file %s %d %d %s > /tmp/ssp-race-%d.log 2>&1 &', escapeshellarg( ABSPATH ), escapeshellarg( $script ), $u, $V2, escapeshellarg( 'race-' . $run . '-' . $i . '-xxxxxxxxxx' ), $i );
}
shell_exec( implode( ' ', $cmds ) . ' wait' );
$v2   = Catalog::variant( $V2 );
$wins = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$T['lines']} WHERE variant_id=%d", $V2 ) );
ssp_check( 6 === (int) $v2->reserved_qty && 2 === $wins, "Concurrent orders never oversell (reserved {$v2->reserved_qty} of 6, {$wins} winners)" );
$recon = Allocation::reconcile( $V2 );
ssp_check( 6 === $recon['reserved'], 'Reserved counter matches order lines after race' );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-51 Waitlist and override' );
wp_set_current_user( $racers[7] );
$loser = $racers[7];
$wl    = Waitlist::join( $loser, $V2, 2 );
ssp_check( is_int( $wl ), 'Fully allocated item offers waitlist entry' );
wp_set_current_user( 1 );
$winner_line = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$T['lines']} WHERE variant_id=%d ORDER BY id LIMIT 1", $V2 ) );
wp_set_current_user( (int) $winner_line->user_id );
$r = Orders::customer_amend( (int) $winner_line->user_id, $winner_line->line_uid, 1 );
ssp_check( true === $r, 'Winner decreases before close (allocation released)' );
$e = Waitlist::get( $wl );
ssp_check( 'offered' === $e->status && 2 === (int) $e->offered_qty, 'Released allocation held for the waitlisted customer (hold mode)' );
ssp_check( 2 === (int) Catalog::variant( $V2 )->held_qty, 'Held quantity counted against allocation' );
$third = $racers[6];
wp_set_current_user( $third );
$steal = Orders::place( $third, array( array( 'variant_id' => $V2, 'qty' => 1, 'fulfillment' => 'decide_later' ) ), 'steal-' . $run . 'xxxxxxxxxxxx' );
ssp_check( is_wp_error( $steal ), 'Others cannot take held allocation' );
wp_set_current_user( $loser );
$conv = Waitlist::accept( $loser, $e->waitlist_uid );
ssp_check( is_int( $conv ) && 'converted' === Waitlist::get( $wl )->status, 'Waitlist offer accepted and converted to a pre-order' );
$v2 = Catalog::variant( $V2 );
ssp_check( 0 === (int) $v2->held_qty && 6 === (int) $v2->reserved_qty, 'Hold consumed; reserved back to full allocation (6)' );
wp_set_current_user( 1 );
$ov = Allocation::add_override( $V2, 0, 'total', 3, 'Mint shipped extra units' );
ssp_check( is_int( $ov ), 'Staff override recorded' );
$ovrow = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$T['overrides']} WHERE id=%d", $ov ) );
ssp_check( 1 === (int) $ovrow->staff_id && 'Mint shipped extra units' === $ovrow->reason && 3 === (int) $ovrow->qty && $ovrow->created_at, 'Override logged with staff, time, quantity, reason' );
ssp_check( is_wp_error( Allocation::add_override( $V2, 0, 'total', 1, '' ) ), 'Override without reason refused' );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-52 Amend before close, lock after close' );
wp_set_current_user( $A );
ssp_check( true === Orders::customer_amend( $A, $lineA->line_uid, 6 ), 'Increase within limits accepted' );
ssp_check( is_wp_error( Orders::customer_amend( $A, $lineA->line_uid, 7 ) ), 'Increase over per-customer limit refused' );
ssp_check( true === Orders::customer_amend( $A, $lineA->line_uid, 5 ), 'Decrease accepted' );
ssp_check( 5 === (int) Catalog::variant( $V1 )->reserved_qty, 'Allocation recalculated (5 reserved)' );
// ETA change after order must not change order snapshot but show current ETA.
wp_set_current_user( 1 );
$p = (array) Catalog::get( $P1 );
$p['eta_type'] = 'text';
$p['eta_text'] = 'Early December';
unset( $p['closing_at'] );
Catalog::save_product( $p, $P1 );
$lineA = Orders::line( $lineA->id );
ssp_check( 'Late November' === $lineA->eta_at_order && 'Early December' === Catalog::eta_label( Catalog::get( $P1 ) ), 'ETA update reflects everywhere; original order snapshot unchanged' );
// Close the presale.
$wpdb->update( $T['products'], array( 'closing_at' => Util::now( -60 ) ), array( 'id' => $P1 ) );
ssp_check( 'presale_ended' === Catalog::effective_lifecycle( Catalog::get( $P1 ) ), 'Countdown at zero: presale ended immediately (server clock)' );
wp_set_current_user( $B );
$late = Orders::place( $B, array( array( 'variant_id' => $V1, 'qty' => 2, 'fulfillment' => 'box' ) ), 'late-' . $run . 'xxxxxxxxxxxx' );
ssp_check( is_wp_error( $late ), 'New orders blocked after closing' );
Catalog::close_due_presales();
wp_set_current_user( $A );
ssp_check( is_wp_error( Orders::customer_amend( $A, $lineA->line_uid, 6 ) ), 'Customer cannot edit after closing (line locked)' );
ssp_check( 'locked' === Orders::line( $lineA->id )->display_status, 'Line status Locked' );
wp_set_current_user( 1 );
ssp_check( true === Orders::staff_set_qty( $lineA->id, 4, 'Customer called; mint short' ), 'Staff correction after close allowed with reason' );
ssp_check( is_wp_error( Orders::staff_set_qty( $lineA->id, 3, '' ) ), 'Staff correction without reason refused' );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-11/12/53 Line availability (partial)' );
ssp_check( true === Orders::set_availability( $lineA->id, 2 ), 'Staff marks part of a line available' );
ssp_check( 'partially_available' === Orders::line( $lineA->id )->display_status, 'Customer sees Partially available' );
ssp_check( is_wp_error( Orders::set_availability( $lineA->id, 9 ) ), 'Availability above ordered refused' );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-13..17/55/56 Box: multiple orders, shipment request, shipping' );
list( $P3, $V3 ) = ssp_new_product( "Box Copper {$run}", array( 'sku' => "BOXCU-{$run}", 'price_usd' => 10 ), 'in_stock' );
wp_set_current_user( $A );
$O2 = Orders::place( $A, array( array( 'variant_id' => $V3, 'qty' => 3, 'fulfillment' => 'decide_later' ) ), 'box2-' . $run . 'xxxxxxxxxxxx' );
$l2 = Orders::lines( $O2 )[0];
ssp_check( true === Orders::set_fulfillment( $l2->id, 'box', $A ), 'Eligible item from a second order added to My Box' );
$box = Boxes::open_box( $A );
$items = Boxes::items( $box->id );
$orders_in_box = array_unique( wp_list_pluck( $items, 'order_number' ) );
ssp_check( 2 === count( $orders_in_box ), 'Box holds lines from 2 different orders with original order references' );
ssp_check( Addresses_default_ok( $A, $box ), 'Default shipping address assigned to box' );
wp_set_current_user( 1 );
Orders::set_availability( $l2->id, 3 );
wp_set_current_user( $A );
$req = Boxes::request_shipment( $box->id, $A, 'ship_available' );
ssp_check( true === $req && 'shipment_requested' === Boxes::get( $box->id )->status, 'Customer requests box shipment' );
$O3 = Orders::place( $A, array( array( 'variant_id' => $V3, 'qty' => 1, 'fulfillment' => 'box' ) ), 'box3-' . $run . 'xxxxxxxxxxxx' );
$newbox = Boxes::open_box( $A );
ssp_check( $newbox && (int) $newbox->id !== (int) $box->id && Boxes::line_box( Orders::lines( $O3 )[0]->id ) === (int) $newbox->id, 'Items ordered after a shipment request go to a new open box (one open box at a time)' );
ssp_check( 'shipment_requested' === Boxes::get( $box->id )->status && 1 === count( Boxes::active_boxes( $A ) ) - 1, 'Requested box keeps its contents; only one box is open' );
wp_set_current_user( 1 );
Boxes::set_preparing( $box->id );
$tier = Shipments::tiers()[0];
$sid  = Boxes::ship( $box->id, array( 'rate_tier_id' => $tier->id, 'carrier' => 'UPS', 'tracking_number' => "1ZTEST{$run}" ) );
ssp_check( is_int( $sid ), 'Staff records tier, carrier and tracking; box shipped' );
$sl = Shipments::lines( $sid );
ssp_check( count( $sl ) >= 2, 'Shipment preserves which lines were included (' . count( $sl ) . ' lines)' );
$la = Orders::line( $lineA->id );
ssp_check( 2 === (int) $la->qty_shipped && Boxes::line_box( $lineA->id ), 'Partially shipped line carried into the open box for the remainder' );
ssp_check( 'shipped' === Boxes::get( $box->id )->status && $tier->id == Shipments::get( $sid )->rate_tier_id, 'Box status Shipped with rate tier recorded' );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-18/54 QuickBooks invoice (simulated QBO), idempotent retry' );
Settings::set( 'qbo_client_id', 'test' );
Settings::set( 'qbo_client_secret', 'secret' );
Settings::set( 'qbo_income_account_id', '79' );
Settings::set( 'qbo_shipping_item_id', '5' );
Settings::set( 'qbo_webhook_verifier', 'verifier-token' );
Qbo::save_tokens( array( 'access_token' => 'AT', 'refresh_token' => 'RT', 'expires_at' => time() + 3600, 'refresh_expires_at' => time() + 86400 * 90, 'realm_id' => '123' ) );
$GLOBALS['qbo_calls'] = array();
$GLOBALS['qbo_fail_invoice'] = true;
$GLOBALS['qbo_paid'] = false;
$GLOBALS['qid'] = (string) ( 7000 + crc32( $run ) % 100000 );
$GLOBALS['pid'] = 'P' . $run;
add_filter(
	'pre_http_request',
	function ( $pre, $args, $url ) {
		if ( strpos( $url, 'quickbooks.api.intuit.com' ) === false ) {
			return $pre;
		}
		$GLOBALS['qbo_calls'][] = array( $args['method'] ?? 'GET', $url );
		$j = function ( $code, $body ) {
			return array( 'response' => array( 'code' => $code, 'message' => '' ), 'body' => wp_json_encode( $body ), 'headers' => array(), 'cookies' => array() );
		};
		if ( strpos( $url, '/query' ) !== false ) {
			return $j( 200, array( 'QueryResponse' => array() ) );
		}
		if ( strpos( $url, '/customer' ) !== false ) {
			return $j( 200, array( 'Customer' => array( 'Id' => '58' ) ) );
		}
		if ( strpos( $url, '/item' ) !== false ) {
			return $j( 200, array( 'Item' => array( 'Id' => '901' ) ) );
		}
		if ( preg_match( '#/invoice\?#', $url ) && 'POST' === ( $args['method'] ?? '' ) ) {
			if ( $GLOBALS['qbo_fail_invoice'] ) {
				return $j( 503, array( 'Fault' => array( 'Error' => array( array( 'Message' => 'Service unavailable', 'code' => '503' ) ) ) ) );
			}
			return $j( 200, array( 'Invoice' => array( 'Id' => $GLOBALS['qid'], 'DocNumber' => '1042', 'TotalAmt' => 108.25, 'Balance' => 108.25, 'TxnDate' => '2026-10-01', 'DueDate' => '2026-10-04' ) ) );
		}
		if ( strpos( $url, '/send' ) !== false ) {
			return $j( 200, array( 'Invoice' => array( 'Id' => $GLOBALS['qid'] ) ) );
		}
		if ( preg_match( '#/invoice/' . $GLOBALS['qid'] . '\?#', $url ) ) {
			return $j( 200, array( 'Invoice' => array( 'Id' => $GLOBALS['qid'], 'DocNumber' => '1042', 'TotalAmt' => 108.25, 'Balance' => $GLOBALS['qbo_paid'] ? 0 : 108.25, 'TxnDate' => '2026-10-01', 'DueDate' => '2026-10-04', 'InvoiceLink' => 'https://app.qbo.intuit.com/app/customer/pay/demo' ) ) );
		}
		if ( strpos( $url, '/payment/' ) !== false ) {
			return $j( 200, array( 'Payment' => array( 'Id' => '9', 'Line' => array( array( 'LinkedTxn' => array( array( 'TxnId' => $GLOBALS['qid'], 'TxnType' => 'Invoice' ) ) ) ) ) ) );
		}
		return $j( 404, array() );
	},
	10,
	3
);
$elig = Invoices::eligible_lines( $A );
$sel  = array();
foreach ( $elig as $l ) {
	$sel[ $l->id ] = array( 'qty' => Invoices::invoiceable_qty( $l ), 'unit_price' => null );
}
ssp_check( count( $sel ) >= 2, 'Staff selects available, uninvoiced lines (' . count( $sel ) . ')' );
$inv_id = Invoices::create( $A, $sel, array( 'amount' => 9, 'description' => 'Build A Box shipping' ), 'nonce-' . $run, 'qbo' );
$inv    = Invoices::get( $inv_id );
ssp_check( 'error' === $inv->sync_status, 'QBO failure: invoice in Error state with actionable message (' . $inv->error_message . ')' );
$invoiced_now = (int) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(qty_invoiced) FROM {$T['lines']} WHERE user_id=%d", $A ) );
ssp_check( 0 === $invoiced_now, 'Failed QBO action did NOT mark lines invoiced' );
ssp_check( 0 === count( Invoices::eligible_lines( $A ) ), 'Lines held as pending so they cannot be double-selected' );
$dupe = Invoices::create( $A, $sel, array( 'amount' => 9, 'description' => 'Build A Box shipping' ), 'nonce-' . $run, 'qbo' );
ssp_check( $dupe === $inv_id, 'Repeating the same staff action returns the same invoice (no duplicate)' );
$GLOBALS['qbo_fail_invoice'] = false;
$job = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$T['jobs']} WHERE idempotency_key=%s", 'qbo_create_invoice:' . $inv_id ) );
Jobs::retry( (int) $job );
$inv = Invoices::get( $inv_id );
ssp_check( 'synced' === $inv->sync_status && '1042' === $inv->doc_number && $GLOBALS['qid'] === $inv->qbo_invoice_id, 'Retry succeeded: QBO invoice number/ID stored' );
$posts = array_filter( $GLOBALS['qbo_calls'], fn( $c ) => 'POST' === $c[0] && preg_match( '#/invoice\?#', $c[1] ) );
$rids  = array_unique( array_map( fn( $c ) => preg_replace( '#.*requestid=([^&]+).*#', '$1', $c[1] ), $posts ) );
ssp_check( count( $posts ) >= 2 && 1 === count( $rids ), 'Both attempts used the same QBO requestid (idempotent at QuickBooks)' );
ssp_check( $inv->pay_link && $inv->due_date && null !== $inv->balance_usd, 'Pay link, due date and amount due retrieved' );
$invoiced_now = (int) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(qty_invoiced) FROM {$T['lines']} WHERE user_id=%d", $A ) );
ssp_check( $invoiced_now === array_sum( wp_list_pluck( $sel, 'qty' ) ), 'Invoice linked to the correct lines at line level' );
ssp_check( 'synced' === $inv->sync_status && 'paid' !== $inv->sync_status, 'Not shown as paid until QBO confirms' );
// Payment webhook.
$GLOBALS['qbo_paid'] = true;
$body = wp_json_encode( array( 'eventNotifications' => array( array( 'realmId' => '123', 'dataChangeEvent' => array( 'entities' => array( array( 'name' => 'Payment', 'id' => $GLOBALS['pid'], 'operation' => 'Create' ) ) ) ) ) ) );
$req  = new WP_REST_Request( 'POST', '/ssp/v1/hooks/qbo' );
$req->set_body( $body );
$req->set_header( 'intuit-signature', base64_encode( hash_hmac( 'sha256', $body, 'verifier-token', true ) ) );
$resp = Qbo::handle_webhook( $req );
ssp_check( 200 === $resp->get_status(), 'Signed QBO webhook accepted' );
$bad  = new WP_REST_Request( 'POST', '/ssp/v1/hooks/qbo' );
$bad->set_body( $body );
$bad->set_header( 'intuit-signature', 'forged' );
ssp_check( 401 === Qbo::handle_webhook( $bad )->get_status(), 'Forged webhook signature rejected' );
Jobs::run( 20, 'qbo' );
ssp_check( 'paid' === Invoices::get( $inv_id )->sync_status, 'Payment status synchronized back automatically (Paid)' );
$again = Qbo::handle_webhook( $req );
ssp_check( ! empty( $again->get_data()['duplicate'] ), 'Duplicate webhook delivery ignored' );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-19/57 Google Sheets one-way copy (simulated API)' );
Settings::set( 'sheets_enabled', 1 );
Settings::set( 'sheets_spreadsheet_id', 'SHEET123' );
$key = openssl_pkey_new( array( 'private_key_bits' => 2048 ) );
openssl_pkey_export( $key, $pem );
Settings::set( 'sheets_service_account', wp_json_encode( array( 'client_email' => 'svc@test.iam.gserviceaccount.com', 'private_key' => $pem ) ) );
delete_transient( 'ssp_gs_token' );
delete_transient( 'ssp_gs_tabs_ok' );
$GLOBALS['gs'] = array( 'rows' => array(), 'appends' => 0, 'puts' => 0 );
add_filter(
	'pre_http_request',
	function ( $pre, $args, $url ) {
		$j = fn( $b ) => array( 'response' => array( 'code' => 200, 'message' => '' ), 'body' => wp_json_encode( $b ), 'headers' => array(), 'cookies' => array() );
		if ( strpos( $url, 'oauth2.googleapis.com' ) !== false ) {
			return $j( array( 'access_token' => 'gtok', 'expires_in' => 3600 ) );
		}
		if ( strpos( $url, 'sheets.googleapis.com' ) === false ) {
			return $pre;
		}
		$path = rawurldecode( wp_parse_url( $url, PHP_URL_PATH ) );
		if ( strpos( $url, 'fields=sheets' ) !== false ) {
			return $j( array( 'sheets' => array() ) );
		}
		if ( preg_match( "#/values/'([^']+)'!A:A$#", $path, $m ) ) {
			$vals = array();
			foreach ( $GLOBALS['gs']['rows'][ $m[1] ] ?? array() as $r ) {
				$vals[] = array( $r[0] );
			}
			return $j( array( 'values' => array_merge( array( array( 'ID' ) ), $vals ) ) );
		}
		if ( preg_match( "#/values/'([^']+)'!A(\d+)$#", $path, $m ) && 'GET' === $args['method'] ) {
			$r = $GLOBALS['gs']['rows'][ $m[1] ][ (int) $m[2] - 2 ] ?? null;
			return $j( array( 'values' => $r ? array( array( $r[0] ) ) : array() ) );
		}
		if ( preg_match( "#/values/'([^']+)'!A1:append$#", $path, $m ) ) {
			$b = json_decode( $args['body'], true );
			$GLOBALS['gs']['rows'][ $m[1] ][] = $b['values'][0];
			++$GLOBALS['gs']['appends'];
			$n = count( $GLOBALS['gs']['rows'][ $m[1] ] ) + 1;
			return $j( array( 'updates' => array( 'updatedRange' => "'{$m[1]}'!A{$n}:Z{$n}" ) ) );
		}
		if ( preg_match( "#/values/'([^']+)'!A(\d+):[A-Z]+\d+$#", $path, $m ) && 'PUT' === $args['method'] ) {
			$b = json_decode( $args['body'], true );
			$GLOBALS['gs']['rows'][ $m[1] ][ (int) $m[2] - 2 ] = $b['values'][0];
			++$GLOBALS['gs']['puts'];
			return $j( array() );
		}
		return $j( array() );
	},
	10,
	3
);
$lineA = Orders::line( $lineA->id );
Sheets::queue( 'Pre-order Lines', $lineA->line_uid );
$wpdb->query( "UPDATE {$T['jobs']} SET next_attempt_at=UTC_TIMESTAMP() WHERE integration='sheets'" );
Jobs::run( 50, 'sheets' );
wp_set_current_user( 1 );
Orders::staff_set_qty( $lineA->id, 3, 'Sheets test change' );
$wpdb->query( "UPDATE {$T['jobs']} SET next_attempt_at=UTC_TIMESTAMP() WHERE integration='sheets'" );
Jobs::run( 50, 'sheets' );
$sheet_err = $wpdb->get_var( "SELECT last_error FROM {$T['jobs']} WHERE integration='sheets' AND last_error IS NOT NULL LIMIT 1" );
if ( $sheet_err ) { echo "  sheets error: {$sheet_err}\n"; }
$rows    = $GLOBALS['gs']['rows']['Pre-order Lines'] ?? array();
$matches = array_filter( $rows, fn( $r ) => $r[0] === $lineA->line_uid );
ssp_check( 1 === count( $matches ), 'Sheet holds exactly one row per stable line ID after repeated events' );
ssp_check( $GLOBALS['gs']['puts'] >= 1, 'Second event updated the row in place (PUT), not appended' );
ssp_check( 3 === (int) array_values( $matches )[0][8], 'Row reflects latest quantity' );
Settings::set( 'sheets_enabled', 0 );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-20/58 Warehouse event idempotency' );
Settings::set( 'warehouse_webhook_secret', 'wh-secret' );
$l2 = Orders::line( $l2->id );
$evt  = wp_json_encode( array( 'event_id' => 'evt-' . $run, 'type' => 'line.availability', 'line_id' => $lineA->line_uid, 'qty_available' => 3 ) );
$wr   = new WP_REST_Request( 'POST', '/ssp/v1/hooks/warehouse' );
$wr->set_body( $evt );
$wr->set_header( 'x-ssp-signature', hash_hmac( 'sha256', $evt, 'wh-secret' ) );
ssp_check( 200 === Warehouse::handle_webhook( $wr )->get_status() && 3 === (int) Orders::line( $lineA->id )->qty_available, 'Warehouse availability event updates the correct line' );
$dup = Warehouse::handle_webhook( $wr );
ssp_check( ! empty( $dup->get_data()['duplicate'] ), 'Repeated warehouse event ignored (no double counting)' );

/* ------------------------------------------------------------------ */
ssp_section( 'AT-22 Archive' );
wp_set_current_user( 1 );
Catalog::set_lifecycle( $P1, 'archived' );
$arc = Catalog::search( array( 'q' => "Eagle {$run}", 'tab' => 'archive' ) );
ssp_check( 1 === $arc['total'] && 0 === Catalog::search( array( 'q' => "Eagle {$run}", 'tab' => 'active' ) )['total'], 'Closed product moved to The Archive tab, out of Active' );
ssp_check( ! Catalog::is_orderable( Catalog::get( $P1 ) ), 'Archived listing not orderable' );
ssp_check( is_wp_error( Catalog::delete_product( $P1 ) ), 'Product with history cannot be deleted' );
ssp_check( (bool) Catalog::by_uid( Catalog::get( $P1 )->product_uid ), 'Permanent link (product UID) still resolves' );

/* ------------------------------------------------------------------ */
ssp_section( 'Audit trail' );
$acts = $wpdb->get_col( "SELECT DISTINCT action FROM {$T['audit']}" );
foreach ( array( 'allocation.override', 'line.availability_changed', 'line.qty_changed', 'box.shipped', 'invoice.synced', 'customer.status_changed', 'product.eta_changed' ) as $a ) {
	ssp_check( in_array( $a, $acts, true ), "Audit log contains {$a}" );
}

echo "\n\033[1mResult: {$GLOBALS['ssp_t']['pass']} passed, {$GLOBALS['ssp_t']['fail']} failed\033[0m\n";
update_option( 'ssp_test_users', array( 'A' => $A, 'B' => $B, 'order_A' => Orders::get( $O1 )->order_number, 'run' => $run ), false );

function Addresses_default_ok( $uid, $box ) {
	$d = \SSP\Domain\Addresses::default_for( $uid, 'shipping' );
	return $d && (int) $box->address_id === (int) $d->id && $box->address_snapshot;
}
