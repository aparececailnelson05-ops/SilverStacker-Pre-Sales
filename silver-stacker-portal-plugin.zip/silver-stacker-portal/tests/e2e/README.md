Browser end-to-end tests (Playwright). Run against a STAGING site seeded with `wp ssp seed_demo`
and after `tests/acceptance.php` (which stores test users the isolation check uses).

    npm install && npx playwright install chromium
    SSP_BASE=https://staging.example.com WP_PATH=/path/to/wordpress npm test

admin.js / staff.js log in to wp-login.php as admin/admin123; edit the credentials for your staging site.
