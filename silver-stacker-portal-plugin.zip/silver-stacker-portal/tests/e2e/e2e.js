const { chromium } = require('playwright');
const { execSync } = require('child_process');
const base = process.env.SSP_BASE || 'http://localhost:8080';
const wp = (c) => execSync(`cd ${process.env.WP_PATH || '.'} && wp ${c}`).toString().trim();
let pass = 0, fail = 0;
const check = (c, l) => { if (c) { pass++; console.log('  PASS', l); } else { fail++; console.log('  FAIL', l); } };
(async () => {
  const b = await chromium.launch(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {});
  const errors = [];
  const mk = async (vp) => { const c = await b.newContext({ viewport: vp || { width: 1360, height: 900 } }); const p = await c.newPage(); p.on('pageerror', e => errors.push(e.message)); return p; };
  const stamp = Date.now().toString(36);

  console.log('Visitor privacy');
  const v = await mk();
  for (const u of ['/portal/shop/', '/portal/search/?q=silver', '/portal/archive/', '/?s=silver', '/?post_type=attachment']) {
    await v.goto(base + u); check(v.url().includes('/login/'), `visitor ${u} -> login`);
    const html = await v.content(); check(!/\$\d+\.\d\d|Maple Leaf|Brumby/.test(html), `no product names or prices on ${u}`);
  }
  const img = wp(`db query "SELECT image_uid FROM wp_ss_product_images LIMIT 1" --skip-column-names`);
  const file = wp(`db query "SELECT file_path FROM wp_ss_product_images LIMIT 1" --skip-column-names`);
  let r = await v.request.get(base + '/portal/media/' + img + '/thumb/', { maxRedirects: 0 }); check(r.status() === 404, 'visitor cannot fetch product image via portal media URL');
  r = await v.request.get(base + '/wp-content/uploads/ss-private/' + file); check(r.status() === 403, 'private upload folder blocked (' + r.status() + ')');
  r = await v.request.get(base + '/wp-json/ssp/v1/catalog/suggest?q=silver'); check(r.status() === 401, 'catalog REST requires login');
  r = await v.request.get(base + '/wp-json/wp/v2/users'); check(r.status() === 401, 'users REST blocked');

  console.log('Registration wizard');
  await v.goto(base + '/register/');
  const email = `e2e${stamp}@example.test`;
  await v.fill('#contact_name', 'Erin Tester'); await v.fill('#phone', '972-555-0199'); await v.fill('#email', email);
  await v.fill('#password', 'Password!2026x'); await v.fill('#password_confirm', 'Password!2026x'); await v.check('[name=agree_individual]');
  await v.click('[data-step].is-active [data-next]');
  await v.fill('#company_name', 'Same Store LLC');
  await v.fill('#billing-name', 'Erin Tester'); await v.fill('#billing-line1', '5 Elm St'); await v.fill('#billing-city', 'Dallas'); await v.fill('#billing-state', 'TX'); await v.fill('#billing-zip', '75201');
  await v.click('[data-step].is-active [data-next]');
  for (const rg of await v.$$('.ssp-yesno')) { await (await rg.$('input[value=Yes]')).check(); }
  await v.fill('textarea[name^=answers]', 'Yes, from the Facebook group');
  await v.screenshot({ path: 'shots/e2e-register-step3.png', fullPage: true });
  await Promise.all([v.waitForNavigation(), v.click('button[type=submit].ssp-btn--accent')]);
  check(v.url().includes('/register/submitted'), 'registration submitted');
  await v.goto(base + '/login/'); await v.fill('#log', email); await v.fill('#pwd', 'Password!2026x');
  await Promise.all([v.waitForNavigation(), v.click('button[type=submit]')]);
  check(v.url().includes('/account-status'), 'pending customer sees account status only');
  await v.goto(base + '/portal/shop/'); check(v.url().includes('/account-status'), 'pending customer blocked from shop');

  console.log('Approve and first access');
  const uid = wp(`user get ${email} --field=ID`);
  wp(`eval '\\SSP\\Domain\\Customers::set_status(${uid}, "approved");'`);
  await v.goto(base + '/portal/shop/'); check(v.url().includes('/portal/terms'), 'approved customer forced to Terms first');
  await v.click('button[type=submit].ssp-btn--accent'); // without checkbox: browser required blocks
  check(v.url().includes('/portal/terms'), 'cannot continue without ticking agreement');
  await v.check('[name=agree]');
  await Promise.all([v.waitForNavigation(), v.click('button[type=submit].ssp-btn--accent')]);
  check(v.url().endsWith('/portal/'), 'after accepting terms: dashboard');

  console.log('Shop, countdown, ETA, order');
  await v.goto(base + '/portal/search/?q=maple');
  check((await v.textContent('.ssp-tabs')).includes('Active Items'), 'search tabs shown');
  const cd = await v.textContent('[data-countdown-value]'); check(/\d\d:\d\d:\d\d/.test(cd), 'live countdown on search results: ' + cd.trim());
  await v.click('.ssp-pcard__name');
  check((await v.textContent('body')).includes('Estimated Arrival'), 'product shows ETA');
  await v.fill('input[name=qty]', '2'); await v.check('input[name=fulfillment][value=box]');
  await Promise.all([v.waitForNavigation(), v.click('form button[type=submit]:has-text("Add to Order")')]);
  check((await v.textContent('.ssp-count')).trim() === '2', 'cart count updated');
  await v.goto(base + '/portal/cart/'); await v.screenshot({ path: 'shots/e2e-cart.png', fullPage: true });
  await Promise.all([v.waitForNavigation(), v.click('button[name=to_review]')]);
  check(v.url().includes('/cart/review'), 'review page');
  await Promise.all([v.waitForNavigation(), v.click('button:has-text("Submit Pre-Order")')]);
  check(v.url().includes('/confirmation'), 'confirmation page after Submit Pre-Order');
  await v.screenshot({ path: 'shots/e2e-confirmation.png', fullPage: true });
  const orderNo = v.url().match(/orders\/(\d+)/)[1];
  await v.goto(base + '/portal/orders/?q=maple'); check((await v.textContent('body')).includes('#' + orderNo), 'order in history, searchable by item');
  await v.goto(base + '/portal/box/'); check((await v.textContent('body')).includes('#' + orderNo), 'item in My Box with original order number');

  console.log('Isolation over HTTP');
  const other = JSON.parse(wp(`option get ssp_test_users --format=json`));
  await v.goto(base + '/portal/orders/' + other.order_A + '/'); check((await v.textContent('body')).includes('Order not found'), 'cannot open another customer\'s order (same company name)');

  console.log('Ship My Box dialog');
  await v.goto(base + '/portal/box/');
  await v.click('button:has-text("SHIP MY BOX")');
  await v.waitForSelector('dialog[open]'); await v.screenshot({ path: 'shots/e2e-ship-dialog.png' });
  await v.click('dialog[open] button[type=submit]'); // without confirm checkbox -> blocked by required
  check(await v.$('dialog[open]') !== null, 'confirmation required before shipment request');
  await v.check('dialog[open] input[name=confirm]');
  const avail = await v.$('dialog[open] input[value=wait_all]');
  if (avail) await avail.check();
  await Promise.all([v.waitForNavigation(), v.click('dialog[open] button[type=submit]')]);
  check((await v.textContent('body')).includes('Shipment requested'), 'shipment requested');

  console.log('Mobile');
  const m = await mk({ width: 390, height: 844 });
  await m.goto(base + '/login/'); await m.fill('#log', email); await m.fill('#pwd', 'Password!2026x');
  await Promise.all([m.waitForNavigation(), m.click('button[type=submit]')]);
  for (const u of ['', 'shop/', 'orders/' + orderNo + '/', 'box/']) {
    await m.goto(base + '/portal/' + u);
    const sw = await m.evaluate(() => document.documentElement.scrollWidth);
    check(sw <= 392, `mobile /portal/${u} has no horizontal scroll (${sw}px)`);
    await m.screenshot({ path: `shots/mobile-${u.replace(/\W/g, '') || 'home'}.png`, fullPage: true });
  }
  console.log('JS errors:', errors.filter(e => !/TUNNEL/.test(e)));
  console.log(`\nE2E: ${pass} passed, ${fail} failed`);
  await b.close();
})();
