const { chromium } = require('playwright');
const base = process.env.SSP_BASE || 'http://localhost:8080';
let pass = 0, fail = 0;
const check = (c, l) => { if (c) { pass++; console.log('  PASS', l); } else { fail++; console.log('  FAIL', l); } };
(async () => {
  const b = await chromium.launch(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {});
  const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  const notice = async () => (await p.$$eval('.ssa-notice', n => n.map(x => x.textContent.trim()).join(' | ')));
  await p.goto(base + '/wp-login.php'); await p.fill('#user_login', 'admin'); await p.fill('#user_pass', 'admin123');
  await Promise.all([p.waitForNavigation(), p.click('#wp-submit')]);

  // Approve pending customer via UI.
  await p.goto(base + '/wp-admin/admin.php?page=ssp-customers&status=pending');
  await p.click('table.ssa-table tbody tr td a');
  await p.check('input[name=status][value=approved]');
  await Promise.all([p.waitForNavigation(), p.click('button:has-text("Save decision")')]);
  check((await notice()).includes('Customer status updated'), 'Staff approves pending registration in UI');

  // Create product with image.
  await p.goto(base + '/wp-admin/admin.php?page=ssp-products&edit=new');
  await p.fill('input[name=name]', 'UI Created Kookaburra 1 oz');
  await p.selectOption('select[name=metal]', 'Silver');
  await p.fill('input[name=closing_at]', '2026-10-20T23:59');
  await p.selectOption('select[name=eta_type]', 'month'); await p.fill('input[name=eta_start_month]', '2026-12');
  await p.fill('input[name=sku]', 'UI-KOOK-' + Date.now().toString(36)); await p.fill('input[name=price_usd]', '42.50'); await p.fill('input[name=total_allocation]', '20');
  await Promise.all([p.waitForNavigation(), p.click('button:has-text("Create product")')]);
  check((await notice()).includes('Product saved'), 'Product created');
  const url = p.url();
  await p.goto(url.replace(/&tab=\w+/, '') + '&tab=images');
  await p.setInputFiles('input[type=file]', '/home/claude/site/wp-content/plugins/silver-stacker-portal/assets/img/logo.png');
  await Promise.all([p.waitForNavigation(), p.click('button:has-text("Upload")')]);
  check((await notice()).includes('1 image(s) uploaded'), 'Image uploaded privately');
  await p.goto(url.replace(/&tab=\w+/, '') + '&tab=details');
  await Promise.all([p.waitForNavigation(), p.click('button:has-text("Publish as Presale")')]);
  check((await notice()).includes('Lifecycle updated'), 'Published as presale');
  check((await p.textContent('body')).includes('December 2026'), 'ETA month shown');

  // Tracker: mark availability for customer 2's separate line and customer 1's box lines.
  await p.goto(base + '/wp-admin/admin.php?page=ssp-tracker&tab=active');
  const inputs = await p.$$('input[name^=avail]');
  for (const i of inputs) { const max = await i.getAttribute('max'); await i.fill(max); }
  await Promise.all([p.waitForNavigation(), p.click('button:has-text("Save quantity available")')]);
  check(/line\(s\) updated/.test(await notice()), 'Tracker bulk availability saved: ' + await notice());

  // Invoice wizard (manual record, QBO connected in tests so choose manual explicitly).
  await p.goto(base + '/wp-admin/admin.php?page=ssp-invoices');
  await p.click('a:has-text("Select lines")');
  await p.check('input[name=mode][value=manual]');
  await p.fill('input[name="manual[doc_number]"]', 'M-' + Date.now().toString().slice(-5));
  await p.fill('input[name="manual[total]"]', '100.00');
  await p.screenshot({ path: 'shots/staff-invoice-wizard.png', fullPage: true });
  await Promise.all([p.waitForNavigation(), p.click('button:has-text("Create invoice")')]);
  check(/created and linked/.test(await notice()), 'Invoice recorded and linked: ' + await notice());

  // Box ship.
  await p.goto(base + '/wp-admin/admin.php?page=ssp-boxes&status=shipment_requested');
  const boxLink = await p.$('table.ssa-table tbody tr td a');
  if (boxLink) {
    await boxLink.click(); await p.waitForLoadState();
    await p.fill('input[name=carrier]', 'USPS'); await p.fill('input[name=tracking_number]', '9400TEST');
    await Promise.all([p.waitForNavigation(), p.click('button:has-text("Record shipment")')]);
    check(/shipped|No available/.test(await notice()), 'Box shipping: ' + await notice());
  }
  // Reports CSV.
  await p.goto(base + '/wp-admin/admin.php?page=ssp-reports&report=product');
  const [dl] = await Promise.all([p.waitForEvent('download'), p.click('a:has-text("Export CSV")')]);
  const path = await dl.path(); const csv = require('fs').readFileSync(path, 'utf8');
  check(csv.startsWith('Product,Code'), 'Report CSV export');
  console.log('JS errors', errs);
  console.log(`\nStaff E2E: ${pass} passed, ${fail} failed`);
  await b.close();
})();
