const { chromium } = require('playwright');
const base = process.env.SSP_BASE || 'http://localhost:8080';
(async () => {
  const b = await chromium.launch(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {});
  const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  await p.goto(base + '/wp-login.php');
  await p.fill('#user_login', 'admin'); await p.fill('#user_pass', 'admin123');
  await Promise.all([p.waitForNavigation(), p.click('#wp-submit')]);
  const pages = (process.argv[2]||'ssp-dashboard,ssp-customers,ssp-customers&view=2,ssp-products,ssp-products&edit=1,ssp-products&edit=1&tab=variants,ssp-products&edit=1&tab=images,ssp-archive,ssp-orders,ssp-orders&order=15000,ssp-orders&view=lines,ssp-allocation,ssp-tracker,ssp-tracker&tab=active,ssp-tracker&tab=ready,ssp-boxes,ssp-boxes&box=1,ssp-invoices,ssp-reports,ssp-reports&report=category,ssp-reports&report=customer,ssp-integrations,ssp-settings,ssp-settings&tab=decisions,ssp-audit,ssp-resources').split(',');
  for (const pg of pages) {
    await p.goto(base + '/wp-admin/admin.php?page=' + pg);
    const txt = await p.textContent('body');
    const bad = /Fatal error|Warning:|Notice:|Deprecated:|critical error/i.exec(txt);
    await p.screenshot({ path: 'shots/admin-' + pg.replace(/[&=]/g,'_') + '.png', fullPage: true });
    console.log(pg, bad ? 'PROBLEM: ' + txt.substr(bad.index, 300).replace(/\s+/g,' ') : 'ok');
  }
  console.log('JS errors', errs);
  await b.close();
})();
