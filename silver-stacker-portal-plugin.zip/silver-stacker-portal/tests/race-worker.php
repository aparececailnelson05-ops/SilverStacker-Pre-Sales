<?php
/**
 * Concurrency helper for tests/acceptance.php: one process places one order.
 * Args: user_id variant_id submit_key
 */
defined( 'ABSPATH' ) || exit;
list( $uid, $vid, $key ) = array( (int) $args[0], (int) $args[1], (string) $args[2] );
wp_set_current_user( $uid );
$r = \SSP\Domain\Orders::place( $uid, array( array( 'variant_id' => $vid, 'qty' => 3, 'fulfillment' => 'decide_later' ) ), $key );
echo is_wp_error( $r ) ? 'REJECT ' . $r->get_error_message() : 'OK ' . $r;
