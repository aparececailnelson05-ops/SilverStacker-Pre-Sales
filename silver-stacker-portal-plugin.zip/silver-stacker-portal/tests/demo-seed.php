<?php
/**
 * Demo data for local evaluation (wp ssp seed_demo). Creates sample products with generated
 * images, customers in each status, and a few orders. Do NOT run on production.
 */

defined( 'ABSPATH' ) || exit;

use SSP\Domain\Catalog;
use SSP\Domain\Customers;
use SSP\Domain\Terms;
use SSP\Core\Util;

class SSP_Demo_Seed {

	public static function coin_image( $label, $metal, $variant = 0 ) {
		$w   = 900;
		$img = imagecreatetruecolor( $w, $w );
		imagesavealpha( $img, true );
		$bg = imagecolorallocate( $img, 244, 245, 249 );
		imagefill( $img, 0, 0, $bg );
		$palette = array(
			'Silver'   => array( array( 200, 205, 214 ), array( 150, 156, 170 ) ),
			'Gold'     => array( array( 232, 196, 90 ), array( 178, 137, 30 ) ),
			'Copper'   => array( array( 214, 140, 88 ), array( 150, 85, 45 ) ),
			'Platinum' => array( array( 222, 226, 232 ), array( 120, 128, 145 ) ),
		);
		list( $c1, $c2 ) = $palette[ $metal ] ?? $palette['Silver'];
		$cx = $w / 2;
		for ( $r = 380; $r > 0; $r -= 2 ) {
			$t   = $r / 380;
			$col = imagecolorallocate( $img, (int) ( $c2[0] + ( $c1[0] - $c2[0] ) * ( 1 - $t * 0.6 ) ), (int) ( $c2[1] + ( $c1[1] - $c2[1] ) * ( 1 - $t * 0.6 ) ), (int) ( $c2[2] + ( $c1[2] - $c2[2] ) * ( 1 - $t * 0.6 ) ) );
			imagefilledellipse( $img, (int) $cx, (int) $cx, $r * 2, $r * 2, $col );
		}
		$rim = imagecolorallocate( $img, $c2[0], $c2[1], $c2[2] );
		imagesetthickness( $img, 10 );
		imageellipse( $img, (int) $cx, (int) $cx, 720, 720, $rim );
		imagesetthickness( $img, 3 );
		imageellipse( $img, (int) $cx, (int) $cx, 640, 640, $rim );
		$blue = imagecolorallocate( $img, 7, 6, 123 );
		$red  = imagecolorallocate( $img, 185, 12, 28 );
		$font = 5;
		$lines = explode( "\n", wordwrap( strtoupper( $label ), 18, "\n", true ) );
		$y     = (int) ( $cx - count( $lines ) * 18 );
		foreach ( $lines as $ln ) {
			$tw = imagefontwidth( $font ) * strlen( $ln );
			$tmp = imagecreatetruecolor( $tw + 4, 18 );
			imagesavealpha( $tmp, true );
			$tr = imagecolorallocatealpha( $tmp, 0, 0, 0, 127 );
			imagefill( $tmp, 0, 0, $tr );
			imagestring( $tmp, $font, 2, 1, $ln, 0 === $variant % 2 ? $blue : $red );
			imagecopyresampled( $img, $tmp, (int) ( $cx - ( $tw * 2.4 ) / 2 ), $y, 0, 0, (int) ( ( $tw + 4 ) * 2.4 ), 43, $tw + 4, 18 );
			imagedestroy( $tmp );
			$y += 46;
		}
		imagestring( $img, 3, (int) ( $cx - 60 ), 760, 'SILVER STACKER DEMO', $rim );
		$file = wp_tempnam( 'ssp-demo' ) . '.png';
		imagepng( $img, $file );
		imagedestroy( $img );
		return $file;
	}

	public static function product( array $d ) {
		$pid = Catalog::save_product( $d['p'] );
		foreach ( $d['v'] as $v ) {
			Catalog::save_variant( $pid, $v );
		}
		for ( $i = 0; $i < ( $d['images'] ?? 2 ); $i++ ) {
			$f = self::coin_image( 0 === $i ? $d['p']['name'] : ( 1 === $i ? 'Reverse' : 'Packaging' ), $d['p']['metal'], $i );
			Catalog::add_image( $pid, array( 'name' => 'demo-' . $i . '.png', 'tmp_name' => $f, 'error' => 0, 'size' => filesize( $f ), 'type' => 'image/png' ) );
			@unlink( $f );
		}
		if ( ! empty( $d['life'] ) ) {
			$r = Catalog::set_lifecycle( $pid, $d['life'] );
			if ( is_wp_error( $r ) && class_exists( 'WP_CLI' ) ) {
				\WP_CLI::warning( $d['p']['name'] . ': ' . $r->get_error_message() );
			}
		}
		return $pid;
	}

	public static function customer( $email, $name, $company, $status = 'approved' ) {
		$questions = Customers::questions();
		$answers   = array();
		foreach ( $questions as $q ) {
			$answers[ $q->id ] = 'yesno' === $q->answer_type ? 'Yes' : 'Yes, bought at the Dallas show last year.';
		}
		$addr = array( 'name' => $name, 'line1' => '100 Main St', 'city' => 'Austin', 'state' => 'TX', 'postal_code' => '78701', 'country' => 'US' );
		$uid  = Customers::register(
			array(
				'contact_name'     => $name,
				'email'            => $email,
				'phone'            => '512-555-0100',
				'company_name'     => $company,
				'password'         => 'DemoPass!2026',
				'password_confirm' => 'DemoPass!2026',
				'billing'          => $addr,
				'shipping_same'    => 1,
				'answers'          => $answers,
				'agree_individual' => 1,
			)
		);
		if ( is_wp_error( $uid ) ) {
			$u = get_user_by( 'email', $email );
			return $u ? $u->ID : 0;
		}
		if ( 'approved' === $status ) {
			Customers::set_status( $uid, 'approved', '', false );
		} elseif ( 'rejected' === $status ) {
			Customers::set_status( $uid, 'rejected', 'Demo rejection', false );
		}
		return $uid;
	}

	public static function run() {
		wp_set_current_user( 1 );
		$sup = Catalog::save_supplier( 'Rogues' );
		$sup2 = Catalog::save_supplier( '320 Coins' );
		$in = function ( $days, $hour = '23:59' ) {
			return wp_date( 'Y-m-d', time() + $days * DAY_IN_SECONDS, \SSP\Core\Util::business_tz() ) . 'T' . $hour;
		};
		$products = array(
			array( 'p' => array( 'name' => '2026 Canada Maple Leaf Stellar Guardian Edition 1 oz Silver Coin', 'metal' => 'Silver', 'brand' => 'Royal Canadian Mint', 'category' => 'Coins', 'mintage' => '5,000', 'description' => "<ul><li>1 oz .9999 fine silver</li><li>Colorized stellar guardian design</li><li>Comes in capsule</li><li>Only 5,000 mintage worldwide</li></ul>", 'closing_at' => $in( 3 ), 'eta_type' => 'month', 'eta_start' => wp_date( 'Y-m', time() + 50 * DAY_IN_SECONDS ), 'supplier_id' => $sup ), 'v' => array( array( 'sku' => 'MAPLE-STELLAR-26', 'barcode' => '062000123456', 'price_usd' => 135, 'total_allocation' => 40, 'per_customer_allocation' => 5, 'supplier_qty_ordered' => 40 ) ), 'life' => 'presale', 'images' => 3 ),
			array( 'p' => array( 'name' => '2026 Australia Brumby Horse 1 oz Silver Coin Colorized', 'metal' => 'Silver', 'brand' => 'Perth Mint', 'category' => 'Coins', 'mintage' => '3,000', 'description' => '<p>1 oz silver, colorized. Ships in display card.</p>', 'closing_at' => $in( 1, '18:00' ), 'eta_type' => 'range', 'eta_start' => wp_date( 'Y-m-d', time() + 45 * DAY_IN_SECONDS ), 'eta_end' => wp_date( 'Y-m-d', time() + 60 * DAY_IN_SECONDS ), 'supplier_id' => $sup ), 'v' => array( array( 'sku' => 'BRUMBY-COLOR-26', 'price_usd' => 119, 'total_allocation' => 10, 'per_customer_allocation' => 3 ) ), 'life' => 'presale' ),
			array( 'p' => array( 'name' => 'Samito Warrior 1 oz Copper', 'metal' => 'Copper', 'brand' => 'Silver Stacker Exclusive', 'category' => 'Rounds', 'mintage' => '3,000', 'description' => "<ul><li>1 oz .999 fine copper, colorized</li><li>Comes in capsule</li><li>We expect to have these in hand late October</li></ul>", 'closing_at' => $in( 6 ), 'eta_type' => 'text', 'eta_text' => 'Late October', 'supplier_id' => $sup2 ), 'v' => array( array( 'sku' => 'SAMITO-CU-1', 'price_usd' => 12, 'min_order_qty' => 2, 'total_allocation' => 500 ) ), 'life' => 'presale' ),
			array( 'p' => array( 'name' => 'Spot Based 1 oz Gold Eagle (Spot + $95)', 'metal' => 'Gold', 'brand' => 'US Mint', 'category' => 'Coins', 'description' => '<p>Spot-based offer. Final price = gold spot at time of invoicing + $95 premium.</p>', 'closing_at' => $in( 10 ), 'eta_type' => 'month', 'eta_start' => wp_date( 'Y-m', time() + 70 * DAY_IN_SECONDS ), 'price_type' => 'spot_based', 'spot_premium_usd' => 95 ), 'v' => array( array( 'sku' => 'AGE-1OZ-SPOT', 'price_usd' => 0.01, 'per_customer_allocation' => 10 ) ), 'life' => 'presale' ),
			array( 'p' => array( 'name' => '2026 Solomon Islands USA 250th Anniversary Stars and Stripes', 'metal' => 'Silver', 'brand' => 'PAMP', 'category' => 'Shaped coins', 'mintage' => '3,000', 'description' => "<ul><li>Minted by PAMP</li><li>Only 3000 pieces worldwide</li><li>Comes in display box with pop up display</li><li>IN STOCK AND READY TO SHIP</li><li>SHIPPING IS $9 FLAT OR ADD TO OPEN BOX</li></ul>", 'eta_type' => 'text', 'eta_text' => 'In hand' ), 'v' => array( array( 'label' => 'Standard', 'sku' => 'INSTOCKSTARSANDSTRIPES', 'price_usd' => 139, 'total_allocation' => 25 ), array( 'label' => 'Gilded', 'sku' => 'INSTOCKSTARS-GILD', 'price_usd' => 169, 'total_allocation' => 10 ) ), 'life' => 'in_stock', 'images' => 3 ),
			array( 'p' => array( 'name' => '1/10 oz Platinum Valkyrie', 'metal' => 'Platinum', 'brand' => 'Germania Mint', 'category' => 'Coins', 'mintage' => '1,500', 'closing_at' => $in( 14 ), 'eta_type' => 'date', 'eta_start' => wp_date( 'Y-m-d', time() + 90 * DAY_IN_SECONDS ) ), 'v' => array( array( 'sku' => 'VALK-PT-110', 'price_usd' => 129, 'per_customer_allocation' => 2, 'total_allocation' => 2 ) ), 'life' => 'presale' ),
			array( 'p' => array( 'name' => '2025 Lunar Dragon 2 oz Silver Coin', 'metal' => 'Silver', 'brand' => 'Perth Mint', 'category' => 'Coins', 'mintage' => '10,000', 'description' => '<p>Previously offered. Reference listing.</p>' ), 'v' => array( array( 'sku' => 'DRAGON-2OZ-25', 'price_usd' => 79 ) ), 'life' => 'in_stock' ),
		);
		$ids = array();
		foreach ( $products as $d ) {
			$ids[] = self::product( $d );
		}
		Catalog::set_lifecycle( end( $ids ), 'archived' );

		// Staff administrators. Replace the placeholder emails with real ones before go-live.
		foreach ( array( 'Cail', 'Eva', 'Ivan', 'Parker' ) as $ssp_admin ) {
			$ssp_login = strtolower( $ssp_admin );
			if ( ! get_user_by( 'login', $ssp_login ) ) {
				wp_insert_user(
					array(
						'user_login'   => $ssp_login,
						'user_email'   => $ssp_login . '@silverstacker.example',
						'user_pass'    => wp_generate_password( 20 ),
						'display_name' => $ssp_admin,
						'first_name'   => $ssp_admin,
						'role'         => 'administrator',
					)
				);
			}
		}
		// Sample customers (generic placeholders, no real names).
		$a = self::customer( 'customer1@example.com', 'Sample Customer 1', 'Sample Store 1' );
		$b = self::customer( 'customer2@example.com', 'Sample Customer 2', 'Sample Store 2' );
		self::customer( 'customer4@example.com', 'Sample Customer 4', 'Sample Store 4', 'pending' );
		self::customer( 'customer5@example.com', 'Sample Customer 5', 'Sample Store 5', 'rejected' );
		foreach ( array( $a, $b ) as $uid ) {
			Terms::accept( $uid, Terms::current()->id );
		}
		// Sample orders.
		$v1 = Catalog::variants( $ids[0] )[0];
		$v3 = Catalog::variants( $ids[2] )[0];
		$v5 = Catalog::variants( $ids[4] )[0];
		wp_set_current_user( $a );
		\SSP\Domain\Orders::place( $a, array( array( 'variant_id' => $v1->id, 'qty' => 2, 'fulfillment' => 'box' ), array( 'variant_id' => $v3->id, 'qty' => 10, 'fulfillment' => 'box' ) ), 'demo-seed-order-a-1', 'Please hold for my box' );
		\SSP\Domain\Orders::place( $a, array( array( 'variant_id' => $v5->id, 'qty' => 1, 'fulfillment' => 'box' ) ), 'demo-seed-order-a-2' );
		wp_set_current_user( $b );
		\SSP\Domain\Orders::place( $b, array( array( 'variant_id' => $v1->id, 'qty' => 3, 'fulfillment' => 'separate' ) ), 'demo-seed-order-b-1' );
		wp_set_current_user( 1 );
	}
}
