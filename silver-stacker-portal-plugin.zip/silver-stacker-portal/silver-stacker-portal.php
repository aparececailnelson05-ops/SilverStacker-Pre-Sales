<?php
/**
 * Plugin Name:       Silver Stacker Pre-Sale Portal
 * Description:       Private, approval-only pre-sale ordering portal for Silver Stacker LLC: accounts, private catalog, pre-orders, allocations, waitlists, Build A Box consolidation, shipments, QuickBooks Online invoicing, Google Sheets reporting and staff operations.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            Silver Stacker LLC
 * Text Domain:       ssp
 */

defined( 'ABSPATH' ) || exit;

define( 'SSP_VERSION', '1.0.0' );
define( 'SSP_DB_VERSION', '1.0.0' );
define( 'SSP_FILE', __FILE__ );
define( 'SSP_DIR', plugin_dir_path( __FILE__ ) );
define( 'SSP_URL', plugin_dir_url( __FILE__ ) );

spl_autoload_register(
	static function ( $class ) {
		if ( strpos( $class, 'SSP\\' ) !== 0 ) {
			return;
		}
		$rel  = str_replace( array( 'SSP\\', '\\' ), array( '', '/' ), $class );
		$file = SSP_DIR . 'includes/' . $rel . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

require_once SSP_DIR . 'includes/functions.php';

register_activation_hook( __FILE__, array( 'SSP\\Core\\Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'SSP\\Core\\Installer', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'SSP\\Plugin', 'boot' ) );
