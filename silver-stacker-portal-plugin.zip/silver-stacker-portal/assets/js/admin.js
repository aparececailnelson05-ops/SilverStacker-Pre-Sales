/* Silver Stacker staff console enhancements. */
(function () {
	'use strict';

	// Toggle hidden panels.
	document.addEventListener('click', function (e) {
		var t = e.target.closest('[data-toggle]');
		if (t) {
			var el = document.querySelector(t.getAttribute('data-toggle'));
			if (el) { el.hidden = !el.hidden; }
		}
	});

	// Two-step confirmation without blocking browser dialogs.
	document.addEventListener('click', function (e) {
		var b = e.target.closest('[data-confirm]');
		if (!b) { return; }
		if (b.getAttribute('data-armed') === '1') { return; }
		e.preventDefault();
		b.setAttribute('data-armed', '1');
		b.setAttribute('data-label', b.textContent);
		b.textContent = 'Click again to confirm';
		b.classList.add('is-armed');
		var note = document.createElement('span');
		note.className = 'ssa-confirm-note';
		note.textContent = b.getAttribute('data-confirm');
		b.parentNode.appendChild(note);
		setTimeout(function () {
			b.removeAttribute('data-armed');
			b.textContent = b.getAttribute('data-label');
			b.classList.remove('is-armed');
			if (note.parentNode) { note.parentNode.removeChild(note); }
		}, 5000);
	});

	// ETA fields: show only the inputs for the selected format.
	document.querySelectorAll('[data-eta]').forEach(function (wrap) {
		var sel = wrap.querySelector('[data-eta-type]');
		function sync() {
			wrap.querySelectorAll('[data-eta-show]').forEach(function (l) {
				l.hidden = l.getAttribute('data-eta-show') !== sel.value;
			});
		}
		sel.addEventListener('change', sync);
		sync();
	});

	// Default closing time when a date is picked.
	document.querySelectorAll('input[type=datetime-local][data-default-time]').forEach(function (i) {
		i.addEventListener('change', function () {
			if (/T00:00$/.test(i.value)) { i.value = i.value.replace('T00:00', 'T' + i.getAttribute('data-default-time')); }
		});
	});

	// Invoice wizard totals.
	var inv = document.querySelector('[data-invoice-form]');
	if (inv) {
		var all = inv.querySelector('[data-check-all]');
		function calc() {
			var sub = 0;
			inv.querySelectorAll('[data-line]').forEach(function (row) {
				var on = row.querySelector('input[type=checkbox]').checked;
				var q = parseFloat(row.querySelector('[data-qty]').value || '0');
				var p = parseFloat(row.querySelector('[data-price]').value || '0');
				var amt = on ? q * p : 0;
				row.querySelector('[data-amount]').textContent = on ? '$' + amt.toFixed(2) : '';
				row.classList.toggle('is-off', !on);
				sub += amt;
			});
			var ship = inv.querySelector('[data-ship]');
			sub += ship ? parseFloat(ship.value || '0') : 0;
			inv.querySelector('[data-subtotal]').textContent = '$' + sub.toFixed(2);
		}
		inv.addEventListener('input', calc);
		inv.addEventListener('change', calc);
		if (all) {
			all.addEventListener('change', function () {
				inv.querySelectorAll('[data-line] input[type=checkbox]').forEach(function (c) { c.checked = all.checked; });
				calc();
			});
		}
		var modes = inv.querySelectorAll('input[name=mode]');
		var manual = inv.querySelector('[data-manual]');
		function syncMode() {
			var m = inv.querySelector('input[name=mode]:checked');
			if (manual) { manual.hidden = !(m && m.value === 'manual'); }
		}
		modes.forEach(function (m) { m.addEventListener('change', syncMode); });
		syncMode();
		calc();
	}

	// Drag to reorder product images.
	document.querySelectorAll('[data-sortable]').forEach(function (list) {
		var dragging = null;
		var form = document.querySelector('[data-order-form]');
		list.addEventListener('dragstart', function (e) { dragging = e.target.closest('[draggable]'); if (dragging) { dragging.classList.add('is-dragging'); } });
		list.addEventListener('dragend', function () {
			if (dragging) { dragging.classList.remove('is-dragging'); }
			dragging = null;
			if (form) {
				var ids = Array.prototype.map.call(list.querySelectorAll('[data-id]'), function (f) { return f.getAttribute('data-id'); });
				form.querySelector('input[name=order]').value = ids.join(',');
			}
		});
		list.addEventListener('dragover', function (e) {
			e.preventDefault();
			var over = e.target.closest('[draggable]');
			if (!dragging || !over || over === dragging) { return; }
			var rect = over.getBoundingClientRect();
			var after = (e.clientX - rect.left) > rect.width / 2;
			list.insertBefore(dragging, after ? over.nextSibling : over);
		});
	});

	// Countdown display in admin.
	var cds = document.querySelectorAll('[data-countdown]');
	function tick() {
		cds.forEach(function (el) {
			var end = Date.parse(el.getAttribute('data-countdown'));
			var out = el.querySelector('[data-countdown-value]') || el;
			var d = Math.floor((end - Date.now()) / 1000);
			if (d <= 0) { out.textContent = 'Pre-Sale Ended'; el.classList.add('is-ended'); return; }
			var days = Math.floor(d / 86400), h = Math.floor(d % 86400 / 3600), m = Math.floor(d % 3600 / 60), s = d % 60;
			out.textContent = (days ? days + 'd ' : '') + ('0' + h).slice(-2) + ':' + ('0' + m).slice(-2) + ':' + ('0' + s).slice(-2);
		});
	}
	if (cds.length) { tick(); setInterval(tick, 1000); }
})();
