/* Silver Stacker Pre-Sale Portal: progressive enhancements (the site works without JS;
   all rules are enforced on the server). */
(function () {
	'use strict';
	document.documentElement.classList.add('js');

	var serverNow = parseInt(document.body.getAttribute('data-server-now') || '0', 10) * 1000;
	var skew = serverNow ? serverNow - Date.now() : 0;

	function pad(n) { return (n < 10 ? '0' : '') + n; }

	/* ---------- Countdowns ---------- */
	var countdowns = Array.prototype.slice.call(document.querySelectorAll('[data-countdown]'));
	function tick() {
		var now = Date.now() + skew;
		countdowns.forEach(function (el) {
			var end = Date.parse(el.getAttribute('data-countdown'));
			var out = el.querySelector('[data-countdown-value]') || el;
			var diff = Math.floor((end - now) / 1000);
			if (isNaN(end)) { return; }
			if (diff <= 0) {
				if (!el.classList.contains('is-ended')) {
					el.classList.add('is-ended');
					out.textContent = 'Pre-Sale Ended';
					var scope = el.closest('[data-orderable]');
					if (scope) {
						scope.querySelectorAll('[data-order-control]').forEach(function (c) {
							c.setAttribute('disabled', 'disabled');
							c.classList.add('is-disabled');
						});
						scope.querySelectorAll('[data-ended-msg]').forEach(function (m) { m.hidden = false; });
					}
				}
				return;
			}
			var d = Math.floor(diff / 86400);
			var h = Math.floor((diff % 86400) / 3600);
			var m = Math.floor((diff % 3600) / 60);
			var s = diff % 60;
			out.textContent = (d > 0 ? d + (d === 1 ? ' Day ' : ' Days ') : '') + pad(h) + ':' + pad(m) + ':' + pad(s);
		});
	}
	if (countdowns.length) { tick(); setInterval(tick, 1000); }

	/* ---------- Quantity steppers ---------- */
	document.addEventListener('click', function (e) {
		var b = e.target.closest('[data-qty-step]');
		if (!b) { return; }
		e.preventDefault();
		var input = b.parentNode.querySelector('input');
		var step = parseInt(b.getAttribute('data-qty-step'), 10);
		var min = parseInt(input.getAttribute('min') || '0', 10);
		var max = input.getAttribute('max') ? parseInt(input.getAttribute('max'), 10) : Infinity;
		var v = parseInt(input.value || '0', 10) + step;
		input.value = Math.max(min, Math.min(max, v));
		input.dispatchEvent(new Event('change', { bubbles: true }));
	});

	/* ---------- Gallery (swipe + arrows + dots + thumbs) ---------- */
	document.querySelectorAll('[data-gallery]').forEach(function (g) {
		var track = g.querySelector('.ssp-gallery__track');
		var slides = track ? track.children : [];
		var dots = g.querySelectorAll('.ssp-gallery__dots button');
		var thumbs = g.querySelectorAll('.ssp-gallery__thumbs button');
		var counter = g.querySelector('[data-gallery-count]');
		function idx() { return Math.round(track.scrollLeft / track.clientWidth); }
		function go(i) {
			i = Math.max(0, Math.min(slides.length - 1, i));
			track.scrollTo({ left: i * track.clientWidth, behavior: 'smooth' });
		}
		function sync() {
			var i = idx();
			dots.forEach(function (d, j) { d.classList.toggle('is-active', i === j); });
			thumbs.forEach(function (t, j) { t.classList.toggle('is-active', i === j); });
			if (counter) { counter.textContent = (i + 1) + ' / ' + slides.length; }
		}
		if (!track) { return; }
		track.addEventListener('scroll', function () { window.requestAnimationFrame(sync); }, { passive: true });
		g.querySelectorAll('[data-gallery-prev]').forEach(function (b) { b.addEventListener('click', function () { go(idx() - 1); }); });
		g.querySelectorAll('[data-gallery-next]').forEach(function (b) { b.addEventListener('click', function () { go(idx() + 1); }); });
		dots.forEach(function (d, j) { d.addEventListener('click', function () { go(j); }); });
		thumbs.forEach(function (t, j) { t.addEventListener('click', function () { go(j); }); });
		g.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowLeft') { go(idx() - 1); }
			if (e.key === 'ArrowRight') { go(idx() + 1); }
		});
		sync();
	});

	/* ---------- Confirmation dialogs (no browser alert/confirm) ---------- */
	document.addEventListener('click', function (e) {
		var opener = e.target.closest('[data-dialog-open]');
		if (opener) {
			var dlg = document.getElementById(opener.getAttribute('data-dialog-open'));
			if (dlg && dlg.showModal) { e.preventDefault(); dlg.showModal(); }
			return;
		}
		var closer = e.target.closest('[data-dialog-close]');
		if (closer) {
			var d = closer.closest('dialog');
			if (d) { e.preventDefault(); d.close(); }
		}
	});

	/* ---------- Registration wizard ---------- */
	var wizard = document.querySelector('.ssp-wizard');
	if (wizard) {
		var steps = wizard.querySelectorAll('[data-step]');
		var bars = document.querySelectorAll('.ssp-wizard__steps span');
		var current = 0;
		var firstError = wizard.getAttribute('data-start-step');
		if (firstError) { current = parseInt(firstError, 10) || 0; }
		function show(i) {
			steps.forEach(function (s, j) { s.classList.toggle('is-active', i === j); });
			bars.forEach(function (b, j) { b.classList.toggle('is-active', j <= i); });
			current = i;
			var h = steps[i].querySelector('h2, legend');
			if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
			window.scrollTo({ top: 0, behavior: 'smooth' });
		}
		function valid(i) {
			var ok = true;
			steps[i].querySelectorAll('input, select, textarea').forEach(function (f) {
				if (f.offsetParent !== null && !f.checkValidity()) { if (ok) { f.reportValidity(); } ok = false; }
			});
			var p1 = wizard.querySelector('[name=password]');
			var p2 = wizard.querySelector('[name=password_confirm]');
			if (ok && i === 0 && p1 && p2 && p1.value !== p2.value) {
				p2.setCustomValidity('Passwords do not match.');
				p2.reportValidity();
				p2.setCustomValidity('');
				ok = false;
			}
			return ok;
		}
		wizard.addEventListener('click', function (e) {
			if (e.target.closest('[data-next]')) { e.preventDefault(); if (valid(current)) { show(current + 1); } }
			if (e.target.closest('[data-prev]')) { e.preventDefault(); show(current - 1); }
		});
		show(current);
	}
	var same = document.querySelector('[name=shipping_same]');
	if (same) {
		var shipBlock = document.querySelector('[data-shipping-block]');
		function toggleShip() {
			shipBlock.hidden = same.checked;
			shipBlock.querySelectorAll('[data-req]').forEach(function (f) { f.required = !same.checked; });
		}
		same.addEventListener('change', toggleShip);
		toggleShip();
	}

	/* ---------- Auto-submit selects ---------- */
	document.querySelectorAll('[data-autosubmit]').forEach(function (s) {
		s.addEventListener('change', function () { s.form.submit(); });
	});

	/* ---------- Prevent double submit ---------- */
	document.querySelectorAll('form[data-once]').forEach(function (f) {
		f.addEventListener('submit', function () {
			f.querySelectorAll('button[type=submit]').forEach(function (b) { b.setAttribute('disabled', 'disabled'); b.textContent = 'Submitting...'; });
		});
	});

	/* ---------- Dismiss alerts ---------- */
	document.addEventListener('click', function (e) {
		var x = e.target.closest('[data-dismiss]');
		if (x) { x.closest('.ssp-alert').remove(); }
	});
})();
